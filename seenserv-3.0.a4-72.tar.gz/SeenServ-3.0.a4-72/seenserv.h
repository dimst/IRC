/* SeenServ - Nickname Seen Service - NeoStats Addon Module
** Copyright (c) 2003-2006 Justin Hammond, Mark Hetherington, Jeff Lang
**
**  This program is free software; you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation; either version 2 of the License, or
**  (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program; if not, write to the Free Software
**  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
**  USA
**
** SeenServ CVS Identification
** $Id: seenserv.h 66 2007-08-01 03:17:25Z Fish $
*/

#include MODULECONFIG

/* Defines */
typedef enum SEEN_CHECK
{
	SS_CHECK_WILDCARD,	/* WildCard Entry Check */
	SS_CHECK_NICK,		/* Nick Entry Check */
	SEEN_CHECK_TYPE_MAX,
} SEEN_CHECK;

typedef enum SEEN_TYPE
{
	SS_CONNECTED,		/* Seen Connection Type */
	SS_QUIT,		/* Seen Quit Type */
	SS_KILLED,		/* Seen Killed Type */
	SS_NICKCHANGE,		/* Seen Nick Change Type */
	SS_JOIN,		/* Seen Join Channel Type */
	SS_PART,		/* Seen Part Channel Type */
	SS_KICKED,		/* Seen Kicked Channel Type */
	SEEN_TYPE_MAX,
} SEEN_TYPE;

typedef enum SEEN_LISTLIMIT
{
	SS_LISTLIMIT_COUNT,	/* Check List Limit by Record Count */
	SS_LISTLIMIT_AGE,	/* Check List Limit by Record Age */
	SEEN_LISTLIMIT_MAX,
} SEEN_LISTLIMIT;

#define SS_MESSAGESIZE	300	/* Message Field Size */
#define SS_GENCHARLEN	128	/* General Character Field Length */

/* Variables And Structs */
Bot *sns_bot;

struct SeenServ {
	int exclusions;
	int enable;
	int enableseenchan;
	char seenchan[MAXCHANLEN];
	int maxentries;
	int eventsignon;
	int eventquit;
	int eventkill;
	int eventnick;
	int eventjoin;
	int eventpart;
	int eventkick;
	int expiretime;
	int dbupdatetime;
	int memorylist;
} SeenServ;

typedef struct SeenData {
	char nick[MAXNICK];
	char userhost[USERHOSTLEN];
	char uservhost[USERHOSTLEN];
	char message[SS_MESSAGESIZE];
	SEEN_TYPE seentype;
	time_t seentime;
	int recordsaved;
} SeenData;

/* this should be portable. See http://gcc.gnu.org/onlinedocs/gcc/Variadic-Macros.html 
 * and http://msdn2.microsoft.com/en-us/library/ms177415(VS.80).aspx and
 * http://en.wikipedia.org/wiki/Variadic_macro
 */
#define seen_report(X, Y, ...) \
	if (X->channel == NULL) irc_prefmsg (sns_bot, X->source, Y, ## __VA_ARGS__); \
	else irc_chanprivmsg (sns_bot, X->channel->name, Y, ## __VA_ARGS__)

typedef struct ExtraSeenChans {
	char name[MAXCHANLEN];
	Channel *c;
} ExtraSeenChans;

/* SeenServ Module Help - seenserv_help.c */
extern const char *sns_help_set_exclusions[];
extern const char *sns_help_set_enable[];
extern const char *sns_help_set_enableseenchan[];
extern const char *sns_help_set_seenchanname[];
extern const char *sns_help_set_maxentries[];
extern const char *sns_help_set_eventsignon[];
extern const char *sns_help_set_eventquit[];
extern const char *sns_help_set_eventkill[];
extern const char *sns_help_set_eventnick[];
extern const char *sns_help_set_eventjoin[];
extern const char *sns_help_set_eventpart[];
extern const char *sns_help_set_eventkick[];
extern const char *sns_help_set_expiretime[];
extern const char *sns_help_set_dbupdatetime[];
extern const char *sns_help_set_memorylist[];
extern const char *sns_help_seen[];
extern const char *sns_help_seennick[];
extern const char *sns_help_del[];
extern const char *sns_help_status[];
extern const char *sns_help_chan[];

/* events.c */
int SeenSignon (const CmdParams *cmdparams);
int SeenQuit (const CmdParams *cmdparams);
int SeenKill (const CmdParams *cmdparams);
int SeenNickChange (const CmdParams *cmdparams);
int SeenJoinChan (const CmdParams *cmdparams);
int SeenPartChan (const CmdParams *cmdparams);
int SeenKicked (const CmdParams *cmdparams);

/* seenserv.c */
int removeagedseenrecords(void *);
int sns_cmd_chan(const CmdParams *cmdparams);
int sns_sort_chanlist( const void *key1, const void *key2 );
int loadseenchanrecords(void *data, int size);
void createseenlist(void);
void loadseenchandata(void);
void destroyseenchanlist(void);
int SeenNewChan (const CmdParams *cmdparams);
int SeenDelChan (const CmdParams *cmdparams);


/* seen.c */
int removepreviousnick(char *nick);
void addseenentry(char *nick, char *host, char *vhost, char *message, int type);
int dbsavetimer(void *);
void checkseenlistlimit(int checktype);
void createseenlist(void);
void loadseendata(void);
int sortlistbytime(const void *key1, const void *key2);
void destroyseenlist(void);
#if 0
void seen_report( const CmdParams *cmdparams, const char *fmt, ... );
#endif
int sns_cmd_seenhost(const CmdParams *cmdparams);
int sns_cmd_seennick(const CmdParams *cmdparams);
int CheckSeenData(const CmdParams *cmdparams, SEEN_CHECK checktype);
int sns_cmd_del(const CmdParams *cmdparams);
int sns_cmd_status(const CmdParams *cmdparams);
