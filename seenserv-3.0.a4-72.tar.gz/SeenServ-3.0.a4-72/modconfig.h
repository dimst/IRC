/* modconfig.h.  Generated from modconfig.h.in by configure.  */
/* define this to enable debug code for this module */
#define DEBUG 1

/* Version number of package */
#define MODULE_VERSION "3.0.a4"

/* Major Version */
#define MODULE_MAJOR "3"

/* Minor Version */
#define MODULE_MINOR "0"

/* Revision */
#define MODULE_REV "a4"
