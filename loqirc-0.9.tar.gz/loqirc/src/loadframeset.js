	// load frameset, if this document is not loaded on a frame

	if(self.location == top.location) {
	  top.location="frameset.html";
	}
