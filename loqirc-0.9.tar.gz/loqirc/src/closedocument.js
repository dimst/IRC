
function closeFramesetDocument()
{
	for (var i = 0; ; i++) {
		var n;
		n = 0;
		for (var f = 0; f < self.frames.length; f++) {
			if (self.frames && self.frames[f] && self.frames[f].document) {
				if (self.frames[f].document.readyState != 'complete') {
					self.frames[f].document.writeln('</body></html>');
					n++;
				}
				self.frames[f].document.close();
			}
		}
		if (n == 0)
			break;
	}

	self.document.close();

	for (var i = 0; i < 100000; i++) {
	}
}
