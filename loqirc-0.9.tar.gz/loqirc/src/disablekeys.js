
// David Borland (daborland@mediaone.net)

function fncKeyStop()
{
	if (window.event.ctrlKey) {
		if (window.event.keyCode == 67 || window.event.keyCode == 86 || window.event.keyCode ==88) {
			//Do nothing if Contol x, c, v (copy functions)
		}
		else {
			event.keyCode = 0;
			event.returnValue = false;
		}
	}
	//Cancel F5 and F11
	if (window.event.keyCode == 122 || window.event.keyCode == 116) {
		window.event.keyCode = 0;
		event.returnValue = false;
	}

	/*
	if (window.event.altKey) {
		//Cancel right arrow, left arrow, and home key
		if (window.event.keyCode == 36 || window.event.keyCode == 39 || window.event.keyCode == 37) {
			//For some reason putting the alert in cancels the keystroke
			alert('Illegal keystroke');
			window.event.keyCode = 0;
			event.returnValue = false;
		}
	}
	*/
}

