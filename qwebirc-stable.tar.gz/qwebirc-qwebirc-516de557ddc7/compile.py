#!/usr/bin/env python
import bin.compile
bin.compile.main()
