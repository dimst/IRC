qwebirc.VERSION = "0.92"
