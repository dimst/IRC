<?php
// Brazilian Portuguese Language Structure
// $Id: index.php 353 2009-03-04 08:51:01Z hal9000 $

/* ensure this file is being included by a parent file */
defined( '_VALID_PARENT' ) or die( 'Direct Access to this location is not allowed.' );

$lang_ver = "1.3.0";					# Compatible phpDenora version
$lang_name = "Portugu�s Brasileiro";				# Language Name
$lang_flag = array("flag.png", 16, 11);	# Language Flag

?>
