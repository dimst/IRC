<?php
// Russian Language Structure
// $Id$

/* ensure this file is being included by a parent file */
defined( '_VALID_PARENT' ) or die( 'Direct Access to this location is not allowed.' );

$lang_ver = "1.3.0";					# Compatible phpDenora version
$lang_name = "Russian";					# Language Name
$lang_flag = array("flag.png", 16, 11);	# Language Flag

?>
