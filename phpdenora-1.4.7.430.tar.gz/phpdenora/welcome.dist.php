<?php
// $Id$

/** ensure this file is being included by a parent file */
defined( '_VALID_PARENT' ) or die( 'Direct Access to this location is not allowed.' );
?>

<div class="title">Welcome to phpDenora</div>
<p>These are the Web Stats of this IRC Network.<br />
You will find detailed information about the network status and the activity of its channels and users.<br />
Enjoy your stay!</p>
