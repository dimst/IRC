<?php
// Classic Theme Structure
// $Id$

/** ensure this file is being included by a parent file */
defined( '_VALID_PARENT' ) or die( 'Direct Access to this location is not allowed.' );

$theme_ver = "1.2.0";							# Compatible phpDenora version
$theme_name = "Dark Classic";						# Theme Name

?>
