<?php
// Next Theme Structure
// $Id$

/** ensure this file is being included by a parent file */
defined( '_VALID_PARENT' ) or die( 'Direct Access to this location is not allowed.' );

$theme_ver = "1.4.5";							# Compatible phpDenora version
$theme_name = "Next";							# Theme Name

?>
