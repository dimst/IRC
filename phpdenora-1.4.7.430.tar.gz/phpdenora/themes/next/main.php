<?php
// Next Theme Main Layout for phpDenora 1.4.5
// $Id$

/** ensure this file is being included by a parent file */
defined( '_VALID_PARENT' ) or die( 'Direct Access to this location is not allowed.' );
?>

<div id="pd_top">
  <div id="pd_header">
    <table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td valign="middle"><a href="<?php echo $pd_neturl ?>"><img src="themes/next/img/logo.png" alt="" id="logo" /></a></td>
        <td valign="middle"><table border="0" cellspacing="0" cellpadding="2">
            <tr align="center">
              <td class="topmenu"><a href="?m=h"><img src="themes/next/img/home.png" alt="" /><br />
                <?php echo _TM_HOME; ?></a></td>
              <td class="topmenu"><a href="?m=n"><img src="themes/next/img/network.png" alt="" /><br />
                <?php echo _TM_NETWORK; ?></a></td>
              <?php if ($pd_ennetgraphs == true || $pd_netsplit_graphs == true || $pd_searchirc_graphs == true) { ?>
              <td class="topmenu"><a href="?m=g"><img src="themes/next/img/graphs.png" alt="" /><br />
                <?php echo _TM_GRAPHS; ?></a></td>
              <?php } ?>
              <td class="topmenu"><a href="?m=c"><img src="themes/next/img/channels.png" alt="" /><br />
                <?php echo _TM_CHANS; ?></a></td>
              <td class="topmenu"><a href="?m=u"><img src="themes/next/img/users.png" alt="" /><br />
                <?php echo _TM_USERS; ?></a></td>
              <td class="topmenu"><a href="?m=s"><img src="themes/next/img/search.png" alt="" /><br />
                <?php echo _TM_SEARCH; ?></a></td>
              <td class="topmenu"><a href="?m=k"><img src="themes/next/img/config.png" alt="" /><br />
                <?php echo _TM_CONFIG; ?></a></td>
            </tr>
          </table></td>
      </tr>
    </table>
  </div>
</div>

<div id="pd_frame">
  <div id="pd_main">
<?php
if (in_array($mode, array('g', 'c', 'u'))) {
	$optmenu = null;
	echo "<div><ul id=\"submenu\">";
	foreach(getMenu($mode) as $item) {
		if ($item[0] == 0) {
			echo "<li class=\"level0\">".$item[1]."</li>";
		} elseif ($item[0] == 1) {
			if (end(explode("/", $_SERVER['REQUEST_URI'])) == $item[2]) {
				echo "<li class=\"level1 active\"><a href=\"".$item[2]."\">".$item[1]."</a></li>";
			} else {
				echo "<li class=\"level1\"><a href=\"".$item[2]."\">".$item[1]."</a></li>";
			}
		} elseif ($item[0] == 2) {
			if ($item[2]{0} != "#") {
				$optmenu .= "<li><a href=\"".$item[2]."\">".$item[1]."</a></li>";
			}
		}
	}
	echo "</ul></div>";
	
	echo "<div><ul id=\"optmenu\">";
	echo $optmenu;
	echo "</ul></div>";
}
include "pages/content.php";
?>
  </div>
</div>
<div id="pd_footer">
  <?php displayFooter(); ?>
</div>
