1. Edit denora.cfg.php
2. Use index.php as an example of the library