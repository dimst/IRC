<?php

$ircd = array('supports_hidden_ops' => 0,
			  'hidden_op_mode' => '',
		      'chanexception'  => 0,
              'chaninvites'    => 0,
			  'sqlinetable'    => 0,
			  'glinetable'     => 0,
			  'services_protection' => 0,
			  'services_protection_mode' => '',
			  'chanhide'       => 0,
			  'chanhide_mode'  => '',
			  'secretchan'     => 1,
			  'secretchan_mode' => 'mode_ls',
			  'privatechan'    => 1,
			  'privatechan_mode' => 'mode_lp');

?>