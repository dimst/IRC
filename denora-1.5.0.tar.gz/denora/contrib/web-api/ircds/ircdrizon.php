<?php

$ircd = array('supports_hidden_ops' => 0,
			  'hidden_op_mode' => '',
		      'chanexception'  => 1,
              'chaninvites'    => 0,
			  'sqlinetable'    => 1,
			  'glinetable'     => 0,
			  'services_protection' => 1,
			  'services_protection_mode' => 'mode_us',
			  'chanhide'       => 1,
			  'chanhide_mode'  => 'mode_lp',
			  'secretchan'     => 1,
			  'secretchan_mode' => 'mode_ls',
			  'privatechan'    => 0,
			  'privatechan_mode' => '');

?>