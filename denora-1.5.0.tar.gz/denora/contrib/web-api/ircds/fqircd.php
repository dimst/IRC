<?php

$ircd = array('supports_hidden_ops' => 1,
			  'hidden_op_mode' => 'mode_uh',
		      'chanexception'  => 1,
              'chaninvites'    => 1,
			  'sqlinetable'    => 1,
			  'glinetable'     => 0,
			  'services_protection' => 0,
			  'services_protection_mode' => '',
			  'chanhide'       => 0,
			  'chanhide_mode'  => '',
			  'secretchan'     => 1,
			  'secretchan_mode' => 'mode_ls',
			  'privatechan'    => 1,
			  'privatechan_mode' => 'mode_lp');

?>