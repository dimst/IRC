;<?php die(); ?>

server = localhost
user = user
pass = password
db = denora
tldtable = tld
maxdisplay = 10

