;<?php die(); ?>

server = localhost
user = denora
pass = password
db = denora

