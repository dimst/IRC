/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/key.h
 * (c) 2008 Murat Deligonul
 */
#ifndef __FS_KEY_H
#define __FS_KEY_H

#include "util/counted_object.h"
#include "fs/fwd.h"

class userdef;

namespace fs {

/**
 * Used by VFS to grant access and check file permissions.
 */
class flib_key : public util::counted_object<flib_key> {
private:
	friend class file_system;
	
	const credentials * const fs_creds;	// access credentials
	directory * cwd;          		// current working directory
	int fs_umask;				// file creation umask

private:
	flib_key(const credentials *, directory *);

public:
	static const int DEFAULT_UMASK	= 0002;
	
	~flib_key();

	const credentials * creds() const { 
		return fs_creds; 
	}
	directory * dir() const { 
		return cwd;
	}

	int umask() const {
		return	fs_umask;
	}
	void set_umask(int new_umask) {
		fs_umask = new_umask;
	}

        void set_dir(directory *);
	
private: 
	// non-copyable
	flib_key(const flib_key&);
	flib_key& operator = (const flib_key&);
};

} // namespace fs
#endif // __FS_KEY_H
