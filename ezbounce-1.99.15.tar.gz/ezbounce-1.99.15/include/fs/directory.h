/**
 * fs/directory.h
 * (c) 2006-2008 Murat Deligonul
 */

#ifndef __FS_DIRECTORY_H
#define __FS_DIRECTORY_H

#include <vector>
#include <deque>
#include <algorithm>
#include <ostream>
#include <ctime>
#include <sys/types.h>
#include "util/hash.h"
#include "util/tracked_object.h"
#include "util/counted_object.h"
#include "fs/entry.h"

namespace fs {

/**
 * Represents a directory in the VFS.
 */
class directory : 
#ifdef __DEBUG__
	public util::tracked_object<directory> {
#else
	public util::counted_object<directory> {
#endif
public:
	/**
	 * Normal C-string hasher with case-sensitive key comparison.
	 */
	typedef util::hash_table<const char *, file_entry *, 
					util::default_hasher<const char *>,
					util::fixed_cstring_predicate<strcmp> >	hash_table_t;

private:
	char * dbfile;			// cached, full path to database file
	char * a_path;			// absolute path to this directory (i.e. on disk)
	const char * r_path;		// relative path to this directory (i.e. starting from VFS root)
	const char * _name;		// name of this directory
	file_entry * _entry;		// file entry

	int fd;				// file descriptor of open database file
	bool batch_mode;		// whether we are executing multiple operations in one access.

	time_t last_mod;		// when database file was last modified, according to our records
	off_t  last_size;		// last known size of the database file	

	hash_table_t			file_cache;
	std::vector<directory *>	children;

	static const char DB_FILE_NAME[];
	static const unsigned short  DB_VERSION;
	
	static const int CACHE_BUCKETS = 7;

private:
	// Found at the beginning of the dbfile.
	struct dbfile_header {
		char 		hstring[10];
		time_t 		timestamp;
		unsigned short 	version;
	};

	// Found at the beginning of an entry in the database file.
	// Note that lengths include 1 byte for the null character, but currently
	// nothing is written (i.e. the field will be zero) if that particular string is empty.
	struct entry_header {
		time_t 		creation;		// Time of creation
		unsigned short  padding_length;		// Whether there is any padding at the end of the entry.
		unsigned short  mode;			// UNIX-style permissions -- note; previously 'reserved0'
		unsigned int 	flags;			// Flags (Directory, Secret, etc)
		unsigned int    reserved1;		// Reserved for future use
		unsigned short  owner_length;		// Owner / Group (stored in same block, separated with ':')
		unsigned short  from_length;		// Where source file was obtained from
		unsigned short  misc_length;		// Misc information (currently unused)
		unsigned short  desc_length;		// Description
		unsigned short  name_length;		// Name of the file
	};

	// Represents raw data of a file entry in the database file.
	// Includes location in the file, its header, and dynamic string data. 
	struct raw_entry {
		off_t  offset;
		char 	* string_data;
		struct entry_header header;		
	};

	/**
	 * Size limits and minimum requirements for entries and entry components.
	 * The lengths for string data include byte for a terminating '\0'.
	 */
	static const size_t MAX_ENTRY_SIZE = 1 << 16;

	static const unsigned short MAX_NAME_LEN = 256;
	static const unsigned short MAX_OWNER_LEN = 256;
	static const unsigned short MAX_FROM_LEN = 2048;
	static const unsigned short MAX_DESC_LEN = 8192;
	static const unsigned short MAX_MISC_LEN = 16384;
	static const unsigned short MAX_PADDING_LEN = MAX_ENTRY_SIZE - sizeof(entry_header);

	static const unsigned short MIN_NAME_LEN = 2;
	static const unsigned short MIN_OWNER_LEN = 4;
	static const unsigned short MIN_FROM_LEN = 0;
	static const unsigned short MIN_DESC_LEN = 0;
	static const unsigned short MIN_MISC_LEN = 0;
	static const unsigned short MIN_PADDING_LEN = 0;

public: 	
	directory(directory *, file_entry *);
	directory(const char *, const char *, const char *);
	~directory();

public:
	const char * abs_path() const  { return a_path; }
	const char * rel_path() const { return r_path; }
	const char * name() const  { return _name; }
	const char * owner() const { return _entry->owner(); }
	int flags() const { return _entry->flags(); }
	file_entry * entry() const { return _entry; }
	directory * parent() const { return _entry->dir(); }

	void inc_count() { _entry->inc_count(); }
	void dec_count() { _entry->dec_count(); }
	unsigned int usage_count() const { return _entry->usage_count(); }
	
	int batch_start();
	int batch_end();

	int create();
	int destroy();
	bool exists() const;
	int validate();
	int is_empty();
	
	file_entry * disk_lookup(const char *, int *);
	int write(const file_entry *, bool = false);
	int unlink(const char *, bool);
	int ls(const char *, std::vector<entry_data>&);

	template<typename Cont> void level_order_traverse(Cont&);

#ifdef __DEBUG__
	int dump(int);
#endif	

	enum {
		ERR_BASE             = -300,
		ERR_ILLEGAL_NAME     = -300,
		ERR_BUSY             = -304,
		ERR_FAILURE          = -305,			
		ERR_DB_CORRUPTION    = -306,
		ERR_DB_VERSION       = -307,
		ERR_DB_OPEN          = -308,
		ERR_DB_EXISTS        = -309,
		ERR_DB_DESTROY       = -310,
		ERR_BAD_WRITE        = -311,
		ERR_MAX              = -311
	};

	static const char * strerror(int);
	static bool is_legal_name(const char *);

public:
	/** 
	  * simple cache to keep track of file_entry objects created
	  */
	file_entry * cache_lookup(const char * name) const {	
		hash_table_t::const_iterator i = file_cache.find(name);
		return (i == file_cache.end()) ? NULL : (*i).second;
	}
	
	void cache_insert(file_entry * f) { 
		file_cache.insert(f->name(), f); 
	}

	void cache_remove(const char * name) {
		file_cache.erase(name);
	}

	int cache_num_open() const;
	int cache_prune();
	
private:
	/** implementation **/
	enum lookup_options {
		MATCH_LITERAL		= 0x0001,
		MATCH_WILDCARD		= 0x0002
	};

	void add_child(directory *);
	void remove_child(directory *);

	int opendb();
	int closedb();
	int read_header(dbfile_header *);
	int write_header(time_t);

	int find_free_entry(unsigned int, struct raw_entry *);
	int free_entry(off_t);
	int write_entry(const struct raw_entry *);
	int locate_entry(const char *, struct raw_entry *, int);

	static void  fill_file_entry(const raw_entry *, file_entry *);
	static size_t fill_header(const file_entry *, entry_header *);
	static size_t fill_dynamic(const file_entry *, char *);

	static int validate_header(const entry_header *);
	static int validate_dynamic(const entry_header *, const char *);

	/**
	 * Calculate the size on disk of the dynamic data portion of 
	 * an entry.  Does not include padding.
	 */
	static size_t calc_dynlen(const entry_header * h) {
		return (h->owner_length + h->from_length + 
			h->misc_length  + h->desc_length +
  					  h->name_length); 
	}

	/**
	 * Calculate the size on disk a complete entry will occupy.
	 * This includes the header, dynamic data, and padding.
	 */
	static size_t calc_entry_len(const entry_header * h) {
		return sizeof(entry_header) + h->padding_length + 
				calc_dynlen(h);
	}
	
private:	
	// non-copyable
	directory(const directory &);
	directory& operator=(const directory&);
};

/**
 * Return a level-order traversal of the active directory 
 * objects, starting from this one.
 */
template<typename Cont> void directory::level_order_traverse(Cont& out)
{
	std::deque<directory *> queue;
	queue.push_back(this);

	while (!queue.empty()) {
		directory * d = queue.front();
		out.push_back(d);

		std::copy(d->children.begin(), d->children.end(), std::back_inserter(queue));
		queue.pop_front();
	}
}

#ifdef __DEBUG__
/**
 * Assist with pretty printing of directory lists.
 */
inline std::ostream& operator << (std::ostream& out, const directory * d)
{
	out << "directory: '" << d->rel_path() << "'";
	return out;
}	
#endif

} // namespace fs
#endif
