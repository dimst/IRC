/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/utility.h -- VFS utilities.
 * (c) 2008 Murat Deligonul
 */
#ifndef __FS_UTILITY_H
#define __FS_UTILITY_H

#include <vector>
#include <iosfwd>
#include "fs/fwd.h"

namespace fs {

	int translate_chmod_str(const flib_key *, const entry_data *, const char *);
	void translate_file_mode(const entry_data *, char *);

	void print_ls(const std::vector<entry_data>&, const char * = "\n");
	void print_full_ls(const std::vector<entry_data>&, std::ostream&, const char * = "\n");

}
#endif
