/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/credentials.h -- VFS access credentials.
 * (c) 2008 Murat Deligonul
 */
#ifndef __FS_CREDENTIALS_H
#define __FS_CREDENTIALS_H

#include <string>
#include <vector>
#include "util/counted_object.h"
#include "util/generic.h"

namespace fs {

class credentials : public util::counted_object<credentials> {
private:
	const std::string 			_user;			// user id
	std::vector<std::string>		groups;			// groups
	int					_flags;

public:
	/**
	 * Available flags.
	 */
	enum flag {
		SUPER_USER	= 1,
	};

	/**
	 * Construct credentials for user with initial group.
	 */
	credentials(const char * u, const char * g) :
			_user(u), 
			_flags(0) {
		assert(!_user.empty());
		groups.push_back(g);
	}

	/**
	 * Get user id and groups.
	 */
	const char * user() const {
		return _user.c_str();
	}
	const char * group() const {
		return groups[0].c_str();
	}
	const char * group(unsigned i) const {
		assert(i < groups.size());
		return groups[i].c_str();
	}

	/** 
	 * Flag access.
	 */
	int flags() const {
		return _flags;
	}
	void set_flag(flag f) {
		_flags |= f;
	}
	void clear_flag(flag f) {
		_flags &= ~f;
	}
	void clear_flags() {
		_flags = 0;
	}

	/**
	 * Group access.
	 */
	bool has_group(const char * group) const {
		return util::contains(groups, group);
	}
	void add_group(const char *);
	void remove_group(const char *);
};

} // namespace fs
#endif // __FS_CREDENTIALS_H
