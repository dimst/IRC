/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/file_system.h -- VFS main interface.
 * (c) 2003-2008 Murat Deligonul
 */
#ifndef __FS_FILE_SYSTEM_H
#define __FS_FILE_SYSTEM_H

#include <vector>
#include <cstring>
#include <sys/param.h>
#include "util/hash.h"
#include "fs/fwd.h"
#include "fs/entry_data.h"
#include "fs/exceptions.h"

namespace fs {

class resolved_path;

class file_system {
private:
	typedef util::hash_table<const char *, directory *, 
			util::default_hasher<const char *>,
		       	util::fixed_cstring_predicate<strcmp> > hash_table_t;

	hash_table_t directories;
	directory * root;
	credentials * root_creds;
	flib_key * root_key;

public:
	file_system(const char *);
	~file_system();
		
	flib_key * create_key(const credentials *, int *);
	int prune_cache();
	
	/** 'system' calls **/
	file_entry * open(const flib_key *, const char *, int, mode_t, int *);
	file_entry * import(const flib_key *, const char *);	
	int save(const flib_key *, file_entry *);
	int close(file_entry *);
	int stat(const flib_key *, const char *, entry_data&);
	
	int unlink(const flib_key *, const char *);	
	int access(const flib_key *, const char *, int);
		
	int chdir(flib_key *, const char *);
	int rmdir(const flib_key *, const char *);
	directory * mkdir(const flib_key *, const char *, mode_t, int *);
	directory * mkdirs(const flib_key *, const char *, mode_t, int *);

	int rename(const flib_key *, const char *, const char *);
	int chmod(const flib_key *, const char *, mode_t);

	int ls(const flib_key *, const char *, std::vector<entry_data>&);

private:
	/** implementation **/
	friend class resolved_path;

	int resolve_path(const flib_key *, const char *, resolved_path *);
	int access(const flib_key *, file_entry *, int);
	int access_entry_only(const flib_key *, file_entry *, int);
	directory * load_directory(const flib_key *, directory *, const char *, int *);

	bool can_delete(const flib_key * key, const file_entry * entry) const;
	
	static int normalize_path(const flib_key * , const char *, char *);	

private:
	// non-copyable
	file_system& operator=(const file_system&);
	file_system(const file_system&);
};

class resolved_path {
private:
	char resolved[PATH_MAX+1];
	char * name_ptr;
	directory * _dir;
	file_entry * _entry;

public:
	char * buffer() { 
		return resolved; 
	}
	directory * dir() const { 
		return _dir; 
	}
	file_entry * cached_entry() const {
		return _entry;
	}

	const char * full_path() const { 
		return resolved; 
	}
	const char * name() const { 
		return name_ptr; 
	}

	resolved_path() : 
		name_ptr(NULL), _dir(NULL), _entry(NULL) {
		resolved[0] = 0;
		name_ptr = &resolved[0];
	}

	friend int file_system::resolve_path(const flib_key *, const char *, resolved_path *);

private:
	// non-copyable
	resolved_path(const resolved_path&);
	resolved_path& operator= (const resolved_path&);
};

} // namespace fs 
#endif
