/**
 * fs/entry_data.h
 * Part of ezbounce
 */
#ifndef __FS_ENTRY_DATA_H
#define __FS_ENTRY_DATA_H

#include <string>
#include "util/managed_table.h"

namespace fs {

enum entry_flag {
	FE_CHAT_LOG			= 0x0002,		/* chat log */
	FE_OBSOLETE_WORLD_READABLE 	= 0x0004,		/* (no longer used) readable by all */
	FE_OBSOLETE_WORLD_WRITEABLE 	= 0x0008,		/* (no longer used) writeable by all */
	FE_DIRECTORY			= 0x0020,		/* is actually a directory */
	FE_EMPTY_ENTRY			= 0x0040,		/* entry refers to empty space; only used on disk */
	FE_PRIVATE			= 0x0080,		/* accessable by only the owner */
};


/**
 * Provides index number to access entry's string data.
 */
enum entry_string {
	OWNER 	= 0,		/* User it belongs to */
	GROUP,			/* Group it belongs to */
	FROM,			/* Where it originated from */
	MISC,			/* Misc. information about the entry (currently unused) */
	DESC,			/* Customizable description */	
	NAME,			/* Name of the file */	
	MAX_STRING
};


struct entry_data {
	util::array<std::string, MAX_STRING>		strings;
	time_t          				creation;	/* Creation time. */
	unsigned int					flags;		/* File status flags. */
	unsigned short					mode;		/* File "permissions. */
	off_t		    				size;		/* NOTE: size is not stored in database; used only for ls */
};


/**
  * Function objects for STL sorting algorithms.
  */

/** 
 * Normal sort: Alphabetical order, but directories come first. 
 */
class sort_normal {
public:
	bool operator()(const entry_data &f1, const entry_data &f2) const {
		const bool dir1 = f1.flags & FE_DIRECTORY;
		const bool dir2 = f2.flags & FE_DIRECTORY;
		if (dir1 && !dir2) {
			return true; 
		} 
		else if (!dir1 && dir2) {
			return false;
		} 
		return f1.strings[NAME].compare(f2.strings[NAME]) < 0;
	}
};

} // namespace fs
#endif // __FS_ENTRY_DATA_H
