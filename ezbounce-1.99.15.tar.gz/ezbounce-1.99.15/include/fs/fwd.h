/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/fwd.h
 * (c) 2008 Murat Deligonul
 */
#ifndef __FS_FWD_H
#define __FS_FWD_H

namespace fs {

	class credentials;
	class directory;
	class entry_data;
	class file_entry;
	class file_system;
	class flib_key;

} // namespace fs
#endif // __FS_FWD_H
