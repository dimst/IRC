/**
 * fs/entry.h
 * Part of ezbounce
 */
#ifndef __FS_ENTRY_H
#define __FS_ENTRY_H

#include <ostream>
#include <sys/stat.h>
#include "util/counted_object.h"
#include "util/tracked_object.h"
#include "fs/fwd.h"
#include "fs/entry_data.h"
#include "io/chain.h"
#include "debug.h"

namespace fs {

class file_entry : 
#ifdef __DEBUG__
	public util::tracked_object<file_entry> {
#else
	public util::counted_object<file_entry> {
#endif
public:
	// types
	typedef io::output_chain	writer_t;
	typedef io::input_chain		reader_t;

	// construction
	explicit file_entry(directory *);
	file_entry(directory *, const char *, const char *, const char *);
#ifdef __DEBUG__
	~file_entry() {
		DEBUG("%s: [%p] destructed '%s'\n", __PRETTY_FUNCTION__, this, name());
	}
#endif
	
private:
	// data
	struct 	entry_data		data;			/* Basic data */
	directory * 			_dir;			/* Directory owning this entry */
	unsigned int			_usage_count;		/* References to this entry */
	writer_t *			fwriter;		/* Currently active writer */
	
public:
	// access
	const entry_data * 	raw_data() const { return &data; }
	
	const char * 	misc() const { return data.strings[MISC].c_str(); }
	const char * 	owner() const { return data.strings[OWNER].c_str(); }
	const char * 	group() const { return data.strings[GROUP].c_str(); }
	const char * 	from() const { return data.strings[FROM].c_str(); }
	const char * 	desc() const { return data.strings[DESC].c_str(); }
	const char * 	name() const { return data.strings[NAME].c_str(); }

	unsigned int 	flags() const { return data.flags; }
	unsigned short	mode() const { return data.mode; }
	off_t    	size() const { return data.size; }
	time_t		creation() const { return data.creation; }	
	directory * 	dir() const { return _dir; }
	unsigned int    usage_count() const { return _usage_count; }
	bool  		is_writing() const { return fwriter != NULL; }
	writer_t * 	writer() const { return fwriter; }

	void  set_owner(const char * val) { data.strings[OWNER] = val; }
	void  set_group(const char * val) { data.strings[GROUP] = val; }
	void  set_desc(const char * val) { data.strings[DESC] = val; }
	void  set_from(const char * val) { data.strings[FROM] = val; }
	void  set_name(const char * val) { data.strings[NAME] = val; }
	void  set_misc(const char * val) { data.strings[MISC] = val; }

	void  set_flags(unsigned int f) { data.flags = f; }
	void  set_mode(unsigned short m) { data.mode = m; }
	void  set_creation(time_t t) { data.creation = t; }
	void  set_size(off_t s) { data.size = s; }

	void  inc_count() {
		DEBUG("file_entry::inc_count(): ['%s' increased to %d]\n", name(), _usage_count+1);
		++_usage_count; 
	}
	void  dec_count() {
		assert(_usage_count > 0);
		DEBUG("file_entry::dec_count(): ['%s' decreased to %d]\n", name(), _usage_count-1);
		--_usage_count; 
	}

	/**
	 * Open and close readers and writers.
	 */
	reader_t * open_reader(reader_t::openmode);
	writer_t * open_writer(writer_t::openmode);
	void close(reader_t *);
	void close(writer_t *);

	void update_size();

	/** 
	 * Error codes.
	 */
	enum {
		ERR_BASE=-100,
		ERR_LOCKED=-101,
		ERR_OPEN=-102,
		ERR_MAX=-103
	};

	static const char * strerror(int err);

private:
	// file_entry objects are non-copyable
	file_entry(const file_entry &);
	file_entry& operator= (const file_entry &);
};

#ifdef __DEBUG__
/**
 * Assist with pretty printing of file entry object lists.
 */
inline std::ostream& operator << (std::ostream& out, const file_entry * f)
{
	out << f->name() << '@' << (void *) f->dir();
	return out;
}
#endif

} // namespace fs
#endif

