/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/error.h
 * (c) 2008 Murat Deligonul
 */
#ifndef __FS_ERROR_H
#define __FS_ERROR_H

namespace fs {

	/** 
	 * Error codes
	 */
	enum {
		ERR_BASE	  = -200,
		ERR_BADFILE 	  = -200,
		ERR_CREATION 	  = -201,
		ERR_PRIVATE_FILE  = -202,
		ERR_NOT_PERMITTED = -203,
		ERR_DIRECTORY     = -206,
		ERR_NOT_DIRECTORY = -207,
		ERR_BUSY 	  = -208,
		ERR_FAILURE       = -209,
		ERR_OPEN_FILES    = -210,
		ERR_RMDIR_FAILURE = -211,
		ERR_MKDIR_FAILURE = -212,
		ERR_SYMLINK       = -213,
		ERR_ACCESS        = -214,
		ERR_EXISTS	  = -215,
		ERR_DOESNT_EXIST  = -216,
		ERR_EXISTS_ON_DISK= -217,
		ERR_CONFIG	  = -218,
		ERR_BAD_KEY       = -219,
		ERR_NO_VFS	  = -220,
		ERR_IO_READ	  = -221,
		ERR_IO_WRITE	  = -222,
	        ERR_MAX		  = -222
	};

	const char * strerror(int);

} // namespace fs
#endif // __FS_ERROR_H
