/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 * conn.h
 * (c) 1998-2008 Murat Deligonul
 */

#ifndef __CONN_H
#define __CONN_H

#include <string>
#include <vector>
#include <queue>
#include <functional>
#include "util/hash.h"
#include "util/timer.h"
#include "util/idgenerator.h"
#include "util/managed_table.h"
#include "util/tracked_object.h"
#include "util/expirable_object.h"
#include "config/user_perms.h"
#include "config/ezb_dependencies.h"
#include "io/filters.h"
#include "irc/fwd.h"
#include "irc/channel.h"
#include "irc/event.h"
#include "irc/server_entry.h"
#include "irc/server_info.h"
#include "fs/fwd.h"
#include "logging/fwd.h"
#include "net/socket_binder.h"
#include "net/resolver.h"
#include "dccfwd.h"
#include "user.h"
#include "rfunc.h"
#include "authorizer.h"

// more forward decls.
class ircproxy;
class reconnect_info;
class textline;
struct cmd;

#ifndef DECLARE_CMDFUNC
#define DECLARE_CMDFUNC(f) int do_##f##_cmd(int, const textline&)
#endif

#ifndef CMDFUNC
#define CMDFUNC(f) int conn::do_##f##_cmd(int type, const textline& args)
#endif

/* Object state flags */
enum {
	ZOMBIE			=	      0,
	REGISTERING		= 	    0x2,	/* Brand new connection */
	NICKED			=	    0x8,	/* NICK command issued */
	USERED			=	   0x10,	/* USER command issued */
	LOGGED_IN		=	   0x20,	/* Successfully logged in */
	CONNECTING		=	   0x40,	/* Connecting to IRC server */	
	RECONNECTING		= 	   0x80,	/* Attempting to reconnect to IRC and rejoin channels */
	BOUNCED                 =    	  0x100,	/* Connected to IRC */
	DETACHED		=  	  0x200,	/* Client is detached */
	ADMIN			=	  0x400,	/* User was granted admin privileges */
	NDM			= 	0x10000, 	/* No Direct Match (when connected) */
	PPE			= 	0x40000, 	/* Pong, Ping, Error */

	REGISTERED		= 	(NICKED | USERED | LOGGED_IN)
};

class conn : public util::tracked_object<conn>, public util::expirable_object<conn> {
public:
	enum event {		
		KILLED = 1,
		IRC_DISCONNECT,
		CLIENT_DISCONNECT,
		IRC_CONNECT,
		CLIENT_CONNECT,
		DETACH,
		REATTACH,
		CHANNEL_JOIN,
		CHANNEL_PART
	};
public:
	explicit conn(net::socket *);

#ifndef GCC_NO_MEMBER_TEMPLATE_FRIENDS
protected:
#endif	
	~conn();
	template<typename Pred> friend void util::tracked_object<conn>::delete_if(Pred);

public:
	/* expirable_object<T> interface requirements */
	int  status_check(time_t, const void **) const;
	int  die(int, const void *);

private:
	/** resolver callback functions **/
	int async_lookup_finished(const net::resolver::result *);
	int async_lookup_failed(const net::resolver::result *);

	enum ezb_string {
		FULLADDR = 0,			/* Full address of the client */
		USERCMD,			/* USER command given when client connected */
		SERVER,				/* Target server in CONN command */
		IRCPASS,
		NUM_STRINGS,
	};

private:
	static ircproxy * proxy;
	
	/* Traffic stats */
	static unsigned bytes_fromc,
			bytes_toc,
			bytes_froms,
			bytes_tos;
	
	static util::id_generator idgen;
	
	std::vector<rfunc *>   		rfuncs;				/* restartable procedure queue */	
	std::queue<std::string>		cqueue;				/* outgoing command queue */
	util::managed_table<std::string, NUM_STRINGS>	
					strings;			/* store various string options */

	/* Handles callback from resolver */
	const net::resolver_callback_wrapper<conn, 
				&conn::async_lookup_finished, 
				&conn::async_lookup_failed> 	r_callback;
	
	const unsigned int _id;
	int stat;
	
	/* IRC information tracking */
	irc::address * 			irc;          		/* Store IRC nickname, username, and host */
	irc::address_cache * 		acache;        		/* Address cache */
	irc::server_info * 		servinfo;  		/* Server attributes and capabilities */
	irc::ignore_list *		ignores;		/* Ignore List */
	irc::flood_protector * 		floodp;			/* Flood Protection */
	
	/* User configuration */
	authorizer 			auth;			
	fs::flib_key *			key;	  		/* VFS access key */
	
	time_t connect_time,					/* When user connected */
		last_recved,					/* When last message received */
		detach_time,					/* When user detached */
		reattach_time;					/* When user reattached */
	
	int 				lookup_id;		/* id of current async. lookup */
	logging::chatlog * 		chan_log;		/* chat logging facilities */
	logging::chatlog * 		priv_log;
	util::timer * 			qtimer;
	util::timer * 			dtimer; 
	util::timer * 			rtimer;

	/* Stores data during IRC server reconnection */
	reconnect_info * 		rinfo;

	union {
		unsigned short failed_passwords;
		unsigned short num_dccs;	
	};
public:
	unsigned int id() const { 
		return _id; 
	}
	userdef * user()  const {
		return auth.get_user(); 
	}
	const char * addr() const {
		return strings.get(FULLADDR).c_str();
	}

	unsigned short inc_dcc_count() { 
		return ++num_dccs;  
	}
	unsigned short dec_dcc_count() {
		return --num_dccs;  
	}
	unsigned short dcc_count() const { 
		return num_dccs;    
	}
	
	char * mkstat(char *) const;
	int  cprintf(const char *, ...) const;
	int  cprintf_multiline(const char *) const;
	void  regulate_io_events();
	void  print_all_logs(const char *);
	void prune_caches();
	void options_updated(const config::hash_entry *);

	static void set_proxy_instance(ircproxy *);
	static conn * lookup(unsigned int);
	static conn * lookup(const char *);

private:
	int  parse();
	int  parse_from_server();
	void  queue_command(const char * format, ...);
	void  process_restartable();
	
	void update_client_address();
	
	int  detach();
	int  do_auto_detach();
	int  reattach(conn *);
	int  validate_reattach(conn *, bool) const;
	
	int  handle_dcc(bool incoming, const irc::address *, const char * target, 
			const char * dcc_type, const char * args);
	int  handle_ctcp(const irc::address *, const char *, const char *);

	void  greet_client();
	void  greet_login();
	int  authorize_client();	
	int  setup_connect(const char *, unsigned short, const char * , bool);
	int  authorize_connect();
	void  setup_fake_ident();
	void  start_connect();

	void show_part_all() const;
	void show_motd() const;
	void show_whois(conn *c) const;

	/**
	 * Timer callbacks.
	 */
	int  throttle_timer_proc(const util::timer::generic_timer_data *);
	int  detached_timer_proc(const util::timer::generic_timer_data *);
	int  reconnect_timer_proc(const util::timer::generic_timer_data *);

private: 	
	/**
	 * Network events
	 */
	int  on_server_readable();
	int  on_server_writeable();
	void  on_server_connect();
	void  on_server_disconnect(int);
	void  on_server_connect_fail(int);
	void  on_server_connecting();

	int  on_client_readable();
	int  on_client_writeable();
	void  on_client_disconnect(int);

	void  client_lost();
	void  server_lost();
	void  dummy_callback();
	void  dummy_callback1(int);

	typedef	net::socket_binder<conn,
					&conn::on_server_readable,
					&conn::on_server_writeable,
					&conn::on_server_connect,
					&conn::on_server_disconnect,
					&conn::on_server_connect_fail,
					&conn::on_server_connecting>			server_sock;
	
	typedef	net::socket_binder<conn,
					&conn::on_client_readable,
					&conn::on_client_writeable,
					&conn::dummy_callback,
					&conn::on_client_disconnect,
					&conn::dummy_callback1,
					&conn::dummy_callback>				client_sock;

	server_sock * server;
	client_sock * client;

private:
	/**
	  * User config settings and capabilities
	  */
	bool is_allowed(config::traits<user_perms, bool>::identifier_t option) {
		if (is_admin()) {
			return true;
		}
		return user()->config()->get<bool>(option);
	}	

	template<typename T> int decide(const config::target_list& targets, 
			typename config::traits<typename T::config_type, bool>::identifier_t val) const	{
		return ::decide_helper<T>(*user()->options(), targets, val, *user()->config());
	}

	const config::target_list& get_server_target() const {
		return (servinfo != NULL) ? servinfo->server_target() : irc::server_info::default_server_target();
	}

	const config::target_list& get_default_channel_target() const {
		return (servinfo != NULL) ? servinfo->default_channel_target() : irc::channel::default_channel_target();
	}

private:
	/** 
	 * The command handlers
	 */
	typedef util::hash_table<const char *, const cmd *, 
				util::default_hasher<const char *>, 
				util::fixed_cstring_predicate<strcasecmp> > hash_table_t;

	typedef util::hash_table<const char *, const char *,
				util::default_hasher<const char *>,
				util::fixed_cstring_predicate<strcasecmp > > help_hash_table_t;

	static hash_table_t 		cmdhash;
      	static hash_table_t 		incoming_hash;
	static help_hash_table_t 	help_table;
	static const char		*extra_help_entries[];
	static const struct cmd * lookup_command(hash_table_t &, const char *, int);

public:
	static void   init_command_hash();
	static void   init_help_system();
	
	DECLARE_CMDFUNC(registration);
	DECLARE_CMDFUNC(pass);
	DECLARE_CMDFUNC(conn);
	DECLARE_CMDFUNC(cancel);
	DECLARE_CMDFUNC(ident);
	DECLARE_CMDFUNC(help);
	DECLARE_CMDFUNC(ezb);
	DECLARE_CMDFUNC(vhost);
	DECLARE_CMDFUNC(vhosts);
	DECLARE_CMDFUNC(detach);
	DECLARE_CMDFUNC(reattach);
	DECLARE_CMDFUNC(disconnect);
	DECLARE_CMDFUNC(log);
	DECLARE_CMDFUNC(quit);
	DECLARE_CMDFUNC(motd);
	DECLARE_CMDFUNC(status);
	DECLARE_CMDFUNC(rehash);
	DECLARE_CMDFUNC(write);
	DECLARE_CMDFUNC(die);
	DECLARE_CMDFUNC(kill);
	DECLARE_CMDFUNC(hash);
	DECLARE_CMDFUNC(privmsg);
	DECLARE_CMDFUNC(notice);
	DECLARE_CMDFUNC(login);
	DECLARE_CMDFUNC(sessions);
	DECLARE_CMDFUNC(traffic);
	DECLARE_CMDFUNC(whois);
	DECLARE_CMDFUNC(set);
	DECLARE_CMDFUNC(get);
	DECLARE_CMDFUNC(unset);
	DECLARE_CMDFUNC(isset);
	DECLARE_CMDFUNC(prefs);
	DECLARE_CMDFUNC(options);
	DECLARE_CMDFUNC(save);
	DECLARE_CMDFUNC(echo);
	DECLARE_CMDFUNC(trace);
	DECLARE_CMDFUNC(allowed);
	DECLARE_CMDFUNC(reload);
	DECLARE_CMDFUNC(about);
	DECLARE_CMDFUNC(version);
	DECLARE_CMDFUNC(file);
	DECLARE_CMDFUNC(dcc);
	DECLARE_CMDFUNC(who);
	DECLARE_CMDFUNC(mode);
	DECLARE_CMDFUNC(acache);
	DECLARE_CMDFUNC(servinfo);
	DECLARE_CMDFUNC(chaninfo);
	DECLARE_CMDFUNC(protoctl);
	DECLARE_CMDFUNC(cap);

#ifdef __DEBUG__
	DECLARE_CMDFUNC(reconnect);
	DECLARE_CMDFUNC(debug);
	DECLARE_CMDFUNC(zombify);
#endif
	
	/* incoming traps */
	DECLARE_CMDFUNC(001_incoming);
	DECLARE_CMDFUNC(servinfo_incoming);
	DECLARE_CMDFUNC(privmsg_incoming);
	DECLARE_CMDFUNC(nick_incoming);
	DECLARE_CMDFUNC(mode_incoming);
	DECLARE_CMDFUNC(join_incoming);
	DECLARE_CMDFUNC(part_incoming);
	DECLARE_CMDFUNC(kick_incoming);
	DECLARE_CMDFUNC(notice_incoming);
	DECLARE_CMDFUNC(topic_incoming);
	DECLARE_CMDFUNC(topic_info_incoming);
	DECLARE_CMDFUNC(quit_incoming);
	DECLARE_CMDFUNC(pong_incoming);
	DECLARE_CMDFUNC(ping_incoming);
	DECLARE_CMDFUNC(error_incoming);
	DECLARE_CMDFUNC(names_incoming);
	DECLARE_CMDFUNC(who_incoming);
	DECLARE_CMDFUNC(nick_failed_incoming);
	DECLARE_CMDFUNC(join_failed_incoming);

private:
	/** dcc management **/
	void   disown_dccs(conn *) const;
	dccsend * dcc_send_file(fs::file_entry * fe, const char * whom, const char * = 0, bool = false);
	dccpipe * proxy_dcc_offer(dcc_offer * offer, std::string&);
	dccget  * receive_dcc_offer(dcc_offer * offer, std::string&);
	int  relay_dcc_offer(dcc_offer *, const char * whom, std::string&);
	void setup_dcc_filters(const char *, const fs::file_entry *, io::filter_list&) const;

	/** log management **/
	int setup_irc_logs(event);
	int stop_irc_logs(const char *);
	int setup_channel_log(irc::channel *, event);
	int stop_channel_log(irc::channel *, const char *);
	void setup_log_filters(io::filter_list&) const;
	void setup_log_filters(irc::channel *, io::filter_list&) const;

	int log_irc_event(irc::event, const irc::address *, const char *, const char *, const char *);
	int log_irc_event(irc::event, const irc::address *, irc::channel *, const char *, const char *);

	/** IRC server reconnection **/
	void start_reconnect();
	void abort_reconnect();
	void finish_reconnect();
	irc::server_entry get_next_reconnect_server() const;

	/** anti idle timer **/
	void setup_anti_idle();
	void stop_anti_idle();

	/** other **/
	template<typename T, typename V> void dump_options(const char *);

	int checkf(int flag) const {
		return (stat & flag);
	}
	void clearf(int flag) {
		stat &= ~flag;
	}
	void setf(int flag) {
		stat |= flag;
	}

public:
	bool is_registered() const { 
		return checkf(REGISTERED) == REGISTERED; 
	}
	bool is_logged_in() const {
		return checkf(LOGGED_IN);
	}
	bool is_admin() const {
		return checkf(ADMIN);
	}
	bool is_detached() const {
		return checkf(DETACHED);
	}
	bool is_reconnecting() const {
		return checkf(RECONNECTING);
	}
	bool is_dead() const { 
		return (stat == 0);
	}
	bool is_connecting() const {
		return checkf(CONNECTING);
	}
	bool is_bounced() const {
		return checkf(BOUNCED);
	}

	bool ignoring_input() const {
		return !rfuncs.empty();
	}
	
	bool recently_reattached() const;

public:	
	// functor to help with id matching
	class id_match_helper {
		unsigned int id;
	public:
		id_match_helper(unsigned int i) : id(i) {}
		bool operator() (const conn * c) const { 
			return (c->id() == id);
		}
	};

private:
	// non-copyable
	conn(const conn &);
	conn& operator=(const conn&);
};
#endif
