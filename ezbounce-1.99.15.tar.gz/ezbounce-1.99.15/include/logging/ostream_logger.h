/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/ostream_logger.h
 * (c) 2007 Murat Deligonul
 **/
 
#ifndef __LOGGING_OSTREAM_LOGGER_H
#define __LOGGING_OSTREAM_LOGGER_H

#include <iosfwd>
#include <stdexcept>
#include "logging/logger.h"

namespace logging {

/**
 * A logger that outputs to a std::ostream.
 */
class ostream_logger : public virtual logger 
{
public:
	typedef	std::ostream		stream_t;

private:
	stream_t * 			stream;

public:
	/**
	 * Normal constructor: assign handle and stream; logger
	 * ready for use.
	 */
	ostream_logger(const handle_t& handle, stream_t * s) :
		logger(handle), stream(s) { }

	virtual ~ostream_logger() { }

protected:
	/**
	 * Special constructor for derived classes: assign stream later 
	 * for more controlled creation.
	 */
	explicit ostream_logger(const handle_t& handle) : 
		logger(handle), stream(NULL) { }

	/**
	 * Assign the stream, but allow the operation only once.
	 */
	void set_stream(stream_t * s) {
		if (stream != NULL) {
			throw std::logic_error("stream has already been assigned");
		}
		stream = s;
	}

public:
	/**
	 * Public interface.
	 */
	stream_t * get_stream() const {
		return stream;
	}

protected:
	virtual void 	flush();
	virtual ssize_t write(const char *, size_t);
	virtual ssize_t writev(const std::vector<sl_pair>&);

private:
	// non-copyable
	ostream_logger(const ostream_logger&);
	ostream_logger& operator=(const ostream_logger&);
};

} /* namespace logging */
#endif  /* __LOGGING_OSTREAM_LOGGER_H */

