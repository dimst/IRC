/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/filtered_logger.h
 * (c) 2007 Murat Deligonul
 **/
 
#ifndef __LOGGING_FILTERED_LOGGER_H
#define __LOGGING_FILTERED_LOGGER_H

#include "util/exception.h"
#include "logging/logger.h"
#include "io/filters.h"

namespace logging {

/**
 * A logger that supports filtering.  Has a type parameter to specify chain type.
 * Currently designed to be used with io::output_chain objects.
 */
template<typename T> class filtered_logger : public virtual logger {
public:
	typedef	T		chain_t;

private:
	chain_t	*		chain;

protected:
	/**
	 * Constructor: set handle only; allow for more controlled setting of
	 * chain pointer later.
	 */
	explicit filtered_logger(const handle_t& handle) : 
		logger(handle), chain(NULL) { }
	
	virtual ~filtered_logger() { }


protected:
	/**
	 * Assign the chain, setup the filters, and complete the chain.
	 * Allow the operation only once.
	 */
	void set_chain(chain_t * s, const io::filter_list& filters) {
		if (chain != NULL) {
			throw std::logic_error("chain has already been assigned");
		}
		io::attach_filters(*s, filters);
		complete(s);
		
		// Everything should be good if we got this far ...
		chain = s;
	}

	chain_t * get_chain() const {
		return chain;
	}

	virtual void flush();
	virtual void complete(chain_t *) = 0;

private:
	/* Forbidden operations */
	filtered_logger(const filtered_logger&);
	filtered_logger& operator = (const filtered_logger&);
};

template<typename T> void filtered_logger<T>::flush() 
{
	get_chain()->flush();
}

} /* namespace logging */
#endif	/* LOGGING_FILTERED_LOGGER_H */

