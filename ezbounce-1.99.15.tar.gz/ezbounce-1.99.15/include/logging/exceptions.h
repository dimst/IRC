/**
 * logging/exceptions.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __LOGGING_EXCEPTIONS_H
#define __LOGGING_EXCEPTIONS_H

#include "util/exception.h"

namespace logging {

	struct logging_exception_tag {};

	typedef util::exception<logging_exception_tag> 	logging_exception;

}
#endif /* __LOGGING_EXCEPTIONS_H */
