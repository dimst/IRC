/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/chatlog.h
 * (c) 2007-2008 Murat Deligonul
 **/
 
#ifndef __LOGGING_CHATLOG_H
#define __LOGGING_CHATLOG_H

#include "logging/logger.h"
#include "logging/vfs_logfile.h"
#include "io/filter_types.h"
#include "irc/fwd.h"
#include "irc/event.h"
#include "fs/fwd.h"


namespace logging {

/**
 * An IRC chat log (which will reside in the VFS).
 */
class chatlog : public vfs_logfile {
public:
	/**
	 * Type of the log 
	 */
	enum log_type {
		LOG_PRIVATE,
		LOG_CHANNEL,
		LOG_PUBLIC = LOG_CHANNEL
	};

	/**
	 * Logging options.
	 */
	enum log_option {
		LOG_FULL_ADDRS = (logging::LAST_OPTION << 1)
	};

private:
	const log_type		type;		/* Type of the log (private or channel) */

public:
	chatlog(const handle_t&, const std::string&, fs::flib_key *, log_type, int, const io::filter_list&); 

	virtual ~chatlog();

//	virtual void set_options(int);

	int  write(irc::event, const irc::address *, const char *, const char *, const char *);

protected:
	virtual void start_message(std::string&) const;
	virtual void stop_message(std::string&) const;

private:
	static void strip_color_codes(const char *, char **);

private:
	// non-copyable
	chatlog(const chatlog&);
	chatlog& operator=(const chatlog&);
};

} /* namespace logging */
#endif	/* LOGGING_CHATLOG_H */

