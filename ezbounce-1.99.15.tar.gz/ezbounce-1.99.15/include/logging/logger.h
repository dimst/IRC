/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/logger.h
 * (c) 2007-2008 Murat Deligonul
 **/
 
#ifndef __LOGGING_LOGGER_H
#define __LOGGING_LOGGER_H

#include <string>
#include <vector>
#include <utility>
#include <stdexcept>
#include <ctime>
#include <cstdarg>
#include "util/counted_object.h"
#include "util/exception.h"
#include "logging/levels.h"
#include "logging/options.h"

namespace logging {

/**
 * Abstract logging facility.
 *
 * NOTES:
 * 	A logger must be ready for logging as soon as it is constructed.  Exceptions 
 * 	should be thrown to indicate failed construction.  Logging should be possible 
 * 	until the destruction of the logger object.  The interface provides no functions
 * 	to manually start or stop logging.
 *
 * 	Derived classes should follow this design.
 */
class logger : public util::counted_object<logger>
{
public:
	typedef	std::string		handle_t;

	/**
	 * Represents a single log message.
	 */
	struct message {
		time_t 			time;			/* Time of message */
		enum level		level;			/* Logging level */
		int			options;		/* Special options (set to -1 for default) */

		const char *		header;			/* Optional header before message */
		const char *		message;		/* Log message body */
	};

	/**
	 * Stores pointer to char and number of bytes to copy from it.
	 */
	typedef std::pair<const char *, size_t>		sl_pair;
	
private:
	/**
	 * Default settings.
	 */
	static const level		DEFAULT_LEVEL = NORMAL;
	static const int		DEFAULT_OPTIONS = LOG_HANDLE | LOG_TIMESTAMP;

	static const time_t *		time_ptr;
	
private:
	const handle_t			handle;
	level				log_level;
	int				options;

public:
	/**
	 * This must first be called to initialize the logging system.
	 */
	static void initialize(const time_t *);

	logger(const handle_t& name, level lev = DEFAULT_LEVEL, int opt = DEFAULT_OPTIONS) : 
		handle(name), log_level(lev), options(opt) { }
	virtual ~logger() { }


	const handle_t& get_handle() const {
		return handle;
	}

	int get_options() const {
		return options;
	}

	// just an alias
	const char * identifier() const {
		return handle.c_str();
	}

	level	get_level() const {
		return log_level;
	}

	void set_level(level l) {
		log_level = l;
	}

	/**
	 * Check if logging is enabled at this level.
	 */
	bool is_loggable(level lev) const {
		return lev != NONE && log_level >= lev;
	}

	/**
	 * Printing functions.
	 */
	int 	printf(level, const char *, ...);
	int	printf(const char *, ...);
	int	vprintf(level, const char *, va_list);
	
	int 	mark_timestamp();

	virtual void set_options(int);
	
protected:
	/**
	 * Fill a message struct with basic default values.
	 */
	static void init_message(message *, level = NORMAL, int options = -1);
	static const char * strlevel(level);

	int	mark_start();
	int	mark_stop();

	/**
	 * Write a single message to the log, taking care of all
	 * prefixes, formatting, and newline issues.
	 */
	ssize_t		write_message(const message *);

	/**
	 * Virtual functions required for implementation.
	 */
	virtual void    flush() = 0;
	virtual ssize_t write(const char *, size_t) = 0;
	virtual ssize_t writev(const std::vector<sl_pair>&);

	virtual void	start_message(std::string&) const;
	virtual void	stop_message(std::string&) const;

private:
	// non-copyable
	logger(const logger&);
	logger& operator=(const logger&);
};

} /* namespace logging */
#endif	/* LOGGING_LOGGER_H */

