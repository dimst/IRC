/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/options.h
 * (c) 2007-2008 Murat Deligonul
 **/
 
#ifndef __LOGGING_OPTIONS_H
#define __LOGGING_OPTIONS_H

namespace logging {

	/**
	 * Display options.  Controls what gets written
	 */
	enum option {
		LOG_LEVEL		= 1,			/* Print the logging level. */
		LOG_HANDLE		= (1 << 1),		/* Logger handle */
		LOG_TIMESTAMP		= (1 << 2),		/* Log basic timestamp */
		LOG_FULL_TIMESTAMP	= (1 << 3),		/* Log complete timestamp */
		ALWAYS_FLUSH		= (1 << 4),		/* Flush after each write */
		LAST_OPTION		= ALWAYS_FLUSH 
	};
}

#endif
