/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/fwd.h
 * (c) 2007-2008 Murat Deligonul
 **/

#ifndef __LOGGING_FWD_H
#define __LOGGING_FWD_H

/**
 * This file just contains forward declarations.
 */
namespace logging {
	template <typename T> class filtered_logger;
	class ostream_logger;
	class vfs_logfile;
	class chatlog;
	class logger;
}
#endif
