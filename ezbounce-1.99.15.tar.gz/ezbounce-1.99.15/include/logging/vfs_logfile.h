/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/vfs_logfile.h
 * (c) 2007-2008 Murat Deligonul
 **/
 
#ifndef __LOGGING_VFS_LOGFILE_H
#define __LOGGING_VFS_LOGFILE_H

#include <string>
#include "logging/ostream_logger.h"
#include "logging/filtered_logger.h"
#include "util/exception.h"
#include "fs/fwd.h"
#include "fs/entry.h"
#include "io/filter_types.h"

namespace logging {

/**
 * A logfile that exists within the ezbounce VFS.
 */
class vfs_logfile : public filtered_logger<fs::file_entry::writer_t>, public ostream_logger {
private:
	using filtered_logger<fs::file_entry::writer_t>::chain_t;	

	fs::file_entry * 	 	entry;

public:
	/**
	 * Normal constructor: set all parameters now, ready to log upon 
	 * completion.  If the constructor succeeds, it takes over the fs::file_entry
	 * resource and automatically closes it (and its writer) upon destruction.
	 *
	 * If the constructor fails, an exception is thrown, with the fs::file_entry resource
	 * being returned to the state it was received in.
	 */
	vfs_logfile(const handle_t& handle, fs::file_entry * e, const io::filter_list& filters) :
		logger(handle), 
		filtered_logger<chain_t>(handle), ostream_logger(handle),
		entry(NULL) {
			set_entry(e, filters);
		}

	virtual ~vfs_logfile();
	virtual void flush();

	std::string filename() const;

protected:
	/**
	 * Special constructor for derived classes: assign entry later
	 * for more controlled construction.
	 */
	explicit vfs_logfile(const handle_t& handle) :
		logger(handle),
		filtered_logger<chain_t>(handle), ostream_logger(handle),
		entry(NULL) { }

	void  set_entry(fs::file_entry *, const io::filter_list&);
	
	virtual void complete(chain_t *);

	static int sanity_check_filters(const io::filter_list&, std::string&);
	static int validate_directory(const std::string&, fs::flib_key *, std::string&);

public:
	static fs::file_entry * create_file_entry(const std::string&, fs::flib_key *, 
						const io::filter_list&, bool, std::string&);
private:
	// non-copyable
	vfs_logfile(const vfs_logfile&);
	vfs_logfile& operator=(const vfs_logfile&);
};

} /* namespace logging */
#endif	/* LOGGING_VFS_LOGFILE_H */

