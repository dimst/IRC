/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/basic_logfile.h
 * (c) 2007 Murat Deligonul
 **/
 
#ifndef __LOGGING_BASIC_LOGFILE_H
#define __LOGGING_BASIC_LOGFILE_H

#include "logging/filtered_logfile.h"
#include "util/exception.h"

namespace logging {

/**
 * A basic, fully functional logfile that supports filtering.
 */
class basic_logfile : public filtered_logfile
{
private:
};

} /* namespace logging */
#endif	/* LOGGING_BASIC_LOGFILE_H */

