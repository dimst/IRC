/**
  * debug.h
  * (c) 2007 Murat Deligonul
  */
#ifndef __DEBUG_H
#define __DEBUG_H

#if defined(__DEBUG__) || defined(ENABLE_DEBUG_LOGGING)
#	include <cstdio>
#	define DEBUG(format, args...) fprintf (stderr, format, ## args)
#else
#	ifndef NDEBUG
#   		define NDEBUG   /* to disable assert() */
#	endif
#	define DEBUG(format, args...)
#endif

#define MARK fprintf(stderr, "%s: %s: %d: marked\n", __FILE__, __PRETTY_FUNCTION__, __LINE__)

#include <cassert>

#endif
