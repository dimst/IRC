/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * dcc.h -- Part of the ezbounce IRC proxy
 * (C) 1999-2008 Murat Deligonul
 */

#ifndef __DCC_H
#define __DCC_H

#include <string>
#include <ctime>
#include <sys/types.h>
#include "util/exception.h"
#include "util/idgenerator.h"
#include "util/tracked_object.h"
#include "util/expirable_object.h"
#include "io/filter_types.h"
#include "fs/entry.h"
#include "dcc_socket.h"

class conn;
class dcc_offer;

struct dcc_exception_tag {};
typedef util::exception<dcc_exception_tag> dcc_exception;


int  lookup_dcc_by_id(conn *, unsigned int,  dcc ** , dcc_offer **);	
void swap_dcc_ids(dcc *, dcc_offer *);
    
/**
 * Base class for DCC objects.
 */
class dcc : public util::tracked_object<dcc>, public util::expirable_object<dcc> {
protected:
	enum dcc_stat {
		DCC_CLOSED    		= 0,
		DCC_NEW,
		DCC_LISTENING,
		DCC_ACCEPTED,
		DCC_CONNECTING,
		DCC_CONNECTED,
		DCC_FINISHED
	};
	
	enum sock_event {
		SOCK_READABLE  = 2,
		SOCK_WRITEABLE  = 4,
		SOCK_CONNECTED = 8,
		SOCK_CLOSED    = 16
	};
	
	enum dcc_sock_role {
		LISTENER,
		SENDER,
		RECEIVER
	};

private:
	static util::id_generator idgen;
	const time_t start;
	time_t timestamp;
	conn * _owner;

	dcc_stat stat;
	unsigned int _id;

public:
	enum dcc_event {
		DCC_EVENT_SUCCESS = 0,
		DCC_SESSION_CLOSED = 1,
		DCC_PIPE_ESTABLISHED,
		DCC_PIPE_CLOSED,
		DCC_PIPE_FAILED,
		DCC_SEND_ESTABLISHED,
		DCC_SEND_COMPLETE,
		DCC_SEND_FAILED,
		DCC_GET_ESTABLISHED,
		DCC_GET_COMPLETE,
		DCC_GET_FAILED,
		DCC_TIMED_OUT,
		DCC_ERROR,
		DCC_CONNECTION_ACCEPTED,
		DCC_USER_KILL,
		DCC_EVENT_MAX
	};

	explicit dcc(conn *);
	virtual ~dcc();
	
	/** 
	 * Accessors 
	 */
	conn * owner() const { 
		return _owner; 
	}
	unsigned int id() const { 
		return _id; 
	}
	dcc_stat status() const { 
		return stat; 
	}

	time_t last_event() const { 
		return timestamp; 
	}
	time_t start_time() const { 
		return start; 
	}
	time_t age(time_t now) const { 
		return now - start; 
	}
	
	virtual std::string info() const = 0;
	virtual std::string full_info() const;
	virtual const char * type() const = 0;
	
	/**
	 * expirable_object<T> interface
	 */
	virtual int  status_check(time_t, const void ** = NULL) const = 0 ;
	virtual int  die(int, const void *);

	int     announce_dcc_event(dcc_event , const char * = "" );
	void    set_owner(conn * c);
	
	static const char * strevent(dcc_event);
	static const char * strstat(dcc_stat);

protected:
	void  set_status(dcc_stat s) {
		stat = s;
	}
	void  set_last_event(time_t t) {
		timestamp = t;
	}

	virtual int socket_event(int s, int events, int extra) = 0;
	friend class dcc_socket;
	friend class dcc_offer;
	friend void swap_dcc_ids(dcc *, dcc_offer *);

private:
	// non-copyable
	dcc(const dcc &);
	dcc& operator=(const dcc&);
};

/**
 * A DCC object with a socket that listens.
 */
class dcc_with_listener : public dcc {
protected:
	dcc_socket * listener;
	virtual int  socket_event(int, int, int) = 0;

public:
	dcc_with_listener(conn *, const net::ap_pair&);
	virtual ~dcc_with_listener();

	virtual std::string info() const;
	virtual std::string full_info() const;
	virtual const char * type() const = 0;
	
	virtual int status_check(time_t, const void ** = NULL) const;
	virtual int  die(int, const void *);

	unsigned short port() { return listener->local_port(); }
	const char * addr() { return listener->local_addr(); }
	int sock_family() { return listener->get_family(); }

private:
	// non-copyable
	dcc_with_listener(const dcc_with_listener &);
	dcc_with_listener & operator = (const dcc_with_listener &);
};

/**
 * Used to send files over a DCC connection
 */
class dccsend : public dcc_with_listener {
private:
	/**
	 * Packet size for sending files.
	 */
	static const unsigned PACKET_SIZE = 4096;

	dcc_socket * 			receiver;	
	fs::file_entry * 		file;
	fs::file_entry::reader_t * 	reader;
	off_t 				sent;
	off_t				ack;

	io::filter_list			filters;
	
	int queue_next_packet();	
		
public:
	dccsend(conn *, fs::file_entry *, const io::filter_list&, off_t, const net::ap_pair&); 
	virtual ~dccsend();
	virtual int  status_check(time_t, const void ** = NULL) const;
	virtual int  die(int, const void *);

	virtual std::string info() const;
	virtual std::string full_info() const;
	virtual const char * type() const;

protected:
	virtual int  socket_event(int, int, int);

private:
	// non-copyable
	dccsend(const dccsend&);
	dccsend& operator = (const dccsend&);
};


/**
 * Used to proxy DCC connections.
 */
class dccpipe : public dcc_with_listener {
private:
	dcc_socket * sender;
	dcc_socket * receiver;

	net::ap_pair s_address;		// info about the sender
    
public:
	dccpipe(conn *, const net::ap_pair&, const net::ap_pair&);
	~dccpipe();
	virtual std::string info() const;
	virtual std::string full_info() const;
	virtual const char * type() const;

	virtual int status_check(time_t, const void ** = NULL) const;
	virtual int die(int, const void *);

protected:
	virtual int socket_event(int, int, int);

private:
	// non-copyable
	dccpipe(const dccpipe&);
	dccpipe& operator = (const dccpipe&);
};

/**
 * Incoming DCC file transfers.
 */
class dccget : public dcc {
private:
	dcc_socket * 			sender;
	unsigned int 			expected;
	unsigned int 			received;
	fs::file_entry * 	 	file;
	fs::file_entry::writer_t *  	writer;

	io::filter_list			filters;

public:
	dccget(conn * owner, fs::file_entry *, dcc_offer *);
	virtual ~dccget();
	virtual std::string info() const;
	virtual std::string full_info() const;
	virtual const char * type() const;

	/**
	 * expirable_object<T> interface
	 */
	virtual int status_check(time_t, const void ** = NULL) const;
	virtual int die(int, const void *);

protected:
	virtual int socket_event(int, int, int);

private:
	// non-copyable
	dccget(const dccget &);
	dccget& operator=(const dccget &);
};

#endif	/* __DCC_H */
