/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *************************************************************************** 
 * net/radaptor.h
 *
 * Allows resolver to be used with the IO engines.
 * (c) 2005-2007 Murat Deligonul
 */
 
#ifndef __NET_RADAPTOR_H
#define __NET_RADAPTOR_H
 
#include "net/resolver.h"
#include "io/engine.h"
#include "io/event.h"
#include "io/pollable.h"

namespace net {

class radaptor : public io::pollable
{
private:
	resolver& r;
	io::engine& e;

public:
	radaptor(resolver &_r, io::engine &_e) : r(_r), e(_e) { 
		set_fd(r.fifo_reader_fd());
		e.add(this, io::EVENT_READ);
	}

	~radaptor() { 
		e.release(this);
       	}

	/* 'pollable' interface */
	virtual int event_callback(int) { 
		r.process_results(); 
		return 0; 
	}
};

} /* namespace net */
#endif 	/* __NET_RESOLVER_H */

