/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * net/socket_binder.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __NET_SOCKET_BINDER_H
#define __NET_SOCKET_BINDER_H

#include "net/socket.h"

namespace net {

/**
  * Essentially a 'glue' class that binds socket callback functions to
  * member functions of another class.
  */
template <class T,
	 	int (T::*on_readable_fn)(),
		int (T::*on_writeable_fn)(),
		void (T::*on_connect_fn)(),
		void (T::*on_disconnect_fn)(int),
		void (T::*on_connect_fail_fn)(int),
		void (T::*on_connecting_fn)()>
	class socket_binder : public socket {
private:
	T * owner;

public:
	// Construct by accept()'ing from source
	socket_binder(T * o, socket * source, size_t min, size_t max) :
		socket(source, min, max), 
		owner(o) { }
	// Create from scratch
	socket_binder(T * o, int family, int options, size_t min, size_t max) :
		socket(family, options, min, max),
		owner(o) { }

	~socket_binder() { }

	// Reassign owner
	void set_owner(T * o) {
		owner = o;
	}

public:
	/**
	  * Binding callback functions.  
	  */
	virtual int on_readable() {
		return (owner->*on_readable_fn)();
	}
	virtual int on_writeable() {
		return (owner->*on_writeable_fn)();
	}
	virtual void on_disconnect(int e) {
		(owner->*on_disconnect_fn)(e);
	}
	virtual void on_connect() {
		(owner->*on_connect_fn)();
		socket::on_connect();
	}
	virtual void on_connect_fail(int e) {
		(owner->*on_connect_fail_fn)(e); 
	}
	virtual void on_connecting() {
		(owner->*on_connecting_fn)();
	}

private:
	// non-copyable
	socket_binder(const socket_binder&);
	socket_binder& operator = (const socket_binder&);
};

}	/* namespace net */
#endif	/* __NET_SOCKET_BINDER_H */
