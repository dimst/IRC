/** 
 * net/resolver.h
 * (c) 2005-2008 Murat Deligonul
 */

#ifndef __NET_RESOLVER_H
#define __NET_RESOLVER_H

#include <vector>
#include <queue>
#include <sys/types.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <pthread.h>
#include "debug.h"

namespace net {

class resolver_callback;

class resolver {
public:	
	/**
	 * Operational constants
	 */
	static const size_t MAX_HOSTLEN = NI_MAXHOST;

	const unsigned int MAX_THREADS;
	const unsigned int MAX_LOOKUPS_PER_THREAD;

	
public:	
	enum { 
		OPT_NORMAL_LOOKUP  = 0,
		OPT_REVERSE_LOOKUP = 1,
	};
	
	enum {
		SUCCESS = 0,
		ILLEGAL_REQUEST = -1,
	};
		
	
public:
	struct request {
		int 		id;		/* request id */
		int 		family;		/* family of address */
		int 		options;	/* other options */
		
		union {
			int	iresult;	/* return value from resolution functions */
			unsigned short port;
		};
			
		addrinfo 			* ai; 		/* raw result data */
		const resolver_callback 	* callback;	/* callback object pointer */
		char name[MAX_HOSTLEN]; 
		
		~request() { 
			if (ai != NULL) {
				freeaddrinfo(ai); 			
			}
		}
	};
	typedef struct request result;

private:
	struct resolver_thread {
		pthread_t 	thread;
		resolver 	*self;
	};	
	
	static const struct resolver_thread 	default_rt;
		
private:
	std::queue<request *> 	request_queue;
	std::vector<int>	cancelled_requests;
	
	/* synchronization elements */
	pthread_mutex_t		queue_mutex;
	pthread_mutex_t		threads_mutex;
	pthread_cond_t		queue_cv;

	int			fifo[2];
	int			current_id;
	unsigned 		active_threads;
	resolver_thread 	first_thread;
	
	
	static void * resolver_thread_fn(void *);

public:
	resolver(unsigned int, unsigned int);
	~resolver();
	
	/* asnyc. dns resolution methods */
	static request * create_request(int, const char *, unsigned short, 
						int, const resolver_callback *);	
	int 	async_lookup(request *);
	int 	cancel_async_lookup(int);
	
	int 	async_lookup(int family, 
			const char * hostname, unsigned short port, 
			int options, const resolver_callback * callback)
	{	
		struct request * req = create_request(family, hostname, port, options, callback);
		return async_lookup(req);
	}
	
	int 	process_results();
	
	/* async. lookup result analysis */
	static char *	result_to_string(const request *, char *, size_t);
	static const char *	result_error(const request * req) {  
		return gai_strerror(req->iresult); 
	}
	
public:
	/* Low level resolution functions */
	static int resolve_address(int, int, const char *, unsigned short, struct addrinfo **);
	static int lookup(const char *, char * , size_t);
	static int reverse_lookup(const char *, char * , size_t);
	static int test_bind(const char *, unsigned short);
	static int raw_to_ip(const struct sockaddr *, size_t, char *, size_t, unsigned short * = NULL);
	static int ip_to_raw(const char *, unsigned short, struct sockaddr *, size_t);
	static bool is_ip_address(int, const char *);

private:
	int 	fifo_reader_fd() const { 
		return fifo[0]; 
	}
	int	fifo_writer_fd() const {
		return fifo[1]; 
	}

	int	process_request(request *);
	int	write_result(const request *);
	request * read_result();
	int 	process_result(request *);	

	friend class radaptor;

private:
	// non-copyable
	resolver(const resolver&);
	resolver& operator=(const resolver&);
};

/** 
  * Interface for resolver callback
  */
class resolver_callback {
public:
	virtual int async_lookup_finished(const resolver::result *) const = 0;
	virtual int async_lookup_failed(const resolver::result *) const = 0;
	virtual ~resolver_callback() {}
};

/**
  * Class template to wrap class member functions into a resolver callback;
  * avoids having to use inheritance.
  */

template<class T, 
	 int (T::*finished_fn)(const resolver::result *), 
	 int (T::*failed_fn)(const resolver::result *)> 
	 	class resolver_callback_wrapper : public resolver_callback {
private:
	T * const instance;

public:
	resolver_callback_wrapper(T * t) : instance(t) { }
	virtual int async_lookup_finished(const resolver::result * r) const {
		return (instance->*finished_fn)(r);
	}

	virtual int async_lookup_failed(const resolver::result * r) const {
		return (instance->*failed_fn)(r);
	}
};

}  /* namespace net */
#endif /* __NET_RESOLVER_H */
