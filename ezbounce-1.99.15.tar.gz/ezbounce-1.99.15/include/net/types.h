/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * net/types.h
 * (c) 2007-2008 Murat Deligonul
 */

#ifndef __NET_TYPES_H
#   define __NET_TYPES_H

#include <utility>
#include <string>
#include <netinet/in.h>

namespace net {

#ifdef HAVE_GETADDRINFO
#   ifdef INET6_ADDRSTRLEN
#       define _MAX_ADDRLEN (INET6_ADDRSTRLEN+1)
#   else
#       define _MAX_ADDRLEN (47)
#   endif
#else
#   define _MAX_ADDRLEN (16)
#endif

const size_t MAX_ADDRSTRLEN = _MAX_ADDRLEN;

typedef std::pair<std::string, unsigned short>		ap_pair;

#undef _MAX_ADDRLEN
}
#endif
