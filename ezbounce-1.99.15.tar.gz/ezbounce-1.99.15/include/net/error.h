/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundatnetn; either versnetn 2 of the License, or
 * (at your optnetn) any later versnetn.
 *
 * net/error.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __NET_ERROR_H
#define __NET_ERROR_H

#include "debug.h"

namespace net {

/** Socket errors **/
enum {
	ERR_SUCCESS = 0,
	ERR_CLOSED = -1,		/** socket closed normally **/
	ERR_FAILURE = -2,      		/** generic error return **/
	ERR_DNS   = -3,        		/** dns lookup failed, or hostname was bad **/
	ERR_AGAIN = -4,        		/** Try again (returned by some SSL functions) **/
	ERR_SYSCALL  = -5,     		/** A system call failed **/
	ERR_UNABLE  = -6,      		/** Unable to create socket (open() failed, or table full) **/
	ERR_ACCEPT  = -7,      		/** Unable to accept connection **/
	ERR_TABLE_FULL = -8,   		/** oops. too many sockets **/
	ERR_HUP	= -9,   		/** Hangup or poll error **/
	ERR_CONN_ABORTED = -10, 	/** non-blocking connect aborted **/
	ERR_LISTENING   = -11,  	/** Socket is already listening **/
	ERR_ALREADY_OPEN = -12, 	/** Socket is already open/connected **/
	ERR_INTERFACE = -13,		/** Unable to bind to requested address **/
	ERR_PROGRESS = -14,		/** Non-blocking operation in progress **/
	ERR_AUTH	= -15,		/** Authorization Error **/
	ERR_SSL   = -16,        	/** SSL library error **/
	ERR_MEM	  = -17,		/** Memory allocation error **/
	ERR_SOCK_CLOSED	= -18		/** Socket already closed **/
};

// return error description
const char * strerror(int);

}  /* namespace net */
#endif	/* __NET_ERROR_H */
