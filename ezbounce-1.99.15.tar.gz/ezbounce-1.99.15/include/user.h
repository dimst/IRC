/**                                                                        
 * This program is free software; you can redistribute it and/or modify  
 * it under the terms of the GNU General Public License as published by  
 * the Free Software Foundation; either version 2 of the License, or     
 * (at your option) any later version.                                   
 *                                                                         
 * user.h -- ezbounce user account definition.
 * (c) 2001-2008 Murat Deligonul
 */
#ifndef __USER_H
#define __USER_H

#include <list>
#include <string>
#include "util/hash.h"
#include "util/counted_object.h"
#include "config/user_perms.h"
#include "config/user.h"
#include "logging/levels.h"
#include "logging/fwd.h"
#include "irc/fwd.h"
#include "irc/rfc1459.h"
#include "fs/fwd.h"

class conn;
class ruleset;

/**
 * Definition of a user:
 *  -- config-defined user permissions
 *  -- user preferences
 *  -- VFS access credentials
 *  -- rulesets
 *  -- vhosts
 *  -- active connections belonging to this user
 */
class userdef : public util::counted_object<userdef> {
private:
	std::string				_name;
	bool					obsolete;
	fs::credentials *			fs_credentials;
	logging::vfs_logfile *		eventlog;

	std::list<conn *>			clist;
	std::vector<ruleset *>			rlist;
	std::vector<std::string>		vlist;

	user_permissions 			permissions;
	user_config_root 			settings;

	int start_event_log();
	void set_fs_paths();

	// backward compatibility 
	int old_load_basic(const char *);

	static std::string clean_log_name(const char *);

public:
	typedef util::hash_table<const char *, userdef *, 
					util::fixed_cstring_hasher<irc::irc_nick_hash>, 
					util::fixed_cstring_predicate<irc::irc_casecmp> > hash_table_t;

public:
	explicit userdef(const char *);
	~userdef();

	bool is_obsolete() const {
		return obsolete; 
	}
	const char * name() const { 
		return _name.c_str(); 
	}

	user_permissions * config() { 
		return &permissions; 
	}
	const user_permissions * config() const  {
		 return &permissions; 
	}

	user_config_root * options() {
		return &settings; 
	}
	const user_config_root * options() const { 
		return &settings; 
	}

	/**
	 * Admin and VFS Superuser settings.
	 * "VFS Superuser" status currently requires proxy admin status.
	 * The IS_VFS_SUPERUSER setting is therefore ignored for non-admin users.
	 */
	bool is_admin() const {
		return permissions.get<bool>(user_perms::IS_ADMIN);
	}
	bool is_vfs_superuser() const {
		return is_admin() && permissions.get<bool>(user_perms::IS_VFS_SUPERUSER);
	}
	
	/**
	 * Ruleset, vhost, conn list access.
	 */
 	std::list<conn *>& conns() 		{ return clist; }
	std::vector<ruleset *>& rulesets() 	{ return rlist; }
	std::vector<std::string>& vhosts() 	{ return vlist; }

	const std::list<conn *>& conns() const           { return clist; }
	const std::vector<ruleset *>& rulesets() const   { return rlist; }
	const std::vector<std::string>& vhosts() const   { return vlist; }
	
	int login(conn *, const char *, bool);
	int logout(const conn *);

	int save_dynamic_config(int);
	int old_load_dynamic_config(const char *);

	void options_updated(const config::hash_entry *) const;
	
	/** 
	 * VFS, logging related ...
	 */
	fs::flib_key * create_fs_key(int *) const;
	void update_fs_credentials() const;
	int printlog(const char *, ...);
	int printlog(logging::level, const char *, ...);
	std::string make_log_path(const char *, const irc::server_info *, const char *, const char *);

	/** 
	 * Rehashing.
	 */
	static hash_table_t * sync_users(hash_table_t *, hash_table_t *);

	/**
	 * Usernames must be legal IRC nicknames.
	 * A few other names are also not allowed. 
	 */
	static bool is_legal_name(const char * n) {
		if (strcasecmp(n, "root") == 0) {
			return false;
		}
		if (strcasecmp(n, "users") == 0) {
			return false;
		}
		return irc::is_legal_nick(n);
	}
	
	static int namecmp(const char *s1, const char * s2) {
		return irc::irc_casecmp(s1, s2);
	}

private:
	// non-copyable
	userdef(const userdef &);
	userdef& operator = (const userdef &);
};
#endif
