/** 
 * authorizer.h 
 *
 * (c) 2005 Murat Deligonul
 */

#ifndef __AUTHORIZER_H
#define __AUTHORIZER_H

#include <string>
#include <vector>
#include "util/managed_table.h"

class ruleset;
class userdef;
class conn;

/**
 * Class to manage authentication of users.
 * Connecting to ezbounce consists of 3 steps:
 *  1) recognize connection:	does *some* userdef allow this IP ?
 *  2) authorize connection:	does the provided login & password work ?
 *  3) register connection:	does *this* userdef allow this IP and this many users ?
 */
class authorizer {
public:
	/**
	 * Error codes
	 */
	enum {
		SUCCESS = 0,
		ERR_ILLEGAL_STATE = -1,
		ERR_NO_MATCH = -2,
		ERR_NOT_ALLOWED = -3,
		ERR_BAD_PASSWORD = -4,
		ERR_UNKNOWN_USER = -5,
	};

	/**
	 * Table index numbers
	 */
	enum authorizer_string {
		FROM_HOST = 0,
		FROM_IP   = 1,
		TO_HOST,
		TO_IP,
		FAILURE_REASON,
		NUM_AUTH_STRINGS
	};
	
	enum authorizer_port {
		FROM_PORT = 0,
		TO_PORT
	};
	
private:
	/* state flags */
	enum {
		RECOGNIZED = 1,
		LOGGED_IN  = 2,
		REGISTERED_FROM = 4,
		REGISTERED_TO   = 8
	};

private:
	util::managed_table<std::string, NUM_AUTH_STRINGS>	strings;
	unsigned short						ports[2];
	int							status;
	userdef * 						user;
	
	std::vector<ruleset *> rulesets;
	
public:
	authorizer();
#ifdef __DEBUG__
	~authorizer();
#endif

public:
	/* String data */
	const char * get(authorizer_string i) const {	
		return strings.get( (unsigned) i).c_str(); 
	}
	void set(authorizer_string i, const char * s) { 
		strings.set( (unsigned) i, s); 
	}	
	
	/* port data */
	unsigned short get(authorizer_port i) const { 
		return ports[(int) i]; 
	}
	void set(authorizer_port i, unsigned short p) { 
		ports[(int) i] = p; 
	}
	
	userdef * get_user() const { 
		return user; 
	}
	
	int 	recognize_connection();
	int	login_connection(conn *, const char *, const char *);
	int	register_connection();
	int	unregister_connection();
	int	logout_connection(conn *);
	
	int 	register_outgoing_connection();
	int	unregister_outgoing_connection();
	
private:
	// non-copyable
	authorizer(const authorizer &);
	authorizer& operator = (const authorizer &);
};

#endif

