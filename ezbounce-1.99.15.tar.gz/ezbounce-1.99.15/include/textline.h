/**
  * textline.h
  * (c) 2006 Murat Deligonul
  */

#ifndef __TEXTLINE_H
#define __TEXTLINE_H

#include <vector>
#include <algorithm>
#include <cstddef>
#include <cstdlib>
#include <climits>
#include "util/generic.h"

/**
  * Tokenizes a line of IRC text and allows easy access via operator [].
  */
class textline {
private: 
	static const char DELIMS[];

	const char * const str;
	mutable char * buffer;

	mutable unsigned int tokens_found;

	mutable std::vector<char *> tokens;
	mutable std::vector<int> properties;

public:
	static const unsigned int MAX = INT_MAX;

	/**
	  * Properties a token may hold.  Currently used for detecting
	  * if a token was an explicit string literal.
	  */
	enum token_property {
		OTHER			= 0,
		STRING_LITERAL		= 1,
		NUMBER			= (1 << 1)
	};

	explicit textline(const char *, int = 0);
	~textline() { delete[] buffer; }
	unsigned int num_found() const { return tokens_found; }
	unsigned int num_tokens() const { return tokenize(MAX); }

	/** 
	  * Get the nth token (0-based offset).
 	  * Tokenizes the string upto that point if necessary.  If the token
	  * does not exist, NULL is returned.
	  */	
	char * operator[](unsigned n) {
		if (n >= tokens_found) {
			tokenize(n+1);
		}
		return tokens[n];
	}
	const char * operator[](unsigned n) const {
		if (n >= tokens_found) {
			tokenize(n+1);
		}
		return tokens[n];
	}

	/**
	  * Return the first token.
	  */
	char * front() {
		return operator[](0);
	}
	const char * front() const {
		return operator[](0);
	}

	/**
	  * Return the last token. 
	  */
	char * back() {
		return operator[](num_tokens()-1);
	}
	const char * back() const {
		return operator[](num_tokens()-1);
	}

	/**
	  * Return the original source string containing the complete 
	  * unmodified text.
	  */
	const char * all() const {
		return str;
	}

	/**
	  * Return properties of nth token (0 based).
	  */
	int get_properties(unsigned n) const {
		if (n >= tokens_found) {
			tokenize(n+1);
		}
		return properties[n];
	}

	bool empty() const {
		return tokenize(1) < 1;
	}

	bool operator < (unsigned n) const {
		return tokenize(n) < n; 
	}

	bool operator <= (unsigned n) const {
		return tokenize(n) <= n;
	}

	bool operator > (unsigned n) const {
		return tokenize(n+1) > n;
	}
	
	bool operator >= (unsigned n) const {
		// XXX: correct?
		return tokenize(n) >= n;
	}
	
	bool operator == (unsigned n) const {
		return tokenize(n+1) == n;
	}

	const char * get_rest(unsigned) const;

	/**
	  * Insert tokens into a container.
	  */
	template<class Cont> 
		size_t get(Cont&, unsigned int, unsigned int = MAX) const;

	unsigned int tokenize(unsigned int) const;
#ifdef __DEBUG__
	void dump() const;
#endif
private:
	// non-copyable
	textline(const textline &);
	textline& operator = (const textline &);
};

/**
  * Note: range goes up to but not including 'end'.
  */
template<class Cont> 
	size_t textline::get(Cont& out, unsigned int start, unsigned int end) const
{
	const size_t started = out.size();
	end = std::min(end, tokenize(end));
	int num = end - start;
	out.reserve(out.size() + num);

	std::copy(&tokens[0], &tokens[end], std::back_inserter(out));
	return out.size() - started;
}

#endif

