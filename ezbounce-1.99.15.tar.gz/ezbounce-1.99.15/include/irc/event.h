/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/event.h
 * (c) 2008 Murat Deligonul
 */
#ifndef __IRC_EVENT_H
#define __IRC_EVENT_H

#include <bitset>

namespace irc {

	enum event {
		// Basic events
		PUBLIC_PRIVMSG = 0,
		PRIVATE_PRIVMSG,
		PUBLIC_NOTICE,
		PRIVATE_NOTICE,

		// CTCP and related events
		PRIVATE_CTCP,
		PUBLIC_CTCP,
		CTCP_REPLY,
		PUBLIC_ACTION,
		PRIVATE_ACTION,
		DCC,

		// Channel events
		JOIN,
		PART,
		KICK,
		MODE,
		TOPIC,

		// Global IRC events
		QUIT,
		NICK_CHANGE,

		// Events dealing with particular client
		CLIENT_CONNECT,
		CLIENT_DISCONNECT,

		LAST_EVENT = CLIENT_DISCONNECT
	};

	typedef std::bitset<LAST_EVENT+1>	event_flagset_t;

	bool is_private_event(event);

} // namespace irc
#endif // __IRC_EVENT_H
