/** 
 * rfc1459.h 
 * part of ezbounce
 * (c) 2003 Murat Deligonul
 */
 
#ifndef __IRC_RFC1459_H
#define __IRC_RFC1459_H

namespace irc {

extern int irc_casecmp(const char *, const char *);
extern int irc_ncasecmp(const char *, const char *, size_t);
extern unsigned int irc_nick_hash(const char *);
extern unsigned int irc_channel_hash(const char *);
extern bool is_legal_nick(const char *);

extern char * irc_to_lowercase(char *);

extern const unsigned char rfc_tolowertab[];
extern const unsigned char rfc_touppertab[];

inline unsigned char irc_tolower(int c) {
	return rfc_tolowertab[(unsigned char)(c)];
}

inline unsigned char irc_toupper(int c) {
	return rfc_touppertab[(unsigned char)(c)];
}

} // namespace irc
#endif
