// irc/cache_entry.h

#ifndef __IRC_CACHE_ENTRY_H
#define __IRC_CACHE_ENTRY_H

#include <list>
#include "util/generic.h"
#include "irc/address.h"

namespace irc {

class channel;

/**
 * Represents a single nick/address element in the address
 * cache.
 */
class cache_entry {
private:
	address 		addr;		// stores address
	std::list<channel *>  	channels;	// channels we are on
	
public:
	/**
	 * Construct cache_entry from a address string, which may contain a full
	 * address, or just a nickname.
	 */
	explicit cache_entry(const char * str) : addr(str) { }

	/**
	 * Construct cache_entry from three separate parts.
	 */
	explicit cache_entry(const char * nick, const char * user, const char * host) 
		: addr(nick, user, host) { }
	~cache_entry(); 
	
	const std::list<channel *>& references()  { 
		return channels;
	}

	/**
	 * Access IRC address data.
	 */
	const char * nick() const { 
		return addr.nick();
	}
	const char * user() const { 
		return addr.user();
	}
	const char * host() const {
		return addr.host();
	}

	const bool has_user_host() const {
		return addr.has_user_host();
	}

protected:
	/**
	 * Modify IRC address/channel data.
	 * To be used by address caching code only.
	 */
	friend class address_cache;

	void change_nick(const char *);
	
	void set_user_host(const char * user, const char * host) {
		addr.set_user_host(user, host);	
	}
	
	void add_chan(channel * c) { 
		DEBUG("aentry::add_chan() [%s]: %p\n", addr.nick(), c);
		assert(c != NULL);
		assert(!util::contains(channels, c));
		channels.push_back(c); 
	}
	void del_chan(channel * c) { 
		DEBUG("aentry::del_chan() [%s]: %p\n", addr.nick(), c);
		assert(c != NULL);
		assert(util::contains(channels, c));
		channels.remove(c);
	}

private:
	// non-copyable
	cache_entry(const cache_entry &);
	cache_entry & operator = (const cache_entry &);
};

} // namespace irc
#endif
