/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef __IRC_ADDRESS_H
#define __IRC_ADDRESS_H

#include "util/strings.h"

namespace irc {

/**
 * Represents the "nickname!user@host" address of an IRC user.
 * The nickname and user@host parts are stored separately, allowing
 * the nickname to be used as a hash key.  This is useful since initially
 * only the nickname is known; later the user@host information can be added
 * without invalidating the nickname and the hash key.
 */
class address {
private:
	char * nickname;
	char * user_host;

public:
	/**
	 * Construct address from a string containing a full address or 
	 * just a nickname. 
	 */
	explicit address(const char *);

	/*
	 * Construct address from 3 different parts.
	 */
	address(const char * n, const char * u, const char * h)
		: nickname(NULL), user_host(NULL) {
		assert(n != NULL);
		set_nick(n);
		set_user_host(u, h);
	}
	
	/**
	 * Construct address from another address.
	 */
	address(const address &that) : nickname(NULL), user_host(NULL) {
		set_nick(that.nick());
		set_user_host(that.user(), that.host());
	}

	/**
	 * Destructor.
	 */
	~address() {
		delete[] nickname;
		delete[] user_host;
	}

	/** 
	 * Assignment operator: primarily used by testing code.
	 */
	address& operator = (const address& that) {
		if (this == &that) {
			return *this;
		}
		set_nick(that.nick());
		set_user_host(that.user(), that.host());
		return *this;
	}

	const char * nick() const { 
		return nickname;
	}

	const char * user() const {
		if (!has_user_host()) {
			return "unknown";
		}
		return user_host;
	}

	const char * host() const {
		if (!has_user_host()) {
			return "unknown.host";
		}
		return user_host+strlen(user_host)+1;
	}

	bool has_user_host() const {
		return user_host != NULL;
	}

	void set_nick(const char * n) {
		assert(n != NULL);
		delete[] nickname;
		nickname = util::strings::my_strdup(n);
	}
	void set_user_host(const char *, const char *);
};

} // namespace irc 
#endif
