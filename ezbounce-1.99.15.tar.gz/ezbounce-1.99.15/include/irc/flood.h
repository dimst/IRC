/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/flood.h
 * (c) 2008 Murat Deligonul
 */
#ifndef __IRC_FLOOD_H
#define __IRC_FLOOD_H

#include <string>
#include <vector>
#include <utility>
#include <ctime>
#include "util/hash.h"
#include "irc/fwd.h"
#include "irc/event.h"

namespace irc {

/**
 * Individual entry in the flood tracking mechanism.
 */
struct flood_entry {
	std::string 			name;			// source of messages
	std::vector<time_t>		priv_msgs;		// "plain" private messages received
	std::vector<time_t>		auto_resp_msgs;		// "auto response" messages received
};


/**
 * Basic flood protection mechanism.
 * This operates by keeping track of two categories of messages from IRC users:
 * 	1. Private messages (anything directly sent to the client)
 * 	2. Automatic response messages (messages that cause the client to respond with something...
 * 					currently just CTCPs and DCCs.  Perhaps in the future,
 * 					scripts that respond to events?)
 *
 * A rate limit is assigned for each category such that there is a maximum (# messages / # seconds).
 * Rate limits can be set both per-user and globally.
 *
 * flood_protector works together with a ignore_list to automatically create ignores to block 
 * offending users and message types.
 *
 * TODO: currently no facilities for outgoing messages (e.g. calculating queueing times)
 */
class flood_protector {
public:
	typedef util::hash_table<const char *, flood_entry *, 
				util::cstring_hash_fn, util::cstring_predicate> nick_hash_t;

	typedef unsigned short msgnum_t;
	typedef unsigned short seconds_t;

	typedef std::pair<msgnum_t, seconds_t>	msg_rate_t;

	/**
	 * Default constants for message rates.
	 * Message rates are specified as [num msgs/num seconds]
	 */
	// default priv msgs / sec (from one user)
	static const msgnum_t 	DEF_PRIV_MSGS 			= 10;
	static const seconds_t  DEF_PRIV_SECS			= 1;

	// default auto-resp. msgs / sec (from one user)
	static const msgnum_t   DEF_AUTO_RESP_MSGS 		= 3;
	static const seconds_t  DEF_AUTO_RESP_SECS		= 1;

	// default global priv msgs / sec 
	static const msgnum_t	DEF_GLOBAL_PRIV_MSGS		= 30;
	static const seconds_t	DEF_GLOBAL_PRIV_SECS		= 2;

	// default global auto-resp. msgs / sec
	static const msgnum_t 	DEF_GLOBAL_AUTO_RESP_MSGS	= 4;
	static const seconds_t	DEF_GLOBAL_AUTO_RESP_SECS	= 6;

	// default ignore times
	static const seconds_t	DEF_IGNORE_TIME			= 30;
	static const seconds_t  DEF_GLOBAL_IGNORE_TIME		= 60;

	/**
	 * Basic types of messages recognized.
	 */	
	enum message_type {
		PRIVATE,
		AUTO_RESPONSE,
		OTHER
	};

	/**
	 * Result of update operations.
	 */
	enum update_result {
		UPDATE_OK		= 0,
		NOW_IGNORING 		= -1,
		ALREADY_IGNORING	= -2,
		INVALID_EVENT		= -3,
	};

private:
	nick_hash_t		nick_hash;
	flood_entry		global;
	ignore_list * const 	ignores;

	msg_rate_t		priv_rate;
	msg_rate_t		auto_resp_rate;

	msg_rate_t		global_priv_rate;
	msg_rate_t		global_auto_resp_rate;

	seconds_t		ignore_time;
	seconds_t		global_ignore_time;

public:
	flood_protector(const server_info *, ignore_list *, size_t);
	~flood_protector();

	int in(const address *, event, time_t);
	int priv_msg_in(const address *, time_t);
	int auto_resp_msg_in(const address *, time_t);

	int nick_change(const char *, const char *);

	void clear_expired(time_t);
	void clear();

	/**
	 * Rate assignment functions.
	 */
	void set_priv_msg_rate(msgnum_t m, seconds_t s) {
		priv_rate = std::make_pair(m, s);
	}

	void set_auto_resp_rate(msgnum_t m, seconds_t s) {
		auto_resp_rate = std::make_pair(m, s);
	}

	void set_global_priv_msg_rate(msgnum_t m, seconds_t s) {
		global_priv_rate = std::make_pair(m, s);
	}
	
	void set_global_auto_resp_rate(msgnum_t m, seconds_t s) {
		global_auto_resp_rate = std::make_pair(m, s);
	}

	/**
	 * Ignore time management.
	 */
	void set_ignore_time(seconds_t t) {
		ignore_time = t;
	}

	void set_global_ignore_time(seconds_t t) {
		global_ignore_time = t;
	}

private:
	flood_entry * find_or_create(const char *);

	static message_type determine_message_type(event);
	static void clear_expired_msgs(std::vector<time_t>&, unsigned, time_t); 
	static bool is_rate_ok(const std::vector<time_t>&, const msg_rate_t&, time_t);

private:
	// non-copyable
	flood_protector(const flood_protector&);
	flood_protector& operator=(const flood_protector&);
};

} // namespace irc
#endif // __IRC_FLOOD_H
