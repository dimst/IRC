/**
 * irc/server_info.h
 * keeps track of IRC server capabilities (numeric 005 and such)
 *
 * things we parse in detail:
 *
 * -- Channel user mode prefixes
 *    PREFIX=(ov)@+ (IRCNet, Bahamut, ircu)
 *    PREFIX=(ohv)@%+ (Hybrid)
 *
 * -- Channel types:
 * 	CHANTYPES=+#& (ircu)
 * 	CHANTYPES=#&!+ (IRCNet)
 * 	CHANTYPES=&# (Bahamut)
 *	CHANTYPES=#& (Hybrid)
 *
 * -- The network we're on
 *	NETWORK=efnet
 *
 * In addition, the numeric 005 data in its entirety, as well as
 * numerics 003 and 004 (creation time and ircd version, respectively) are stored.
 * This stuff is needed on reattach.
 */
#ifndef __IRC_SERVERINFO_H
#define __IRC_SERVERINFO_H

#include <string>
#include <cctype>
#include "util/managed_table.h"
#include "config/types.h"

#include "debug.h"

class textline;

namespace irc {

class server_info {
public:
	/**
	 * Channel mode types 
	 * These are found in the numeric 005 token, 'CHANMODE=A,B,C,D'
	 */ 
	enum chan_mode {
	        CHAN_MODE_A = 0,
		CHAN_MODE_B,
		CHAN_MODE_C,
		CHAN_MODE_D,
		CHAN_MODE_PREFIX,
		CHAN_MODE_UNKNOWN,
        };

	/**
	 * Casemapping (as given by numeric 005)
	 */
	enum casemapping_id {
		ASCII = 0,
		RFC1459,
		STRICT_RFC1459
	};

	/**
	 * Nickname flags.
	 */
	typedef unsigned int mode_flag_t;

	static const size_t MAX_FLAGS;

	static const int DEFAULT_MAX_CHANNELS = 10;
	static const int DEFAULT_NICK_LEN     = 9;	

private:
	/**
	 * Casemapping data structure used internally.
	 */
	struct casemapping {
		casemapping_id id;
		const char * name;
		bool (*legal_nick_func)(const char *);
		int (*irc_casecmp_func)(const char *, const char *);
		int (*irc_ncasecmp_func)(const char *, const char *, size_t);
		unsigned int (*channel_hash_func)(const char *);
		unsigned int (*nick_hash_func)(const char *);
		char * (*to_lowercase_func)(char *);
	};

private:
	/** 
	 * For the string table.
	 */
	enum data_string {
	        CHAN_TYPES = 0,
		UNOFFICIAL_SERVER_NAME,
		IRC_NETWORK,
		SERVER_NAME,
		SERVER_VERSION,
		SERVER_CREATED,
		SERVER_MODES,
		NUMERIC_005_1,
		NUMERIC_005_2,
		NUMERIC_005_3,
		PREFIX_SYMBOL_LIST,
		PREFIX_MODE_LIST,
		CHAN_MODE_LIST,
		NUM_DATA_STRINGS,               /* not used */
	};

	/**
	 * Cached target lists; used to set/get config data.
	 */
	config::target_list					network_target_list;
	config::target_list					server_target_list;	
	config::target_list					default_channel_target_list;

	util::managed_table<std::string, NUM_DATA_STRINGS>	strings;	
	const casemapping *					mapping;
	unsigned short int 					max_chans, nick_len;

	
	int parse_numeric_003(const textline&);
	int parse_numeric_004(const textline&);
	int parse_numeric_005(const textline&);
	void set_casemapping(const char *);
        static int get_005_token(const char *, const char *, char *, int);

	/**
	 * Default values for these string settings.
	 */
	static const char def_chan_types[];
	static const char def_irc_network[];
	static const char def_prefix_symbol_list[];  /* stuff like @+% */
	static const char def_prefix_mode_list[];  /* stuff like ovh */
	static const char def_chan_mode_list[];    /* chan_mode */

	/**
	 * Default casemapping settings.
	 */
	static const casemapping ASCII_MAPPING;
	static const casemapping RFC1459_MAPPING;
	static const casemapping STRICT_RFC1459_MAPPING;

	/**
	 * Default target lists.
	 */
	static const config::target_list default_server_target_list;
	static const config::target_list default_network_target_list;

public:
        explicit server_info(const char *);

	/**
	 * String comparison function; not case-sensitive; 
	 * precise behavior depends on case-mapping 005 setting. 
	 */
	int strcasecmp(const char * s1, const char * s2) const {
		return mapping->irc_casecmp_func(s1, s2);
	}
	int strncasecmp(const char * s1, const char * s2, int n) const {
		return mapping->irc_ncasecmp_func(s1, s2, n);
	}
	bool is_legal_nick(const char * n) const {
		if (strlen(n) > get_nick_len()) {
			return false;
		}
		return mapping->legal_nick_func(n);
	}
	
	/* convert a string to lower case. */
	char * to_lowercase(char * s) {
		return mapping->to_lowercase_func(s);
	}

	/* return direct pointers to functions; needed in some cases. */
	bool (*legal_nick_func() const)(const char *) {
		return mapping->legal_nick_func;
	}
	int (*casecmp_func() const)(const char *, const char *) {
		return mapping->irc_casecmp_func;
	}
	int (*ncasecmp_func() const)(const char *, const char *, size_t) {
		return mapping->irc_ncasecmp_func;
	}

	/* return pointers to the hash functions */
	unsigned int (*channel_hash_func() const)(const char *) {
		return mapping->channel_hash_func;
	}
	unsigned int (*nick_hash_func() const)(const char *)  {
		return mapping->nick_hash_func;
	}
	
	/* return pointer to the lowercase function */
	char * (*lowercase_func() const)(char *) {
		return mapping->to_lowercase_func;
	}
	  
	/* accessors for channel types */
 	bool is_channel_prefix(char c) const { 
		return strings[CHAN_TYPES].find(c) != std::string::npos; 
	}
	bool is_channel(const char *) const;

	/* and prefix mode/symbol */
	bool is_prefix_symbol(char c) const {
		return strings[PREFIX_SYMBOL_LIST].find(c) != std::string::npos;
       	}
	bool is_prefix_mode(char c) const { 
		return is_type(CHAN_MODE_PREFIX, c);  
       	}
	bool is_type(chan_mode t, char c) const {
		return chan_mode_type(c) == t;
	}

	/* and numbers of this stuff */
	size_t  num_chan_types() const { 
		return strings[CHAN_TYPES].size(); 
	}
	size_t  num_prefix_symbols() const { 
		return strings[PREFIX_SYMBOL_LIST].size(); 
	}

	/**
	  * Processing of channel and user modes.
	  */
	chan_mode chan_mode_type(char) const;
	mode_flag_t mode_to_flag(chan_mode, char) const;
	size_t	    str_flags(chan_mode, mode_flag_t, char *) const;


	/**
	  * Processing of user prefixes (+@%, etc)
	  */
	const char * strip_prefix_symbols(const char *, mode_flag_t * = NULL) const;
	size_t str_prefix_symbols(mode_flag_t flags, char * buffer) const;

	mode_flag_t prefix_symbol_to_flag(char c) const {
		using std::string;
		size_t i = strings[PREFIX_SYMBOL_LIST].find(c);
		if (i == string::npos || i >= MAX_FLAGS) {
			return 0;
		}
		return (1 << i);
	}
	mode_flag_t prefix_symbols_to_flags(const char *s) const { 
		mode_flag_t i; 
		strip_prefix_symbols(s, &i); 
		return i; 
	}

	unsigned get_nick_len() const { 
		return nick_len; 
	}
	unsigned get_max_chans() const { 
		return max_chans; 
	}

	const char * network() const { return strings[IRC_NETWORK].c_str(); }
	const char * unofficial_name() const { return strings[UNOFFICIAL_SERVER_NAME].c_str(); }
	const char * name() const    { return strings[SERVER_NAME].c_str(); }
	const char * version() const { return strings[SERVER_VERSION].c_str(); }
	const char * created() const { return strings[SERVER_CREATED].c_str(); }
	const char * modes() const   { return strings[SERVER_MODES].c_str(); }
	const char * numeric_005_1() const { return strings[NUMERIC_005_1].c_str(); }
	const char * numeric_005_2() const { return strings[NUMERIC_005_2].c_str(); }
	const char * numeric_005_3() const { return strings[NUMERIC_005_3].c_str(); }
	const char * casemapping_name() const { return mapping->name; }
	const char * prefix_modes() const { return strings[PREFIX_MODE_LIST].c_str(); }
	const char * prefix_symbols() const { return strings[PREFIX_SYMBOL_LIST].c_str(); }

	const config::target_list& network_target() const { return network_target_list; }
	const config::target_list& server_target() const { return server_target_list; }
	const config::target_list& default_channel_target() const { return default_channel_target_list; }

	static const config::target_list& default_network_target() { return default_network_target_list; }
	static const config::target_list& default_server_target() { return default_server_target_list; }

	static const char * default_irc_network() { return def_irc_network; }
	//--------------------------------------------------
	// casemapping_t case_mapping() const { return casemapping->; }
	//-------------------------------------------------- 

	int parse_numeric(const textline&);
	//--------------------------------------------------
	// static const char * str_casemapping(casemapping_t);
	//-------------------------------------------------- 

private:
	const char * get_modes_ptr(chan_mode) const;

private:
	// non-copyable
	server_info& operator = (const server_info &);
	server_info(const server_info&);	
};

} // namespace irc 
#endif

