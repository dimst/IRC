/**
 * irc/addrcache.h
 * Part of ezbounce
 */
#ifndef __IRC_CACHE_H
#define __IRC_CACHE_H

#include "util/hash.h"
#include "irc/fwd.h"
#include "irc/cache_entry.h"
#include "irc/channel.h"
#include "net/socket.h"
#include "rfunc.h"

#include "debug.h"

class textline;

namespace irc {

class server_info;

class address_cache {
public:
	/**
	 * Hash tables and their types.
	 */
	typedef util::hash_table<const char *, cache_entry *, util::cstring_hash_fn, util::cstring_predicate> nick_hash_t;
	typedef util::hash_table<const char *, channel *, util::cstring_hash_fn, util::cstring_predicate> channel_hash_t;

private:
	nick_hash_t			nick_hash;
	channel_hash_t			channel_hash;
	const server_info * const	server;

public:
	address_cache(const server_info *, size_t);
	~address_cache();

	/** 
	 * Channel & nick management interface
	 * Return < 0 on error conditions
	 */
	int add_channel(const char *);			// user 'joins' a channel
	int delete_channel(const char *);		// user 'parts' a channel

	/**
	 * Lookup functions.
	 * These return NULL if the requested entity doesn't exist.
	 */
	channel * lookup_channel(const char * name) { 
		channel_hash_t::iterator i = channel_hash.find(name);
		return (i == channel_hash.end()) ? NULL : (*i).second;
       	}
	cache_entry * lookup_nick(const char * nick) { 
		nick_hash_t::iterator i = nick_hash.find(nick);
		return (i == nick_hash.end()) ? NULL : (*i).second;
	}

	size_t num_channels() const { 
		return channel_hash.size(); 
	}
	size_t num_nicks() const { 
		return nick_hash.size(); 
	}

	/**
	  * Iterators to channel list.
	  */
	channel_hash_t::const_iterator channels_begin() const {
		return channel_hash.begin();
	}

	channel_hash_t::const_iterator channels_end() const {
		return channel_hash.end();
	}

	int add_nick(const char *, const char *, server_info::mode_flag_t = 0);
	int add_entry(const address *, const char *, server_info::mode_flag_t = 0);
	int delete_nick(const char *, const char * = NULL);
	int change_nick(const char *, const char *);
	int set_nick_user_host(const char *, const char *, const char *);

	void set_nick_flags(const char * a, const char * b, server_info::mode_flag_t c) { flag_operator(1, a,b,c); }
	void clear_nick_flags(const char * a, const char * b, server_info::mode_flag_t c) { flag_operator(2, a,b,c); }
	int get_nick_flags(const char * a, const char * b) { return flag_operator(0, a, b, 0); }

	void stats(util::hash_stats *,	util::hash_stats *) const;

        /**
	 * Line parsing functions 
	 */
	int parse_mode_line(const char * channel, const textline&);

	/**
	 * Block parsing functions
	 */
	int parse_names_block(const char *, const textline&, unsigned int * = NULL);
	int end_names_block(const char *);

	int parse_who_block(const char *, const textline&);
	int end_who_block(const char *);

	enum rfunc_t {
		RFUNC_NAMES,
		RFUNC_WHO
	};

	rfunc * create_rfunc(rfunc_t, net::socket *, const char *, const char *);

private:
	int flag_operator(int, const char *, const char *, server_info::mode_flag_t);
	
private:
	// noncopyable
	address_cache(const address_cache&);
	address_cache& operator=(const address_cache&);
};

} // namespace irc
#endif 
