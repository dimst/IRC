/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/channel.h
 * (c) 2001-2008 Murat Deligonul
 */
#ifndef __IRC_CHANNEL_H
#define __IRC_CHANNEL_H

#include <map>
#include <string>
#include <utility>
#include <ostream>
#include <stdexcept>
#include "util/hash.h"
#include "util/generic.h"
#include "config/types.h"
#include "irc/cache_entry.h"
#include "irc/server_info.h"
#include "logging/chatlog.h"
#include "debug.h"

namespace irc {

/**
 * Represents an IRC channel, its data, and its users.
 */
class channel {
public:
	typedef util::hash_table<const char *, std::pair<cache_entry *, server_info::mode_flag_t>, 
					util::cstring_hash_fn, util::cstring_predicate> 	hash_table_t;
						
	enum chan_flag {
		NAMES_DATA_RECVED    =  1,
		WHO_REQ_SENT         = (1 << 1),
		RELAY_WHO_RESP       = (1 << 2), 
		WHO_DATA_RECVED      = (1 << 3),

		MODE_REQ_SENT		= (1 << 4),
		RELAY_MODE_RESP		= (1 << 5),
		MODE_DATA_RECVED	= (1 << 6)
	};

private:
	typedef 	std::pair<char, std::string> 		mode_entry;

	const char * const		_name;
	int 				flags;
	logging::chatlog * 		log;
	bool				logging;
	int 				log_options;

	/**
	 * Stores topic; pair stores who set it and when.
	 */
	std::string				topic_str;
	std::pair<std::string, std::string>	topic_data;

	/**
	 * Channel modes:
	 *		'D' modes do not have nickname parameters and are stored as numeric flags.
	 *		'B' and 'C' (valued) modes always have a parameter and are stored as pair
	 */
	server_info::mode_flag_t		modes;
	std::map<char, std::string>		valued_modes;

	/**
	 * Config system targets.
	 */
	config::target_list 		channel_target_list;
	static config::target_list	default_target_list;

	hash_table_t nick_hash;

public:
	channel(const server_info *, const char *, int);
	~channel();

	/** 
	 * The target list, used for accessing user preferences 
	 * for this channel. 
	 */
	const config::target_list& channel_target() const {
		return channel_target_list;
	}

	/**
	 * Default.
	 */
	static const config::target_list& default_channel_target() {
		return default_target_list;
	}

	/**
 	 * Basic properties.
 	 */
	const char * name() const { 
		return _name; 
	}
	size_t population() const { 
		return nick_hash.size(); 
	}

	/**
	 * Channel topic.
	 */
	const char * topic() const {
		return topic_str.c_str();
	}
	void set_topic(const char * str) {
		topic_str = str;
	}
	bool has_topic() const {
		return !topic_str.empty();
	}
	const char * topic_setter() const {
		return topic_data.first.c_str();
	}
	const char * topic_time() const {
		return topic_data.second.c_str();
	}
	void set_topic_data(const char * setter, const char * time) {
		topic_data.first = setter;
		topic_data.second = time;
	}

	/**
	 * Channel flags.
	 * NOTE: these are not modes.
	 */
	int chan_flags() const { 
		return flags; 
	}
	bool is_chan_flag_set(chan_flag f) const {
		return (flags & f);
	}
	void set_chan_flag(chan_flag f) { 
		flags |= f; 
	}
	void clear_chan_flag(chan_flag f) { 
		flags &= ~f; 
	}
	void clear_chan_flags() {
		flags = 0;
	}

	/**
	 * Returns true if all channel data from the server has been obtained.
	 */
	bool has_all_data() const {
		return is_chan_flag_set(NAMES_DATA_RECVED) &&
			is_chan_flag_set(WHO_DATA_RECVED) &&
			is_chan_flag_set(MODE_DATA_RECVED);
	}

	/**
	 * Channel modes.
	 * B/C type modes (e.g. +k, +l)
	 */
	void set_valued_mode(char c, const char * value) {
		assert(c != 0);
		assert(value != NULL);		      
		valued_modes[c] = std::string(value);
	}

	// get value of a mode; NULL if not set.
	const char * get_valued_mode(char c) const {
		std::map<char, std::string>::const_iterator i = valued_modes.find(c);
		return (i != valued_modes.end()) ? (*i).second.c_str() : NULL;
	}
	bool is_valued_mode_set(char c) const {
		return util::contains_if(valued_modes.begin(), valued_modes.end(), 
					util::pair_key_predicate<char, std::string>(c));
	}
	void clear_valued_mode(char c) {
		valued_modes.erase(c);
	}
	void clear_valued_modes() {
		valued_modes.clear();
	}

	/**
	 * Other channel modes.
	 */
	int  chan_modes() const {
		return modes;
	}
	bool is_chan_mode_set(server_info::mode_flag_t flag) const {
		return (modes & flag);
	}
	void set_chan_mode(server_info::mode_flag_t flag) {
		modes |= flag;
	}
	void clear_chan_mode(server_info::mode_flag_t flag) {
		modes &= ~flag;
	}
	void clear_chan_modes() {
		modes = 0;
	}
	
	// Get a string containing all modes
	void get_all_modes(const server_info *, std::string &) const;


	/**
	 * Logging.
	 */
	logging::chatlog * get_chatlog() const { 
		return log; 
	}
	void set_chatlog(logging::chatlog * c) { 
		log = c; 
		if (log != NULL) {
			log->set_options(log_options);
		}
	}

	int get_log_options() const { 
		return log_options; 
	}
	void set_log_options(int i) { 
		log_options = i;
		if (log != NULL) {
			log->set_options(log_options);
		}
	}

	bool is_logging() const { 
		return logging; 
	}
	void set_logging(bool b) { 
		logging = b; 
	}

	/**
	 * Nickname access.
	 * TODO: These should only be called by the address_cache code.  May want to
	 * 	 make these private and make address_cache a friend (cache_entry too?).
	 */
	bool has_nick(const char * n) const {
		return nick_hash.contains(n);
	}
	cache_entry * lookup_nick(const char * n) const { 
		hash_table_t::const_iterator i = nick_hash.find(n);
		if (i == nick_hash.end()) {
			return NULL;
		}
		return (*i).second.first;
	}
	void add_nick(cache_entry * n, server_info::mode_flag_t f = 0) {
		DEBUG("channel::add_nick() [%s]: %s (w/ flags %u)\n", _name, n->nick(), f);
		assert(!nick_hash.contains(n->nick()));
		nick_hash.insert(n->nick(), std::make_pair(n, f));
	}
	void del_nick(const cache_entry * n) {
		DEBUG("channel::del_nick() [%s]: %s\n", _name, n->nick());
		assert(nick_hash.contains(n->nick()));
		nick_hash.erase(n->nick());
	}

	int nick_flags(const cache_entry *) const;
	void set_nick_flags(const cache_entry *, server_info::mode_flag_t);
	void clear_nick_flags(const cache_entry *, server_info::mode_flag_t);

	hash_table_t::iterator nicks_begin() {
		return nick_hash.begin();
	}
	hash_table_t::iterator nicks_end() {
		return nick_hash.end();
	}
	void nick_hash_stats(util::hash_stats * ht) const {
		nick_hash.stat(ht);
	}
			
private: 
	// non-copyable
	channel(const channel &);
	channel & operator=(const channel&);
};

inline std::ostream& operator << (std::ostream& out, const channel& chan) {
	out << chan.name();
	return out;
}

inline std::ostream& operator << (std::ostream& out, const channel * chan) {
	out << chan->name();
	return out;
}

} // namespace irc
#endif
