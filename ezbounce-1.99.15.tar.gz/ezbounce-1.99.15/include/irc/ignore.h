/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/ignore.h
 * (c) 2008 Murat Deligonul
 */
#ifndef __IRC_IGNORE_H
#define __IRC_IGNORE_H

#include <string>
#include <vector>
#include <climits>
#include <ctime>
#include "irc/fwd.h"
#include "irc/event.h"


namespace irc {

/**
 * A specific entry in the ignore list.
 */
struct ignore_entry {
	std::string		mask;
	event_flagset_t		flags;
	time_t			expiration;
};


/**
 * Simple list to keep track of ignores.
 */
class ignore_list {
private:
	typedef std::vector<ignore_entry>	container_type;
	container_type				ignores;

public:
	// FIXME: this assumes that sizeof(time_t) >= sizeof(long)
	static const time_t IGNORE_FOREVER = LONG_MAX;

	// how many ignores?
	size_t size() const {
		return ignores.size();
	}

	// empty?
	bool empty() const {
		return ignores.empty();
	}

	// remove all ignores
	void clear() {
		ignores.clear();
	}

	bool contains(const char *, const event_flagset_t&) const;
	
	bool is_ignored(const char *, event, time_t) const;
	bool is_ignored(const address *, event, time_t) const;

	void add(const char *, const event_flagset_t &, time_t);
	void add(const address *, const event_flagset_t &, time_t);

	void clear_expired(time_t);

private:
	void add(const ignore_entry&);
};

} // namespace irc
#endif // __IRC_IGNORE_H
