/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/message.h
 * (c) 2008 Murat Deligonul
 */
#ifndef __IRC_MESSAGE_H
#define __IRC_MESSAGE_H

#include <string>
#include "irc/event.h"

class textline;

namespace irc {

	event extract_ctcp(event, const textline&, unsigned, std::string&, std::string&, std::string&);	

} // namespace irc
#endif // __IRC_MESSAGE_H
