/**
  * server_entry.h
  *
  * part of ezbounce
  * (c) 2007-2008 Murat Deligonul
  */

#ifndef __IRC_SERVER_ENTRY_H
#define __IRC_SERVER_ENTRY_H

#include <string>
#include "debug.h"

namespace irc {

/**
  * Represents a single entry in a server list.
  */
class server_entry {
private:
	std::string	s_name;
	std::string	s_network;
	std::string	s_ports;
	std::string	s_password;
	bool 		ssl;

	// FIXME: temporary hack
	unsigned short  temp_port;

public:
	server_entry(const char *, const char *, const char * = "6667", const char * = "", bool = false);
	server_entry(const char *, const char *, unsigned short, const char * = "", bool = false);
	server_entry(const std::string&, const std::string&, const std::string&, const std::string &, bool = false);
	// default destructor, copy constructor, and assignment operator suffice.

	const std::string& name() const { 
		return s_name;
	}
	const std::string& network() const {
		return s_network;
	}
	const std::string& ports() const {
		return s_ports;
	}
	const std::string& password() const {
		return s_password;
	}
	const bool is_ssl() const {
		return ssl;
	}

	void set_name(const char * n) {
		s_name = n;
	}
	void set_network(const char * n) {
		s_network = n;
	}
	void set_password(const char * p) {
		s_password = p;
	}
	void set_ports(const char *);

	unsigned short get_random_port() const;
};

} // namespace irc
#endif
