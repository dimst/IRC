/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/chain_policies.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_CHAIN_POLICIES_H
#define __IO_CHAIN_POLICIES_H

#include <fstream>
#ifdef HAVE_BOOST_IOSTREAMS
#	include <boost/iostreams/filtering_stream.hpp>
#endif

namespace io {

/**
 * Class templates to defines behaviors for various types of streams.
 * This is the default template which does nothing.
 */
template <typename T> class stream_policy 
{
public:
	typedef	T		stream_t;
	static void flush(T& ) {
	}
	static void close(T& ) {
	}
	static bool is_complete(const T&) {
		return true;
	}
	template <typename Dummy> static void push(T&, const Dummy&) {
		/* not supported */
	}
};

/**
 * Stream policy for ofstream:
 * 	dummy push and is_complete
 */
template <> class stream_policy<std::ofstream> 
{
public:
	typedef std::ofstream 		stream_t;
	static void flush(stream_t &stream) {
		stream.flush();
	}
	static void close(stream_t &stream) {
		stream.close();
	}
	static bool is_complete(const stream_t &) {
		return true;
	}
	template <typename Dummy> static void push(stream_t&, const Dummy&) {
		/* not supported */
	}
};

template <> class stream_policy<std::ifstream> 
{
public:
	typedef std::ifstream 		stream_t;
	static void flush(stream_t &stream) {
		stream.sync();
	}
	static void close(stream_t &stream) {
		stream.close();
	}
	static bool is_complete(const stream_t &) {
		return true;
	}
	template <typename Dummy> static void push(stream_t&, const Dummy&) {
		/* not supported */
	}
};

#ifdef HAVE_BOOST_IOSTREAMS
/**
 * Stream policies for boost filtering_streams
 */
template <> class stream_policy<boost::iostreams::filtering_stream<boost::iostreams::output> > 
{
public:
	typedef boost::iostreams::filtering_stream<boost::iostreams::output>	stream_t;

	static void flush(stream_t& stream) {
		stream.flush();
	}
	static void close(stream_t& stream) {
		stream.reset();
	}
	static bool is_complete(const stream_t &stream) {
		return stream.is_complete();
	}

	template<typename StreamType> static void push(stream_t& stream, StreamType& element) {
		stream.push(element);	
	}
	template<typename FilterType> static void push(stream_t& stream, const FilterType& element) {
		stream.push(element);	
	}
};

template <> class stream_policy<boost::iostreams::filtering_stream<boost::iostreams::input> > 
{
public:
	typedef boost::iostreams::filtering_stream<boost::iostreams::input>		stream_t;

	static void flush(stream_t& stream) {
		stream.sync();
	}
	static void close(stream_t& stream) {
		stream.reset();
	}
	static bool is_complete(const stream_t &stream) {
		return stream.is_complete();
	}

	template<typename StreamType> static void push(stream_t& stream, StreamType& element) {
		stream.push(element);	
	}
	template<typename FilterType> static void push(stream_t& stream, const FilterType& element) {
		stream.push(element);	
	}
};
#endif
}
#endif

