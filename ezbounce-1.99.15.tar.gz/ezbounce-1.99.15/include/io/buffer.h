/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/buffer.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_BUFFER_H
#define __IO_BUFFER_H

#include <iosfwd>
#include <utility>
#include <cstddef>
#include <climits>

#ifdef HAVE_SSL
#define OPENSSL_NO_KRB5		/* prevent compilation error on RH Linux 9, et al */
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/rand.h>
#endif


namespace io {

/**
 * A dynamically growable FIFO buffer.
 */
class buffer {
private:
	char * 			buff;		// allocated buffer
	char *			start;		// where data actually starts

	const size_t		min;		// minimum size to keep at
	const size_t		max;		// maximum size to grow to

	size_t			alloced;	// storage allocated
	size_t			in;		// bytes added

public:
	// type definitons
	typedef	char		value_type;
	typedef char * 		iterator;
	typedef const char * 	const_iterator;

	static const size_t 	SYS_PAGE_SIZE;
	static const size_t 	MINIMUM		= 512;
	static const size_t	MAXIMUM		= INT_MAX;

public:
	explicit buffer(size_t = MINIMUM, size_t = MAXIMUM);
	~buffer() {
		delete[] buff;
	}

	/** 
	 * Accessors
	 */
	size_t size() const {
		return in;
	}
	size_t capacity() const {
		return alloced;
	}
	size_t max_capacity() const {
		return max;
	}
	size_t min_capacity() const {
		return min;
	}

	// available storage
	size_t available() const {
		return max_capacity() - size();
	}
	// available storage without having to allocate more memory
	size_t available_now() const {
		return capacity() - size();
	}
	
	bool   empty() const {
		return size() == 0;
	}
	bool   full() const {
		return available() == 0;
	}
	void * data() const {
		return start;
	}

	// STL-like iterator interface
	iterator begin() {
		return start;
	}
	iterator end() {
		return start+size();
	}

	const_iterator begin() const {
		return start;
	}
	const_iterator end() const {
		return start+size();
	}

	/**
	 * Insert contents into buffer from various sources.
	 * 
	 * NOTE: Data insertion functions are all or none; if the requested amount cannot be 
	 *       added (due to space limitations), nothing will be added.
	 *       The only exception is specifying a zero size to the from-fd and from-SSL 
	 *       insertion functions, which will then determine how many bytes are readable from the file
	 *       descriptor and add as much as space permits.
	 */
	ssize_t	insert(const void *, size_t);
	ssize_t insert(int, size_t = 0);

	/**
	 * Flush buffer contents into various sinks.
	 */
	ssize_t	flush(int, size_t);
	ssize_t flush(std::ostream&, size_t);
	ssize_t flush(buffer *, size_t);
	ssize_t flush(size_t);

	// inline alternate forms
	ssize_t flush(int f) {
		return flush(f, size());
	}
	ssize_t flush(std::ostream& out) {
		return flush(out, size());
	}
	ssize_t flush(buffer * out) {
		return flush(out, size());
	}

	/**
	 * OpenSSL-specific stuff
	 */
#ifdef HAVE_SSL
	ssize_t insert(SSL *, size_t = 0);
	ssize_t flush(SSL *, size_t);
	ssize_t flush(SSL * s) {
		return flush(s, size());
	}
#endif
	/**
	 * Other operations 
	 */
	void clear() {
		in = 0;
		start = buff;
	}
	// resize the buffer to an optimal size
	void optimize();
	void reserve(size_t);

private:
	void remove(size_t);
	static unsigned nearest_power_of_2(unsigned);

private:
	// non-copyable
	buffer(const buffer&);
	buffer& operator=(const buffer&);
};

/**
 * Additional useful types
 */
typedef std::pair<buffer::iterator, size_t>	byte_length_pair;


} /* namespace io */
#endif /* __IO_BUFFER_H */

