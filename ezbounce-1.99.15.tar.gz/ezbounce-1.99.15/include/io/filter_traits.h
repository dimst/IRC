/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/filter_traits.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_FILTER_TRAITS_H
#define __IO_FILTER_TRAITS_H

#include <string>
#ifdef HAVE_BOOST_IOSTREAMS
#include <boost/iostreams/filter/gzip.hpp>
#include <boost/iostreams/filter/bzip2.hpp>
#include <boost/iostreams/filter/newline.hpp>
#endif
#include "io/exceptions.h"
#include "io/filter_types.h"
#include "io/dummy_filter.h"
#include "io/modes.h"

namespace io {

template<filter_t F> struct filter_traits {
	typedef io::bidirectional			mode;
	typedef dummy_filter				filter_type;
	typedef dummy_filter::dummy_params		parameter_type;

	static parameter_type create_parameter(const std::string& ) {
		return parameter_type();
	}
};

#ifdef HAVE_BOOST_IOSTREAMS
/** 
 * Specializations: these all require the boost::iostreams library.
 */
template<> struct filter_traits<GZIP_COMPRESSOR> {
	typedef io::output				mode;
	typedef boost::iostreams::gzip_compressor	filter_type;
	typedef boost::iostreams::gzip_params		parameter_type;

	static const filter_mode FILTER_MODE 		= BINARY_MODE;
	static const char EXTENSION[];

	static parameter_type create_parameter(const std::string&) {
		return parameter_type();
	}
};

template<> struct filter_traits<GZIP_DECOMPRESSOR> {
	typedef io::input				mode;
	typedef boost::iostreams::gzip_decompressor	filter_type;
	typedef int					parameter_type;
	
	//
	// from boost::iostreams documentation
	static const int DEFAULT_WINDOW_BITS		= 15;

	static const filter_mode FILTER_MODE		= BINARY_MODE;
	static const char EXTENSION[];

	static parameter_type create_parameter(const std::string&) {
		return DEFAULT_WINDOW_BITS;
	}
};

#endif /* HAVE_BOOST_IOSTREAMS */

} /* namespace io */
#endif /* __IO_FILTER_TRAITS_H */

