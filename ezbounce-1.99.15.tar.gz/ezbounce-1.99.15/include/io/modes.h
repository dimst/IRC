/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/modes.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_MODES_H
#define __IO_MODES_H

/**
 * Tag structs that list the available io modes.  
 * These are used by the chain and filter classes.
 */
namespace io {

namespace detail {
	struct input_tag { };
	struct output_tag { };
	struct bidirectional_tag : public input_tag, public output_tag { };
}

typedef detail::input_tag 		input;
typedef detail::output_tag 		output;
typedef detail::bidirectional_tag	bidirectional;
}

#endif
