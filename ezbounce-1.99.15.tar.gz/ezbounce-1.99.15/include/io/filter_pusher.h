/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/filter_pusher.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_FILTER_PUSHER_H
#define __IO_FILTER_PUSHER_H

#include <stdexcept>

namespace io {

/**
 * Helper class to perform pushing of filters onto IO chains.
 * Handles error conditions (e.g. trying to use input filter on output chain)
 *
 * The default implementation simply throws an exception.
 * The specialization below handles the correct use case.
 */
template<typename Mode1, typename Mode2> class filter_pusher {
public:
	template<typename Chain, typename Filter> static void push(Chain&, const Filter&) {
		throw std::invalid_argument("invalid filter for chain's IO mode");
	}
};


template<typename Mode> class filter_pusher<Mode, Mode> {
public:
	template<typename Chain, typename Filter> static void push(Chain& chain, const Filter& filter) {
		chain.push(filter);
	}
};

} /* namespace io */
#endif /* __IO_FILTER_PUSHER_H */

