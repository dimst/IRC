/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/chain.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_CHAIN_H
#define __IO_CHAIN_H

#include <ios>
#include <string>
#include <sstream>
#include "util/type_chooser.h"
#include "io/chain_traits.h"
#include "io/chain_policies.h"
#include "io/exceptions.h"
#include "io/modes.h"
#include "debug.h"

namespace io {

/**
 * Defines an IO chain, which essentially just pairs an ostream or istream device
 * with a Boost filtering_stream object.  The filtering and IO work is handled entirely
 * by the iostream and Boost classes.
 * Also abstracts away several details of the Boost library, allowing the rest of the program
 * to be built even without Boost.
 */
template<typename Mode, 
		bool Filter = true,
		typename Traits = chain_traits<Mode, Filter>,
	        template<typename> class StreamPolicy = stream_policy> class chain {
public:
	typedef Mode						mode;
	typedef Traits   					mode_traits;
	typedef typename mode_traits::openmode_type		openmode;
	typedef typename mode_traits::handle_type		handle_t;

	typedef typename mode_traits::stream_type		stream_t;
	typedef typename mode_traits::filtering_stream_type	filtering_stream_t;
	typedef typename mode_traits::base_stream_type		base_stream_t;


	typedef StreamPolicy<stream_t>				s_policy;
	typedef StreamPolicy<filtering_stream_t>		fs_policy;

	static  const bool WANT_FILTERING = Filter;
	static  const bool HAVE_FILTERING = mode_traits::HAVE_FILTERING;

private:
	const handle_t		handle;
	stream_t		stream;
	filtering_stream_t	filtering_stream;


public:
	explicit chain(const handle_t&, openmode);
	~chain();

	/**
	 * Return the handle.
	 */
	const handle_t& get_handle() const {
		return handle;
	}

	/**
	 * Return the filtering stream.  Note that if there is no filtering enabled (or possible), 
	 * the clever deciding template returns the raw stream instead.
	 */
	base_stream_t& get_stream() {
		assert(is_complete());
		using util::type_chooser;
		return type_chooser<HAVE_FILTERING, filtering_stream_t, stream_t>::choose(filtering_stream, stream);
	}
	
	/**
	 * Return the raw stream.
	 */
	base_stream_t& get_raw_stream() {
		return stream;
	}

	/**
	 * Checks if the stream is ready for IO.
	 */
	bool is_complete() const {
		return s_policy::is_complete(stream) && 
			fs_policy::is_complete(filtering_stream);
	}

	/**
	 * Flush/sync buffers
	 */
	void flush() {
		fs_policy::flush(filtering_stream);
		s_policy::flush(stream);
	}

	/** 
	 * Finalize the chain and make it ready for IO 
	 */
	void complete() {
		if (!is_complete()) {
			fs_policy::push(filtering_stream, stream);
		}
	}

	/** 
	 * Add a filter to the chain.  The chain must not be complete. 
	 * If filtering isn't supported, an exception is thrown immediately.
	 */
	template<typename T> void push(const T& f) {
		if (!HAVE_FILTERING) {
			throw io_exception("Chain does not support filtering");
		}
		if (is_complete()) {
			throw io_exception("Chain is already complete");
		}
		fs_policy::push(filtering_stream, f);
	}

private:
	/**
	 * Close the streams.
	 * FIXME: remove this?
	 */
	void close() {
		fs_policy::close(filtering_stream);
		s_policy::close(stream);
	}

private:
	/**
	 * Forbidden operations 
	 */
	chain(const chain &);
	chain& operator= (const chain &);
};

/**
 * Construct a new chain.
 * Try to open the stream first; throw exception if it fails.
 */
template<typename Mode, bool Filter, typename Traits, template <typename> class StreamPolicy> 
	chain<Mode, Filter, Traits, StreamPolicy>::chain(
					const chain<Mode, Filter, Traits, StreamPolicy>::handle_t & name, 
				 	chain<Mode, Filter, Traits, StreamPolicy>::openmode mode) 
							: handle(name), 
								stream(name, mode)
{
	using std::string;
	using std::ostringstream;
	if (!stream) {
		ostringstream error;
		error << "unable to file: " << "FIXME"; 
		throw io_exception(error.str());		
	}
}

/**
 * Destructor:
 * Flush and ensure no exceptions get thrown.
 */
template<typename Mode, bool Filter, typename Traits, template <typename> class StreamPolicy> 
	chain<Mode, Filter, Traits, StreamPolicy>::~chain() 
{
	try {
		flush();
		close();
	}
	catch (...) {
		DEBUG("chain::~chain():	exception caught; ignoring\n");
	}
}

/**
 * Typedefs
 */
typedef 	chain<output, true>	output_chain;
typedef		chain<input, true>	input_chain;
typedef		chain<output, false>	raw_output_chain;
typedef		chain<input, false>	raw_input_chain;

}
#endif

