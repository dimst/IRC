/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/chain_traits.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_CHAIN_TRAITS_H
#define __IO_CHAIN_TRAITS_H

#include <iosfwd>
#include <string>

#ifdef HAVE_BOOST_IOSTREAMS
#	include <boost/iostreams/filtering_stream.hpp>
#endif
#include "io/modes.h"

namespace io {

/**
 * Defines traits for filtering chain types.
 * (specializations below)
 */
template <typename T, bool Filter> class chain_traits;

namespace detail {
	// not a real stream
	struct dummy_stream { };
	/**
	 * Determines the filtering stream type for input/output
	 * and whether filtering is requested/available.
	 * This default definition defines no filtering stream.
	 */
	template<typename T, bool Filter> class stream_traits {
	public:
		typedef dummy_stream	type;
		static const bool HAVE_FILTERING = false;
	};


#ifdef HAVE_BOOST_IOSTREAMS
	template<> class stream_traits<input, true> {
	public:
		typedef boost::iostreams::filtering_stream<boost::iostreams::input>	type;
		static const bool HAVE_FILTERING = true;
	};

	template<> class stream_traits<output, true> {
	public:
		typedef boost::iostreams::filtering_stream<boost::iostreams::output>	type;
		static const bool HAVE_FILTERING = true;
	};
#endif
}

/**
 * Traits for input chains [with and without filtering capabilities]
 */
template<bool Filter> class chain_traits<input, Filter> {
public:
	typedef const char *							handle_type;
	typedef std::ios::openmode						openmode_type;

	typedef std::istream							base_stream_type;
	typedef std::ifstream 							stream_type;
	typedef typename detail::stream_traits<input, Filter>::type		filtering_stream_type;

	static	const bool HAVE_FILTERING = detail::stream_traits<input, Filter>::HAVE_FILTERING;
};

// output

template<bool Filter> class chain_traits<output, Filter> {
public:
	typedef const char * 							handle_type;
	typedef std::ios::openmode						openmode_type;

	typedef std::ostream							base_stream_type;
	typedef std::ofstream 							stream_type;
	typedef typename detail::stream_traits<output, Filter>::type		filtering_stream_type;

	static	const bool HAVE_FILTERING = detail::stream_traits<input, Filter>::HAVE_FILTERING;
};

}
#endif
