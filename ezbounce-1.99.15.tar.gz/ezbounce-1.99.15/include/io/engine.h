/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/engine.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_ENGINE_H
#define __IO_ENGINE_H

#include <vector>
#include <ctime>
#include "io/pollable.h"
#include "io/event.h"
#include "debug.h"

namespace io {

/**
  * An IO event handling interface.
  */
class engine {
private:
	std::vector<pollable *> objects;
	time_t 			* last_event;
	time_t			dummy_time;
		
public:
	static const unsigned DEFAULT_INITIAL_CAPACITY = 256;

	explicit engine(unsigned size = DEFAULT_INITIAL_CAPACITY, time_t * = NULL); 
	virtual ~engine();

	virtual int add(pollable *, int);
	virtual int release(pollable *);
	virtual void set_events(pollable *, int);
	virtual void compress();
	virtual int poll(int) = 0;

	/* Convenience function; non-virtual */
	int add(pollable * p) {
		return add(p, p->get_events());
	}
	time_t get_time() const {
		return *last_event;
	}
	size_t get_table_size() const {
		return objects.size();
	}

protected:
	void update_time() {
		*last_event = ::time(NULL);
	}
	const std::vector<pollable *>& get_table() const {
		return objects;
	}

private:
	// non-copyable
	engine(const engine &);
	engine& operator = (const engine&);
};


}  /* namespace io */
#endif	/* __IO_ENGINE_H */
