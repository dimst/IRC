/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/error.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_ERROR_H
#define __IO_ERROR_H

#include "debug.h"

namespace io {

enum error {
	SUCCESS 		= 0,
	INVALID_FD 		= -1,
	DUPLICATE_FD 		= -2,
	READ_ERROR		= -100,
	WRITE_ERROR		= -101,
	BUFFER_FULL		= -102	
};

// return error description
const char * strerror(int);

}  /* namespace io */
#endif	/* __IO_ERROR_H */
