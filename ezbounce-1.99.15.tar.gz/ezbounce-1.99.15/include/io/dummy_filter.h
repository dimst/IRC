/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/dummy_filter.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_DUMMY_FILTER_H
#define __IO_DUMMY_FILTER_H

#ifdef HAVE_BOOST_IOSTREAMS
#include <boost/iostreams/categories.hpp>
#include <boost/iostreams/concepts.hpp>
#include <boost/iostreams/operations.hpp>
#endif

namespace io {

/**
 * The 'default' filter and parameter types used when filtering 
 * is not available.
 * If boost::iostreams is being used, we must model this according to its
 * concepts.
 */
struct dummy_filter { 
	struct dummy_params { };

	dummy_filter(const dummy_params&) {
		throw io_exception("trying to create dummy filter");
	}

#ifdef HAVE_BOOST_IOSTREAMS
	typedef char		char_type;
	struct category 
		: boost::iostreams::dual_use,
			boost::iostreams::filter_tag,
			boost::iostreams::closable_tag 
		{ };

	template<typename S> 
	std::streamsize read(const S&, char_type *, std::streamsize) {
		return std::streamsize();
	}
			

#endif
};
} /* namespace io */
#endif /* __IO_DUMMY_FILTER_H */

