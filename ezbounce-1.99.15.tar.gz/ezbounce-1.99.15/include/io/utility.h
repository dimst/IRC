/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/utility.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_UTILITY_H
#define __IO_UTILITY_H

namespace io {

/**
 * printf()-like function for outputting to file descriptors.
 */
extern int fdprintf(int, const char *, ...);

} /* namespace io */
#endif /* __IO_UTILITY_H */

