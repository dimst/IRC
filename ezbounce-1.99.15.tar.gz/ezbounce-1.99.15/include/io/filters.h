/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/filters.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_FILTERS_H
#define __IO_FILTERS_H

#include <string>
#include "util/array.h"
#include "io/filter_types.h"
#include "io/filter_traits.h"
#include "io/filter_pusher.h"

namespace io {

/**
 * Get various properties.
 */
const char * filter_file_extension(filter_t);
const char * filter_name(filter_t);
filter_mode  filter_io_mode(filter_t);
filter_kind  filter_work_kind(filter_t);

template<typename T> filter_t get_filter_by_extension(const char *);


/**
 * Constructs filters and attaches them to chains.
 */
template<filter_t F, typename Traits = filter_traits<F> > class filter_factory {
public:
	typedef	Traits					traits;
	typedef	typename traits::mode			filter_mode;
	typedef typename traits::filter_type		filter_type;
	typedef typename traits::parameter_type		parameter_type;

public:
	static filter_type construct(const std::string& params) {
		const parameter_type& param = traits::create_parameter(params);
		return filter_type(param);
	}

	/**
	 * Attach this filter, if the enum id matches.
	 */
	template<typename Chain> static void try_attach(Chain& chain, const filter_pair& pair) {
		if (F == pair.first) {
			// hack to handle illegal filters being added to chains 
			// (e.g. output filter to input chain)
			filter_pusher<typename Chain::mode, filter_mode>::push(chain, construct(pair.second));
			return;
		}
		filter_factory<(filter_t) (F+1)>::try_attach(chain, pair);
	}

private:
	// forbidden operations	 
	filter_factory();
	filter_factory(const filter_factory&);
	filter_factory& operator=(const filter_factory&);
};

/**
 * Partial specialization to end recursion.
 */
template<typename Traits> class filter_factory<FILTER_END, Traits> {
public:
	template<typename Chain> static void try_attach(const Chain&, const filter_pair&) {
		throw std::invalid_argument("unsupported filter");
	}		 

	template<typename Func> static void apply(const Func&) {
		// do nothing
	}
};

/**
 * Given a list of filter/parameter pairs, attempt to attach them all
 * to an io::chain.
 * The filters are pushed onto the chain in ... order. (FIXME)
 */
template<typename Chain> void attach_filters(Chain& chain, const filter_list& filters)
{
	for (filter_list::const_iterator i = filters.begin(),
					 e = filters.end();
					 i != e;
					 ++i) {
		filter_factory<FILTER_START>::try_attach(chain, *i);
	}
}

/**
 * BinaryFunction to be used with std::accumulate() to append each filter's 
 * file extension to a string.
 */
struct filter_ending_appender {
	std::string operator()(std::string& a, const filter_pair& b) const {
		a += '.';
		a += filter_file_extension(b.first);
		return a;
	}
};

/**
 * Check if filter does IO in a certain mode (binary vs. text).
 */
class is_filter_io_mode {
	const filter_mode 	mode;
public:
	is_filter_io_mode(filter_mode m) : mode(m) { }
	bool operator()(const filter_pair& b) {
		return filter_io_mode(b.first) == mode;
	}
};

/**
 * Gathers stats on number of the types of filters.
 */
struct filter_kind_stats {
	util::array<unsigned, LAST_FILTER_KIND>	count;

	filter_kind_stats() {
		count.assign(0);
	}
	
	void operator()(const filter_pair& b) {
		filter_kind fk = filter_work_kind(b.first);
		++count[fk];
	}
};
} /* namespace io */
#endif /* __IO_FILTERS_H */

