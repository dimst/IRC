/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/exceptions.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_EXCEPTIONS_H
#define __IO_EXCEPTIONS_H

#include <stdexcept>
#include "util/exception.h"

namespace io {

struct io_exception_tag {};

typedef util::exception<io_exception_tag, std::runtime_error>	 	io_exception;


}
#endif /* __IO_EXCEPTIONS_H */
