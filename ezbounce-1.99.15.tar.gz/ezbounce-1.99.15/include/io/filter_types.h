/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/filter_types.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_FILTER_TYPES_H
#define __IO_FILTER_TYPES_H

#include <utility>
#include <string>
#include <vector>

namespace io {

/**
 * The various filter types (potentially) available.
 */
enum filter_t {
	GZIP_COMPRESSOR = 0,
	GZIP_DECOMPRESSOR,
	BZIP2_COMPRESSOR,
	BZIP2_DECOMPRESSOR,
	BLOCK_ENCRYPTION_FILTER,
	BLOCK_DECRYPTION_FILTER,
	LAST_FILTER
};

/**
 * Properties of these filters.
 */
enum filter_kind {
	COMPRESSOR,
	DECOMPRESSOR,
	ENCRYPTER,
	DECRYPTER,
	OTHER,
	LAST_FILTER_KIND
};

enum filter_mode {
	TEXT_MODE,
	BINARY_MODE
};

/**
 * Controls template recursion in factory class
 */
#ifdef HAVE_BOOST_IOSTREAMS
const filter_t FILTER_START = GZIP_COMPRESSOR;
const filter_t FILTER_END   = BZIP2_COMPRESSOR;
#else
const filter_t FILTER_START = LAST_FILTER;
const filter_t FILTER_END   = LAST_FILTER;
#endif

const filter_t INVALID_FILTER = LAST_FILTER;

typedef std::pair<filter_t, std::string>	filter_pair;
typedef std::vector<filter_pair>		filter_list;

} /* namespace io */
#endif /* __IO_FILTER_TYPES_H */

