/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/poll_engine.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_POLL_ENGINE_H
#define __IO_POLL_ENGINE_H

#include <vector>
#include "io/engine.h"
#include "io/pollable.h"
#include "io/event.h"

#ifdef HAVE_POLL_H
#	include <poll.h>
#elif HAVE_SYS_POLL_H
#	include <sys/poll.h>
#else
#	error ezbounce CANNOT be compiled without the poll() system call.
#endif /* HAVE_POLL_H */

#include "debug.h"

/**
 * tricks needed to get STL stuff to work 
 * NOTE: keep in global namespace 
 */
inline bool operator == (const struct pollfd &a, const struct pollfd &b) 
{ 
	return a.fd == b.fd; 
}

inline bool operator < (const struct pollfd &a, const struct pollfd &b)
{
	return a.fd < b.fd;
}


namespace io {

/**
  * IO engine that uses poll() system call
  */
class poll_engine : public engine {
private:
	static const struct pollfd blank_pollfd;
	std::vector<struct pollfd> pollfds;
	int highest_fd;

public:
	explicit poll_engine(unsigned size = engine::DEFAULT_INITIAL_CAPACITY, time_t * = NULL); 
	virtual ~poll_engine();
	virtual int add(pollable *, int);
	virtual int release(pollable *);
	virtual void set_events(pollable *, int);
	virtual void compress();
	virtual int poll(int);

private:
	/**
	  * Translate event flags to poll() event flags
	  */
	static short to_poll_events(int i) {
		short out = 0;
		if (i & EVENT_READ) {
			out |= POLLIN;
		}
		if (i & EVENT_WRITE) {
			out |= POLLOUT;
		}
		// XXX: poll() won't accept these as input
		//--------------------------------------------------
		// if (i & EVENT_ERROR) {
		// 	out |= POLLHUP | POLLERR;
		// }
		//-------------------------------------------------- 
		return out;
	}

	/**
	  * Translate poll() event flags into ours
	  */
	static int to_io_events(short i) {
		int out = 0;
		if (i & POLLIN) {
			out |= EVENT_READ;
		}
		if (i & POLLOUT) {
			out |= EVENT_WRITE;
		}
		if (i & (POLLERR | POLLHUP)) {
			out |= EVENT_ERROR;
		}
		return out;
	}

private:
	/* Forbidden */
	poll_engine(const poll_engine &);
	poll_engine& operator = (const poll_engine&);
};

}  /* namespace io */
#endif	/* __IO_POLL_ENGINE_H */
