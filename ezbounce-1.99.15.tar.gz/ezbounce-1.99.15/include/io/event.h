/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/event.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_EVENT_H
#define __IO_EVENT_H

namespace io {

enum event {
	EVENT_NONE  = 0,
	EVENT_READ  = 1,
	EVENT_WRITE = 2,
	EVENT_ERROR = 4
};

}  /* namespace io */
#endif	/* __IO_EVENT_H */
