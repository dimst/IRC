/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/pollable.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __IO_POLLABLE_H
#define __IO_POLLABLE_H
 
#include "io/event.h"

namespace io {

class pollable {
private:
	int fd;
	short events;

	friend class engine;	

protected:
	void set_fd(int f) {
		fd = f;
	}
	void set_events(short events) {
		this->events = events;
	}

public:
	int get_fd() const {
		return fd;
	}
	short get_events() const {
		return events;
	}

public:
	pollable() : fd(-1), events(EVENT_NONE) { }
	explicit pollable(int f, short e = EVENT_NONE) :
			fd(f), events(e) { }
	virtual ~pollable() {}
	virtual int event_callback(int) = 0;
};

} /* namespace net */
#endif  /* __IO_POLLABLE_H */
