/**
  * commands.h
  */
#ifndef __COMMANDS_H
#define __COMMANDS_H

#include "conn.h"

class textline;

typedef int (conn::*cmd_handler_t)(int, const textline &);

struct cmd {
	const char * msg;                 /* the actual command */
	int id;                           /* numerical id */
	int req_flags;                    /* flags to match */
	int bad_flags;                    /* flags that we can't have */
	/* pointer to handler function */
	cmd_handler_t handler;
	const char * help;
};

extern const struct cmd command_table[];
extern const struct cmd incoming_command_table[];

/* Commands from clients */
enum {
	CMD_USER,   		CMD_NICK,   	CMD_PASS,   	
	CMD_KILL,   		CMD_DIE,    	CMD_REHASH, 	
	CMD_INTERFACE,  	CMD_VHOSTS, 	CMD_WRITE,      
	CMD_DISCONNECT, 	CMD_IDENT,                  	
	CMD_MOTD, 		CMD_QUIT,   			
	CMD_HASH,   
	CMD_TRAFFIC,    	CMD_WHOIS,  
	CMD_TRACE,  		CMD_ALLOWED,            	
	CMD_VERSION,    	CMD_CHATSEND,
	CMD_ZOMBIFY,    	CMD_FILE,   			
	CMD_CONN,       	CMD_STATUS,
	CMD_DIENOW,     	CMD_CANCEL, 
	CMD_HELP,
	CMD_DETACH, 		CMD_REATTACH,
	CMD_LOG,
	CMD_EZBOUNCE,		
	CMD_LOGIN,      	CMD_SESSIONS,
	CMD_SET,        	CMD_GET,
	CMD_UNSET,		CMD_ISSET,
	CMD_PREFS,		CMD_OPTIONS,
	CMD_ECHO,   		CMD_SAVE,
	CMD_RELOAD,     	CMD_DEBUG,  
	CMD_ABOUT,

	CMD_DCC,        	CMD_WHO,    
	CMD_ACACHE,		CMD_SERVINFO,
	CMD_PRIVMSG,		CMD_NOTICE,
	CMD_CHANINFO,
	CMD_PROTOCTL,		CMD_CAP,
	CMD_MODE,
	

	CMD_RECONNECT		// DEBUG only
};

/* Commands parsed from IRC server */
enum {
	INCOMING_001 = 100,
	INCOMING_003,	    INCOMING_004,       INCOMING_005,
	INCOMING_PRIVMSG,   INCOMING_MODE,      INCOMING_NICK,
	INCOMING_JOIN,      INCOMING_PART,      INCOMING_KICK,
	INCOMING_TOPIC,     INCOMING_NOTICE,    INCOMING_QUIT,
	INCOMING_PING,      INCOMING_PONG,      INCOMING_ERROR,
	INCOMING_352,		/* WHO reply */
	INCOMING_315,		/* End of WHO */
	INCOMING_353,	    	/* NAMES reply */
	INCOMING_366,		/* End of NAMES */

	INCOMING_324,		/* MODE (output of /MODE) */

	INCOMING_332,		/* Channel TOPIC */
	INCOMING_333,		/* Channel TOPIC information: setter and time */

	INCOMING_375,		/* MOTD Start */
	INCOMING_422,		/* No MOTD */

	INCOMING_432,		/* Illegal nickname */
	INCOMING_433,		/* Nickname in use */

	INCOMING_403,		/* Channel doesn't exist, or channel name illegal */
	INCOMING_405,		/* Too many channels */
	INCOMING_470,		/* Cannot join, but forwarding to another channel */
	INCOMING_471,		/* Channel full */
	INCOMING_473,		/* Channel invite only (+i) */
	INCOMING_474,		/* Banned from channel */
	INCOMING_475,		/* Channel key required */
	INCOMING_477,		/* Need registered nick (+r) to join channel (asuka, UnrealIRCD, others?) */
	INCOMING_479,		/* Channel G-Lined (asuka), illegal channel name (hybrid, others?) */
};

#endif /* __COMMANDS_H */

