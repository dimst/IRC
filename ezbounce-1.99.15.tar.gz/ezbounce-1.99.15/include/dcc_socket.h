/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * dcc_socket.h -- Part of the ezbounce IRC proxy
 * (C) 2007 Murat Deligonul
 */

#ifndef __DCC_SOCKET_H
#define __DCC_SOCKET_H

#include "net/socket.h"

// forward declaration
class dcc;

/** 
 * The socket class used by all DCCs 
 */
class dcc_socket : public net::socket {
private:
	dcc *			_owner;
	int 			_role;

public:
	/** 
	 * Create socket from scratch 
	 */
	dcc_socket(dcc * o, int r, 
			int min = net::socket::BUFFER_MINIMUM, 
			int max = net::socket::BUFFER_MAXIMUM)
		: net::socket(PF_UNSPEC, 0, min, max), 
		_owner(o), _role(r) { }

	/**
	 * accept() a connection 
	 */
	dcc_socket(dcc * o, dcc_socket * source, int r,
			int min = net::socket::BUFFER_MINIMUM, 
			int max = net::socket::BUFFER_MAXIMUM) 
		: net::socket(source, min, max), 
		_owner(o), _role(r) { }

	dcc * owner() { 
		return _owner; 
	}
	int role() const { 
		return _role; 
	}

	/**
	 * Event handlers 
	 */
	virtual int on_readable();
	virtual int on_writeable();
	virtual void on_connect();
	virtual void on_connect_fail(int);
	virtual void on_disconnect(int);

private:
	// non-copyable
	dcc_socket(const dcc_socket&);
	dcc_socket& operator= (const dcc_socket&);
};

#endif /* __DCC_SOCKET_H */
