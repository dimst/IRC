/**
 * compiler_bugs.h
 */

#ifndef __COMPILER_BUGS_H
#define __COMPILER_BUGS_H

/**
  * GCC 3.0 or later is required.
  * 2.95 has compiler bugs and incomplete support for ISO C++.
  */
#ifdef __GNUC__
#   if __GNUC__ < 3
#	error "Your GCC is too old"
#	error "GCC 3.0 or later is required to compile ezbounce"
#   endif
#endif

/**
 * GCC < 3.4.0 has problems with using statements, private inheritance 
 * and templated base classes.
 */
#ifdef __GNUC__
#	if __GNUC__ == 3 && __GNUC_MINOR__ <= 3
#		define __conditional_private	public
#	else
#		define __conditional_private	private
#	endif
#endif

/**
 * GCC < 3.4.0 does not honor template member friends.
 */
#ifdef __GNUC__
#	if __GNUC__ == 3 && __GNUC_MINOR__ < 4
#		define GCC_NO_MEMBER_TEMPLATE_FRIENDS
#	endif
#endif

#endif
