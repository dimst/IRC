/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * dcc_offer.h -- Part of the ezbounce IRC proxy
 * (C) 2007-2008 Murat Deligonul
 */

#ifndef __DCC_OFFER_H
#define __DCC_OFFER_H

#include <string>
#include "util/tracked_object.h"
#include "util/expirable_object.h"
#include "util/managed_table.h"
#include "net/types.h"

#include "debug.h"

class dcc;
class conn;

class dcc_offer : public util::tracked_object<dcc_offer>, public util::expirable_object<dcc_offer> {
public:
	enum dcc_offer_flag {
		DEAD     	= 0,
		INCOMING 	= 1,
		OUTGOING 	= 2,
		RESUMABLE 	= 4,
	};
	
	enum dcc_offer_info {
		FROM 		= 0,
		TO,
		TYPE,
		FILENAME,
		NUM_STRINGS
	};

private:
	util::managed_table<std::string, NUM_STRINGS> 		data;
	net::ap_pair						host_data;
	const time_t 						_start;
	conn * 							_owner;
	int 							_flags;
	unsigned int 						_id;
	unsigned int 						_size;
	unsigned int 						_offset;
	
public:
	// basic constructor
	dcc_offer(conn *, const char * type, const net::ap_pair &,
			const char * from, const char * to, int f);
	// for sends
	dcc_offer(conn *, const char * type, const net::ap_pair &,
			const char * from, const char * to,
			const char * file, unsigned int size, unsigned int offset, int f);
	~dcc_offer();
	
	int flags() const { 
		return _flags; 
	}

	unsigned int id() const { 
		return _id; 
	}
	unsigned int   size() const { 
		return _size; 
	}
	unsigned int   offset() const { 
		return _offset; 
	}
	unsigned short port() const { 
		return host_data.second; 
	}

	const char * address() const { 
		return host_data.first.c_str();
	}
	const char * type() const { 
		return data.get(TYPE).c_str(); 
	}
	const char * to() const { 
		return data.get(TO).c_str(); 
	}
	const char * from() const { 
		return data.get(FROM).c_str(); 
	}
	const char * filename() const { 
		return data.get(FILENAME).c_str(); 
	}
	conn * owner() const { 
		return _owner; 
	}
	time_t age(time_t now) const { 
		return now - _start; 
	}
	time_t start_time() const { 
		return _start; 
	}

	void set_host_data(const net::ap_pair& ap) {
		host_data = ap;
	}
	void set(dcc_offer_info i, const char * str) { 
		data.set(i, str); 
	}
	void set_owner(conn * o) {
		DEBUG("dcc_offer::set_owner() [%p] %p ---> %p\n", this, _owner, o);    
		_owner = o;
	}

	std::string info() const;
	std::string full_info() const;

	/**
	 * expirable_object<T> interface requirements 
	 */	
	int status_check(time_t, const void ** = NULL) const;
	int die(int, const void *);

protected:
	void set_flags(int f)  { 
		_flags = f; 
	}

	friend void swap_dcc_ids(dcc *, dcc_offer *);

private:
	// non-copyable
	dcc_offer(const dcc_offer&);
	dcc_offer& operator = (const dcc_offer&);
};

#endif
