/**
  * ruleset.h
  * part of ezbounce
  */

#ifndef __RULESET_H
#define __RULESET_H

#include <vector>
#include "util/strings.h"
#include "util/counted_object.h"
#include "debug.h"

/* 
 *  holds information stored in
 *  allow|deny {
 *     from ...
 *     to ...
 *  }
 *  blocks in the configuration file
 */

class ruleset : public util::counted_object<ruleset> {
public:
	enum host_type {
	     FROM, 
	     TO
	};

	static const int  UNLIMITED;
	
	ruleset() : num_registered_to(0), num_registered_from(0), obsolete(false) { }
	virtual ~ruleset();
	
	/* check if this user is permitted to connect to the server*/
	virtual int is_allowed(const char * host, const char * ip, 
					unsigned short port, 
					char *, size_t) const = 0;
	/* check if this user may connect to "to" */
	virtual int is_allowed_to(const char *to, const char * to_ip,
					unsigned short, 
					char *, size_t) const = 0;
	/* checks if host & port are in its list of addresses */
	virtual bool does_match(const char *, const char *, 
				unsigned short, host_type t) const = 0;
	
	/* add a host name to the list of hosts that can connect */
	virtual int add_host_from(const char *address, const char *ports,
				const char *reason, int max);
				
	/* add a host name to the list of places users can connect to */
	virtual int add_host_to(const char *address, const char *ports,
				const char *reason, int max);
	
	virtual int register_connection(host_type, const char * host, const char * ip, 
					unsigned short);
					
	virtual int unregister_connection(host_type, const char * host, const char * ip, 
					unsigned short);

	virtual bool is_legal() const = 0;
	

	bool operator == (const ruleset &) const;
	bool dead() const { return (obsolete && !num_registered_to && !num_registered_from); }
	bool is_obsolete() const { return obsolete; }

	static std::vector<ruleset *> * sync_lists(std::vector<ruleset *> *, std::vector<ruleset *> *);

protected:

	struct rsh_comp_helper
	{
		const char * host;
		const char * ip;
		unsigned short port;
		rsh_comp_helper(const char *h, const char *i, unsigned short p) 
			: host(h), ip(i), port(p) { }
	};

	struct rs_host 
	{
		char * pattern;
		char * ports;
		char * reason;
		host_type type;
		int  max, num;
		~rs_host();
		rs_host(host_type, const char *, const char *, const char *, int);
		rs_host(const rs_host &);
		
		/**
		  * Comparison function with helper struct: used for finding rulesets
		  * matching a given address/port combination. 
                  */		  
		bool operator == (const rsh_comp_helper &rh) const {
			return (!smart_match(rh.host, rh.ip, pattern) && port_in_set(ports, rh.port));
		} 

		/**
		  * Standard comparison method.
		  * NOTE: does not compare 'num' fields.
		  */
		bool operator == (const rs_host &that) const {
			using util::strings::safe_strcasecmp;
			return (type == that.type &&
					max == that.max &&
					safe_strcasecmp(pattern, that.pattern) == 0 &&
					safe_strcasecmp(reason, that.reason) == 0 &&
					safe_strcasecmp(ports, that.ports) == 0);
		}
	};

	friend class rs_host;
	std::vector<rs_host> from_hosts;
	std::vector<rs_host> to_hosts;    
private:
	/* these keep track of register_connection() and unregister_connection calls */
	unsigned int num_registered_to;
	unsigned int num_registered_from;
	bool 		obsolete;
	
	static int smart_match(const char *, const char *, const char *); 
	static bool port_in_set(const char *, unsigned short);
	static bool is_ip_pattern(const	char *);

private:
	ruleset(const ruleset& );
	ruleset& operator= (const ruleset& );
};

class allowed_ruleset : public ruleset {
public:
	int is_allowed(const char *, const char *, unsigned short, char *, size_t) const ;
	int is_allowed_to(const char *, const char *, unsigned short, char *, size_t) const ;
	int register_connection(host_type, const char *, const char *, unsigned short);
	int unregister_connection(host_type, const char * , const char *, unsigned short);
	bool does_match(const char *, const char *, unsigned short port, host_type t) const;
	bool is_legal() const;
};

class denied_ruleset : public ruleset {
public:
	int is_allowed(const char *, const char *, unsigned short, char *, size_t) const;
	int is_allowed_to(const char *, const char *, unsigned short, char *, size_t) const ;
	bool does_match(const char *, const char *, unsigned short port, host_type t) const;
	bool is_legal() const;
};

#endif
