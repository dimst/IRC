/**
 * reconnect.h
 *
 * part of ezbounce
 * (c) 2007-2008 Murat Deligonul
 */

#ifndef __RECONNECT_H
#define __RECONNECT_H

#include <string>
#include <utility>
#include <map>
#include <vector>
#include <algorithm>
#include "util/generic.h"
#include "util/strings.h"
#include "irc/server_entry.h"
#include "irc/channel.h"
#include "debug.h"

class reconnect_info {
public:
	// channels are stored as a <channel name, channel key> pair.
	typedef std::pair<std::string, std::string> 		channel_entry;
	typedef std::map<std::string, std::string>		channel_map;

private:
	std::map<std::string, std::string>	target_channels;		// channels to rejoin
	std::vector<std::string>		succeeded_channels;		// channels successfully rejoined
	std::vector<std::string>		failed_channels;		// channels we couldn't join

	irc::server_entry		last_server;
	int				tries;
	const int			max_tries;
	const int			delay;

public:
	reconnect_info(const irc::server_entry& se, int m, int d) : last_server(se), tries(0),
       									max_tries(m), delay(d) { 
		assert(delay >= 3);
		assert(max_tries > 0);
	}

	int get_delay() const {
		return delay;
	}
	int get_max_tries() const {
		return max_tries;
	}
	int get_tries() const {
		return tries;
	}
	void inc_tries() {
		++tries;
	}

	size_t num_succeeded() const {
		return succeeded_channels.size();
	}
	size_t num_failed() const {
		return failed_channels.size();
	}

	const irc::server_entry& get_server() const {
		return last_server;
	}
	void set_server(const irc::server_entry& se) {
		last_server = se;
	}

	void add_failed(const char * name) {
		failed_channels.push_back(name);
	}
	void add_succeeded(const char * name) {
		succeeded_channels.push_back(name);
	}

	void reset_succeeded() {
		succeeded_channels.clear();
	}
	void reset_failed() {
		failed_channels.clear();
	}

	const std::map<std::string, std::string>& channels() const {
		return target_channels;
	}
	bool has_target(const char * name) {
		return target_channels.find(name) != target_channels.end();
	}

	// Adds channels to the target channel list
	template<typename InputIterator> void add_channels(InputIterator, InputIterator);

private:
	/* forbidden */
	reconnect_info(const reconnect_info &);
	reconnect_info& operator =(const reconnect_info &);
};


template<typename InputIterator> void reconnect_info::add_channels(InputIterator begin, InputIterator end)
{
	using util::strings::non_null;
	using irc::channel;
	using std::string;
	for (; begin != end; ++begin) {
		channel * c = *begin;

		assert(!has_target(c->name()));
		const char * key = non_null(c->get_valued_mode('k'));
		target_channels.insert( std::make_pair(string(c->name()), string(key)));
	}	
}
	
#endif
