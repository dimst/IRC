/**
 * ezbounce.h 
 */

#ifndef __EZBOUNCE_H
#define __EZBOUNCE_H

/**
 * Hacks for special test mode.
 */
#ifdef __TEST__
	#define main	ezbounce_main
#endif


extern const char EZBOUNCE_VERSION[];
extern const char EZBOUNCE_BUILD[];

// TODO: move this out
#define EZB_PREF_FILE_VERSION 2.00

#endif /* __EZBOUNCE_H */
