/**
 * messages.h
 *
 * I moved some of the proxy messages here.  Perhaps one day, 
 * if all the messages are here, there will be possibilities
 * for foreign language versions of ezbounce.
 *
 * NOTE: these are just declarations.  For actual definitions,
 * see src/help.cc and src/messages.cc
 */

#ifndef __MESSAGES_H
#define __MESSAGES_H

#define EZBOUNCE_HEADER "ezbounce!srv"

/**
  * Defined in messages.cc
  */
extern const char MSG_BANNED[];
extern const char MSG_CONN_SUCCESSFUL[];
extern const char MSG_NOT_AUTHORIZED[];
extern const char MSG_INSUFFICIENT_ARGS[];

extern const char MSG_STATUS_UPTIME[];
extern const char MSG_STATUS_CONNECTIONS[];
extern const char MSG_STATUS_CPUTIME[];
extern const char MSG_STATUS_LISTHEADER[];

extern const char MSG_DIEING[];
extern const char MSG_DIEING_NOW[];

extern const char MSG_TOO_MANY_FAILURES[];

 
#define HELP_ENTRY(x,y) const char __##x##_help[] = (y)
#define __HELP_ENTRY(x) __##x##_help
#define DECLARE_HELP_ENTRY(x) extern const char  __##x##_help[]

DECLARE_HELP_ENTRY(user);
DECLARE_HELP_ENTRY(nick);
DECLARE_HELP_ENTRY(pass);
DECLARE_HELP_ENTRY(conn);
DECLARE_HELP_ENTRY(status);
DECLARE_HELP_ENTRY(kill);
DECLARE_HELP_ENTRY(die);
DECLARE_HELP_ENTRY(rehash);
DECLARE_HELP_ENTRY(reload);
DECLARE_HELP_ENTRY(dienow);
DECLARE_HELP_ENTRY(cancel);
DECLARE_HELP_ENTRY(help);
DECLARE_HELP_ENTRY(vhost);
DECLARE_HELP_ENTRY(vhosts);
DECLARE_HELP_ENTRY(write);
DECLARE_HELP_ENTRY(detach);
DECLARE_HELP_ENTRY(reattach);
DECLARE_HELP_ENTRY(disconnect);
DECLARE_HELP_ENTRY(ident);
DECLARE_HELP_ENTRY(log);
DECLARE_HELP_ENTRY(motd);
DECLARE_HELP_ENTRY(quit);
DECLARE_HELP_ENTRY(ezbounce);
DECLARE_HELP_ENTRY(hash);
DECLARE_HELP_ENTRY(login);
DECLARE_HELP_ENTRY(sessions);
DECLARE_HELP_ENTRY(traffic);
DECLARE_HELP_ENTRY(whois);
DECLARE_HELP_ENTRY(set);
DECLARE_HELP_ENTRY(unset);
DECLARE_HELP_ENTRY(isset);
DECLARE_HELP_ENTRY(get);
DECLARE_HELP_ENTRY(echo);
DECLARE_HELP_ENTRY(save);
DECLARE_HELP_ENTRY(trace);
DECLARE_HELP_ENTRY(allowed);
DECLARE_HELP_ENTRY(command_list);
DECLARE_HELP_ENTRY(about);
DECLARE_HELP_ENTRY(version);
DECLARE_HELP_ENTRY(debug);
DECLARE_HELP_ENTRY(file);
DECLARE_HELP_ENTRY(dcc);
DECLARE_HELP_ENTRY(prefs);
DECLARE_HELP_ENTRY(options);
DECLARE_HELP_ENTRY(logging);
DECLARE_HELP_ENTRY(config);
DECLARE_HELP_ENTRY(vfs);
DECLARE_HELP_ENTRY(servinfo);
DECLARE_HELP_ENTRY(chaninfo);
DECLARE_HELP_ENTRY(reconnection);

#endif
