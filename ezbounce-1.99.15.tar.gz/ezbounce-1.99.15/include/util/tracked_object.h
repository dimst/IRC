/**                                                                        
 * This program is free software; you can redistribute it and/or modify  
 * it under the terms of the GNU General Public License as published by  
 * the Free Software Foundation; either version 2 of the License, or     
 * (at your option) any later version.                                   
 *                                                                         
 * util/tracked_object.h
 * Part of ezbounce
 * (c) 2007 Murat Deligonul
 */

#ifndef __UTIL_TRACKED_OBJECT_H
#define __UTIL_TRACKED_OBJECT_H

#include <cstddef>
#include <list>
#include "util/scoped_setter.h"
#include "util/generic.h"

#include "debug.h"

namespace util {


/**
 * When used as a based class, tracks all instances, provide methods to delete 
 * all or some of the entries.
 * NOTE: this is intended for objects allocated on the heap only.
 */
template<class T> class tracked_object {
public:
	typedef T *						value_type;
	typedef	std::list<T *>					container_type;
	typedef typename std::list<T *>::iterator		iterator;
	typedef typename std::list<T *>::const_iterator		const_iterator;

private:
	static std::list<T *> 		_objects;
	static bool 			removal_lock;
	
public:
	tracked_object() {
		_objects.push_back(static_cast<T*>(this));
	}
	tracked_object(const tracked_object&) {
		_objects.push_back(static_cast<T*>(this));
	}
	~tracked_object() {
		if (!removal_lock) {
			_objects.remove(static_cast<T *>(this));
		}
	}

	static size_t count() {
		return _objects.size();
	}
	
	/**
	 * Instance list access functions.
	 */
	static const std::list<T *>& objects() {
		return _objects;
	}

	template<typename Predicate> static void delete_if(Predicate pred) {
		scoped_setter<bool> st(removal_lock, true);
		assert(removal_lock);
		
		iterator i = _objects.begin(), 
			       e = _objects.end();
		while (i != e) {
			if (pred(*i)) {
				delete *i;
				i = _objects.erase(i);
			}
			else {
				++i;
			}
		}
		/* removal_lock set to false once again */
	}
	
	static void delete_all() {
		delete_if(always<true>());
		assert(!removal_lock);
		assert(_objects.empty());
	}
};

// static variable definitions
template<class T> std::list<T *> tracked_object<T>::_objects;
template<class T> bool tracked_object<T>::removal_lock = false;

}
#endif /* __UTIL_TRACKED_OBJECT_H */
