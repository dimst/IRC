/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * util/strings.h
 * (c) 1998-2008 Murat Deligonul
 */

#ifndef __UTIL_STRINGS_H
#define __UTIL_STRINGS_H

#include <string>
#include <cstring>
#include <cstdarg>
#include <ctime>
#include "debug.h"

namespace util {
  namespace strings {

extern int   wild_match(const char *, const char *);

extern char * my_strdup(const char *);
extern char * my_strdup2(const char *, const char *);
extern char * my_strdup3(const char *, const char *, const char *);
extern size_t my_strlcpy(char *, const char *, size_t);
extern int    safe_strcasecmp(const char *, const char *);

extern int    my_asprintf(char **, const char *, ...);
extern int    my_sprintf(std::string &, const char *, ...);
extern int    my_vasprintf(char **, const char *, va_list);
extern std::string my_sprintf(const char *, ...);

extern std::string escape_quotes(const std::string&);

extern std::string& duration(std::string&, time_t, bool);
extern std::string& timestamp(std::string&, const char *, time_t = 0);
extern std::string& timestamp_full(std::string&, time_t = 0);

extern const char * no_leading(const char *);
inline char * no_leading(char * orig) {
	return const_cast<char *>(no_leading((const char *) orig));
}

extern std::string&  to_lowercase(std::string &);
extern std::string&  to_uppercase(std::string &);
extern char * to_lowercase(char *);
extern char * to_uppercase(char *);

extern bool check_bool(const char *, bool *);
extern bool check_on_off(const char *, bool *);
extern bool check_int(const char *, int *);

extern bool is_non_empty(const char *);

// XXX: to be removed 
struct simple_table {
	const char * str;
	int id;
};

// XXX: to be removed
inline int simple_table_lookup(const char * str, const struct simple_table * table, size_t size) {
	for (unsigned i = 0; i < size; ++i) {
		if (!strcasecmp(str, table[i].str)) {
			return table[i].id;
		}
	}
	return -1;
}

/**
 * See if a string matches any in a basic string table.
 * Return the index, or -1 if not found.
 * XXX: to be removed
 */
inline int simple_table_lookup(const char * str, const char ** strings, size_t size) {
	for (unsigned i = 0; i < size; ++i) {
		if (!strcasecmp(str, strings[i])) {
			return i;
		}
	}
	return -1;
}


/**
 * Returns the source string or a pointer to the empty string, if the
 * source string is a null pointer.
 */
inline const char * non_null(const char * src) {
	return (src != NULL) ? src : "";
}

/**
 * Return index of a character, or -1 if the character was not found.
 */
inline int index_of(const char * str, char c) {
	if (c == 0) {
		return -1;
	}
	const char * p = strchr(str, c);
	return (p != NULL) ? (p-str) : -1;
}

inline const char * yesno(int i) {
	return i ? "yes" : "no";
}

inline const char * true_false(bool b) {
	return b ? "true" : "false";
}

  } /* namespace strings */
} /* namespace util */

#endif  /* __UTIL_STRINGS_H */
