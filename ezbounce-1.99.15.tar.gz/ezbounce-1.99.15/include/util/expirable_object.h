/**
 * util/expirable_object.h
 *
 * (c) 2007 Murat Deligonul
 */
#ifndef __UTIL_EXPIRABLE_OBJECT_H
#define __UTIL_EXPIRABLE_OBJECT_H

#include <ctime>

namespace util {

/**
 * When used as a base class, provides status_check() and die() functions to 
 * manage object lifetimes.  The functions are implemented with a template trick
 * to avoid the need for dynamic binding (and hence the overhead for a vtable).
 * It may also be useful to make class T's destructor non-public since use of
 * this class implies the need for controlled deletion.
 */
template<class T> struct expirable_object {
	/**
	 * Return codes from status_check():
	 *   < 0   -- object is dead, delete it
	 *     0   -- active object
         *   > 0   -- object is idle, call die() and then delete it
	 */
	int status_check(time_t t, const void ** data) const {
		return static_cast<const T *>(this)->status_check(t, data);
	}

	/**
	 * Effectively place the object in a 'zombie' state, ready for deletion.
         * Must ignore additional die requests while in the 'zombie' state.
	 * Must not delete the object itself.
	 */
	int die(int i, const void * data) {
		return static_cast<T *>(this)->die(i, data);
	}
};

}
#endif /* __UTIL_EXPIRABLE_OBJECT_H */
