/** 
 * util/iterators.h
 *
 * (c) 2007 Murat Deligonul
 */
 
#ifndef __UTIL_ITERATORS_H
#define __UTIL_ITERATORS_H

#include "util/tr1.h"
#include "util/type_chooser.h"

namespace util {

/**
 * Iterator that wraps a map's pair-based iterator and 
 * returns only the values.
 */
template<typename Iter> class map_value_iterator {
	Iter i;
public:
	//
	// ugh .. lots of template tricks, but it works
	typedef typename Iter::value_type::second_type			value_type;
	typedef typename remove_pointer<typename Iter::pointer>::type	pair_type;

	typedef typename type_chooser<is_const<pair_type>::value, 
		const value_type, 
		value_type>::type *     				pointer;

	typedef typename type_chooser<is_const<pair_type>::value, 
		const value_type, 
		value_type>::type &    					reference;

	typedef std::forward_iterator_tag				iterator_category;
	typedef typename Iter::difference_type				difference_type;

	// constructor
	explicit map_value_iterator(const Iter& _i) : i(_i) { }

	reference operator*() {
		return (*i).second;
	}

	pointer operator->() {
		return &((*i).second);
	}

	map_value_iterator& operator++() {
		++i;
		return *this;
	}

	map_value_iterator operator++(int) {
		map_value_iterator tmp(*this);
		++i;
		return tmp;
	}

	bool operator == (const map_value_iterator& that) const {
		return this->i == that.i;
	}

	bool operator != (const map_value_iterator& that) const {
		return this->i != that.i;
	}
};

/**
 * Helper function.
 */
template<typename Iter> inline map_value_iterator<Iter> make_value_iterator(const Iter& i) {
	return map_value_iterator<Iter>(i);
}

} /* namespace util */
#endif /* __UTIL_ITERATORS_H */
