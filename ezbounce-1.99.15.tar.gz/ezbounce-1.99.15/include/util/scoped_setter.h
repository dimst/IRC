/**
 * util/scoped_setter.h
 *
 * (c) 2007 Murat Deligonul
 */
#ifndef __UTIL_SCOPED_SETTER_H
#define __UTIL_SCOPED_SETTER_H

namespace util {

/**
 * Assigns a value to a variable, saving the old value and reassigning
 * it when the scoped_setter goes out of scope.
 */
template<typename T> class scoped_setter
{
private:
	T& 		var;
	T const		old_value;
public:
	scoped_setter(T& v, T new_value) : 
		var(v), old_value(v) {
			var = new_value;
		}

	~scoped_setter() {
		var = old_value;
	}

private:
	scoped_setter(const scoped_setter&);
	scoped_setter& operator = (const scoped_setter&);
};

// this would be more useful if we didn't explicitly specify the type 
#define SCOPED_SET(type, var, val) util::scoped_setter<type> var##_setter(var, val)
}
#endif /* __UTIL_SCOPED_SETTER_H */
