/** 
 * util/generic.h
 *
 * (c) 2005-2008 Murat Deligonul
 */
 
#ifndef __UTIL_GENERIC_H
#define __UTIL_GENERIC_H

#include <string>
#include <sstream>
#include <iterator>
#include <functional>
#include <utility>
#include "util/strings.h"

namespace util {

/**
 * Allows deletion of pointers with e.g. for_each()
 */
struct delete_ptr {
	template<typename T> void operator()(T& p) const { 
		delete p; 
	}
};

struct delete_array {
	template<typename T> void operator()(T& p) const { 
		delete[] p; 
	}
};

/**
 * Allows functor to be used on second member of a pair.
 */
template<typename Func> class apply_second {
	Func fn;
public:
	apply_second(const Func& f = Func()) : fn(f) { }

	template<typename K, typename V> void operator()(std::pair<K, V>& p) {
		fn(p.second);
	}

	template<typename K, typename V> void operator()(const std::pair<K, V>& p) {
		fn(p.second);
	}
};

/**
 * Predicate that always returns true or false.
 */
template<bool Value> struct always {
	template<typename T> bool operator()(const T& ) const {
		return Value;
	}

	template<typename T> bool operator()(const T&, const T&) const {
		return Value;
	}
};

/**
 * clamp() - restrict var to the range [min, max]
 */
template<typename T> inline void clamp(T& var, const T& floor, const T& ceil) {
	assert(floor <= ceil);
	var = std::min<T>(std::max<T>(var, floor), ceil);
}

/**
 * in_range() -- check if value is within [min, max] range
 */
template<typename T> inline bool in_range(T var, T min, T max) {
	assert(min <= max);
	return (var >= min) && (var <= max);
}

/**
  * copy_if(): stupidly omitted from C++ Standard.
  */
template<typename In, typename Out, typename Pred> 
	Out copy_if(In first, In last, Out res, Pred p)
{
	while (first != last) {
		if (p (*first)) {
			*res++ = *first;
		}
		++first;
	}
	return res;
}

/**
  * copy_n_max(): copies at most n elements, or all elements
  * in the sequence, whichever happens first.
  */
template<typename In, typename Out> 
	size_t copy_n_max(In first, In last, size_t max, Out res)
{
	size_t n = 0;
	while (first != last && n < max) {
		*res = *first;
		++res;
		++first;
		++n;
	}
	return n;
}

/**
 * copy_n(): copy n elements.
 */
template<typename In, typename Out>
	Out copy_n(In first, size_t size, Out out)
{
	for (size_t n = 0; n < size; ++n) {
		*out++ = *first;
		++first;
	}
	return out;
}


/**
 * Given a start and end point, adds each item found to a string. 
 * e.g.: [element1], [element2], [element3]
 */
template<typename InputIterator> 
	void print_into(InputIterator first, InputIterator last, std::string &result, 
			const char * sep = ", ", const char * borders = "[]") 
{
	std::ostringstream out;
	bool first_one = true;
	char lborder = 0;
	char rborder = 0;
	
	if (strings::is_non_empty(borders) && strlen(borders) >= 2) {
		lborder = borders[0];
		rborder = borders[1];
	}

	for (; first != last; ++first) {
		if (!first_one) {
			out << sep;
		} 
		else {
			first_one = false;
		}		
		if (lborder != 0) {
			out << lborder << *first << rborder;
		}
		else {
			out << *first;
		}
	}
	result = out.str();
}

template<class Cont>
	inline void print_container(const Cont& container, std::string &result, 
				const char * sep = ", ", const char * borders = "[]")
{
	print_into(container.begin(), container.end(), result, sep, borders);
}

/**
 * Given a std::pair, provides a predicate that compares pairs by their
 * first values.
 */
template<typename T1, typename T2> class pair_key_predicate 
			: public std::unary_function<std::pair<T1, T2>, bool>
{
public:
	typedef std::pair<T1, T2>	argument_type;
	typedef T1			key_type;
	typedef	T2			value_type;

private:	
	const key_type & target;

public:
	pair_key_predicate(const key_type &t) : target(t) { }

	bool operator()(const argument_type& p) const {
		return p.first == target;
	}
};

/**
  * Checks if a range contains a value.
  */
template<typename InputIter, typename T> bool contains(InputIter begin, InputIter end, const T& value)
{
	while (begin != end) {
		if (*begin == value) {
			return true;
		}
		++begin;
	}
	return false;
}

/**
  * Similar, but operates on a predicate.
  */
template<typename InputIter, typename Pred> bool contains_if(InputIter begin, InputIter end, const Pred& pred)
{
	while (begin != end) {
		if (pred(*begin)) {
			return true;
		}
		++begin;
	}
	return false;
}

/**
 * Friendlier version for containers.
 */
template<typename T, typename Cont> inline bool contains(const Cont& cont, const T& value)
{
	return contains(cont.begin(), cont.end(), value);
}

template<typename Cont, typename Pred> inline bool contains_if(const Cont& cont, const Pred& pred)
{
	return contains_if(cont.begin(), cont.end(), pred);
}

//--------------------------------------------------
// The following code example is taken from the book
// The C++ Standard Library - A Tutorial and Reference
// by Nicolai M. Josuttis, Addison-Wesley, 1999
// (c) Copyright Nicolai M. Josuttis 1999
//-------------------------------------------------- 

/** 
 * class for the compose_f_gx_hx adapter
 */
template <class OP1, class OP2, class OP3>
class compose_f_gx_hx_t
 : public std::unary_function<typename OP2::argument_type,
                              typename OP1::result_type>
{
  private:
    OP1 op1;    // process: op1(op2(x),op3(x))
    OP2 op2;
    OP3 op3;
  public:
    // constructor
    compose_f_gx_hx_t (const OP1& o1, const OP2& o2, const OP3& o3)
     : op1(o1), op2(o2), op3(o3) {
    }

    // function call
    typename OP1::result_type
    operator()(const typename OP2::argument_type& x) const {
        return op1(op2(x),op3(x));
    }
};

/**
 * convenience function for the compose_f_gx_hx adapter
 */
template <class OP1, class OP2, class OP3>
inline compose_f_gx_hx_t<OP1,OP2,OP3>
compose_f_gx_hx (const OP1& o1, const OP2& o2, const OP3& o3) {
    return compose_f_gx_hx_t<OP1,OP2,OP3>(o1,o2,o3);
}

/** 
 * class for the compose_f_gx adapter
 */
template <class OP1, class OP2>
class compose_f_gx_t
 : public std::unary_function<typename OP2::argument_type,
                              typename OP1::result_type>
{
  private:
    OP1 op1;    // process: op1(op2(x))
    OP2 op2;
  public:
    // constructor
    compose_f_gx_t(const OP1& o1, const OP2& o2)
     : op1(o1), op2(o2) {
    }

    // function call
    typename OP1::result_type
    operator()(const typename OP2::argument_type& x) const {
        return op1(op2(x));
    }
};

/**
 * convenience function for the compose_f_gx adapter
 */
template <class OP1, class OP2>
inline compose_f_gx_t<OP1,OP2>
compose_f_gx (const OP1& o1, const OP2& o2) {
    return compose_f_gx_t<OP1,OP2>(o1,o2);
}

/**
 * class for the compose_f_gxy adapter
 */
template <class OP1, class OP2>
class compose_f_gxy_t
: public std::binary_function<typename OP2::first_argument_type,
	typename OP2::second_argument_type,
	typename OP1::result_type>
{
private:
	OP1 op1;    // process: op1(op2(x,y))
	OP2 op2;
public:
	// constructor
	compose_f_gxy_t (const OP1& o1, const OP2& o2)
		: op1(o1), op2(o2) {
		}

	// function call
	typename OP1::result_type
		operator()(const typename OP2::first_argument_type& x,
				const typename OP2::second_argument_type& y) const {
			return op1(op2(x,y));
		}
};

/** 
 * convenience function for the compose_f_gxy adapter
 */
template <class OP1, class OP2>
inline compose_f_gxy_t<OP1,OP2>
compose_f_gxy (const OP1& o1, const OP2& o2) {
	return compose_f_gxy_t<OP1,OP2>(o1,o2);
}

} /* namespace util */
#endif

