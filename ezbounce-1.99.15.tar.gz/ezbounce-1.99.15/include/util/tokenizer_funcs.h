/**
 * util/tokenizer_funcs.h
 * (c) 2007 Murat Deligonul
 */
#ifndef __UTIL_TOKENIZER_FUNCS_H
#define __UTIL_TOKENIZER_FUNCS_H

#include <utility>
#include <cstring>

namespace util { 
  namespace strings {

	//
	// The tokenizer functions will take in iterators representing the 
	// start and end of the search range.  The start iterator will be a modifiable
	// reference and will be set to the start of the found token upon exit.
	// 
	// If the end is reached and no suitable token is found, zero will be returned, 
	// and start == end will be true.
	//

	/**
	 * The basic tokenizer function object.
	 */
	template<typename T = char> class delimeter_seeker {
	private:
		const T* const		delims;			// delimeters 	
		const bool 		require_ending;		// whether the last token must be terminated 
								// by a delimeter
								 
	public:
		explicit delimeter_seeker(const T* _delims, bool _require_ending = false) : 
			delims(_delims), require_ending(_require_ending) { }

		template<typename InputIterator> 
		size_t operator()(InputIterator& begin, InputIterator end) const {
			size_t size = 0;

			for (InputIterator i = begin; i != end; ++i) {
				const T * d = strchr(delims, *i);

				if (size == 0) {
					if (!d) {
						// non-delimeter located
						size = 1;
						begin = i;
					}
				}
				else {
					if (d) {
						// next delimeter found, token complete
						return size;
					}
					++size;
				}
			}
			// unexpected ending
			if (!size || require_ending) {
				size = 0;
				begin = end;
			}
			return size;
		}
	};
  } /* namespace strings */
} /* namespace util */

#endif /* __UTIL_TOKENIZER_FUNCS_H */
