/***************************************************************************
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 ***************************************************************************/

#ifndef __UTIL_HASHER_H
#define __UTIL_HASHER_H

namespace util {

/**
  * Pointer to a hash function for a c-style string.
  */
typedef unsigned int (*cstring_hash_fn)(const char *);

/**
  * General purpose string hashing function and string comparison function.
  */
extern unsigned int string_hash(const char *);

template<typename T> struct default_hasher;

template<> struct default_hasher<const char *> {
	unsigned int operator()(const char * str) const {
		return string_hash(str);
	}
};

/**
  * Template to permanently bind a string hash function to the struct.
  */
template<cstring_hash_fn fn> struct fixed_cstring_hasher {
	unsigned int operator()(const char * str) const {
		return fn(str);
	}
};

}	/* namespace util */
#endif		/* __UTIL_HASHER_H */
