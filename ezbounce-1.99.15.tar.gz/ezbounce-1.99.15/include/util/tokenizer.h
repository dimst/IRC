/**
 * util/tokenizer.h
 */
#ifndef __UTIL_TOKENIZER_H
#define __UTIL_TOKENIZER_H

#include <iterator>
#include <memory>
#include <climits>
#include "util/generic.h"
#include "util/tokenizer_funcs.h"
#include "debug.h"

namespace util {
  namespace strings {

/**
 * Improved tokenizer.
 * Type parameters:
 * 	TokenizerFunc	
 * 	InputIterator		- type of input iterator 
 * 	Type			- the type to be generated
 */
template<typename TokenizerFunc = delimeter_seeker<char>,
		typename InputIterator = const char *,
		typename Type = std::string>  
class tokenizer {
public:
	// Iterator class
	class token_iterator {
	public:
		typedef Type				value_type;
		typedef Type *				pointer;
		typedef	Type &				reference;

		typedef std::ptrdiff_t			difference_type;
		typedef	std::forward_iterator_tag	iterator_category;
	
		value_type operator *() const {
			assert(current != last);
			return Type(current, range);
		}

		token_iterator& operator++() {
			assert(current != last);
			increment();
			assign_range();
			return *this;
		}

		token_iterator operator++(int) {
			assert(current != last);
			token_iterator prev(*this);
			increment();
			assign_range();
			return prev;
		}

		bool operator == (const token_iterator& that) const {
			return current == that.current &&
				last == that.last;
		}

		bool operator != (const token_iterator& that) const {
			return !(*this == that);
		}
				

	public:
		/**
		 * Construction.
		 */
		token_iterator(const TokenizerFunc& fn, InputIterator beg, InputIterator end) :
			tokenizer_fn(fn), 
			current(beg), 
			last(end),
			range(0) {
				assign_range();
			}
	private: 
		/**
		 * Determine location of current token.
		 */
		void assign_range() {
			// note also advances current
			range = tokenizer_fn(current, last);
		}

		void increment() {
			current += range;
		}

	private:
		TokenizerFunc				tokenizer_fn;
		InputIterator				current;
		InputIterator				last;
		size_t					range;
	};

public:
	/**
	 * Types 
	 */
	typedef Type					value_type;
	typedef Type *					pointer;
	typedef Type &					reference;
	typedef const Type *				const_pointer;
	typedef const Type &				const_reference;

	typedef token_iterator				iterator;
	typedef token_iterator				const_iterator;

public:
	/** 
	 * Construction
	 */
	tokenizer(InputIterator start, InputIterator end, const TokenizerFunc& _func = TokenizerFunc()) :
		func(_func),
		first(start), 
		last(end) { }
	
	template<typename Cont> tokenizer(const Cont& cont, const TokenizerFunc& _func = TokenizerFunc()) :
		func(_func),
		first(cont.begin()),
		last(cont.end()) { }

	/**
	 * Iterator Access 
	 */
	iterator begin() const {
		return iterator(func, first, last);
	}
	iterator end() const {
		return iterator(func, last, last);
	}

	// to reset
	void assign(InputIterator start, InputIterator end, const TokenizerFunc& _func) {
		func = _func;
		first = start;
		last = end;
	}

private:
	TokenizerFunc 				func;
	InputIterator 				first;
	InputIterator 				last;
};
	
/**
 * Tokenize and place results into a container of type Cont.
 * Maximum number of tokens can be specified.
 */	
template<typename T, typename InputIterator, typename OutputIterator> 
	size_t tokenize(InputIterator first, InputIterator last, const char * delim, OutputIterator i, unsigned max) 
{
	tokenizer<delimeter_seeker<>, InputIterator, T> tokens(first, last, delimeter_seeker<>(delim));
	return copy_n_max(tokens.begin(), tokens.end(), max, i);
}

/**
 * Helper function for C-style strings, for insertion into containers.
 */
template<typename T, template<typename, typename = std::allocator<T> > class Cont> 
	inline size_t tokenize(const char * str, const char * delim, Cont<T>& cont, unsigned max = INT_MAX) 
{
	return tokenize<T>(str, str+strlen(str), delim, std::back_inserter(cont), max);
}

/**
 * Another helper function for C-style strings, for insertion using arbitrary OutputIterator.
 */
template<typename OutputIterator> 
	inline size_t tokenize(const char * str, const char * delim, OutputIterator out, unsigned max = INT_MAX) 
{
	typedef typename std::iterator_traits<OutputIterator>::value_type 	VT;
	return tokenize<VT>(str, str+strlen(str), delim, out, max);
}
  } /* namespace strings */
} /* namespace util */
#endif
