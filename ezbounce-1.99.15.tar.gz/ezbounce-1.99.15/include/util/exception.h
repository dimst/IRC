/**                                                                        
 * This program is free software; you can redistribute it and/or modify  
 * it under the terms of the GNU General Public License as published by  
 * the Free Software Foundation; either version 2 of the License, or     
 * (at your option) any later version.                                   
 *                                                                         
 * util/exception.h
 * Part of ezbounce
 * (c) 2001-2007 Murat Deligonul
 */

#ifndef __UTIL_EXCEPTION_H
#define __UTIL_EXCEPTION_H

#include <exception>
#include <stdexcept>
#include <string>

namespace util {

/**
 * General exception class. 
 */
template <typename T, 
	   typename Base = std::runtime_error>    
	   class exception : public Base {
public:
	explicit exception(const std::string& e, int c = 0) 
		: Base(e) { }
	
	~exception() throw() { }

private:
	exception& operator = (const exception &);
};

} /* namespace util */
#endif /* __UTIL_EXCEPTION_H */

