/**
 * util/type_chooser.h
 *
 * (c) 2007 Murat Deligonul
 */
#ifndef __UTIL_TYPE_CHOOSER_H
#define __UTIL_TYPE_CHOOSER_H

namespace util {

/**
 * Type Chooser
 */
template<bool B, typename T1, typename T2> struct type_chooser;

// Partial specialization for 'true' -- return first one
template<typename T1, typename T2> struct type_chooser<true, T1, T2> {
	typedef T1  type;
	static T1& choose(T1& t1, T2& t2) {
		return t1;
	}
};

// Partial specialization for 'false' -- return second one
template<typename T1, typename T2> struct type_chooser<false, T1, T2> {
	typedef T2  type;
	static T2& choose(T1& t1, T2& t2) {
		return t2;
	}
};

}
#endif /* __UTIL_TYPE_CHOOSER_H */
