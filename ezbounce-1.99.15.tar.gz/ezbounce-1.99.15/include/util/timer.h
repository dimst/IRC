/**
 * util/timer.h
 */
#ifndef __UTIL_TIMER_H
#define __UTIL_TIMER_H

#include <queue>
#include <vector>
#include <ctime>
#include "util/counted_object.h"

#include "debug.h"

namespace util {

namespace detail {
	// forward declaration
	template<typename> class generic_timer;
}

/**
 * General purpose periodic timer.
 */
class timer : public counted_object<timer> {
private:
	/* Used in prioritizing timer list */
	struct ticket {
		timer *	owner;
		time_t	scheduled;
		bool operator > (const ticket& o) const { 
			return (scheduled > o.scheduled); 
		}

		ticket(timer * o, time_t t) : owner(o), scheduled(t) { }
	};
	static std::priority_queue<ticket, std::vector<ticket>, std::greater<ticket> > timers;

private:
	const int id;			/* an id for this timer. defaults to zero */
	const int interval;		/* how often this timer is executed */
	int options;			/* timer options */
	const time_t epoch;		/* when we started */
	time_t scheduled;		/* when (real time) are we scheduled to execute next ? */

	static time_t last_poll;
	static time_t _now;

public:
	timer(int, int = 0, int = 0);
	
protected:
	virtual ~timer() {  
		assert((options & TIMER_EXPIRED)); 
	}

public:
	static int poll();

	static time_t now() {
	       	return _now; 
	}
	static void set_now(time_t t) { 
		_now = t; 
	}
	static void set_now() {
		_now = time(NULL);
	}
	static time_t * get_now_ptr() {
		return &_now;
	}
	static time_t get_wait_time(time_t n) { 	
		if (!timers.empty()) {
			const ticket &t = timers.top();
			return t.scheduled - n;
		}
		return 0;
	}

	void enable();
	void die();
	
	time_t schedule_next();

	int get_id() const { return id; }
	int get_interval() const { return interval; }
	int get_options()  const { return options; }
	time_t get_scheduled() const { return scheduled; }
	time_t get_epoch() const { return epoch; }

	/* Factory function */
	template<typename Func> static timer * create_generic_timer(int, const Func&,
			void * = NULL, int = 0, int = 0);

	/**
	 * Various timer options:
	 * 	TIMER_ONESHOT:		execute only once
	 *	TIMER_ENABLED:		timer is enabled
	 *	TIMER_ABSOLUTE:		timer is scheduled relative to system time
	 * 	TIMER_EXPIRED:		timer is finished and will be deleted
	 */
	enum {
		TIMER_ENABLED 		= 0x1,
		TIMER_ONESHOT 		= 0x2,
		TIMER_ABSOLUTE 		= 0x4,
		TIMER_EXPIRED  		= 0x8
	};


	/**
	  * Used in generic timer callbacks.
	  */
	struct generic_timer_data {
		time_t	time;
		int  	id;
		void *  data;
	};

protected:
	/**
	 * For all timer_procs:
	 * 	return <  0 	-- to disable timer after this execution
	 *	return => 0	-- ignored
	 *
	 * never call enable() or disable() in here cause it will screw
	 * with the list while the iterator is traversing it
	 */
	virtual int timer_proc(time_t) = 0;

private:
	/* Forbidden operations */
	timer(const timer &);
	timer& operator = (const timer &);
};



namespace detail {

/**
 * Allows creation of timers through a factory function without the need for deriving custom classes.
 * A single parameter of (const struct generic_timer_data *) is passed to callback function.
 * The callback function must return int.
 */
template<typename Func> class generic_timer : public timer {
private:
	Func callback;
	void * data;

	virtual int timer_proc(time_t);

	/** this should never be delete'd directly **/
	~generic_timer() { }		
	generic_timer(int _int, const Func& func,
			void * d = 0, int _opt = 0, int _id = 0)
		: timer(_int, _opt, _id), callback(func), data(d)
	{ }

	friend class timer;

private:
	/* forbidden operations */
	generic_timer(const generic_timer &);
	generic_timer& operator = (const generic_timer &);
};

template<typename Func> int generic_timer<Func>::timer_proc(time_t t)
{
	DEBUG("generic_timer()::timer_proc() -- %p\n", this);
	struct generic_timer_data data = {
		t,
		get_id(),
		this->data
	};
	return callback(&data);
}

}	/* namespace detail */

/**
 * Factory function for generic_timer's.
 * The timer will not be scheduled for execution until enable() is called.
 */
template<typename Func> inline timer * timer::create_generic_timer(int interval, 
		const Func& func,
		void * data,
		int options, int id) 
{
	return new detail::generic_timer<Func>(interval, func, data, options, id);
}

}	/* namespace util */
#endif  /* __UTIL_TIMER_H */	
