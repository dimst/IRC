/***************************************************************************
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 ***************************************************************************/

#ifndef __HASH_PREDICATE_H
#define __HASH_PREDICATE_H

#include <cstring>

namespace util {

template<typename T> struct default_predicate {
	bool operator() (const T& v1, const T& v2) const {
		return v1 == v2;
	}
};

template<> struct default_predicate<const char *> {
	bool operator() (const char *v1, const char *v2) const {
		return strcasecmp(v1, v2) == 0;
	}
};

typedef int (*cstring_comparator_fn)(const char *, const char *);

/**
  * Predicate that can be used to wrap any string comparison function.
  */
class cstring_predicate {
private:
	const cstring_comparator_fn comparator;

public:
	cstring_predicate(cstring_comparator_fn f) : comparator(f) { }

	bool operator()(const char * str1, const char * str2) const {
		return comparator(str1, str2) == 0;
	}
};

/**
  * Similar to above, but creates compile-time mapping.
  */
template<cstring_comparator_fn fn> struct fixed_cstring_predicate {
	bool operator()(const char * str1, const char * str2) const {
		return fn(str1, str2) == 0;
	}
};
}	/* namespace util */
#endif		/* __HASH_PREDICATE_HASH */
