/**
 * util/modifying_tokenizer.h
 */

#ifndef __UTIL_MODIFYING_TOKENIZER_H
#define __UTIL_MODIFYING_TOKENIZER_H

#include "util/strings.h"

namespace util {
  namespace strings {
		
/**
 * The original tokenizer, which performs the tokenization in place,
 * modifying the string. (However, can restore original characters when done)
 */
class modifying_tokenizer
{
private:
        char * start, * end;
       	char end_char;
	const char * delim;     /* delimeter string */
	int 	options;
	int 	*count;

public:
	/**
	 * Options for use.
	 */
	enum {
		COUNT_DELIMS = 2,
		DONT_RESTORE = 4,
	};

	modifying_tokenizer(char *, const char *, int = 0); 
        ~modifying_tokenizer() { 
		if (end && end_char) { 
			*end = end_char; 
		}
		delete[] count; 
	}

	int 	get_count(char c) const {
		int i = index_of(delim, c);
		return (i < 0) ? -1 : count[i];		
	}
	char * next();
	void set_options(int);

private:
	/* Forbidden */
	modifying_tokenizer(const modifying_tokenizer&);
	modifying_tokenizer& operator=(const modifying_tokenizer&);
};

  } /* strings */
} /* namespace util */

#endif
