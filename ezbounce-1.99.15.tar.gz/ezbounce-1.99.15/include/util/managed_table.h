/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * util/managed_table.h
 * (c) 2007-2008 Murat Deligonul
 */

#ifndef __UTIL_MANAGED_TABLE_H
#define __UTIL_MANAGED_TABLE_H

#include <bitset>
#include <cstddef>
#include "util/array.h"

namespace util {

/**
 * A typesafe table that also keeps track of what options have been set
 * and what have not, and allows for 'unsetting' of options.
 */
template<typename T, size_t N>	class managed_table {
public:
	static const size_t SIZE = N;

	// type definitions
	typedef T              		value_type;
	typedef T&             		reference;
	typedef const T&       		const_reference;

	typedef	util::array<T, N>	container_type;

private:
	container_type			array;
	std::bitset<N>			flags;

public:
	managed_table() { }
	explicit managed_table(const T& init_val) {
		// assign value to all elements.
		// mark all as set.
		set_all(init_val);
	}

	managed_table(const managed_table& that) {
		// copy everything over: 
		// correctness depends on whether T supports proper deep copy
		array = that.array;
		flags = that.flags;
	}

	managed_table& operator = (const managed_table& that) {
		// again, just copy, correctness depends on T supporting deep copy
		if (this != &that) {
			array = that.array;
			flags = that.flags;
		}
		return *this;
	}

	void swap(managed_table& that) {
		if (this == &that) {
			return;
		}
		array.swap(that.array);
		flags.swap(that.flags);
	}

	/**
	 * Clear all items, assigning them the default value T().
	 */
	void clear() {
		set_all(T());
		flags.clear();
	}	

	/**
	 * Assign value to position i, replacing its former value.
	 */
	void set(unsigned i, const T& val) {
		array[i] = val;
		flags.set(i);
	}

	/**
	 * Assign, but only once.
	 */
	void set_once(unsigned i, const T& val) {
		if (!flags[i]) {
			set(i, val);
		}
	}

	void set_all(const T& val) {
		array.assign(val);
		flags.set();
	}

	/**
	 * Check if item at position i has been assigned.
	 */ 
	bool is_set(unsigned i) const {
		return flags[i];
	}

	void unset(unsigned i) {
		array[i] = T();
		flags.reset(i);
	}

	const_reference get(unsigned i) const {
		return array[i];
	}

	reference get(unsigned i) {
		return array[i];
	}

	const_reference operator[] (unsigned i) const {
		return array[i];
	}


	/**
	 * Checked versions: checks that the index is valid, and that something 
	 * is actually set there.
	 */
	//--------------------------------------------------
	// const_reference at(unsigned i) const {
	// 	// FIXME: complete
	// }
	//-------------------------------------------------- 

	//--------------------------------------------------
	// reference at(unsigned i) const {
	// }
	//-------------------------------------------------- 

	/**
	 * Return the underlying container. 
	 */
	container_type& container() {
		return this->array;
	}
};

//--------------------------------------------------
// 
// 
// /**
//  * Partial specialization for bool.
//  * Use std::bitset for storage.
//  */
// template<size_t N> 	class managed_table<bool, N> {
// public:
// 	static const size_t SIZE = N;
// 
// 	typedef bool			T;
//         // type definitions
//         typedef T              		value_type;
// 	typedef	std::bitset<N>		container_type;
// 
// 	// these are weird with bitset
//         typedef typename container_type::reference		reference;
//         typedef typename container_type::reference		const_reference;
// 
// private:
// 	container_type			array;
// 	std::bitset<N>			flags;
// 
// public:
// 	managed_table() { }
// 	explicit managed_table(const T& init_val) {
// 		// assign value to all elements.
// 		// mark all as set.
// 		set_all(init_val);
// 	}
// 
// 	managed_table(const managed_table& that) {
// 		// copy everything over: 
// 		// correctness depends on whether T supports proper deep copy
// 		array = that.array;
// 		flags = that.flags;
// 	}
// 
// 	managed_table& operator = (const managed_table& that) {
// 		// again, just copy, correctness depends on T supporting deep copy
// 		if (this != &that) {
// 			array = that.array;
// 			flags = that.flags;
// 		}
// 		return *this;
// 	}
// 
// 	void swap(managed_table& that) {
// 		if (this == &that) {
// 			return;
// 		}
// 		array.swap(that.array);
// 		flags.swap(that.flags);
// 	}
// 
// 	/**
// 	 * Clear all items, assigning them the default value T().
// 	 */
// 	void clear() {
// 		set_all(T());
// 		flags.clear();
// 	}	
// 
// 	/**
// 	 * Assign value to position i, replacing its former value.
// 	 */
// 	void set(unsigned i, const T& val) {
// 		array[i] = val;
// 		flags.set(i);
// 	}
// 
// 	/**
// 	 * Assign, but only once.
// 	 */
// 	void set_once(unsigned i, const T& val) {
// 		if (!flags[i]) {
// 			set(i, val);
// 		}
// 	}
// 
// 	void set_all(const T& val) {
// 		if (val) {
// 			array.set();
// 			flags.set();
// 		}
// 		else {
// 			array.reset();
// 			flags.reset();
// 		}
// 	}
// 
// 	/**
// 	 * Check if item at position i has been assigned.
// 	 */ 
// 	bool is_set(unsigned i) const {
// 		return flags[i];
// 	}
// 
// 	void unset(unsigned i) {
// 		array[i] = T();
// 		flags.reset(i);
// 	}
// 
// 	reference get(unsigned i) const {
// 		return const_cast<container_type&>(array)[i];
// 	}
// 
// 	reference get(unsigned i) {
// 		return array[i];
// 	}
// 
// 	/**
// 	 * Checked versions: checks that the index is valid, and that something 
// 	 * is actually set there.
// 	 */
// 	//--------------------------------------------------
// 	// const_reference at(unsigned i) const {
// 	// 	// FIXME: complete
// 	// }
// 	//-------------------------------------------------- 
// 
// 	//--------------------------------------------------
// 	// reference at(unsigned i) const {
// 	// }
// 	//-------------------------------------------------- 
// 
// 	/**
// 	 * Return the underlying container. 
// 	 */
// 	container_type& container() {
// 		return this->array;
// 	}
// };
//-------------------------------------------------- 

} /* namespace util */
#endif  /* __UTIL_MANAGED_TABLE_H */
