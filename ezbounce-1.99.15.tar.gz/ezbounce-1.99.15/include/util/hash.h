/***************************************************************************
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 ***************************************************************************
 * util/hash.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __UTIL_HASH_H
#define __UTIL_HASH_H

#include <algorithm>
#include <functional>
#include <utility>
#include <iterator>
#include <cstddef>
#include <cstring>
#include "util/hasher.h"
#include "util/hash_predicate.h"

#include "debug.h"

/** 
 * Chained hash table with type-safe template support.
 * 02-2007: Rewritten with proper template usage.
 */
namespace util {

/**
 * Prime number helper functions ..
 */
extern unsigned int nearest_prime(unsigned int);
extern bool is_prime(unsigned int);

static const unsigned int SENTINEL = 0x1982;


/**
 * A simple Hash Table stats interface..
 */
struct hash_stats {
	unsigned int buckets;		// # of buckets
	unsigned int buckets_in_use;	// total buckets in use
	unsigned int lookups;		// number of lookups
	unsigned int hits;		// number of successful lookups
	unsigned int size;		// number of entries
	unsigned int sizes[5];       	// buckets with 0, 1, 2, 3, 4+ elements 
};

/**
 * KEY			- type of keys
 * VALUE		- type of values
 * Hash		- hash function or object
 * Pred		- key comparison function or object
 */
template<typename KEY, 
		typename VALUE, 
		typename Hash	= default_hasher<KEY>, 
		typename Pred	= default_predicate<KEY> > 
			class hash_table {
public:
	// types
	typedef KEY				key_type;
	typedef VALUE				mapped_type;
	typedef std::pair<const KEY, VALUE>	value_type;
	typedef Pred				key_compare;

private:
	/**
	 * Hash function.
	 */
	Hash	hasher;

	/**
	 * The key comparator predicate must return:
	 * true  if a == b,  false otherwise.
	 */
	Pred 	key_comparator;

	/**
	 * Data members.
	 */
	size_t buckets;
	size_t entries;	
	mutable unsigned int lookups;
	mutable unsigned int hits;
	unsigned int rehash_trigger_high;
	
private:
	/**
	 * Node and bucket structures.
	 */
	struct node {
		std::pair<const KEY, VALUE> 	pair;
		node * 				next;

		node(const KEY& k, const VALUE& v, node * n = NULL) : 
			pair(k, v), 
			next(n) { }
	};

	/**
	 * Bucket management:
	 * We actually allocate (num_buckets+1) nodes.  The last node is used as sentinel
	 * needed for the iterators to properly function.
	 */
	struct node ** table;
		
	bool list_add(struct node **, const KEY&, const VALUE&);
	bool list_remove(struct node **, const KEY&);
	void list_remove(struct node **, struct node *);
	void list_destroy(struct node **);
	node * list_find(struct node *, const KEY&) const;

public:
	explicit hash_table(size_t, const Hash& = Hash(), const Pred& = Pred());
	~hash_table();

	size_t size() const {
		return entries;
	}

	size_t num_buckets() const {
		return num_buckets;
	}

	bool empty() const {
		return (size() == 0);
	}

	/** 
	 * automatically rehash when 
	 * size >= (high) * buckets
	 * or when size < (low) * buckets [not implemented yet]
	 * only triggered on insert (for high)
	 *		and remove (for low) [again, not yet implemented]
	 */ 
	void  set_rehash_trigger(unsigned int /* low */, unsigned int high) { 
		rehash_trigger_high = high; 
	}

	/**
	 * Interface.
	 */
	bool   insert(const KEY&, const VALUE&);
	void   replace(const KEY&, const VALUE&);
	size_t erase(const KEY&);
	
	bool contains(const KEY&) const;
	void clear();

	void rehash(size_t);

	void swap(hash_table&);

public:
	/**
	  * STL-compatible iterators.
	  */
	class iterator_base {
	public:
		typedef 	std::ptrdiff_t	difference_type;

	protected:
		node ** current_root;
		node * current;

		iterator_base(node ** s) :
			current_root(s), current(*s) { }

		iterator_base(node ** s, node * c) :
			current_root(s), current(c) { }

		void increment() {
			if (current && current->next) {
				current = current->next;
				return;
			}

			++current_root;
			while (!*current_root) {
				++current_root;
			}
			current = *current_root;
		}
		
		node * where() const {
			return current;
		}

	public:
		bool operator == (const iterator_base &that) const {
			return current == that.current;
		}
		
		bool operator != (const iterator_base &that) const {
			return current != that.current;
		}
		friend class hash_table;
	};

	class iterator : public iterator_base {
	public:
		typedef typename hash_table<KEY, VALUE, Hash, Pred>::value_type 	value_type;
		typedef value_type *							pointer;
		typedef value_type &							reference;
		typedef std::forward_iterator_tag					iterator_category;

		// XXX: allow this?
		// iterator() : iterator_base(NULL, NULL) { }
		iterator(node ** root, node * n) : iterator_base(root, n) { }
		explicit iterator(node ** root) : iterator_base(root) { }

		reference operator*() const {
			return this->current->pair;
		}

		pointer operator->() const {
			return &this->current->pair;
		}

		iterator & operator++() {
			this->increment();
			return *this;
		}

		iterator operator++(int) {
			iterator tmp(*this);
			this->increment();
			return tmp;
		}
		// XXX: needed to work around bug (?) in gcc 4.0
		friend class hash_table::const_iterator;
	};

	/**
	  * And a const_iterator ..
	  */
	class const_iterator : public iterator_base { 
	public:
		typedef typename hash_table<KEY, VALUE, Hash, Pred>::value_type 	value_type;
		typedef const value_type *						pointer;
		typedef const value_type &						reference;
		typedef std::forward_iterator_tag					iterator_category;

		const_iterator(const iterator& that) : iterator_base(that.current_root, that.current) { }
		const_iterator(node ** root, node * n) : iterator_base(root, n) { }
		explicit const_iterator(node ** root) : iterator_base(root) { }


		reference operator*() const {
			return this->current->pair;
		}

		pointer operator->() const {
			return &this->current->pair;
		}

		const_iterator & operator++() {
			this->increment();
			return *this;
		}

		const_iterator operator++(int) {
			const_iterator tmp(*this);
			this->increment();
			return tmp;
		}
	};

public:
	/**
	 * STL-compatible iterator creation functions.
	 */
	iterator begin() {
		iterator i(&table[0]);
		if (!i.where()) {
			i.increment();
		}
		return i;
	}

	const_iterator begin() const {
		const_iterator i(&table[0]);
		if (!i.where()) {
			i.increment();
		}
		return i;
	}

	iterator end() {
		return iterator(&table[buckets]);
	}

	const_iterator end() const {
		return const_iterator(&table[buckets]);
	}

	/**
	 * Additional STL-Compatible interface functions
	 */
	iterator erase(iterator i) {
		iterator i2 = i;
		++i2;
		list_remove(i.current_root, i.current);
		--entries;
		return i2;
	}

	/**
	 * find() and its const version 
	 */
	iterator find(const KEY& key) {
		unsigned idx = hasher(key) % (buckets);
		node * n = list_find(table[idx], key);
		++lookups;
		if (n == NULL) {
			return end();
		}
		++hits;
		return iterator(&table[idx], n);
	}

	const_iterator find(const KEY& key) const {
		unsigned idx = hasher(key) % (buckets);
		node * n = list_find(table[idx], key);
		++lookups;
		if (n == NULL) {
			return end();
		}
		++hits;
		return  const_iterator(&table[idx], n);
	}

	void stat(struct hash_stats * ht) const;

private:
	/* Forbidden */
	hash_table(const hash_table&);
	hash_table & operator = (const hash_table &);
};


template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	hash_table<KEY, VALUE, Hash, Pred>::hash_table(size_t n, const Hash& h, const Pred& p) :
		hasher(h), key_comparator(p), buckets(n),
		entries(0), 
		lookups(0),
		hits(0)
{
	/** 
	  * By default, we will automatically rehash if
	  * size = 4 * buckets
	  */
	rehash_trigger_high = 4; 

	table = new struct node*[buckets+1];
	std::fill_n(&table[0], buckets, (node *) NULL);
	// assign sentinel
	table[buckets] = reinterpret_cast<node *>(SENTINEL);
}

template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	hash_table<KEY, VALUE, Hash, Pred>::~hash_table()
{
	for (unsigned i = 0; i < buckets; ++i) {
		list_destroy(&table[i]);
	}
	delete[] table;
}


/**
 * Add an entry to a bucket chain.
 *
 * @return true if the insert succeeded, false otherwise.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	bool hash_table<KEY, VALUE, Hash, Pred>::list_add(struct hash_table<KEY, VALUE, Hash, Pred>::node ** head, 
								const KEY& key,
								const VALUE& data)
{
	if (*head == NULL) {
		*head = new node(key, data, NULL);
		return true;
	} 

	struct node * n = *head;
	if (key_comparator(n->pair.first, key) == true) {
		// already exists!
		return false;
	}		
	for (; n->next ; n = n->next) {
		if (key_comparator(n->next->pair.first, key) == true) {
			// already exists!
			return false;
		}		
	}
	n->next = new node(key, data, NULL);
	return true;
}

/**
 * Remove an entry from a bucket chain.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	bool hash_table<KEY, VALUE, Hash, Pred>::list_remove(struct hash_table::node ** head, 
								const KEY& key)
{
	node * n = *head;
	if (!n) {
		return false;
	}
	if (key_comparator(key, n->pair.first) == true) {
		*head = n->next;
		delete n;
		return true;
	}

	for (; n->next; n = n->next) {
		if (key_comparator(n->next->pair.first, key) == true)	{
			node * tn = n->next;
			n->next = n->next->next;
			delete tn;
			return true;
		}
	}
	return false;
}

/**
 * Remove an entry, given pointers to bucket and node.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	void hash_table<KEY, VALUE, Hash, Pred>::list_remove(struct hash_table::node ** head, 
								hash_table::node * target)
{
	node *n = *head;
	if (!n) {
		// XXX: should not occur.
		assert(false);
		return;
	}

	if (n == target) {
		*head = n->next;
		delete n;
		return;
	}

	for (; n->next; n = n->next) {
		if (n->next == target) {
			node * tn = n->next;
			n->next = n->next->next;
			delete tn;
			return;
		}
	}
}

/**
 * Destroy a chain.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	void hash_table<KEY, VALUE, Hash, Pred>::list_destroy(struct hash_table::node ** head)
{
	struct node * n = *head;
       	struct node * n2;
	while (n) {
		n2 = n->next;
		delete n;
		n = n2;
	}
	*head = NULL;
}

/**
 * Given head of the chain, locate node with matching key.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	typename hash_table<KEY, VALUE, Hash, Pred>::node * 
		hash_table<KEY, VALUE, Hash, Pred>::list_find(struct hash_table::node * n, const KEY& key) const 
{
	for (; n; n = n->next) {
		if (key_comparator(key, n->pair.first) == true) {
			return n;
		}
	}
	return NULL;
}

/**
 * Insert an element.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	bool hash_table<KEY, VALUE, Hash, Pred>::insert(const KEY& key, const VALUE& data)
{
	unsigned idx = hasher(key) % buckets;
	if (!list_add(&table[idx], key, data)) {
		return false;
	}
	++entries;

	// Automatic rehash?
	if (rehash_trigger_high > 1) {
		if (entries >= rehash_trigger_high * buckets) {
			unsigned int new_buckets = 
				nearest_prime(rehash_trigger_high * buckets);
		
			//DEBUG("hash_table::insert() [%p] ---> auto rehash triggered [%u >= %u * %u] buckets: [%u ----> %u]\n",
			//	this, size(), rehash_trigger_high, buckets, buckets, new_buckets);
			rehash(new_buckets);					
		}
	}
	//DEBUG("__htbl::insert(%p, %p) [%p] ---> bucket %d [new size: %d]\n", &key, &data, this, idx, size());
	return true;
}

/**
 * Replace element that mapped to an existing key.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	void hash_table<KEY, VALUE, Hash, Pred>::replace(const KEY& key, const VALUE& data)
{
	iterator i = find(key);
	*i = data;
}

/**
 * Remove the element matching a Key.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	size_t hash_table<KEY, VALUE, Hash, Pred>::erase(const KEY& key)
{
	unsigned idx = hasher(key) % buckets;
	if (!list_remove(&table[idx], key)) {
		return 0;
	}
	--entries;
	return 1;
}

/**
 * Check whether a matching value exists for a given Key.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	bool hash_table<KEY, VALUE, Hash, Pred>::contains(const KEY& key) const
{
	return find(key) != this->end();
}

/**
 * Clear all elements; resize table to a default value.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	void hash_table<KEY, VALUE, Hash, Pred>::clear()
{
	for (unsigned i = 0; i < buckets; ++i) {
		list_destroy(&table[i]);
	}
	delete[] table;
	table = NULL;
	buckets = 0;
	entries = 0;
	rehash(7);
}

/**
 * swap()
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	void hash_table<KEY, VALUE, Hash, Pred>::swap(hash_table &that)  
{
	if (&that == this) {
		return;
	}
	std::swap(buckets, that.buckets);
	std::swap(entries, that.entries);
	std::swap(rehash_trigger_high, that.rehash_trigger_high);
	std::swap(table, that.table);

	// swap these ??
	std::swap(hasher, that.hasher);
	std::swap(key_comparator, that.key_comparator);
}

/**
 * rehash
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	void hash_table<KEY, VALUE, Hash, Pred>::rehash(size_t new_buckets)  
{
	assert(new_buckets > 3);	/* let's be realistic ..*/
	struct node ** new_table = new struct node*[new_buckets+1];
      	struct node **h;
	size_t new_entries = 0;
	std::fill_n(&new_table[0], new_buckets, (node *) NULL);
	new_table[new_buckets] = reinterpret_cast<node *>(SENTINEL);
	
	h = &table[0];
	
	for (unsigned i = 0; i < buckets; h=&table[++i]) {
		for (node * n = *h; n; n = n->next) {
			int idx = hasher(n->pair.first) % new_buckets;
			list_add(&new_table[idx], n->pair.first, n->pair.second);
			++new_entries;
		}
		list_destroy(h);
	}
	
	assert(new_entries == entries);
	delete[] table;
	table = new_table;
	entries = new_entries;
	buckets = new_buckets;
	lookups = hits = 0;
}

/**
 * Stats.
 */
template<typename KEY, typename VALUE, typename Hash, typename Pred> 
	void hash_table<KEY, VALUE, Hash, Pred>::stat(struct hash_stats * ht) const
{
	DEBUG("hash_table::stat() [%p]\n", this);
	assert(ht);
	memset(ht, 0, sizeof(hash_stats));
	ht->buckets = buckets;
	ht->hits = hits;
	ht->lookups = lookups;
	ht->size = entries;

	/* Now figure how big the buckets are */
	for (unsigned i = 0; i < buckets; ++i) {
		/**
		  * Figure out exactly how many nodes in this bucket..
		  */
		int s = 0;
		for (node * n = table[i]; n != NULL; n = n->next) {
			++s;
		}

		if (s < 5) {
			ht->sizes[s]++;
		}
		else if (s > 4) {
			ht->sizes[4]++;
		}
	}

	ht->buckets_in_use = ht->sizes[1] + ht->sizes[2] + ht->sizes[3] + ht->sizes[4];
}

}	/* namespace util */
#endif /* __UTIL_HASH_H */

