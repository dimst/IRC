/** 
 * util/tr1.h
 *
 * (c) 2007 Murat Deligonul
 */

#ifndef __UTIL_TR1_H
#define __UTIL_TR1_H

// some stuff from the C++ TR1 update
namespace util {

/**
 * Given a type T *, return T.
 */
template<typename T> struct remove_pointer {
	typedef T type;
};

template<typename T> struct remove_pointer<T *> {
	typedef T type;
};

/**
 * Yield true if T has a const qualifier.
 */
template<typename T> struct is_const {
	static const bool value = false;
};

template<typename T> struct is_const<T const> {
	static const bool value = true;
};

} /* namespace util */
#endif
