/**                                                                        
 * This program is free software; you can redistribute it and/or modify  
 * it under the terms of the GNU General Public License as published by  
 * the Free Software Foundation; either version 2 of the License, or     
 * (at your option) any later version.                                   
 *                                                                         
 * util/counted_object.h
 * Part of ezbounce
 * (c) 2007 Murat Deligonul
 */

#ifndef __UTIL_COUNTED_OBJECT_H
#define __UTIL_COUNTED_OBJECT_H

#include <cstddef>
#include "debug.h"

namespace util {

/**
 * When used as a base class, counts how many instances of an object 
 * have been created.  
 */
template<class T> class counted_object {
private:
	static size_t _count;

public:
	counted_object() {
		++_count;
	}
	counted_object(const counted_object&) {
		++_count;
	}
	~counted_object() {
		--_count;
	}

	static size_t count() {
		return _count;
	}
};

template<class T> size_t counted_object<T>::_count = 0;

}
#endif /* __UTIL_COUNTED_OBJECT_H */
