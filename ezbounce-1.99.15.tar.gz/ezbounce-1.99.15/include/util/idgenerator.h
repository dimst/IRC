/* util/idgenerator.h
 * part of ezbounce
 * (c) 2003-2007 Murat Deligonul  **/

#ifndef __UTIL_ID_GENERATOR_H
#define __UTIL_ID_GENERATOR_H

#include <cstdlib>
#include <cstring>
#include "debug.h"

namespace util {

class id_generator {
private:
	static const unsigned int CHUNK;
	unsigned int * base;
	unsigned int alloced;

public:
	id_generator(unsigned int init = 4) {
		base = new unsigned int[init];
		memset(base, 0, sizeof(unsigned int) * init);
		alloced = init;
	}
	~id_generator() { delete[] base; }

	unsigned int generate();
	unsigned int get(unsigned int) const;
	void clear(unsigned int x) { DEBUG("idgenerator::clear(%u) [%p]\n", x,this); set(x, false); }
	void set(unsigned int, bool = true);

private:
	id_generator(const id_generator &);
	id_generator& operator = (const id_generator&);
};

}
#endif
