/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * dccfwd.h
 * (C) 2007 Murat Deligonul
 */

#ifndef __DCCFWD_H
#define __DCCFWD_H

// forward declarations only
class dcc;
class dccsend;
class dccget;
class dccpipe;
class dcc_offer;
class dcc_socket;

#endif
