/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * proxy.h
 * (C) 1998-2008 Murat Deligonul
 */

#ifndef __PROXY_H
#define __PROXY_H

#include <string>
#include <list>
#include <vector>
#include <fstream>
#include <ctime>
#include "util/tracked_object.h"
#include "util/timer.h"
#include "util/hash.h"
#include "config/proxy.h"
#include "logging/fwd.h"
#include "logging/levels.h"
#include "fs/fwd.h"
#include "io/engine.h"
#include "net/socket.h"
#include "net/resolver.h"
#include "dccfwd.h"
#include "user.h"

class listen_sock;
class conn;
class ruleset;

class ircproxy {
private:
	const time_t 			st_time;	
	proxy_options 			options;

	std::vector<std::string> 	vhosts;
	std::vector<ruleset *> 		banned;
	userdef::hash_table_t 		user_hash;

	std::ofstream 			logfile;
	logging::logger *		log;

	std::vector<listen_sock *> 	sockets;
	class io::engine * 		engine;
	class net::resolver * 		resolver;
	
	fs::file_system * 		library;

	bool 				terminate_request, 
					rehash_request;
	
private:
	// singleton class
	static ircproxy * proxy;
	ircproxy();

	void kill_conns();
	void kill_dccs();
	void create_timers();
	int process_timers(const util::timer::generic_timer_data *);
	int listen(const char *, unsigned short, bool);
	int start_sockets_raw(const char *, bool);

	void print_all_logs(const char *);
	
	int write_prefs_header(int) const;
	bool is_old_prefs_format(const char *) const;
	int load_old_prefs(const char *);
	
	enum {
		TIMER_30_SEC,
		TIMER_60_SEC,
		TIMER_5_MIN,
		TIMER_10_MIN,
		TIMER_30_MIN,
		TIMER_MIDNIGHT
	};

public:
	static ircproxy * create();
	static ircproxy * instance() { return proxy; }
	~ircproxy();

	const std::list<conn *>& conn_list() { return util::tracked_object<conn>::objects(); }
	const std::list<dcc *>& dcc_list() { return util::tracked_object<dcc>::objects(); }
	const std::list<dcc_offer *>& dcc_offer_list() { return util::tracked_object<dcc_offer>::objects(); }

	std::vector<std::string>& vhost_list() { return vhosts; }
	std::vector<ruleset *>& shitlist() { return banned; }

	fs::file_system * vfs() { return library; }	
	userdef::hash_table_t& users() { return user_hash; }
	const proxy_options& config() const { return options; }

	int set_config_data(proxy_options &, userdef::hash_table_t&, 
				std::vector<std::string>&, std::vector<ruleset *>&);
	int set_config_file(const char *);
	
public:
	int event_loop();
	int request_shutdown(bool, const char *);
	int request_rehash();

	int startlog();
	int stoplog();	
	int redir_stdxxx();
	int setup_vfs(std::string&);
	int setup_sockets();
	int setup_ssl();
	int start_sockets();
	int start_ssl_sockets();
	int rehash();
	int save_prefs();
	int load_prefs();

	int printlog(const char *, ...);
	int printlog(logging::level, const char *, ...);

	userdef * lookup_user(const char * name) {
		userdef::hash_table_t::iterator i = user_hash.find(name);
		return i == user_hash.end() ? NULL : (*i).second;
	}

	int num_ports() const { 
		return sockets.size(); 
	}

	bool has_vfs() const {
		return library != NULL;
	}

	time_t time() const { 
		using util::timer;
		return timer::now(); 
	}
	time_t start_time() const { 
		return st_time; 
	}

private:
	// non-copyable
	ircproxy(const ircproxy&);
	ircproxy& operator =(const ircproxy&);
};	
#endif  /* __PROXY_H */
