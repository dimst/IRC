/**
  * config/traits.h
  */

#ifndef __CONFIG_TRAITS_H
#define __CONFIG_TRAITS_H

#include <string>
#include <ostream>
#include "util/strings.h"
#include "config/defaults.h"
#include "config/types.h"

namespace config {

using std::string;

// forward declaration
template<typename V> struct limits;

/**
  * Template Magic.
  */
template<typename T, typename V> struct traits;

/**
 * Boolean Options
 */
template<typename T> struct traits<T, bool> {
	typedef typename T::bool_option 		identifier_t;
	static const identifier_t 	MAX_IDENTIFIER = T::BOOL_MAX;
	static const option_type 	OPTION_TYPE = config::BOOLEAN;

	typedef defaults<identifier_t, bool, MAX_IDENTIFIER> 	defaults_t;
	typedef limits<bool>					limits_t;
	static const defaults_t& DEFAULTS;

	/* Helper function for prettier printing */
	static void print(std::ostream& out, bool val) {
		out << ((val == true) ? "true" : "false");
	}		
};

template<typename T> 
	const typename traits<T, bool>::defaults_t & 
		traits<T,bool>::DEFAULTS = T::defaults.bool_defaults;


/**
 * Int Options 
 */	
template<typename T> struct traits<T, int> {
	typedef typename T::int_option 			identifier_t;
	static const identifier_t 	MAX_IDENTIFIER = T::INTEGER_MAX;
	static const option_type 	OPTION_TYPE = config::INTEGER;

	typedef defaults<identifier_t, int, MAX_IDENTIFIER> 	defaults_t;
	typedef limits<int>					limits_t;
	static const defaults_t& DEFAULTS;

	/* Helper function for prettier printing; nothing to do here. */
	static void print(std::ostream& out, int val) {
		out << val;
	}		
};

template<typename T> 
	const typename traits<T, int>::defaults_t & 
		traits<T, int>::DEFAULTS = T::defaults.integer_defaults;


/**
 * String Options 
 */
template<typename T> struct traits<T, string> {
	typedef typename T::string_option 		identifier_t;

	static const identifier_t 	MAX_IDENTIFIER = T::STRING_MAX;
	static const option_type 	OPTION_TYPE = config::STRING;

	typedef defaults<identifier_t, const char *, MAX_IDENTIFIER> 	defaults_t;
	typedef limits<const char *>					limits_t;
	static const defaults_t& DEFAULTS;

	/**
	 * Helper function for prettier printing:
	 * Enclose string in quotes.
	 */
	static void print(std::ostream& out, const string &val) {
		using util::strings::escape_quotes;
		const std::string& clean = escape_quotes(val);
		out << '\"' << clean << '\"';
	}		
};

template<typename T>
	const typename traits<T, string>::defaults_t & 
		traits<T, string>::DEFAULTS = T::defaults.string_defaults;

/**
  * Used in the config defaults code. 
  */
template<typename T> struct default_set {
	const typename traits<T, bool>::defaults_t 		bool_defaults;	
	const typename traits<T, int>::defaults_t		integer_defaults;
	const typename traits<T, string>::defaults_t		string_defaults;
};

}
#endif
