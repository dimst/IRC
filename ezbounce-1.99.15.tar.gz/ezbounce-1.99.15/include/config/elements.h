/**
  * config/elements.h
  *
  * part of ezbounce
  * (c) 2006-2008 Murat Deligonul
  */

#ifndef __CONFIG_ELEMENTS_H
#define __CONFIG_ELEMENTS_H

#include "config/defaults.h"
#include "config/traits.h"
#include "irc/rfc1459.h"

using config::defaults;
using config::default_set;


/**
 * proxy configuration options first
 */
struct proxy_config {
public:
	static const char NAME[];
	enum bool_option {
		SILENT_REJECTION,
		ENCRYPTED_PASSWORDS,
		BOOL_MAX
	};
	
	enum int_option {
		MIN_BUFFER_SIZE = 0,
		MAX_BUFFER_SIZE,
		MAX_SOCKETS,
		MAX_FAILED_PASSWORDS,
		MAX_VFS_AGE,
		MAX_REGISTER_TIME,
		INTEGER_MAX
	};

	enum string_option {
		PORTS 	= 0,
		SSL_PORTS = 1,
		DCC_PORTS,
		CONFIG_FILE,
		LOG_FILE,
		PID_FILE,
		CERT_FILE,
		MOTD_FILE,
		USER_FILE,
		LISTEN_VHOST,
		VFS_DIR,
		FAKE_IDENT_METHOD,
		GREET_METHOD,
		STRING_MAX
	};
	static const struct default_set<proxy_config> defaults;
};

/**
 * User permissions, as defined in the proxy configuration.
 * These aren't configurable by the user.
 */
struct user_perms {
public:
	static const char NAME[];

	enum bool_option {
		ENABLE_VFS_ACCESS = 0,
		ENABLE_DCC_STORAGE,
		ENABLE_OUTGOING_DCC_PROXYING,
		ENABLE_INCOMING_DCC_PROXYING,
		ENABLE_CHAT_LOGGING,
		ENABLE_PER_CHANNEL_LOGGING,
		ENABLE_DETACH_COMMAND,
		ENABLE_FAKE_IDENTS,
		ENABLE_VHOST_COMMAND,
		IS_ADMIN,
		IS_VFS_SUPERUSER,
		ENABLE_COMPRESSION,
		BOOL_MAX
	};

	enum int_option {
		MAX_IDLE_TIME,
		MAX_DCCS,
		VFS_QUOTA,
		INTEGER_MAX
	};

	enum string_option {
		PASSWORD,
		HOME_DIR,		/* XXX: dunno */
		STRING_MAX
	};

	static const struct default_set<user_perms> defaults;
};

/**
 * User configurable preferences.
 */
struct user_config {
public:
	static const char NAME[];

	enum bool_option { 
		BOOL_MAX = 0,
	};

	enum int_option {
		INTEGER_MAX = 0,
	};

	enum string_option {
		AUTO_SERVER,
		FAKE_IDENT,
		VHOST,
		CHATLOG_DIR,
		DCC_IN_DIR,
		DCC_OUT_DIR,
		STRING_MAX
	};

	static const struct default_set<user_config> defaults;
};

struct irc_network_config {
public:
	static const char NAME[];

	enum bool_option { 
		BOOL_MAX,
	};

	enum int_option {
		INTEGER_MAX
	};

	enum string_option {
		STRING_MAX
	};

	/* Node name comparison function */
	static int strcasecmp(const char * s1, const char * s2) {
		extern int strcasecmp(const char *, const char *);
		return ::strcasecmp(s1, s2);
	}

	/* Default Values */
	static const struct default_set<irc_network_config> defaults;
};

struct irc_server_config {
public:
	static const char NAME[];

	enum bool_option {
		AUTO_DETACH,
		PROXY_DCC_IN,
		PROXY_DCC_OUT,
		FILTER_DCCS,
		LOG_PRIVATE,
		COMPRESS_PRIVATE_LOG,
		AUTO_RECONNECT,
		ANTI_IDLE,
		PART_ON_DISCONNECT,
		BOOL_MAX,
	};

	enum int_option {
		MAX_RECONNECT_TRIES,
		RECONNECT_DELAY,
		INTEGER_MAX,
	};

	enum string_option {
		CTCP_VERSION_REPLY,
		SERVER_PASSWORD,
		DETACH_NICK,
		DETACH_AWAY_MSG,
		STRING_MAX
	};

	/* Node name comparison function */
	static int strcasecmp(const char * s1, const char * s2) {
		extern int strcasecmp(const char *, const char *);
		return ::strcasecmp(s1, s2);
	}

	/* Default values */
	static const struct default_set<irc_server_config> defaults;
};

struct irc_channel_config {
public:
	static const char NAME[];

	enum bool_option { 
		AUTO_REJOIN,
		LOG_DETACHED_ONLY,
		LOG_ALWAYS,
		LOG_OWN_FILE,		
		LOG_ADDRESSES,	
		LOG_TIMESTAMPS,
		COMPRESS_LOG,
		BOOL_MAX 
	};

	enum int_option {
		INTEGER_MAX
	};

	enum string_option {
		CHANNEL_PASSWORD,
		STRING_MAX
	};

	static int strcasecmp(const char * s1, const char * s2) {
		return irc::irc_casecmp(s1, s2);
	}

	static const struct default_set<irc_channel_config> defaults;
};
#endif
