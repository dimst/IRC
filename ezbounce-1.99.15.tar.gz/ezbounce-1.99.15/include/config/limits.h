/**
  * config/limits.h
  */

#ifndef __CONFIG_LIMITS_H
#define __CONFIG_LIMITS_H

#include <string>
#include <sstream>

// TODO: not sure how to handle strings

namespace config {

template<typename V> struct limits;

/**
  * Generic version. Legal values are >= min and <= max
  */
template<typename V> struct limits {
	const V min;
	const V max;
	bool check(const V& compare) const {
		return compare >= min && compare <= max;
	}

	void explain(std::string& out) const {
		std::ostringstream os;
		os << "value must be >= " << min << " and <= " << max;
		out = os.str();
	}
};


/**
  * Specialization for bool: silly.
  */
template<> struct limits<bool> {

	bool check(bool) const { 
		return true;
	}

	void explain(std::string&) const {
		/* nothing to explain. */
	}
};

/**
  * Specialization for const char *: 
  *  Also used by std::string, with hacks.
  * Uses separate comparator function to validate values.
  */
template<> struct limits<const char *> {
	bool (*const comparator)(const char *);
	void (*const explain_fn)(std::string&);

	bool check(const std::string& param) const {
		return check(param.c_str());
	}

	bool check(const char * param) const {
		if (comparator != NULL) { 
			return comparator(param);
		}
		return true;
	}

	void explain(std::string& out) const {
		if (explain_fn != NULL) {
			explain_fn(out);
		}
		else {
			out = "value is not allowed";
		}
	}
};

}
#endif
