/**
  * config/errors.h
  */

#ifndef __CONFIG_ERRORS_H
#define __CONFIG_ERRORS_H

namespace config {

enum config_error {
	SUCCESS 		= 0,
	TOO_FEW_ARGS		= -1,
	TOO_MANY_ARGS		= -2,
	UNKNOWN_OPTION		= -3,
	ILLEGAL_OPTION		= -4,
	UNKNOWN_CLASS		= -5,
	CLASS_OUT_OF_ORDER	= -6
};

/**
  * Result from a target list parse.  First part refers to 
  * error code (or SUCCESS), second part is token offset at which
  * the parse failed.
  */
typedef std::pair<config_error, int> parse_result;

extern const char * strerror(config_error);

}
#endif

