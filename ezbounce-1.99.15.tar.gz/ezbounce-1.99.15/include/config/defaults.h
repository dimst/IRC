/**
  * config/defaults.h
  */

#ifndef __CONFIG_DEFAULTS_H
#define __CONFIG_DEFAULTS_H

#include "config/limits.h"

namespace config {

/**
  * Aliases for config variable names:
  * Somewhat of a hack; the number of aliases is specified and all aliases
  * are inserted into one string literal separated by '\0'.
  */ 
struct item_aliases {
	unsigned int num;
	const char * aliases;
};

/**
  * Properties for a config setting's name.
  */
struct item_name {
	const char * 	name;
	item_aliases 	aliases;
	const char * 	desc;
};


template<typename I, typename V> struct setting {
	const I id;
	const V value;
	const struct limits<V> limits;
	const struct item_name info;
};


template<typename I, typename V, int N> struct defaults {
	typedef struct setting<I, V> setting_t;

	const setting_t settings[N];
	enum {
		SIZE = N
	};
};

/** 
  * Partial specialization necessary for N=0 case since some compilers
  * do not support zero-length arrays.  (I'm also not sure if they are legal
  * to begin with)
  */
template<typename I, typename V> struct defaults<I, V, 0> {
	typedef struct setting<I, V> setting_t;

	setting_t settings[1];
	enum {
		SIZE = 0
	};
};
}
#endif
