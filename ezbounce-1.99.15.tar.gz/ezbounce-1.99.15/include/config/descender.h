/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * config/descender.h
 * (c) 2007-2008 Murat Deligonul
 */

#ifndef __CONFIG_DESCENDER_H
#define __CONFIG_DESCENDER_H

#include <vector>
#include <string>
#include <stdexcept>
#include <cstring>
#include "util/hash.h"
#include "config/traits.h"

namespace config {

// forward declaration
template<typename, typename> class node;

using std::vector;
using std::string;
using util::hash_table;

/**
 * Recursive node access helper.  Moved some of the tree-descending operations here to 
 * manage clutter as well as specify what level to stop the descent.
 */
template <typename T, int DISTANCE> class descender {
private:
	descender();
	typedef typename T::child_type child_type;
	typedef typename T::config_type config_type;

private:
	static void fill_hash(hash_table<const char *, hash_entry *> * out) {
		T::template fill_hash_entries<int>(T::ID, out);
		T::template fill_hash_entries<bool>(T::ID, out);
		T::template fill_hash_entries<string>(T::ID, out);
		descender<child_type, DISTANCE-1>::fill_hash(out);
	}

	static int lookup_class(const char * name) {
		if (strcasecmp(config_type::NAME, name) == 0) {
			return T::ID;
		}
		return descender<child_type, DISTANCE-1>::lookup_class(name);
	}

	static const char * lookup_id(int i) {
		if (T::ID == i) {
			return config_type::NAME;
		}
		return descender<child_type, DISTANCE-1>::lookup_id(i);
	}

	template<typename N> static N * find_descendant(const T *, const target_list&);

	/** 
	  * get() and set() helper functions
	  */
	template<typename I, typename V> static bool get_helper(const T *, const target_list&, I opt, const V ** out);
	template<typename I, typename V> static void set_helper(T *, const target_list&, I opt, const V * val);

	/**
	  * Run time user input -> type safe binding helper functions.
	  */
	template<typename S, typename V> static const V& dispatch_get(const S * source, const target_list& targets, int opt) {
		if (S::ID - T::ID == targets.size()) {
			return source->template get<T, V>(targets, typename traits<typename T::config_type, V>::identifier_t(opt));
		}
		return descender<child_type, DISTANCE-1>::template dispatch_get<S,V>(source, targets, opt);
	}

	template<typename S, typename V> static void dispatch_set(S * source, const target_list& targets, int opt, const V * val) {
		if (S::ID - T::ID == targets.size()) {
			if (val != NULL) {
				source->template set<T, V>(targets, typename traits<typename T::config_type, V>::identifier_t(opt), *val);
				return;
			}
			source->template unset<T, V>(targets, typename traits<typename T::config_type, V>::identifier_t(opt));
			return;
		}
		descender<child_type, DISTANCE-1>::template dispatch_set<S,V>(source, targets, opt, val);
	}

	template<typename S, typename V> static bool dispatch_is_set(const S * source, const target_list& targets, int opt) {
		if (S::ID - T::ID == targets.size()) {
			return source->template is_set<T, V>(targets, typename traits<typename T::config_type, V>::identifier_t(opt));
		}
		return descender<child_type, DISTANCE-1>::template dispatch_is_set<S,V>(source, targets, opt);
	}

	/**
	  * Friends.
          * XXX: the config:: prefix was needed to work around a gcc 3.2.3 ICE issue.
	  */
	template<typename, typename> friend class config::node;
	template<typename> friend class node_searcher;
	template<typename, int> friend class descender;
};

/**
 * Base case for most operations.
 * Some operations require a case for DISTANCE=0, which we also have to define..
 */
template <typename T> class descender<T, 1> {
private:
	descender();

	static const int DISTANCE = 1;
	typedef typename T::child_type child_type;
	typedef typename T::config_type config_type;

private:
	static void fill_hash(hash_table<const char *, hash_entry *> * out) {
		T::template fill_hash_entries<int>(T::ID, out);
		T::template fill_hash_entries<bool>(T::ID, out);
		T::template fill_hash_entries<string>(T::ID, out);
		descender<child_type, DISTANCE-1>::fill_hash(out);
	}

	static int lookup_class(const char * name) {
		if (strcasecmp(config_type::NAME, name) == 0) {
			return T::ID;
		}
		return descender<child_type, DISTANCE-1>::lookup_class(name);
	}

	static const char * lookup_id(int i) {
		if (T::ID == i) {
			return config_type::NAME;
		}
		return descender<child_type, DISTANCE-1>::lookup_id(i);
	}

	template <typename N> static N * find_descendant(const T * node, const target_list& targets) {
		const config_target& target = targets.back();
		if (child_type::config_type::strcasecmp(target, "all") == 0) {
			throw std::invalid_argument("invalid query for target 'all'");
		}
		return node->find_direct_child(target);
	}

	/**
	  * get() and set() helper functions.
	  */
	template <typename I, typename V> static bool get_helper(const T * node, const target_list& targets, I opt, const V ** out) {
		// TODO: allow empty target list (default to "default" ?)
		assert(!targets.empty());
		
		// get queries cannot contain "all" in their target
		const config_target& target = targets.back();
		if (child_type::config_type::strcasecmp(target, "all") == 0) {
			throw std::invalid_argument("invalid query for target 'all'");
		}

		vector<child_type *> new_targets;
		int r = node->delegate(target, new_targets);			
		const child_type * child = (r < 0) ? &node->default_child : new_targets.front();

		bool test = child->template is_set<V>( opt );
		if (test == false && child != &node->default_child) {
			child = &node->default_child;
			test = child->template is_set<V>( opt );
		}
		if (test == true) {
			*out = & (child->template get<V>(opt));
		}
		return test;
	}

	template<typename I, typename V> static void set_helper(T * node, const target_list& targets, I opt, const V * val) {
		vector<child_type *> new_targets;
		// TODO: allow empty target list (defaulting to "default" ?)
		assert(!targets.empty());

		const config_target& target = targets.back();
		int r = node->delegate(target, new_targets);
		if (r < 0) {
			/**
			  * If unset operation is requested, creating new nodes doesn't make sense. 
			  * Silently ignore. 
			  */
			if (val == NULL) {
				return;
			}
			/** Must create this node **/
			child_type * c = node->add_child(target);
			new_targets.push_back(c);
		}

		typename vector<child_type *>::iterator i = new_targets.begin(), 
							 e = new_targets.end();

		/* Direct child(ren) is/are intended target */
		if (val != NULL) {
			for (; i != e; ++i) {
				(*i)->template set<V>(opt, *val);
			}
		}
		else {
			for (; i != e; ++i) {
				(*i)->template unset<V>(opt);
			}
		}
	}

	/**
	  * Run time user input -> type safe binding helper functions.
	  */
	template<typename S, typename V> static const V& dispatch_get(const S * source, const target_list& targets, int opt) {
		if (S::ID - T::ID == targets.size()) {
			return source->template get<T, V>(targets, typename traits<typename T::config_type, V>::identifier_t(opt));
		}
		// short cut
		return source->template get<child_type, V>(targets, typename traits<typename child_type::config_type, V>::identifier_t(opt));
	}

	template<typename S, typename V> static bool dispatch_is_set(const S * source, const target_list& targets, int opt) {
		if (S::ID - T::ID == targets.size()) {
			return source->template is_set<T, V>(targets, typename traits<typename T::config_type, V>::identifier_t(opt));
		}
		// short cut
		return source->template is_set<child_type, V>(targets, typename traits<typename child_type::config_type, V>::identifier_t(opt));
	}

	template<typename S, typename V> static void dispatch_set(S * source, const target_list& targets, int opt, const V * val) {
		if (S::ID - T::ID == targets.size()) {
			if (val != NULL) {
				source->template set<T, V>(targets, typename traits<typename T::config_type, V>::identifier_t(opt), *val);
				return;
			}
			source->template unset<T, V>(targets, typename traits<typename T::config_type, V>::identifier_t(opt));
			return;
		}
		// short cut
		if (val != NULL) {
			source->template set<child_type, V>(targets, typename traits<typename child_type::config_type, V>::identifier_t(opt), *val);
			return;
		}
		source->template unset<child_type, V>(targets, typename traits<typename child_type::config_type, V>::identifier_t(opt));
	}

	/**
	  * Friends.
	  */
	template<typename, typename> friend class config::node;
	template<typename, int> friend class descender;
};

/**
  * Partial specialization for DISTANCE=0 case.
  * Several operations are undefined or no-ops at this level, since they are meaningless.
  */
template <typename T> class descender<T, 0> {
private:
	descender();

	static const int DISTANCE = 0;
	typedef typename T::config_type config_type;

private:
	static void fill_hash(hash_table<const char *, hash_entry *> * out) {
		T::template fill_hash_entries<bool>(T::ID, out);
		T::template fill_hash_entries<int>(T::ID, out);
		T::template fill_hash_entries<string>(T::ID, out);
	}

	static int lookup_class(const char * name) {
		if (strcasecmp(config_type::NAME, name) == 0) {
			return T::ID;
		}
		return -1;
	}

	static const char * lookup_id(int id) {
		if (T::ID == id) {
			return config_type::NAME;
		}
		return NULL;
	}

	/**
	  * NOTE: no-op at this level.
	  */
	template <typename N> static N * find_descendant(const T *, const target_list&) {
		return NULL;
	}

	/**
	  * get() and set() helper functions.
	  * FIXME: verify target?
	  */
	template <typename I, typename V> static bool get_helper(const T * node, const target_list& targets, I opt, const V ** out) {
		if (node->template is_set<V>(opt)) {
			*out = & (node->template get<V>(opt));
			return true;
		}
		return false;
	}

	template<typename I, typename V> static void set_helper(T * node, const target_list& targets, I opt, const V * val) {
		if (val != NULL) {
			node->template set<V>(opt, *val);
			return;
		}
		node->template unset<V>(opt);
	}

	/**
	  * Friends.
	  */
	template<typename, typename> friend class config::node;
	template<typename> friend class node_searcher;
	template<typename, int> friend class descender;
};

/**
  * Operations for descender class, general case.
  */
template<typename T, int DISTANCE> 
	template<typename N> 
	N * descender<T, DISTANCE>::find_descendant(const T * node, const target_list& targets) 
{
	const child_type * child = &node->default_child;
	if (targets.size() >= DISTANCE) {
		// "get" request targets cannot contain "all"
		const config_target& target = targets[targets.size() - DISTANCE];
		if (child_type::config_type::strcasecmp(target, "all") == 0) {
			throw std::invalid_argument("invalid query for target 'all'");
		}

		child = node->find_direct_child(target);
		if (child == NULL) {
			child = &node->default_child;
		}
	}
	return descender<child_type, DISTANCE-1>::template find_descendant<N>(child, targets);
}

/**
  * get() helper; general case.
  */
template<typename T, int DISTANCE>
	template<typename I, typename V>
	bool descender<T, DISTANCE>::get_helper(const T * node, const target_list& targets, I opt, const V ** out)
{
	if (DISTANCE > targets.size()) {
		return descender<child_type, DISTANCE-1>::template get_helper<I, V>(&node->default_child, targets, opt, out);
	}
	
	// get request targets cannot contain "all"
	const config_target& target = targets[targets.size() - DISTANCE];
	if (child_type::config_type::strcasecmp(target, "all") == 0) {
		throw std::invalid_argument("invalid query for target 'all'");
	}

	vector<child_type *> new_targets;
	int r = node->delegate(target, new_targets);
	const child_type * child = (r < 0) ? &node->default_child : new_targets.front(); 

	bool test = descender<child_type, DISTANCE-1>::template get_helper<I,V>(child, targets, opt, out);
	if (test == false && child != &node->default_child) {
		test = descender<child_type, DISTANCE-1>::template get_helper<I,V>(&node->default_child, targets, opt, out);
	}
	return test;
}

/**
  * set() and unset() helper; general case.
  * NOTE: val parameter has pointer to data.  It is set to NULL if unset operation is requested.
  */
template<typename T, int DISTANCE>
	template<typename I, typename V>
	void descender<T, DISTANCE>::set_helper(T * node, const target_list& targets, I opt, const V * val)
{
	vector<child_type *> new_targets;

	if (targets.size() >= DISTANCE) {
		const config_target& target = targets[targets.size() - DISTANCE];
		int r = node->delegate(target, new_targets);
		if (r < 0) {
			/* If unset operation is requested, creating new nodes doesn't make sense. 
			 * Silently ignore. */
			if (val == NULL) {
				return;
			}
			/* Otherwise, must create this node */
			child_type * c = node->add_child(target);
			new_targets.push_back(c);
		}
	}
	else {
		new_targets.push_back(&node->default_child);
	}

	typename vector<child_type *>::iterator i = new_targets.begin(), e = new_targets.end();
	for (; i != e; ++i) {
		/* General case */
		descender<child_type, DISTANCE-1>::template set_helper<I,V>(*i , targets, opt, val);
	}
}

} 
#endif /* __CONFIG_DESCENDER_H */
