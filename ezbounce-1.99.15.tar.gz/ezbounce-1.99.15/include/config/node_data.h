/**
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation; either version 2 of the License, or
  * (at your option) any later version.
  *
  * config/node_data.h 
  * (c) 2007 Murat Deligonul
  */
#ifndef __CONFIG_NODE_DATA_H
#define __CONFIG_NODE_DATA_H

#include <ostream>
#include <algorithm>
#include <string>
#include <cstdlib>
#include "util/managed_table.h"
#include "util/hash.h"
#include "config/traits.h"
#include "config/types.h"
#include "debug.h"

#define NODE_DATA_PERFORM_RANGE_CHECKS

namespace config {

using std::string;
using util::hash_table;
using util::managed_table;

/**
 * Provides common code for all node classes to store and access
 * their data.
 */
template<typename T> class node_data {
public:
	static const int INT_SIZE 	= traits<T, int>::MAX_IDENTIFIER;
	static const int BOOL_SIZE	= traits<T, bool>::MAX_IDENTIFIER;
	static const int STRING_SIZE	= traits<T, string>::MAX_IDENTIFIER;

	// type definitions
	typedef managed_table<int, INT_SIZE>			int_table_t;
	typedef managed_table<bool, BOOL_SIZE>			bool_table_t;
	typedef managed_table<string, STRING_SIZE>		string_table_t;

private:
	int_table_t		int_table;
	bool_table_t		bool_table;
	string_table_t		string_table;

public:
	node_data() { }
	void swap(node_data &);

	/** 
	 * Parameterized data set/get/check functions.
	 * They perform range checking and validation of input.
	 */
	template<typename V> void set(typename traits<T,V>::identifier_t i, const V& val) {
		range_check<V>(i);
		typename traits<T,V>::limits_t const & limits = traits<T,V>::DEFAULTS.settings[ unsigned(i) ].limits;
		if (!limits.check(val)) {
			std::string reason;
			limits.explain(reason);
			throw std::invalid_argument(reason);		
		}
		managed_table<V, traits<T,V>::MAX_IDENTIFIER>& t = table((V *) NULL);
		t.set(i, val);
	}

	template<typename V> void unset(typename traits<T,V>::identifier_t i) {
		managed_table<V, traits<T,V>::MAX_IDENTIFIER>& t = table((V *) NULL);
		t.unset(i);
	}

	template<typename V> const V& get(typename traits<T,V>::identifier_t i) const {	
		range_check<V>(i);
		// FIXME: should also check if option is assigned
		assert(is_set<V>(i));	

		const managed_table<V, traits<T,V>::MAX_IDENTIFIER>& t = table((V *) NULL);
		return t.get(i);				
	}

	template<typename V> bool is_set(typename traits<T,V>::identifier_t i) const {
		range_check<V>(i);
		const managed_table<V, traits<T,V>::MAX_IDENTIFIER>& t = table((V *) NULL);
		return t.is_set(i);			
	}

	
	/**
	 * Printing of values, loading of defaults, and hash table helpers
	 */
	template <typename V> void print_values(std::ostream &, int = 0);	
	template <typename V> void load_defaults();
	template <typename V> static void fill_hash_entries(int, hash_table<const char *, hash_entry *> *);

private:
	/**
	 * Range checking function -- I'm not sure whether to use this since the 
	 * only way this can be violated is by using stupid type casts.
	 */
	template<typename V> static void range_check(typename traits<T, V>::identifier_t i) {
#ifdef NODE_DATA_PERFORM_RANGE_CHECKS
		if (i >= traits<T,V>::MAX_IDENTIFIER) {
			throw std::out_of_range("option value of out of range");
		}
#endif
	}

	/** 
	 * Hacks needed to access the proper tables.
	 */
	int_table_t& table(int *) {
		return int_table;
	}
	bool_table_t& table(bool *) {
		return bool_table;
	}
	string_table_t& table(string *) {
		return string_table;
	}

	const int_table_t& table(int *) const {
		return int_table;
	}
	const bool_table_t& table(bool *) const {
		return bool_table;
	}
	const string_table_t& table(string *) const {
		return string_table;
	}

private:
	/* forbidden operations */
	node_data(const node_data&);
	node_data& operator=(const node_data&);
};

/**
  * Swap data members.
  */
template<typename T> void node_data<T>::swap(node_data<T>& that) 
{
	if (&that == this) {
		return;
	}
	std::swap(int_table, that.int_table);
	std::swap(bool_table, that.bool_table);
	std::swap(string_table, that.string_table);
}


/**
 * Load defaults settings for this node, for type V.
 */
template<typename T> 
	template<typename V>
	inline void node_data<T>::load_defaults()
{
	DEBUG("%s - loading defaults\n", __PRETTY_FUNCTION__);
	for (unsigned i = 0; i < traits<T,V>::defaults_t::SIZE; ++i) {
		typename traits<T, V>::defaults_t::setting_t const& 
				setting = traits<T,V>::DEFAULTS.settings[i];
		assert(unsigned(setting.id) == i);
		set<V>(setting.id, setting.value);
	}
}

/**
 * Print current values for this node in ezbounce configuration file format.
 */
template <typename T>
	template <typename V>
	void node_data<T>::print_values(std::ostream &out, int off) 
{
	std::string padding(off, '\t');

	for (unsigned i = 0; i < traits<T,V>::defaults_t::SIZE; ++i) {
		typename traits<T, V>::defaults_t::setting_t const& 
				setting = traits<T,V>::DEFAULTS.settings[i];
		if (!is_set<V>(setting.id)) {
			continue;
		}
		const V val = get<V>(setting.id);

		out << padding << "set \"" << setting.info.name << "\" ";
		traits<T,V>::print(out, val);
		out << "\n";
	}
}

/**
 * Populate a hash table with entries for this type.
 */
template <typename T> 
	template <typename V> 
	/* static */ void node_data<T>::fill_hash_entries(int id, hash_table<const char *, hash_entry *> * out)
{
 	for (unsigned i = 0; i < traits<T,V>::defaults_t::SIZE; ++i) {
		typename traits<T, V>::defaults_t::setting_t const& 
				setting = traits<T,V>::DEFAULTS.settings[i];
		hash_entry * entry = new hash_entry;
		memset(entry, 0, sizeof (hash_entry));	
		
		entry->item = &setting.info;
		entry->type = traits<T,V>::OPTION_TYPE;
		entry->option = (int) setting.id;
		entry->level  = id;

		out->insert(entry->item->name, entry);

		// do aliases if necessary
		const char * alias = setting.info.aliases.aliases;
		for (unsigned j = 0; j < setting.info.aliases.num; ++j) {
                        hash_entry * new_entry = new hash_entry;
                        memset(new_entry, 0, sizeof(hash_entry));
                        memcpy(new_entry, entry, sizeof(hash_entry));
			out->insert(alias, new_entry);
			alias += strlen(alias) + 1;
		}
	}
}

}
#endif
