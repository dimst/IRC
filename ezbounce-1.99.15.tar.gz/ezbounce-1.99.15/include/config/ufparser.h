/***********************************
 * config/ufparser.h 
 * part of ezbounce
 * (c) 2006 Murat Deligonul
 ***********************************
 */

#ifndef __CONFIG_UFPARSER_H
#define __CONFIG_UFPARSER_H

#include <vector>
#include "config/user.h"
#include "config/proxy.h"
#include "util/hash.h"
#include "parser_core.h"
#include "../user.h"

class ruleset;
class cstrtok;

/**
 * Currently supports:
 *  	different users with network/server/channel preferences
 *	custom irc server lists (stub functionality only)
 *
 * TODO:	
 *	will there be any server-level runtime configurable options??
 */
class userfile_parser : public parser_core {
private:
	proxy_options 					& options;
	const userdef::hash_table_t		 	& users;
	parser_core::hash_table_t			chash;

public: 
	userfile_parser(const char *, proxy_options &, const userdef::hash_table_t &);
	virtual ~userfile_parser();

private:	
	/* implementation details .. */
	virtual int	enter_context(const config_symbol *, context &, std::vector<config_token> &, std::vector<config_token> &);
	virtual int	leave_context(context &, bool);
	virtual int 	do_command(const config_symbol *, std::vector<config_token> &, std::vector<config_token> &);
	virtual int 	validate_config() const;

	virtual int 	resolve_trailing_args(std::vector<config_token>& );
	virtual const parser_core::hash_table_t * symbol_table() const; 
	virtual const char * str_context(int) const;
	// virtual const char * str_argtype(int) const;

	int do_set_command(const config_symbol *, std::vector<config_token> &, std::vector<config_token> &);
	int do_version_command(const config_symbol *, std::vector<config_token> &, std::vector<config_token> &);

	/* possible states */
	enum {
		CTX_USER   		= 0x8,
		CTX_USER_OPTIONS	= 0x10,
		CTX_NETWORK  		= 0x20,
	       	CTX_SERVER		= 0x40,
		CTX_CHANNEL		= 0x80,
		CTX_SERVER_LIST 	= 0x100
	};	

	/* argument type patterns */
	static const int 	SET_ARG_PATTERN[],
				BLOCK_ARG_PATTERN[],
				OPTION_BLOCK_ARG_PATTERN[];

	static const struct config_symbol 		 	symtab[];

private:
	/* forbidden operations */
	userfile_parser(const userfile_parser &);
	userfile_parser & operator=(const userfile_parser &);
};
#endif

