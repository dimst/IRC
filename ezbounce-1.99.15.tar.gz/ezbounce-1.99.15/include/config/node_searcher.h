/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * config/node_searcher.h
 * (c) 2007 Murat Deligonul
 */

#ifndef __CONFIG_NODE_SEARCHER_H
#define __CONFIG_NODE_SEARCHER_H

#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
#include "util/hash.h"
#include "config/types.h"
#include "config/errors.h"
#include "config/descender.h"
#include "util/generic.h"

namespace config {

using std::vector;
using std::string;

/**
  * Maintains a hash table of all config variables for a particular node class.
  */
template <typename T> class node_searcher {
private:
	typedef hash_table<const char *, hash_entry *> hash_table_t;
	static hash_table_t table;

	node_searcher();
public:
	/**
	  * Populate hash table with all config variable names.
	  */
	static void populate_table() {
		if (!table.empty()) {
			return;
		}
		descender<T, T::ID>::fill_hash(&table);
	}

	/**
	 * Clear hash table.
	 */
	static void clear_table() {
		using util::apply_second;
		std::for_each(table.begin(), table.end(), apply_second<util::delete_ptr>());
		table.clear();
		assert(table.empty());
	}

	/**
	  * Search for a config option in the hash table.
	  * Return NULL if the option doesn't exist.
	  */
	static const hash_entry * lookup_option(const char * opt) {
		hash_table_t::iterator i = table.find(opt);
		return i == table.end() ? NULL : (*i).second;
	}

	/**
	  * Lookup integer id of a node class name (e.g. "channel", "server", "network")
	  */
	static int lookup_class(const char * name) {
		return descender<T, T::ID>::lookup_class(name);
	}

	/**
	  * Lookup string node class name from node level id.
	  */
	static const char * lookup_id(int id) {
		return descender<T, T::ID>::lookup_id(id);
	}

	/**
	  * Utility functions to aid with parsing config requests issued at runtime.
	  */
	static parse_result parse_user_command(const vector<parse_token>&, target_list&, const hash_entry **);
	static int validate_target_list(const target_list&, const parse_token&,  const hash_entry **); 
	static void generate_user_command(const target_list&, vector<string> &);
};

template<typename T> typename node_searcher<T>::hash_table_t 
	node_searcher<T>::table(17);

/**
  * Parses an expression of the form:
  * [<class-name> name]* <option>
  * 
  * Parameters:
  *		args			vector of parse_token (currently const char *) containing
  *					user-provided data.  Do not include the value parameter in this vector.
  * 
  * Returns:
  *		targets:		vector of config_target's describing the path to the target node(s)
  *		out:			pointer to hash_entry describing option to be manipulated
  *		int:			whether operation succeeded
  *
  */
template<typename T> parse_result node_searcher<T>::parse_user_command(const vector<parse_token>& args,
								target_list& targets, const hash_entry ** out) 
{
	const unsigned size = args.size();
	if (size == 0) {
		return parse_result(TOO_FEW_ARGS, -1);
	}

	const parse_token& option = args.back();

	const hash_entry * h = lookup_option(option);
	if (h == NULL) {
		return parse_result(UNKNOWN_OPTION, size-1);
	}

	const int DISTANCE = T::ID - h->level;
	if (DISTANCE < 0) {
		/* Shouldn't happen. */
		return parse_result(ILLEGAL_OPTION, size-1);
	}
	const unsigned MAX_ARGS = 2 * (unsigned) DISTANCE;
	if (size > MAX_ARGS+1) {
		return parse_result(TOO_MANY_ARGS, MAX_ARGS);
	}

	targets.reserve(DISTANCE);

	int prev = T::ID;
	unsigned odd = 1;
	for (unsigned i = 0; i < size-1; ++i, odd ^= 1) {
		const parse_token& token = args[i];
		/**
	  	  * Even numbered argument: channel name, server name, etc.
		  * TODO: could verify legality of name here
		  */
		if (! (odd & 1)) {
			targets.push_back(token);
			continue;
		}

		/**
		 * Odd numbered argument must be a node class name
		 * (e.g. "server" "network". 
		 */
		int id = lookup_class(token);
		if (id < 0) {
			return parse_result(UNKNOWN_CLASS, (int) i);
		}

		// example: network needed, but channel level node found 			  
		if (id < h->level) {
			return parse_result(CLASS_OUT_OF_ORDER, (int) i);
		}

		/**
		 * Two more things to check for:
		 * Illegal sequence:  4 3 2 5 ... (not legal)
		 *		       4 3 2 2 		
		 * Missing target:  4 3 1 ...     (legal, fill in)
		 */
		if (id >= prev) { 
			return parse_result(CLASS_OUT_OF_ORDER, (int) i);
		}
		if (id + 1 < prev) {
			int diff = prev - (id+1);
			std::fill_n(back_inserter(targets), diff, config_target("default") );				
		}
		prev = id;		
	}

	if (!(odd & 1)) {
		/** 
		  * Premature termination.
		  */
		return parse_result(TOO_FEW_ARGS, size-1);
	}

	/** 
	  * Ensure last target deals with this node type.  Fill in with trailing
	  * "default" tokens if necessary.
	  */
	if (prev != h->level) {
		//--------------------------------------------------
		// if (size > 1) {
		// 	return parse_result(ILLEGAL_OPTION, size - 1);
		// }
		//-------------------------------------------------- 

		std::fill_n(back_inserter(targets), (prev - h->level), config_target("default"));
	}

	*out=h;
	return parse_result(SUCCESS, 0);
}

/**
  * Transform a full target_list into a user friendly command string.
  * e.g. ["EFnet" "default" "#blah"] --> ["network" "EFnet" "server" "default" "channel" "#blah"]
  *
  * NOTE: the target list must be complete (no leading or in-between targets omitted)
  */
template<typename T> void node_searcher<T>::generate_user_command(const target_list& targets, 
								std::vector<string>& out)
{
	target_list::const_iterator i = targets.begin(),
					e = targets.end();
	int j = T::ID - 1;
	for (; i != e; ++i) {
		out.push_back(string(lookup_id(j--)));
		out.push_back(string(*i));
	}
}

/**
  * Validates the option given for the specified target list.
  * NOTE: The target list must be complete (no leading targets omitted).
  *
  * return a config_error indicating result.
  */
template<typename T> int node_searcher<T>::validate_target_list(const target_list &targets, 
								const parse_token &option,  const hash_entry ** out) 
{
	/* First: lookup the option. */
	const hash_entry * h = lookup_option(option);
	if (h == NULL) {
		return UNKNOWN_OPTION;
	}

	const unsigned int DISTANCE = T::ID - h->level;

	if (targets.size() != DISTANCE) {
		return ILLEGAL_OPTION;
	}
	*out = h;
	return SUCCESS;
}

} /* namespace config */
#endif /* __CONFIG_SEARCHER_H */
