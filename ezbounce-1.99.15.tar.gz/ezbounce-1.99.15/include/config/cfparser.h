/***********************************
 * config/cfparser.h 
 * part of ezbounce
 * (c) 2006-2007 Murat Deligonul
 ***********************************
 * 7/06 -- factored out common core
 * 8/05 -- rewritten
 */

#ifndef __CONFIG_CFPARSER_H
#define __CONFIG_CFPARSER_H

#include <vector>
#include <string>
#include "util/hash.h"
#include "config/proxy.h"
#include "parser_core.h"
#include "../user.h"

class ruleset;
class cstrtok;

class config_parser : public parser_core {
private:	
	/** temporary lists **/
	std::vector<ruleset *> 			shitlist;
	std::vector<std::string> 		vhosts;

	userdef::hash_table_t			users;
	proxy_options				options;

	parser_core::hash_table_t  		chash;

public: 
	explicit config_parser(const char *);
	virtual ~config_parser();

	/** accessing results: these return non-const references cause it's faster to 
	  * swap() than copy */
	std::vector<ruleset *>& get_shitlist() 		{ return shitlist; }
	std::vector<std::string>& get_vhosts() 		{ return vhosts; }
	userdef::hash_table_t& get_users() 		{ return users; }
	proxy_options& get_options() 			{ return options; }

private:	
	/* implementation details .. */
	virtual int	enter_context(const config_symbol *, context &, std::vector<config_token> &, std::vector<config_token> &);
	virtual int	leave_context(context &, bool);
	virtual int 	do_command(const config_symbol *, std::vector<config_token> &, std::vector<config_token> &);
	int 	do_set_command(const config_symbol *, std::vector<config_token> &, std::vector<config_token> &);	
	int 	do_rs_command(const config_symbol *, std::vector<config_token> &, std::vector<config_token> &);
	int 	do_listen_command(const config_symbol *, std::vector<config_token> &, std::vector<config_token> &);

	int     validate_user_config(userdef *);
	virtual int	validate_config() const;
	virtual int 	resolve_trailing_args(std::vector<config_token>&);
	virtual const parser_core::hash_table_t * symbol_table() const; 
	virtual const char * str_context(int) const;
	virtual const char * str_argtype(int) const;
	
	/* possible states */
	enum {
		CTX_USER   	= 0x8,
		CTX_VHOSTS	= 0x10,
		CTX_ALLOW  	= 0x20,
	       	CTX_DENY	= 0x40,
		CTX_RULESET 	= 0x60,
	};	

	/* argument type patterns */
	static const int 	SET_ARG_PATTERN[],
		     		LISTEN_ARG_PATTERN[],
				BLOCK_ARG_PATTERN[],
				USER_ARG_PATTERN[];

	static const struct config_symbol 		 	symtab[];

private:	/* forbidden operations */
	config_parser(const config_parser &);
	config_parser & operator=(const config_parser &);
};
#endif

