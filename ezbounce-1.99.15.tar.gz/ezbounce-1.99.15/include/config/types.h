/**
  * config/types.h
  */

#ifndef __CONFIG_TYPES_H
#define __CONFIG_TYPES_H

#include <vector>

namespace config {

typedef const char * config_target;
typedef const char * parse_token;
typedef std::vector<config_target> target_list;

/**
 * User friendly representation of the config types.
 */
enum option_type {
	BOOLEAN,
	INTEGER,
	STRING
};

struct item_name;

struct hash_entry {
	const struct item_name * item;
	option_type type;
	int option;
	int level;
};

extern const char * stroption(option_type);
}
#endif

