/**
  * config/option_traits.h
  */

#ifndef __CONFIG_OPTION_TRAITS_H
#define __CONFIG_OPTION_TRAITS_H

#include <string>
#include "config/types.h"

namespace config {

/**
 * Class template to define properties of the config option type, including
 * the matching option_type enum, and return types to be used from get() functions.
 * TODO: implement
 */
template<typename V> struct option_traits;

template<> struct option_traits<int> 
{
	// TODO
};

template<> struct option_traits<bool>
{
	// TODO
};

template<> struct option_traits<std::string>
{
	static const option_type OPTION_TYPE 	= STRING;

	typedef const std::string&		return_type;
};

}
#endif

