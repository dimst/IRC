/**
  * config/dependencies.h
  */
#ifndef __CONFIG_DEPENDENCIES_H
#define __CONFIG_DEPENDENCIES_H

#include "config/traits.h"
#include "config/node.h"

namespace config {

/**
  * Defines boolean logic operations for boolean options relating of 'T' type nodes.
  */
template<typename T> struct dependency_expression {
	typedef T		 								node_t;
	typedef typename config::traits<typename T::config_type, bool>::identifier_t		identifier_t;

	template<identifier_t V> struct value_of {
		static bool compute(const node_t& n) {
			return n.template get<bool>(V);
		}
	};

	template<class C1, class C2> struct _and {
		static bool compute(const node_t& n) {
			return C1::compute(n) && C2::compute(n);
		}
	};

	template<class C1, class C2> struct _or	{
		static bool compute(const node_t& n) {
			return C1::compute(n) || C2::compute(n);
		}
	};
};

/**
  * Used as placeholder when required or bad expression isn't needed.
  */
template<class N, bool B> struct dummy_expression {
	static bool compute(const N&) {
		return B;
	}
};


/**
  * Represents a dependency in class Root on a boolean option in Class dest.
  * The 'Required' condition must be satisfied by the boolean settings in class Perm.
  * The 'Bad' condition must be false.
  *
  * The decide() functions returns one of the following:
  *		-1:		The operation is forbidden by the configuration
  *		 0:		The operation is permitted, but the user has it set to 'off' in his settings.
  *		 1: 		The operation is permitted, and the user has it set to 'on'
  */
template<class Root, 
		class Dest, 
		typename config::traits<typename Dest::config_type, bool>::identifier_t V, 
		class Perm,
		class Required,
		class Bad = dummy_expression<Perm, false> >	
			class dependency {
public:
	static int decide(const Root& n, const config::target_list& targets, const Perm& p) {
		if (Bad::compute(p)) {
			return -1;
		}

		if (!Required::compute(p)) {
			return -1;
		}

		if (n.template get<Dest, bool>(targets, V) == false) {
			return 0;
		}
		return 1;
	}
};

/**
  * Different version, specialized for options in a top level node only.
  */
template<class Root, 
		typename config::traits<typename Root::config_type, bool>::identifier_t V, 
		class Perm,
		class Required,
		class Bad>
	class dependency<Root, Root, V, Perm, Required, Bad> {
public:
	static int decide(const Root& n, const Perm& p) {
		if (Bad::compute(p)) {
			return -1;
		}

		if (!Required::compute(p)) {
			return -1;
		}

		if (n.template get<bool>(V) == false) {
			return 0;
		}
		return 1;
	}
};
}
#endif
