/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * config/ezb_dependencies.h
 * (c) 2007-2008 Murat Deligonul
 */

#ifndef __CONFIG_EZB_DEPENDENCIES_H
#define __CONFIG_EZB_DEPENDENCIES_H

#include "config/dependencies.h"
#include "config/user_perms.h"
#include "config/user.h"

/**
  * General template for deciding dependencies:
  * No requirements to check; 
  * just see if the option is on.
  *
  * Again, return value are:
  *		-1:		The operation is forbidden by the configuration
  *		 0:		The operation is permitted, but the user has it set to 'off' in his settings.
  *		 1: 		The operation is permitted, and the user has it set to 'on'
  */
template<class T> int decide_helper(const user_config_root& root, const config::target_list& targets, 
				typename config::traits<typename T::config_type, bool>::identifier_t val, 
				const user_permissions&)
{
	if (root.template get<T, bool>(targets, val) == true) {
		return 1;
	}
	return 0;
}
#endif
