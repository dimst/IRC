/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * config/node.h
 *
 * Template-generated tree-like configuration data storage structure.
 * (c) 2006-2008 Murat Deligonul
 */

#ifndef __CONFIG_NODE_H
#define __CONFIG_NODE_H

#include <vector>
#include <ostream>
#include <exception>
#include <stdexcept>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include "config/types.h"
#include "config/errors.h"
#include "config/traits.h"
#include "config/node_data.h"
#include "config/descender.h"
#include "util/generic.h"
#include "debug.h"

namespace config {

using std::string;

/**
  * Node class.  Insert explanation here.
  *	
  *	TODO:
  *		- Should target lists permit extra parameters?
  *
  *	NOTE: __conditional_private becomes public on gcc 3.2; has bugs with private inheritance
  *	    	  and templates.
  */
template <typename T, typename C = void> class node : __conditional_private node_data<T> {
public:
	static const int ID = C::ID + 1;

	typedef  C 			child_type;
	typedef  T			config_type;

private:
	mutable C			default_child;
	std::vector<C *> 		children;
	const string			name;

public:
	explicit node(const char *, bool = false); 

	~node() {
		DEBUG("%s -- destructing \"%s\"\n", __PRETTY_FUNCTION__, get_name());
		std::for_each(children.begin(), children.end(), util::delete_ptr());
	}
	int get_id() const { 
		return ID; 
	}
	const char * get_name() const { 
		return name.c_str(); 
	}

	/*
	 * Swap values with another node.
	 */
	void swap(node&);

	/**
	 * Recursively descend children and print their values in friendly 
	 * config format.  Also see helper function in node_data.
	 */
	void print(std::ostream &, int = 0);

	/**
	  * Set/get/check values of config items, given the type of the target configuration
	  * node as a template argument.  The target list specifies the node(s) that will be
	  * affected or accessed by the operation.  
	  *
	  * For distance D between nodes in levels S going to N, the last D targets will be 
	  * accessed in the given list.  Extra targets in the front of the list are ignored.
	  * If D > 0, there must be at least 1 target in the list.
	  */
	template <typename N, typename V> const V& get(const target_list&,
							typename traits<typename N::config_type, V>::identifier_t) const;
	template <typename N, typename V> void set(const target_list&,
							typename traits<typename N::config_type, V>::identifier_t,
							V);
	template <typename N, typename V> bool is_set(const target_list&, 
							typename traits<typename N::config_type, V>::identifier_t) const;
	template <typename N, typename V> void unset(const target_list&, 
							typename traits<typename N::config_type, V>::identifier_t);

	/**
	  * Set/get/check values of config items, without knowing the precise type of the target configuration
	  * node.  Used for handling runtime user input and mapping into the typesafe structures
	  * here.  The target list must be well-formed (i.e. have the precise number of targets needed).
	  */
	template <typename V> const V& get(const target_list&, int) const;
	template <typename V> void set(const target_list&, int, V);
	template <typename V> bool is_set(const target_list&, int) const;
	template <typename V> void unset(const target_list&, int);

	/** 
	  * Search for a descendant node of a specific type.
	  */
	template <typename N> N * find_descendant(const target_list& targets) const {
		return descender<node<T,C>, (ID - N::ID)>::template find_descendant<N>(this, targets);
	}

	using node_data<T>::set;
	using node_data<T>::unset;
	using node_data<T>::get;
	using node_data<T>::is_set;

	using node_data<T>::print_values;
	using node_data<T>::load_defaults;

	using node_data<T>::fill_hash_entries;

	template<typename, int> friend class descender;

private:
	int delegate(const config_target&, std::vector<C *>&) const;
	C * find_direct_child(const char * name) const;
	C * add_child(const char * name);

	/**
	  * Unary functor for STL find_if() algorithm to locate child of a certain name
	  */
	struct child_finder {
	public:
		const char * const tname;

		child_finder(const char * n) : tname(n) { }
		bool operator() (const C * child) const { 
			return C::config_type::strcasecmp(tname, child->get_name()) == 0; 
		}
	};

private:
	// non-copyable
	node(const node&);	
	node& operator = (const node&);
};


/**
  * Base case partial specialization.
  *
  * NOTE: some operations are not defined:
  *		- type-safe child node value get/set/is_set/unset
  * 		- looking up child by name
  */
template<typename T> class node<T, void> : __conditional_private node_data<T> {
public:
	static const int ID = 0;

	typedef  T			config_type;
	typedef  void   		child_type;

private:
	const string 			name;

public:
	explicit node(const char *, bool = false);
	int get_id() const { 
		return ID; 
	}
	const char * get_name() const { 
		return name.c_str(); 
	}

	/**
	  * Specialized swap() for leaf nodes 
	  */
	void swap(node& that) {
		if (this == &that) {
			return;
		}
		node_data<T>::swap(that);
	}

	/**
	 * Recursively descend children and print their values in friendly 
	 * config format.  Also see helper function in node_data.
	 */
	void print(std::ostream &, int = 0);


	using node_data<T>::set;
	using node_data<T>::unset;
	using node_data<T>::get;
	using node_data<T>::is_set;

	using node_data<T>::print_values;
	using node_data<T>::load_defaults;

	using node_data<T>::fill_hash_entries;

private:
	// non-copyable
	node(const node&);
	node& operator=(const node&);
};

/**
  * (Partially specialized) base case node implementation.
  */
template<typename T> node<T, void>::node(const char * n, bool set_defaults) : 
	name(n)
{			
	DEBUG("%s - constructing \"%s\"\n", __PRETTY_FUNCTION__, n);
	if (set_defaults) {
		this->template load_defaults<bool>();
		this->template load_defaults<int>();
		this->template load_defaults<string>();
	}
}

/**
 * Recursive version; not much to do for leaf node.
 */
template <typename T>
	void node<T, void>::print(std::ostream& out, int off) 
{
	string padding(off, '\t');

	out << padding << T::NAME << " \"" << get_name() << "\" {\n";
	this->template print_values<bool>(out, off+1);
	this->template print_values<int>(out, off+1);
	this->template print_values<string>(out, off+1);
	out << padding << "}\n";
}


/***************************************
  *
  * Generic implementation.
  *
  **************************************/

template<typename T, typename C> 
	node<T,C>::node(const char * n, bool set_defaults) : 
		default_child("default", set_defaults),
		name(n)
{
	DEBUG("%s - constructing \"%s\"\n", __PRETTY_FUNCTION__, n);
	if (set_defaults) {
		this->template load_defaults<bool>();	
		this->template load_defaults<int>();	
		this->template load_defaults<string>();	
	}
}

/**
  * Swap data members, the child pointers vector, and then the default child
  * (which recursively performs the same operations)
  */
template<typename T, typename C>
	void node<T,C>::swap(node<T,C>& that)
{
	if (this == &that) {
		return;
	}
	node_data<T>::swap(that);
	children.swap(that.children);
	default_child.swap(that.default_child);	
}


/**
 * Descend the tree and print values starting at this node.
 * Prints out node header, options for this node, and then calls
 * same function in the children.
 */
template <typename T, typename C>
	void node<T, C>::print(std::ostream& out, int off)
{
	std::string padding(off, '\t');

	out << padding << T::NAME << " \"" << get_name() << "\" {\n";
	this->template print_values<bool>(out, off+1);
	this->template print_values<int>(out, off+1);
	this->template print_values<string>(out, off+1);

	out << padding << "\n";
	default_child.print(out, off+1);
	typename std::vector<C *>::iterator i = children.begin(),
		 e = children.end();
	for (; i != e; ++i) {
		(*i)->print(out, off+1);
	}
	out << padding << "}\n";
}

/**
  * get(): use descender helper.
  */
template<typename T, typename C>
	template <typename N, typename V> 
	inline const V& node<T,C>::get(const target_list& targets, 
				typename traits<typename N::config_type, V>::identifier_t opt) const
{
	const V * val = NULL;
	bool result = descender<node<T,C>, (ID - N::ID)>::template get_helper
		<typename traits<typename N::config_type, V>::identifier_t, V>(this, targets, opt, &val);
	if (result == false) {
		throw std::invalid_argument("option has not been set for requested target");
	}
	return *val;
}

/**
  * set(): use descender helper.
  */
template<typename T, typename C>
	template <typename N, typename V> 
	inline void node<T,C>::set(const target_list& targets,
					typename traits<typename N::config_type, V>::identifier_t opt,
					V val) 
{
	descender<node<T,C>, (ID - N::ID)>::template set_helper<typename traits<typename N::config_type, V>::identifier_t, V>
		(this, targets, opt, &val);
}

/**
  * unset(): use descender helper.
  */
template<typename T, typename C>
	template <typename N, typename V> 
	inline void node<T,C>::unset(const target_list& targets,
					typename traits<typename N::config_type, V>::identifier_t opt)
{
	descender<node<T,C>, (ID - N::ID)>::template set_helper<typename traits<typename N::config_type, V>::identifier_t, V>
		(this, targets, opt, NULL);
}

/**
  * is_set()
  * NOTE: this has a hack for the N=node<T,C> case.
  *	  (since there is no way to specialize the function template for N=node<T,C> without 
  *	   defining the class template parameters)
  */
template<typename T, typename C>
	template <typename N, typename V> 
	inline bool node<T,C>::is_set(const target_list& targets, 
				typename traits<typename N::config_type, V>::identifier_t opt) const 
{
	const N * n = find_descendant<N>(targets);
	if (ID == N::ID) {
		// XXX: HACK 
		n = (N *) this;
	}
	else if (n == NULL) {
		return false;
	}
	// n->validate_target();
	return n->template is_set<V>(opt);
}

/**
  * Alternate form of get()
  */
template <typename T, typename C>
	template <typename V>
	inline const V& node<T,C>::get(const target_list &targets, int opt) const
{
	return descender<node<T,C>, ID>::template dispatch_get<node<T,C>, V>(this, targets, opt);
}

/**
  * Alternate form of set()
  */
template <typename T, typename C>
	template <typename V>
	inline void node<T,C>::set(const target_list &targets, int opt, V val)
{
	descender<node<T,C>, ID>::template dispatch_set<node<T,C>, V>(this, targets, opt, &val);
}

/**
  * Alternate form of unset()
  */
template <typename T, typename C>
	template <typename V>
	inline void node<T,C>::unset(const target_list &targets, int opt)
{
	descender<node<T,C>, ID>::template dispatch_set<node<T,C>, V>(this, targets, opt, NULL);
}

/**
 * Alternate form of is_set()
 */
template <typename T, typename C>
	template <typename V>
	inline bool node<T,C>::is_set(const target_list &targets, int opt) const
{
	return descender<node<T,C>, ID>::template dispatch_is_set<node<T,C>, V>(this, targets, opt);
}

/**
  * Helper function used during get/set operations.
  */
template<typename T, typename C> 
	int node<T,C>::delegate(const config_target& target, std::vector<C *>& out) const
{
	bool to_all = C::config_type::strcasecmp(target, "all") == 0;
	bool to_default = C::config_type::strcasecmp(target, "default") == 0;

	if (to_all || to_default) {
		out.push_back(&default_child);
		if (to_all) {
			std::copy(children.begin(), children.end(), std::back_inserter(out));
		}
		return out.size();
	}
	/**
	 * Not "default" or "all" -- going to a specific child.
	 */
	C * child = find_direct_child(target);

	if (child == NULL) {
		/** 
		 * Nothing found:
		 * Let caller handle.
		 */
		return -1;
	}
	/* Found the child. */
	out.push_back(child);
	return 1;	
}

/**
  * Find a direct child by name.
  */
template<typename T, typename C> 
	C * node<T,C>::find_direct_child(const char * name) const
{
	if (C::config_type::strcasecmp(default_child.get_name(), name) == 0) {
		return &default_child;
	}

	typename std::vector<C *>::const_iterator i = std::find_if(children.begin(), 
								children.end(), 
								child_finder(name));
	if (i == children.end()) {
		return NULL;
	}
	return *i;
}

/**
  * Create a child with requested name and it to list of children.
  * Throws exceptions on "all", "default", or if the requested name exists or is otherwise illegal.
  */ 
template<typename T, typename C> 
	C * node<T,C>::add_child(const char * name)
{
	if (C::config_type::strcasecmp(name, "all") == 0 || C::config_type::strcasecmp(name, "default") == 0) {
		throw std::invalid_argument("'all' or 'default' are not legal names for new child nodes");
	}

	if (find_direct_child(name) != NULL) {
		throw std::invalid_argument("requested node name already exists");
	}

	DEBUG("node<T,C>::add_child(): creating node '%s' of type '%s'\n", name, child_type::config_type::NAME);
	C * child = new C(name);
	children.push_back(child);
	return child;
}

} 	/* namespace config */
#endif

