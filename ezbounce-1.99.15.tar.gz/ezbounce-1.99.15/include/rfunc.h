/**
 * rfunc.h
 * (c) 2003-2007 Murat Deligonul
 */
#ifndef __RFUNC_H
#define __RFUNC_H

/**
 * General interface for restartable functions.
 */
class rfunc {
public:
	virtual int execute(int) = 0;
	virtual ~rfunc() { }
};
#endif
