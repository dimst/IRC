/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * parser_core.h -- Part of the ezbounce IRC proxy
 * (c) 2006-2008 Murat Deligonul
 */

#ifndef __PARSER_CORE_H
#define __PARSER_CORE_H

#include <string>
#include <list>
#include <vector>
#include <stack>
#include "util/hash.h"
#include "util/strings.h"
#include "util/tokenizer.h"

class parser_core {
private:
	// FIXME: can these be moved below?	
	const char * 					filename;
	int						current_line;

public: 
	explicit parser_core(const char * file) : filename(util::strings::my_strdup(file)), 
						current_line(0) { }
	virtual ~parser_core();
	int parse();


protected:
	struct config_symbol;
	/* Each line is broken up into the std::lists of these ... */	
	struct config_token {
		const config_symbol * symbol; 
		const char * token;
		int other_value;
			
	};

	/* ... which point to one of these */
	struct config_symbol {
		const char * 	symbol;
		int 		id;
		int 		good_ctx;		/* contexts symbol is allowed in */
		int		flags;			/* rules parser must enforce for the symbol */
		int		arguments;		/* how many expected */
		const int	*arg_types;		/* what type of arguments, if any, symbol expects */
	};

        struct context {
		int state;
		void * data;
	};

	// rather important typedef
	typedef 	util::hash_table<const char *, const config_symbol *> 	hash_table_t;

	/* IDs for built-in symbols */
	enum {
		SYM_UNKNOWN = 0,
		SYM_NUMBER  = 1,
		SYM_COMMENT,
		SYM_STRING_LITERAL,
		SYM_NEWLINE,
		SYM_BOOLEAN,
		CUSTOM_SYM_START 	= 20
	};
	
	/* Built-in flags for symbols */
	enum {
		CREATE_CONTEXT  = 0x8,			/* encountering symbol enters new context */
		EXIT_CONTEXT	= 0x10,			
		COMMAND		= 0x20,			/* indicated a command */
		ARGS_SAME_LINE  = 0x40,			/* arguments must be on same line */
		ARG_TYPE_STRING = 0x100,
		ARG_TYPE_NUMBER = 0x200,
		ARG_TYPE_BLOCK  = 0x400,
		ARG_TYPE_BOOL	= 0x800,
		ARG_TYPE_OTHER  = 0x1000
	};

	std::stack<context>                     context_stack;

	static const int	 CTX_GLOBAL, 		/* special global "top-level" context */
		     		 CTX_ARG, 		/* special context for command arguments */
				 CTX_ANY;	    	/* special flag that matches all contexts */

	/* Pre-defined argument patterns */
	static const int BOOL_ARG[];
	static const int STRING_ARG[];
	static const int NUMBER_ARG[]; 

protected:	
	/** Must be implemented by the derived class. **/
	virtual int 	enter_context(const config_symbol *, context &, 
				std::vector<config_token> &, 
				std::vector<config_token> &) = 0;
	virtual int	leave_context(context &, bool) = 0;
	virtual int 	do_command(const config_symbol *, std::vector<config_token> &, 	std::vector<config_token> &) = 0;
	virtual int	validate_config() const = 0;
	virtual int 	resolve_trailing_args(std::vector<config_token>&) = 0;
	virtual const hash_table_t * symbol_table() const = 0;
	virtual const char * str_context(int) const;	
	virtual const char * str_argtype(int) const;
	
	/* Other */
	int	error(const char * fmt, ...) const;
	int 	warning(const char * fmt, ...) const;

	std::string str_argtypes(int) const;
	
private:
	/* Implementation details */
	int 	tokenize(char *);
	int 	process_tokens();
	const 	config_symbol * lookup_symbol(const char *) const;	
	
	bool	more_tokens() const { 
		return token_iterator != tokens.end(); 
	}
	const   config_token& next_token() { 
		return *token_iterator++; 
	}

	static bool is_possible_ip(const char *);

#ifdef __DEBUG__
	void dump_lines() const;
#endif
	
	std::list<config_token>::const_iterator		token_iterator;
	std::list<config_token> 			tokens;	

	static const char 	DELIMETERS[];
	static const char	COMMENT[];
	static const struct 	config_symbol 	special_sym[];

private:
	// non-copyable
	parser_core(const parser_core &);
	parser_core & operator=(const parser_core &);
};

#endif
