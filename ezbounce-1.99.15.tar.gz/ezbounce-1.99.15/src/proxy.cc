/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * proxy.cc
 * (C) 1998-2008 Murat Deligonul
 * ---
 * does: server code; listening for connections, accepting, logging
 * ---
 *
 */

#include "autoconf.h"

#include <string>
#include <list>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <cstdarg>
#include <cerrno>
#include <ctime>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#ifdef HAVE_SYS_TIME_H
    #include <sys/time.h>
#endif
#include "util/hash.h"
#include "util/timer.h"
#include "util/generic.h"
#include "util/tokenizer.h"
#include "util/counted_object.h"
#include "util/tracked_object.h"
#include "util/expirable_object.h"
#include "util/strings.h"
#include "config/ufparser.h"
#include "config/cfparser.h"
#include "config/node.h"
#include "config/proxy.h"
#include "config/node_searcher.h"
#include "logging/ostream_logger.h"
#include "io/engine.h"
#include "io/error.h"
#include "io/poll_engine.h"
#include "io/utility.h"
#include "irc/rfc1459.h"
#include "fs/directory.h"
#include "fs/file_system.h"
#include "net/socket.h"
#include "net/error.h"
#include "proxy.h"
#include "dcc.h"
#include "dcc_offer.h"
#include "ruleset.h"
#include "conn.h"
#include "user.h"

#include "debug.h"

using std::string;
using std::vector;
using std::list;
using std::for_each;
using std::bind1st;
using std::bind2nd;
using std::mem_fun;

using fs::directory;
using fs::flib_key;
using fs::file_system;
using fs::file_entry;
using net::resolver;
using net::socket_exception;
using util::timer;
using util::delete_ptr;
using util::apply_second;
using util::tracked_object;
using util::expirable_object;
using util::counted_object;

using namespace util::strings;

/**
 * Class for server sockets
 */
class listen_sock : public net::socket {
private:
	listen_sock() : net::socket(PF_UNSPEC, 0, io::buffer::MINIMUM, io::buffer::MAXIMUM) { }
	virtual int on_readable();
	virtual int on_writeable();

	friend class ircproxy;
};

template<class T> static bool is_dead_idle(expirable_object<T> *);
template<class T> static bool announce_and_kill(expirable_object<T> *);
static bool is_dead_ruleset(const ruleset * );

/* static */ ircproxy * ircproxy::proxy = NULL;

/* static */ ircproxy * ircproxy::create() 
{
	if (proxy != NULL) {
		fprintf(stderr, "fatal: trying to create a second ircproxy instance\n");
		abort();
	}
	proxy = new ircproxy();
	return proxy;
}

ircproxy::ircproxy() : st_time(::time(NULL)),
			options("default", true), 
			user_hash(7),
			log(NULL),
			engine(NULL),
			library(NULL),
			terminate_request(false),
			rehash_request(false)				    
{
	/**
	  * Set these up too.
	  */
	config::node_searcher<user_config_root>::populate_table();  
	DEBUG("ircproxy::ircproxy() [%p] constructed\n", this);
}

ircproxy::~ircproxy()
{
        save_prefs();

	print_all_logs("Proxy shutting down.");

	tracked_object<conn>::delete_if(announce_and_kill<conn>);
	tracked_object<dcc>::delete_if(announce_and_kill<dcc>);
	tracked_object<dcc_offer>::delete_if(announce_and_kill<dcc_offer>);

	for_each(sockets.begin(), sockets.end(), delete_ptr());
	for_each(banned.begin(), banned.end(), delete_ptr());
	for_each(user_hash.begin(), user_hash.end(), apply_second<delete_ptr>());
	
	delete engine;
	//FIXME: thread cleanup is messy; hold off for now
        //delete resolver;
	delete library;

	config::node_searcher<proxy_options>::clear_table();
	config::node_searcher<user_config_root>::clear_table();

	ircproxy::proxy = NULL;

	assert(counted_object<userdef>::count() == 0);
	assert(counted_object<flib_key>::count() == 0);
	assert(counted_object<ruleset>::count() == 0);
	assert(file_entry::count() == 0);
	assert(directory::count() == 0);

	DEBUG("ircproxy::~ircproxy() [%p] destructed\n", this);
}

void ircproxy::create_timers()
{
	timer * t[] = { timer::create_generic_timer(30, 		bind1st(mem_fun(&ircproxy::process_timers), this), 0, 0, 			TIMER_30_SEC),
			timer::create_generic_timer(60, 		bind1st(mem_fun(&ircproxy::process_timers), this), 0, 0,			TIMER_60_SEC),
			timer::create_generic_timer(10 * 60, 		bind1st(mem_fun(&ircproxy::process_timers), this), 0, timer::TIMER_ABSOLUTE,	TIMER_10_MIN),
			timer::create_generic_timer(30 * 60, 		bind1st(mem_fun(&ircproxy::process_timers), this), 0, timer::TIMER_ABSOLUTE,	TIMER_30_MIN)
			// XXX: disable this until we can get a timer to fire precisely at midnight
			//timer::create_generic_timer(60 * 60 * 24, 	bind1st(mem_fun(&ircproxy::process_timers), this), 0, timer::TIMER_ABSOLUTE,	TIMER_MIDNIGHT)
	};
	for (unsigned i = 0; i < (sizeof(t) / sizeof(timer *)); ++i) {
		t[i]->enable();
	}
}

int ircproxy::listen(const char * interface, unsigned short port, bool ssl)
{
	listen_sock * sock = NULL;
	int i;
	try {
		sock = new listen_sock();
		i = sock->listen(interface, port, 100, ssl ? net::socket::SOCK_SSL : net::socket::SOCK_DEFAULT);
		if (i < 0) {
			DEBUG("listen() failed: %s\n", net::strerror(i));
			delete sock;
			return -1;
		}
	} 
	catch (socket_exception& e) {
		DEBUG("socket_exception caught: %s\n", e.what());
		delete sock;
		return -1;
	}
	/* every thing seems to work */
	DEBUG("ircproxy::listen(): Adding a socket fd %d [%s:%d]\n", sock->get_fd(), 
			sock->local_addr(), sock->local_port());
	sockets.push_back(sock);
	return 0;
}

int ircproxy::setup_vfs(std::string& reason)
{
	try {
		const string& location = options.get<string>(proxy_config::VFS_DIR);
		library = new file_system(location.c_str());    
	} 
	catch (fs::flib_exception &e) {
		library = NULL;
		reason = e.what();
		return -1;
	}
	return 0;
}


/**
  * Assign values to our config settings from a newly parsed config.
  * For speed, we currently just call swap() on the containers.
  */
int ircproxy::set_config_data(proxy_options & c_options, userdef::hash_table_t & c_users, 
				vector<string>& c_vhosts, vector<ruleset *>& c_shitlist) 
{
	c_options.swap(options);
	c_users.swap(user_hash);
	c_vhosts.swap(vhosts);
	c_shitlist.swap(banned);

	DEBUG("ircproxy::set_config_data(): Received: %zd users, %zd shitlist entries, %zd vhosts\n",
				vhosts.size(), banned.size(), user_hash.size());
	return 0;
}

int ircproxy::set_config_file(const char * file) 
{
	options.set<string>(proxy_config::CONFIG_FILE, file);
	return 0;
}

int ircproxy::event_loop()
{
	time_t wait_time;
	timer::set_now();
	wait_time = timer::now();
	create_timers();
	conn::set_proxy_instance(this);
	conn::init_command_hash();
	conn::init_help_system();
	wait_time = timer::get_wait_time(wait_time);
	printlog("Server ready\n");

	while (1) {
		DEBUG("---> Waiting for %lu seconds\n", wait_time);
		engine->poll(wait_time * 1000);
		
		if (terminate_request) {
			static const char message[] = "@ @ @ @ NOTICE @ @ @ @\r\n"
							"\002Proxy terminating\002\r\n";
			printlog("Terminate request: exiting...\n");
			for_each(conn_list().begin(), conn_list().end(), 
					std::bind2nd(std::mem_fun(&conn::cprintf_multiline), message));
		        // let destructor perform cleanups.	
			return 0;
		}
	
		if (rehash_request) {
			printlog("Rehashing the proxy options file (signal)\n");
			switch (rehash()) {
			case 0:
				printlog("Rehash successful\n");
				break;
			case -1:
				printlog("Rehash failed: %s\n", strerror(errno));
				break;
			default:
				printlog("Rehash failed\n");
				break;
			}
			rehash_request = false;
		}
	
		/**
		 * Handle timer events if necessary 
		 */
		timer::poll();
		wait_time = timer::get_wait_time(timer::now());
		assert(wait_time >= 0);
	}
	return 0;
}  


/**
 * Requests server termination
 * if now == 1, all conn objects are freed and server exit()s.
 * if it's 0, a flag is set which the server can read and terminate
 * when ready.
 */
int ircproxy::request_shutdown(bool now, const char *reason)
{
	if (now) {
		// terminate now, do not broadcast, since this might have been called
		// from a signal handler
		save_prefs();

		// notify everyone
		print_all_logs("Proxy shutting down.");		
		
		// kill all objects
		tracked_object<conn>::delete_if(announce_and_kill<conn>);
		tracked_object<dcc>::delete_if(announce_and_kill<dcc>);
		tracked_object<dcc_offer>::delete_if(announce_and_kill<dcc_offer>);

		for_each(sockets.begin(), sockets.end(), delete_ptr());
		for_each(banned.begin(), banned.end(), delete_ptr());
		for_each(user_hash.begin(), user_hash.end(), apply_second<delete_ptr>());

		delete engine;
                // delete resolver;
		delete library;

		exit(0);
	}
        if (!terminate_request) {
                terminate_request = true;
        }
	return 0;
}   

int ircproxy::startlog()
{
	using std::ios_base;
	const string& path = options.get<string>(proxy_config::LOG_FILE);
	logging::logger::initialize(timer::get_now_ptr());

	logfile.open(path.c_str(), ios_base::out | ios_base::app | ios_base::ate);
	if (logfile.fail()) {
		return -1;
	}
	chmod(path.c_str(), 0600);

	log = new logging::ostream_logger("ezbounce", &logfile);
	log->set_options(logging::LOG_FULL_TIMESTAMP | logging::ALWAYS_FLUSH);

	return 0;	
}

int ircproxy::stoplog()
{
	printlog("Server log ended\n");
	delete log;
	logfile.close();
	log = NULL;
	return 0;
}

/**
 * Put a message into the proxy log. 
 * Defaults to INFO level.
 */
int ircproxy::printlog(const char *fmt, ...)
{
	if (!log) {
		return -1;
	}
	va_list ap;
	va_start(ap, fmt);
	int len = log->vprintf(logging::INFO, fmt, ap);
	va_end(ap);
	return len;
}

/**
 * Put a message into the proxy log.
 */
int ircproxy::printlog(logging::level lvl, const char * fmt, ...)
{
	if (!log) {
		return -1;
	}
	va_list ap;
	va_start(ap, fmt);
	int len = log->vprintf(lvl, fmt, ap);
	va_end(ap);
	return len;
}

int ircproxy::setup_sockets()
{
	engine = new io::poll_engine(options.get<int>(proxy_config::MAX_SOCKETS), timer::get_now_ptr());
	resolver = new net::resolver(3,5); 
	net::socket::assign_resolver(resolver);
	net::socket::assign_engine(engine);
	return 0;
}

int ircproxy::setup_ssl()
{
#ifdef HAVE_SSL
	return (net::socket::init_ssl(options.get<string>(proxy_config::CERT_FILE).c_str()));
#else
	return 0;
#endif
}

/** Return number of sockets created **/
int ircproxy::start_sockets_raw(const char * orig_ports, bool use_ssl) 
{
	if (!orig_ports) {
		return 0;
	}
	
	std::vector<string> tokens;
	tokenize(orig_ports, ",", tokens);

	const string& interface = options.get<string>(proxy_config::LISTEN_VHOST);
	bool first = true;
	int num = 0;

	for (std::vector<string>::const_iterator i = tokens.begin(), e = tokens.end();
			i != e;
			++i) {
		const char * port = (*i).c_str();
		unsigned short val = (unsigned short) atoi(port);
		if (this->listen(interface.c_str(), val, use_ssl) != 0) {
			printf("\n%sError listening on port %d: %s", (use_ssl) ? "[SSL] " : "", val, strerror(errno));
			first = true;
			continue;
		} 
		if (first) {
			printf("\n%sListening on ports(s): ", (use_ssl) ? "[SSL] " : "");
			first = false;
		}
		printf("%d ", val);
		++num;
	}
	printf("\n");
	fflush(stdout);
	return num;		
}

/** defer operations to helper function; return number of sockets created **/
int ircproxy::start_sockets()
{
	return start_sockets_raw(options.get<string>(proxy_config::PORTS).c_str(), false);
}

int ircproxy::start_ssl_sockets()
{
#ifdef HAVE_SSL
	return start_sockets_raw(options.get<string>(proxy_config::SSL_PORTS).c_str(), true);
#else
	return 0;
#endif	
}

int ircproxy::request_rehash()
{
	rehash_request = 1;
	return 0;
}

int ircproxy::redir_stdxxx()
{
	// FIXME: this is now broken, since we can't get at the logger's file descriptor
	//--------------------------------------------------
	// dup2(fd_log, STDOUT_FILENO);
	// dup2(fd_log, STDERR_FILENO);   
	//-------------------------------------------------- 
	return 0;
}

/* 
 * This function will be called every 30 seconds at least.
 */
int ircproxy::process_timers(const timer::generic_timer_data * data)
{
	const int id = data->id;
	if (id == TIMER_60_SEC) {
		DEBUG("ircproxy::process_timers(): 60-second check\n");
		/**
		 * Check global ban list first.
		 * TODO: can combine some of these loops
		 */
		vector<ruleset *>::iterator new_end = 
			std::remove_if(banned.begin(), banned.end(), is_dead_ruleset);
		std::for_each(new_end, banned.end(), delete_ptr());
		banned.erase(new_end, banned.end());

		/**
		 * Find obsolete user definitions,
		 * and clean up any obsolete rulesets they may have.
		 */
		userdef::hash_table_t::iterator i = user_hash.begin(),
						e = user_hash.end();
		while (i != e) {
			userdef * u = (*i).second;
			if (u->is_obsolete() && u->conns().empty()) {
				DEBUG("check_timers(): Deleting obsolete user def. %p (%s)\n", u, u->name());
				delete u;
				i = user_hash.erase(i);
				continue;
			}
			vector<ruleset *>& r = u->rulesets();
			new_end = std::remove_if(r.begin(), r.end(), is_dead_ruleset);
			std::for_each(new_end, r.end(), delete_ptr());
			r.erase(new_end, r.end());
			++i;
		}

		/**
		 * Delete stale ignore entries and such.
		 */
		for_each(conn_list().begin(), conn_list().end(), std::mem_fun(&conn::prune_caches));

		/** 
		 * Compress socket table.
		 * FIXME: this currently does nothing.
		 */
		net::socket::compress();
	} 
	else if (id == TIMER_30_SEC) { 
		/**
		 * 30-second timer:
		 *  - Kill condemned DCCs and conns
		 *  - Check for idling connections and dccs
		 */
		DEBUG("ircproxy::process_timers(): 30-second check\n");
		tracked_object<conn>::delete_if(is_dead_idle<conn>);
		tracked_object<dcc>::delete_if(is_dead_idle<dcc>);
		tracked_object<dcc_offer>::delete_if(is_dead_idle<dcc_offer>);
	}
	else if (id == TIMER_10_MIN) {
		/**
		 * 10-minute timer:
		 * Save user preferences
		 */
		DEBUG("ircproxy::process_timers(): 10-minute check\n");
		save_prefs();
	}
	else if (id == TIMER_30_MIN) {
		/** 
		 * Save file database, among other things 
		 */
		DEBUG("ircproxy::process_timers(): 30-minute check\n");
		if (has_vfs()) {
			// FIXME: add more calls to compress databases, etc.
			library->prune_cache();	
		}

		/**
		 * Executed at every midnight: insert an informative message into every
		 * active logfile.
		 */
		struct tm tm;
		localtime_r(&data->time, &tm);
		if (tm.tm_hour == 0 && tm.tm_min == 0) {
			std::string time;
			timestamp_full(time);

			std::string msg = my_sprintf("The time is now: %s", time.c_str());
			print_all_logs(msg.c_str());
		}
	}
	return 1;
}

/**
 * Predicate to check if a expirable_object is active, idle, or dead.
 */
template<class T> static bool is_dead_idle(expirable_object<T> * object)
{
	int r;
	const void * data = NULL;
	time_t t = timer::now();

	r = object->status_check(t, &data);
	if (!r) {
		return false;
	}
	else if (r < 0) { 
		// object in zombie state, kill now
		DEBUG("proxy: Removing dead object: %p\n", object);
		return true;
	} 
	// idle time limit exceeded, call die() first
	object->die(r, data);
	return true;
}

/**
 * Dummy function predicate for expirable_object that announces a shutdown
 * and calls die() on the object.
 */
template<typename T> static bool announce_and_kill(expirable_object<T> * object)
{
	object->die(0, "Proxy shutting down");
	return true;
}

/**
 * Check if a ruleset is no longer used.
 */
static bool is_dead_ruleset(const ruleset * r)
{
	if (r->dead()) {
		DEBUG("Removing dead ruleset %p\n", r);
		return true;
	}
	return false;
}

int ircproxy::rehash()
{
	DEBUG("ircproxy::rehash(): entering\n");
	// Note: make a copy
	const string cf = options.get<string>(proxy_config::CONFIG_FILE);
	config_parser parser(cf.c_str());
	int r = parser.parse();

	if (r < 0) {
		return -1;
	}

	DEBUG("ircproxy::rehash(): parse succesful, merging options ...\n");

	vhosts.swap(parser.get_vhosts());
	banned.swap(parser.get_shitlist());	
	options.swap(parser.get_options());
	// this got clobbered
	set_config_file(cf.c_str());

	// this is the hard part 
        // also, this should not leak
	userdef::hash_table_t * newusers = userdef::sync_users(&user_hash, &parser.get_users());
        assert(user_hash.empty());
	user_hash.swap(*newusers);
	delete newusers;
	
	DEBUG("ircproxy::rehash(): exiting\n");
    	return 0;
}

/**
 * Insert a message into all active log files.
 */
void ircproxy::print_all_logs(const char * message)
{
	printlog("%s\n", message);
	// active user event logs
	for (userdef::hash_table_t::iterator i = user_hash.begin(), e = user_hash.end();
					i != e;
					++i) {
		userdef * user = (*i).second;
		user->printlog("%s\n", message);
	}
					
	// active chat logs
	std::for_each(util::tracked_object<conn>::objects().begin(),
			util::tracked_object<conn>::objects().end(),
			bind2nd(std::mem_fun(&conn::print_all_logs), message));
}

/*
 * Save stuff to the user file ... right now we only save
 * user preferences; in the future we might have a dynamic list of
 * bans or some such.
 */	
int ircproxy::save_prefs()
{
	const string& file = options.get<string>(proxy_config::USER_FILE);
	if (file.empty()) {
		return -1;
	}
		
	int f = open(file.c_str(), O_WRONLY | O_CREAT, 0600);
	if (f < 0) {
		printlog("Error saving user preferences: %s\n", strerror(errno));
		return -1;
	}
	DEBUG("ircproxy::save_prefs(): starting\n");
	ftruncate(f, 0);

	write_prefs_header(f);

	/* TODO: any future proxy-specific options here. */

	/* Save users' preferences. */
	userdef::hash_table_t::const_iterator i = user_hash.begin(),
						e = user_hash.end();
	for (; i != e; ++i) {
		userdef * u = (*i).second;
		if (!u->is_obsolete()) {
			u->save_dynamic_config(f);
		}
	}

	/* Done. */
	close(f);
	//printlog("Successfully saved preferences to user file.\n");

	DEBUG("ircproxy::save_prefs(): finished\n");
	return 0;
}

/**
  * Load the user preferences file.
  * Return values:
  *	
  * TODO: some way of capturing stderr output during this thing?
  */
int ircproxy::load_prefs()
{
	const string& file = options.get<string>(proxy_config::USER_FILE);

	if (file.empty()) {
		/** no dynamic user file .. **/
		return -1;
	}

	if (is_old_prefs_format(file.c_str())) {
		DEBUG("ircproxy::load_prefs(): Detected old style preferences file\n");
		/* Load old prefs here */
		int ret = load_old_prefs(file.c_str());
		if (ret == 0) {
			/* Parsing succeeded: rename the old file since it will be
			 * overwritten soon. */
			char pid[20] = "";
			sprintf(pid, "%d", getpid());
			const char * newname = my_strdup3(file.c_str(), ".backup.", pid);
			DEBUG("ircproxy::load_prefs(): saving old-style file as %s\n", newname);
			rename(file.c_str(), newname);
			delete[] newname;		
		}
		return ret;
	}

	userfile_parser parser(file.c_str(), options, user_hash);
	int i = parser.parse();

	if (i < 0) {
		/* report errors */
		return -1;
	}
	/* Success: parser handled all the setting of variables, so we're done here */
	
	DEBUG("ircproxy::load_prefs(): finished\n");
	printlog("Loaded preferences from user file\n");
	return 0;
}

/**
  * Write the header for the user preferences file (comments and such)
  */
int ircproxy::write_prefs_header(int fd) const
{
	static const char header[] =
		"######################################################################\n"
		"#                                                                    #\n"
		"# ezbounce user preferences file                                     #\n"
		"#                                                                    #\n"
		"#                                                                    #\n"
		"# NOTE: This file is automatically generated.  Please do not edit!   #\n"
		"#                                                                    #\n"
		"######################################################################\n"
		"\n"
		"\n";

	write(fd, header, sizeof(header) - 1);
	return 0;
}

/**
  * Check to see if the prefs file is in the old format. 
  * Very rudimentary; just read first few bytes of the file.
  */
bool ircproxy::is_old_prefs_format(const char * file) const
{
	static const char search[] = "ezb user preferences file version";
	char buffer[ sizeof(search) + 1];

	int f = open(file, O_RDONLY);
	if (f < 0) {
		return false;
	}

	int r = read(f, buffer, sizeof(search));
	close(f);
	if (r < 0) {
		return false;
	}
	buffer[r] = 0;

	if (strcmp(buffer, search) == 0) {
		return true;
	}
	return false;
}

/**
  * Actually load an old format preferences file.
  */
int ircproxy::load_old_prefs(const char * file) 
{
	int f = open(file, O_RDONLY);
	if (f < 0) {
		return -1;
	}	

	struct stat st;
	memset(&st, 0, sizeof(struct stat));

	char * buffer = new char[st.st_size + 1];
	int bytes = read(f, buffer, st.st_size);
	close(f);

	if (bytes < 0) {
		delete[] buffer;
		return -1;
	}

	std::vector<string> lines;
	tokenize(buffer, "\r\n", lines);
	delete[] buffer;

	for (std::vector<string>::const_iterator i = lines.begin(), e = lines.end();
			i != e;
			++i) {
		const char * line = (*i).c_str();
		std::string tokens[2];
		tokenize(line, " ", &tokens[0], 2);
		if (tokens[1].empty()) {
			continue;
		}

		const char * b = tokens[1].c_str();
		userdef * u = lookup_user(b);

		if (u == NULL || u->is_obsolete()) {
			DEBUG("ircproxy::load_old_prefs(): skipping bad user %s\n", b);
			continue;
		}
		u->old_load_dynamic_config(line);
	}
	return 0;
}

int listen_sock::on_readable()
{
	try {
		new conn(this);
		// automatically added to global list
	} 
	catch (std::exception& e) {
		ircproxy::instance()->printlog("Unable to accept connection: %s\n", e.what());
	}
	return 1;
}

int listen_sock::on_writeable()
{
	/* do nothing */
	return 0;
}
