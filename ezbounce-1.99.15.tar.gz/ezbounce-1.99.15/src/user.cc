/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 * user.cc
 * Part of ezbounce
 * (C) 2001-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <string>
#include <algorithm>
#include <sstream>
#include <stdexcept>
#include <cstdio>
#include <cstdlib>
#include "util/generic.h"
#include "util/hash.h"
#include "logging/vfs_logfile.h"
#include "io/filters.h"
#include "irc/rfc1459.h"
#include "irc/server_info.h"
#include "fs/credentials.h"
#include "fs/directory.h"
#include "fs/entry.h"
#include "fs/error.h"
#include "fs/key.h"
#include "fs/file_system.h"
#include "user.h"
#include "conn.h"
#include "ruleset.h"
#include "proxy.h"
#include "textline.h"
#include "debug.h"

using std::string;
using std::vector;

using fs::flib_key;
using fs::file_entry;
using fs::file_system;
using logging::logger;
using logging::vfs_logfile;
using util::delete_ptr;

using namespace util::strings;

/**
 * Construct a new userdef.
 * The requested name is checked for legality and then converted into 
 * IRC-lowercase.
 */
userdef::userdef(const char * user)
	: _name(user),
		obsolete(false),
		fs_credentials(NULL),
		eventlog(NULL),
		permissions("default", true),
		settings("default", true)
{
	DEBUG("userdef::userdef(): [%p] (%s)\n", this, _name.c_str());
	if (!is_legal_name(user)) {
		throw std::invalid_argument("illegal user name");
	}
	std::transform(_name.begin(), _name.end(), _name.begin(), irc::irc_tolower);
	
	// setup VFS credentials
	// all users belong to their user-private group, and the group "users"
	fs_credentials = new fs::credentials(_name.c_str(), _name.c_str());
	fs_credentials->add_group("users");
	set_fs_paths();
}

userdef::~userdef()
{
	DEBUG("userdef::~userdef(): [%p] (%s)\n", this, name());
        assert(clist.empty());
	std::for_each(rlist.begin(), rlist.end(), delete_ptr());
	delete eventlog;
	delete fs_credentials;
}

/**
 * Attempt to login a conn with given password.  Performs
 * no ruleset checks. Return:
 *	0:		success
 *	-1:		login failed
 */
int userdef::login(conn * c, const char * password, bool encrypted)
{
	const string& stored = permissions.get<string>(user_perms::PASSWORD);

#ifdef HAVE_CRYPT	
	if (encrypted) {
		/**
		 * Encrypted password ...  
		 */
		password = crypt(password, stored.c_str());
	}
#endif 		   
	if (stored != password) {
		return -1;
	}
	clist.push_back(c);

	if (clist.size() == 1) {
		// also start this
		start_event_log();
	}

	printlog("Login: %s [assigned id %d]\n", c->addr(), c->id());
	return 0;
}

int userdef::logout(const conn * c)
{
	DEBUG("userdef::logout(): for %s (%p)\n", _name.c_str(), c);
	printlog("Logout: connection id %d\n", c->id());
	clist.erase(std::find(clist.begin(), clist.end(), c));
	if (clist.empty()) {
		printlog("Event log stopped\n");
		delete eventlog;
		eventlog = NULL;
	}
	return 0;
}

/**
 * Set the config variables controlling user's home directory, 
 * dcc-in directory, dcc-out directory, and chatlogs directory.
 * Assigns default values of /home/user/logs, etc..
 */
void userdef::set_fs_paths()
{
	char buffer[512];
	const char * n = _name.c_str();
	snprintf(buffer, sizeof buffer, "/home/%s", n);
	permissions.set<string>(user_perms::HOME_DIR, buffer);

	snprintf(buffer, sizeof buffer, "/home/%s/dcc-in", n);
	settings.set<string>(user_config::DCC_IN_DIR, buffer);

	snprintf(buffer, sizeof buffer, "/home/%s/dcc-out", n);
	settings.set<string>(user_config::DCC_OUT_DIR, buffer);

	snprintf(buffer, sizeof buffer, "/home/%s/logs", n);
	settings.set<string>(user_config::CHATLOG_DIR, buffer);
}

/**
 * Analyze config and set filesystem access credentials.
 */
void userdef::update_fs_credentials() const
{
	assert(fs_credentials != NULL);
	fs_credentials->clear_flags();
	if (is_vfs_superuser()) {
		fs_credentials->set_flag(fs::credentials::SUPER_USER);
	}
}

/**
 * Verify VFS access permissions and create a new key for access.
 */
flib_key * userdef::create_fs_key(int *err) const
{
	file_system * lib = ircproxy::instance()->vfs();

	// Is there even a VFS?
	if (lib == NULL) {
		*err = fs::ERR_NO_VFS;
		return NULL;
	}
	// does he have permission to use it?
	const bool basic_access = permissions.get<bool>(user_perms::ENABLE_VFS_ACCESS);
	if (!basic_access && !is_admin() && !is_vfs_superuser()) {
		*err = fs::ERR_CONFIG;
		return NULL;
	}

	update_fs_credentials();
	fs::flib_key * fs_key = lib->create_key(fs_credentials, err);

	if (fs_key == NULL) {
		return NULL;
	}

	*err = lib->chdir(fs_key, permissions.get<string>(user_perms::HOME_DIR).c_str());

	/**
	 * This part is optional, but we'd like for it to succeed:
	 * Make sure directories exist for the user to store chat logs and dcc tranfers. 
	 */
	const char * dirs[] = {
		settings.get<string>(user_config::CHATLOG_DIR).c_str(),
		settings.get<string>(user_config::DCC_IN_DIR).c_str(),
		settings.get<string>(user_config::DCC_OUT_DIR).c_str(),
		NULL
	};

	for (int i = 0; dirs[i] != NULL; ++i) {
		const char * dir = dirs[i];
		int dummy = lib->access(fs_key, dir, 0);
		if (dummy == fs::ERR_DOESNT_EXIST) {
			lib->mkdir(fs_key, dir, 0700, &dummy);
		}
	}

	return fs_key;
}

/**
  * Return the desired name for a logfile.
  * Conflict resolution and file creation are handled elsewhere (by the chatlog class).
  * Parameters:
  *			logtype		- type of the log file (private or channel)
  *			serv		- server_info object pointer, to get IRC network name (may be NULL)
  *			name		- base name desired for the log file
  *			extra		- other information to append
  */
std::string userdef::make_log_path(const char * logtype, const irc::server_info * serv, 
				const char * name, const char * extra)
{
	DEBUG("%s: %s, %s, %s\n", __PRETTY_FUNCTION__, logtype, name, extra);
	
	std::string out;
	std::string clean_name = clean_log_name(name);

	const char * dir = settings.get<string>(user_config::CHATLOG_DIR).c_str();
	const char * dash = "-";
	const char * network = (serv == NULL) ? irc::server_info::default_irc_network() : serv->network(); 	

	std::string clean_network = clean_log_name(network);
	std::string ts;
	
	to_lowercase(clean_network);
	timestamp(ts, "%Y-%m-%d", ircproxy::instance()->time());

	if (!is_non_empty(extra)) {
		dash = "";
	}

	assert(dir[0] == '/');
	// assemble. example: /home/murat/logs/efnet/channel/#dummy.log
	my_sprintf(out, "%s/%s/%s/%s%s%s.%s.log", dir, clean_network.c_str(), logtype, 
					 	clean_name.c_str(), dash, 
						extra, ts.c_str());
	return out;	
}

/**
 * Clean up name for logfile, replacing dangerous characters such as
 * '/' and '.'  
 * Non printable ASCII characters are also replaced.  UTF-8 special characters
 * should not be affected.  Currently all bad characters get replaced with an 
 * underscore.
 */
std::string userdef::clean_log_name(const char * name)
{
	std::string out;
	out.reserve(strlen(name));

	for (const char * p = name; *p != 0; ++p) {
		switch (*p) {
		case '.':
		case '*':
		case '?':
		case '/':
		case '\\':
			out += '_';
			break;

		default:
			// Check for control characters
			if (*p > 0 && *p < 32) {
				out += '_';
			}
			else {
				out += *p;
			}
			break;
		}	
	}
	DEBUG("userdef::clean_log_name(): entered with '%s', exiting with '%s'\n", 
			name, out.c_str());
	return out;
}

/**
 * Create the event log.
 * The log will reside in /home/<user>/logs/
 */
int userdef::start_event_log()
{	
	static const char logname[] = "user.log";
	int err = 0;

	if (eventlog != NULL) {
		return -1;
	}

	fs::flib_key * fs_key = create_fs_key(&err);
	if (fs_key == NULL) {
		return -1;
	}

	io::filter_list filters;
	const std::string& dir = settings.get<string>(user_config::CHATLOG_DIR);
	std::string clean = dir + "/" + logname;
	std::string error;

	file_entry * fe = vfs_logfile::create_file_entry(clean, fs_key, filters,
								true, error);
	delete fs_key;

	if (fe == NULL) {
		// FIXME: print error ?
		return -1;
	}

	try {
		eventlog = new vfs_logfile("eventlog", fe, filters);
	}
	catch (std::exception& e) {
		// FIXME: print error ?
		file_system * vfs = ircproxy::instance()->vfs();
		vfs->close(fe);
		return -1;
	}

	eventlog->set_options(logging::LOG_FULL_TIMESTAMP | logging::LOG_LEVEL);
	eventlog->printf("Event log started\n");
	return 0;	
}

/**
 * Write to the user event log.
 */
int userdef::printlog(logging::level level, const char * fmt, ...)
{
	if (eventlog == NULL) {
		return -1;
	}
	va_list ap;
	va_start(ap, fmt);
	int ret = eventlog->vprintf(level, fmt, ap);
	va_end(ap);
	return ret;
}

/**
 * Write to event log; alternate version. 
 * Default to level INFO
 */
int userdef::printlog(const char * fmt, ...)
{
	if (eventlog == NULL) {
		return -1;
	}
	va_list ap;
	va_start(ap, fmt);
	int ret = eventlog->vprintf(logging::INFO, fmt, ap);
	va_end(ap);
	return ret;
}

/**  
 * Used during rehash to synchronize collections of users.
 *
 * For each user in the old collection:
 *      - Check if he has a match in the new collection:
 *          - if he does, syncronize options
 *              add original to out, remove new one from new collection, and delete
 *          - if he doesn't,
 *              mark as obsolete
 *		if he has no users, 
 *			delete and remove from collection
 *              if he he has users, 
 * 			mark obsolete and add to out
 *
 *      Add anyone left in new collection to "out"
 */
/* static */ userdef::hash_table_t * 
	userdef::sync_users(userdef::hash_table_t * oldhash, 
			userdef::hash_table_t * newhash)
{
	DEBUG("userdef::sync_users(): entering\n");
	hash_table_t::iterator i = oldhash->begin(),
				e = oldhash->end();
	hash_table_t * out = new hash_table_t(7);

	while (i != e) {
		userdef * u = (*i).second;

		hash_table_t::iterator i2 = newhash->find(u->name());
		if (i2 != newhash->end()) {
			userdef * const u2 = (*i2).second;
			/** swap vhost list, transfer options **/
			DEBUG("\t USER: processing %p (%s)\n", u, u->name());
			u2->vlist.swap(u->vlist);
			u2->config()->swap( *u->config() );
			u2->options()->swap( *u->options() );
			u->obsolete = false;			

			if (u->clist.empty()) {
				DEBUG("\t USER: %p has no clients, just getting new rulesets\n", u);
				/** no clients: swap ruleset list and we're done **/
				u->rlist.swap(u2->rlist);
			}
			else {

				DEBUG("\t USER: %p has clients, MERGING RULESETS\n", u);
				/** clients exist: transfer rulesets properly **/
				vector<ruleset *> * new_rlist =
					ruleset::sync_lists(&u->rlist, &u2->rlist);
				u->rlist.swap(*new_rlist);
				delete new_rlist;				
			}
			newhash->erase(i2);
			delete u2;

			out->insert(u->name(), u);			
		}
		else {
			/** not in the new set of users; condemned. **/
			if (u->clist.empty()) {				
				DEBUG("\t USER %s: NO MATCH deleting this user\n", u->name());
				delete u;
			}
			else {
				/** we have users .. mark this one as obsolete **/
				DEBUG("\t USER %s: marking as obsolete\n", u->name());
				u->obsolete = true;
				out->insert(u->name(), u);
			}
		}
		i = oldhash->erase(i);
	}

	/** Add remaining new users **/
	i = newhash->begin();
	e = newhash->end();
	while (i != e) {
		userdef * u = (*i).second;
		out->insert(u->name(), u);
		i = newhash->erase(i);
	}

	assert(newhash->size() == 0);
	assert(oldhash->size() == 0);
	assert(out->size() != 0);
	return out;
}

/**
 * Called when user preferences have been changed.
 * Notifies active clients of changes.
 */
void userdef::options_updated(const config::hash_entry * entry) const
{
	for_each(clist.begin(), clist.end(), 
			std::bind2nd(std::mem_fun(&conn::options_updated), entry));
}

/**
  * Write users personal preferences to the given fd.
  */
int userdef::save_dynamic_config(int fd)
{
	DEBUG("userdef::save_dynamic_config(): entering for user %s\n", name());
	std::ostringstream out;

	out << "user \"" << name() << "\" {\n";
	settings.print(out, 1);	
	out << "}\n\n";
	
	const std::string &str = out.str();
	write(fd, str.c_str(), str.size());
	return 0;
}

/**
  * Load preferences from old-style user file.
  */
int userdef::old_load_dynamic_config(const char * line)
{
	DEBUG("userdef::old_load_dynamic_config(): entering for user %s\n", name());

	textline args(line);
	const char * dummy = args[0];
	const char * rest = args.get_rest(2); 

	if (!strcasecmp(dummy, "prefs")) {
		return old_load_basic(line);
	}
	if (!rest || !strcmp(rest, "[none]")) {
		return 0;
	}

	config::target_list default_server(2, config::config_target("default"));

	if (strcasecmp(dummy, "ctcp-version-reply") == 0) {
		settings.set<server_node, string>( default_server, irc_server_config::CTCP_VERSION_REPLY, rest);
	}
	else if (strcasecmp(dummy, "detach-away") == 0) {
		settings.set<server_node, string>( default_server, irc_server_config::DETACH_NICK, rest);
	}
	else if (strcasecmp(dummy, "default-vhost") == 0) {
		settings.set<string>(user_config::VHOST, rest);
	}
	else if (strcasecmp(dummy, "auto-server") == 0) {
		settings.set<string>(user_config::AUTO_SERVER, rest);
	}
	return 0;
}

int userdef::old_load_basic(const char *s) 
{
	char s_dummy[256];
	char s_autopass[128], s_fake_ident[128], s_detach_nick[128] = "";
	int dummy;
	int flags = 0;
	int log_options = 0;
	int r;
	
	r = sscanf(s, "%s %s %d %d %u %d %d %d %s %s %s %s\n",
		s_dummy,
		s_dummy,
		&flags,
		&log_options,
		&dummy,
		&dummy,
		&dummy,
		&dummy,
		s_fake_ident,
		s_autopass,
		s_dummy,
		s_detach_nick);

#ifdef __DEBUG__
	if (r < 12) {
		DEBUG("User file corrupted??\n");
	}
#endif

	/* numeric options */
	// num_options[OPT_DEFAULT_LOG_OPTIONS] = log_options;

	config::target_list default_server(2, config::config_target("default"));
	/* string options */
	if (strcmp(s_autopass, "[none]") != 0 && is_non_empty(s_autopass)) {
		// obsolete?
		// set<const char *>(OPT_AUTO_PASS, s_autopass);
	}
	if (strcmp(s_fake_ident, "[none]") != 0 && is_non_empty(s_fake_ident)) {
		settings.set<string>(user_config::FAKE_IDENT, s_fake_ident);
	}
	if (strcmp(s_detach_nick, "[none]") != 0 && is_non_empty(s_detach_nick)) {
		settings.set<server_node, string>(default_server, irc_server_config::DETACH_NICK, s_detach_nick);
	}

	//--------------------------------------------------
	// DEBUG("    ---> (old-format) size() for %s ...\n", s_dummy);
	// DEBUG("         flags: %d\n", flags);
	// DEBUG("         log options: %d\n" , log_options);
	// DEBUG("         autopass: %s\n" , s_autopass);
	// DEBUG("         fake-ident: %s\n", s_fake_ident);
	// DEBUG("         detach-nick: %s\n", s_detach_nick);
	//-------------------------------------------------- 
	return 0;
}
