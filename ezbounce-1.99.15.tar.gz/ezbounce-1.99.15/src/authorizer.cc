/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * authorizer.cc
 * (c) 2005 Murat Deligonul
 */

#include "autoconf.h"

#include <list>
#include <algorithm>
#include "util/generic.h"
#include "util/hash.h"
#include "config/proxy.h"
#include "authorizer.h"
#include "proxy.h"
#include "user.h"
#include "ruleset.h"

#include "debug.h"

using util::copy_if;

/** STL helper classes **/
class register_helper {
private:
	authorizer * const a;
	int res;	/* cumulative result of register/unregister operations */
	int op;		/* Stores the operation (only low 8 bits are relevant)
			 * [000a000b]
			 * a:		0 = register, 1 = unregister
			 * b:		0 = from,     1 = to
			 */
public:
	register_helper(authorizer * auth, int o, ruleset::host_type t) : a(auth), res(1),
						op((o << 4) | int(t == ruleset::TO)) { }

	int result() const { return res; }
	void operator() (ruleset * r);
};

class allowed_helper {
private:
	authorizer * const a;
	int res;			/* cumulative result of is_allowed operations */
	ruleset::host_type op;		/*		0 = from, 1 = to  	      */
	char rbuf[256];
public:

	allowed_helper(authorizer * auth, ruleset::host_type o) : a(auth), res(0), op(o) { }
	int result() const { return res; }
	const char * reason() const { return rbuf; }
	void operator() (ruleset * r);
};

class match_helper {
private:
	authorizer * const a;
public:
	match_helper(authorizer * auth) : a(auth) { }
	bool operator()(const ruleset * r) const {
		return (!r->is_obsolete() && r->does_match(a->get(a->FROM_HOST), 
						a->get(a->FROM_IP), 
						a->get(a->FROM_PORT), ruleset::FROM));	
	}

};

/** Constructor for authorizer **/
authorizer::authorizer()
	: status(0),
	   user(NULL)
{
	ports[0] = ports[1] = 0;
}

#ifdef __DEBUG__
authorizer::~authorizer()
{
	assert(!(status & LOGGED_IN));
	assert(rulesets.empty());
}
#endif


/**
 * Return values for these functions:
 * -1:		Illegal state (not enough info to call this fn right now)
 *  0:		Success
 *  -2:		Legal state but operation failed
 * < -2:	Other errors 
 */
int authorizer::recognize_connection()
{
	assert(!(status & RECOGNIZED));
	
	const allowed_helper& h = std::for_each(ircproxy::instance()->shitlist().begin(), 
						ircproxy::instance()->shitlist().end(),
						allowed_helper(this, ruleset::FROM));

	if (h.result() < 0) {
		set(FAILURE_REASON, h.reason());
		return ERR_NOT_ALLOWED;
	}
	
	userdef::hash_table_t::const_iterator i = ircproxy::instance()->users().begin(),
						e = ircproxy::instance()->users().end();

	int res = 0;
	for (; i != e; ++i) {
		userdef * u = (*i).second;
		if (u->is_obsolete()) {
			continue;
		}
		const allowed_helper& h2 = std::for_each(u->rulesets().begin(),
							u->rulesets().end(),
							allowed_helper(this, ruleset::FROM));
		res = std::max(res, h2.result());
	}
	
	if (res < 1) {
		set(FAILURE_REASON, "No authorization");
		return ERR_NO_MATCH;
	}
	
	status |= RECOGNIZED;
	
	assert(user == 0);
	return SUCCESS;
}

/**
 * This is where the password validation occurs.
 */
int authorizer::login_connection(conn * c, const char * login, const char * pass)
{
	assert(user == 0);
	assert(rulesets.empty());
	assert(!(status & LOGGED_IN));
	
	userdef::hash_table_t::iterator i = ircproxy::instance()->users().find(login);
	if (i == ircproxy::instance()->users().end()) {
		return ERR_UNKNOWN_USER;
	}

	userdef * u = (*i).second;
	if (u->is_obsolete()) {
		return ERR_UNKNOWN_USER;
	}
		
	/** Find matching rulesets **/
	copy_if(u->rulesets().begin(), u->rulesets().end(), 
		std::back_inserter(rulesets), 
		match_helper(this));
	
	if (rulesets.empty()) {
		return ERR_NO_MATCH;
	}
	
	const bool encrypt = ircproxy::instance()->config().get<bool>(proxy_config::ENCRYPTED_PASSWORDS);
	if (u->login(c, pass, encrypt) < 0) {
		rulesets.clear();
		return ERR_BAD_PASSWORD;
	}
		
	this->user = u;
	status |= LOGGED_IN;
	
	assert(user != 0);
	assert(rulesets.size() > 0);
	return SUCCESS;
}

/**
 * At this point we are logged in and have a list of matching
 * rulesets.  Now check if we are allowed and register 
 * the connections 
 */
int authorizer::register_connection()
{
	assert(user != 0);
	assert(rulesets.size() > 0);
	assert(!(status & REGISTERED_FROM));
	
	DEBUG("auth::register_connection() [%p]\n", this);
	
	const allowed_helper& h = std::for_each(rulesets.begin(), rulesets.end(),
						allowed_helper(this, ruleset::FROM));
	if (h.result() < 0) {
		set(FAILURE_REASON, h.reason());
		return ERR_NOT_ALLOWED;
	} 
	else if (h.result() == 0) {
		/* this should not happen */
		assert(0);
		return ERR_NO_MATCH;
	}
	
	std::for_each(rulesets.begin(), rulesets.end(), register_helper(this, 0, ruleset::FROM));
	status |= REGISTERED_FROM;
	return SUCCESS;	
}

int authorizer::unregister_connection()
{
//	assert(status & REGISTERED_FROM);
	if (!(status & REGISTERED_FROM)) {
		return ERR_ILLEGAL_STATE;
	}

//	assert(rulesets.size() > 0);
	DEBUG("authorizer::unregister_connection() [%p]\n", this);
	
	std::for_each(rulesets.begin(), rulesets.end(), register_helper(this, 1, ruleset::FROM));
	status &= ~REGISTERED_FROM;
	return SUCCESS;
}

int authorizer::logout_connection(conn * c) 
{
// FIXME: these need to be reenabled at some point
//	assert(user != 0);
//	assert(rulesets.size() > 0);
//	assert(!(status & REGISTERED_FROM));
//	assert(!(status & REGISTERED_TO));
	if (!user || (status & REGISTERED_FROM) || (status & REGISTERED_TO)) {
		return ERR_ILLEGAL_STATE;
	}
	
	user->logout(c);
	user = 0;
	rulesets.clear();
	
	status &= ~LOGGED_IN;
	assert(user == 0);
	assert(rulesets.empty());
	return SUCCESS;
}

int authorizer::register_outgoing_connection()
{
	assert(status & LOGGED_IN);
	assert(!(status & REGISTERED_TO));
	assert(get(TO_IP) != 0);
	DEBUG("auth::register_outgoing_connection() [%p]\n", this);
	
	const allowed_helper& h= std::for_each(rulesets.begin(), rulesets.end(),
						allowed_helper(this, ruleset::TO));
	
	const allowed_helper& h2 = std::for_each(ircproxy::instance()->shitlist().begin(),
						ircproxy::instance()->shitlist().end(),
						allowed_helper(this, ruleset::TO));			
	if (h.result() < 0) {
		/* ruleset ban */
		set(FAILURE_REASON, h.reason());
		return ERR_NOT_ALLOWED;
	} 
	else if (h2.result() < 0) {
		/* global ban list */
		set(FAILURE_REASON, h2.reason());
		return ERR_NOT_ALLOWED;
	}
	else if (h.result() == 0) {
		/* no authorization */
		set(FAILURE_REASON, "Host is not in allowed list");
		return ERR_NO_MATCH;
	}
	
	std::for_each(rulesets.begin(), rulesets.end(), register_helper(this, 0, ruleset::TO));
	status |= REGISTERED_TO;
	return SUCCESS;			
}

int authorizer::unregister_outgoing_connection()
{
//	assert(rulesets.size() > 0);
//	assert(status & REGISTERED_TO);
	if (!(status & REGISTERED_TO)) {
		DEBUG("authorizer::unregister_outgoing_connection(): [%p] called with illegal state\n", this);
		return ERR_ILLEGAL_STATE;
	}
	DEBUG("auth::unregister_outgoing_connection() [%p]\n", this);
	
	std::for_each(rulesets.begin(), rulesets.end(), register_helper(this, 1, ruleset::TO));
	status &= ~REGISTERED_TO;
	return SUCCESS;
}


void allowed_helper::operator() (ruleset * r)
{
	if (res < 0)	{
		/* Already found out we're banned */
		return;
	}
	int i;
	if (op == ruleset::FROM) {
		i = r->is_allowed(a->get(a->FROM_HOST), a->get(a->FROM_IP), 	
					a->get(a->FROM_PORT),
					rbuf, sizeof(rbuf));
	} 
	else {
		i = r->is_allowed_to(a->get(a->TO_HOST), a->get(a->TO_IP), 
					a->get(a->TO_PORT),
					rbuf, sizeof(rbuf));
	}
	if (i != 0) {
		res = i;
	}
}

void register_helper::operator() (ruleset * r)
{
	int i;
	switch (op) {
	case	0x00:	/* register from */
		i = r->register_connection(ruleset::FROM, a->get(a->FROM_HOST), 
					a->get(a->FROM_IP), a->get(a->FROM_PORT));
		break;
	case 	0x01: 	/* register to */
		i = r->register_connection(ruleset::TO, a->get(a->TO_HOST), 
					a->get(a->TO_IP), a->get(a->TO_PORT));	
		break;
	case 	0x10:	/* unregister from */
		i = r->unregister_connection(ruleset::FROM, a->get(a->FROM_HOST), 
					a->get(a->FROM_IP), a->get(a->FROM_PORT));
		break;
	case 	0x11: 	/* unregister to */
		i = r->unregister_connection(ruleset::TO, a->get(a->TO_HOST),
					a->get(a->TO_IP), a->get(a->TO_PORT));
		break;
	default:
		abort();
	}
	
	res = std::min(res, i);
}

