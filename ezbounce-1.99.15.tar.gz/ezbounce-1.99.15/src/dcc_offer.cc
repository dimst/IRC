/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * dcc_offer.cc -- Part of the ezbounce IRC proxy
 * (C) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include "util/strings.h"
#include "fs/directory.h"
#include "dcc_offer.h"
#include "dcc.h"
#include "debug.h"

using std::string;
using fs::directory;

using namespace util::strings;

/**
 * Basic constructor; for DCC Chats.
 */
dcc_offer::dcc_offer(conn * owner, const char * type,
			const net::ap_pair& addr,
			const char * from, const char * to, int f)
	: host_data(addr),
		_start(time(NULL)),
		_owner(owner),
		_flags(f),
		_id(dcc::idgen.generate()),
		_size(0),
		_offset(0)
{
	assert(type);
	assert(!((f & INCOMING) && (f & OUTGOING)));
	assert((f & INCOMING) || (f & OUTGOING));
	
	data.set(FROM,from);
	data.set(TO, to);
	data.set(TYPE, type);
	
	DEBUG("dcc_offer::dcc_offer() [%p] New offer (...)\n", this);
}

/**
 * Constructor for DCC Send offers.
 */
dcc_offer::dcc_offer(conn * owner, const char * type,
			const net::ap_pair& addr,
			const char * from, const char * to,
			const char * filename,
			unsigned int size, unsigned int offset, int f)
	: host_data(addr),
		_start(time(NULL)),
		_owner(owner),
		_flags(f),
		_id(dcc::idgen.generate()),
		_size(size),
		_offset(offset)
{
	assert(type);
	assert(!((f & INCOMING) && (f & OUTGOING)));
	assert((f & INCOMING) || (f & OUTGOING));

	if (!directory::is_legal_name(filename)) {
		throw dcc_exception("Illegal character(s) in filename");
	}

	//--------------------------------------------------
	// const unsigned short max_dccs = owner->user()->config()->get<int>(user_perms::MAX_DCCS);
	// if (owner != NULL && max_dccs > 0 && owner->dcc_count() >= max_dccs) {
	// 	owner->dec_dcc_count();
	// 	throw dcc_exception("DCC Limit Exceeded");
	// }
	//-------------------------------------------------- 

	data.set(FROM,from);
	data.set(TO, to);
	data.set(TYPE, type);
	data.set(FILENAME, filename);

	DEBUG("dcc_offer::dcc_offer() [%p] New offer (...)\n", this);
}

dcc_offer::~dcc_offer() 
{
	set_owner(NULL); 
	dcc::idgen.clear(_id); 
}

/** 
 * An offer is idle when:
 * nothing happens after 5 minutes (set flags to 0) 
 */
int dcc_offer::status_check(time_t now, const void **) const
{
	if (flags() == DEAD) {
		return -1;
	}
	if (now - _start > 60 * 5) {
		if (_owner) {
			//_owner->cprintf("DCC Offer %d has expired\r\n", id());
		}
		return 1;    
	}
	return 0;
}

int dcc_offer::die(int, const void *)
{
	_flags = DEAD;
	return 0;
}

/**
 * Obtain 1-line basic information.
 */
string dcc_offer::info() const
{
	if (_flags) {
		const char * arrow = "-->";
		if (_flags & INCOMING) {
			arrow = "<--";
		}
		return my_sprintf("%s %s %s[%s:%d]-->%s (%s %d)",
					arrow, type(), 
					from(), address(), port(), 
					to(), filename(), size());
	}
	return "[invalid offer]";
}

/**
 * Obtain multi-line, more descriptive information.
 */
string dcc_offer::full_info() const
{
	string ts;
	timestamp_full(ts, start_time());
	return my_sprintf("Type: %s\r\n"
				"Created: %s\r\n"
				"%s ------> %s\r\n"
				"Address: %s [port: %d]\r\n"
				"Other: %s %d\r\n",
				type(), ts.c_str(),
				from(), to(),
				address(), port(),
				filename(), size());
}
