/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * dcc.cc -- Part of the ezbounce IRC proxy
 * (C) 1999-2008 Murat Deligonul
 *
 * ---
 * This handles the dcc proxying and sending for ezbounce. 
 * The dcc command interception and redirecting is done in the conn class
 * --
 */

#include "autoconf.h"

#include <list>
#include <iterator>
#include <sstream>
#include <fstream>
#include <stdexcept>
#include <cerrno>
#include <cstdlib>
#include <ctime>
#include <sys/types.h>
#include <unistd.h>
#include "util/strings.h"
#include "util/idgenerator.h"
#include "config/proxy.h"
#include "io/event.h"
#include "fs/entry.h"
#include "fs/directory.h"
#include "fs/file_system.h"
#include "net/error.h"
#include "dcc.h"
#include "dcc_offer.h"
#include "dcc_socket.h"
#include "user.h"
#include "conn.h"
#include "proxy.h"
#include "debug.h"

using std::ios;
using std::ios_base;
using std::istream;
using std::string;

using fs::file_entry;
using fs::file_system;
using net::socket_exception;
using net::ap_pair;
using util::strings::timestamp_full;
using util::strings::my_sprintf;

/* static */ util::id_generator dcc::idgen(4);

/** 
 * Given a unified dcc/offer handle, find who/what it belongs to.
 *
 * Return:
 *      0 	success -- the proper pointer is assigned, the other is set to NULL
 *      -1	error -- nothing matching the id was found
 */
int lookup_dcc_by_id(conn * owner, unsigned int id, dcc ** d, dcc_offer ** offer)
{
	const std::list<dcc *>& dcc_list = ircproxy::instance()->dcc_list();
	const std::list<dcc_offer *>& dcc_offer_list = ircproxy::instance()->dcc_offer_list();

	std::list<dcc *>::const_iterator dcci = dcc_list.begin(),	
					dcce  = dcc_list.end();
		
	std::list<dcc_offer *>::const_iterator oi = dcc_offer_list.begin(),
						oe = dcc_offer_list.end(); 
	assert(d && offer);

	while (dcci != dcce) {
		*d = *dcci;		
		if ((*d)->owner() == owner && (*d)->id() == id 
				&& (*d)->status_check(0, NULL) >= 0) {
			*offer = NULL;
			return 0;
		}
		++dcci;
	}

	while (oi != oe) {
		*offer = *oi;
		if ((*offer)->owner() == owner && (*offer)->id() == id 
				&& (*offer)->status_check(0, NULL) >= 0) {
			*d = NULL;
			return 0;
		}
		++oi;
	}
	*d = NULL;
	*offer = NULL;
	return -1;
}

/**
 * Swap IDs of a DCC and a DCC Offer.
 */
void swap_dcc_ids(dcc * d, dcc_offer * offer)
{
	unsigned int temp;
	temp = offer->id();
	offer->_id = d->id();
	d->_id = temp;
}

/** dcc_socket **/
void dcc_socket::on_connect()
{
	assert(role() == dcc::SENDER);
	owner()->socket_event(role(), dcc::SOCK_CONNECTED, 0);
	net::socket::on_connect();
}

int dcc_socket::on_writeable()
{
	assert(role() != dcc::LISTENER);
	assert(role() == dcc::RECEIVER || role() == dcc::SENDER);
	owner()->socket_event(role(), dcc::SOCK_WRITEABLE, 0);
	return 0;
}

int dcc_socket::on_readable()
{
	switch (role()) {
	case dcc::LISTENER:
		/** 
		 * Connection accepted on socket ?
		 */
		owner()->socket_event(role(), dcc::SOCK_READABLE, 0);
		return 0;

	case dcc::RECEIVER:
	case dcc::SENDER:
		// otherwise, read into buffer
		if (this->read() < 0) {
			owner()->socket_event(role(), dcc::SOCK_CLOSED, 0);
		} 
		else {
			owner()->socket_event(role(), dcc::SOCK_READABLE, 0);
		}
	}
	return 0;
}

void dcc_socket::on_disconnect(int e)
{
	owner()->socket_event(role(), dcc::SOCK_CLOSED, e);
}

void dcc_socket::on_connect_fail(int e)
{
	assert(role() == dcc::SENDER);
	owner()->socket_event(role(), dcc::SOCK_CLOSED, e);
}

/** 
 * The base dcc constructor.
 */
dcc::dcc(conn * o) :
	start(time(NULL)),
	_owner(NULL),
	stat(DCC_NEW),
	_id(idgen.generate())
{
	DEBUG("dcc::dcc() -- [%p]\n", this);

	set_owner(o);

	//--------------------------------------------------
	// // XXX: obsolete
	// const unsigned short max_dccs = o->user()->config()->get<int>(user_perms::MAX_DCCS);
	// if (o != NULL && max_dccs > 0 && o->dcc_count() >= max_dccs) 
	// {
	// 	throw dcc_exception("Max DCC Count Exceeded");
	// }
	//-------------------------------------------------- 

	timestamp = start;
}


dcc::~dcc()
{
	/**
	 * DCC Objects should never be destroyed directly.  Call die() first.
	 */
	assert(status() == DCC_CLOSED || status() == DCC_NEW); 
	set_owner(NULL); 
	idgen.clear(_id); 
}

void dcc::set_owner(conn * c)
{
	DEBUG("dcc::set_owner() [%p] %p ---> %p\n", this, _owner, c);
	_owner = c;        
}

/**
 * 'condemn' this DCC. notify owner if necessary.
 */
int dcc::die(int e, const void * str)
{
	if (status() != DCC_CLOSED) {
		announce_dcc_event((dcc_event) e, (const char *) str);
		ircproxy::instance()->printlog("Killing DCC [%u]: %s: %s\n", id(), strevent((dcc_event) e), str);
		stat = DCC_CLOSED;
	}
	set_owner(NULL);
	return 0;
}

int dcc::announce_dcc_event(dcc_event e, const char * str)
{
	if (owner()) {
		owner()->cprintf("DCC Event [%u]: %s: %s\r\n", id(), strevent(e), str);
		owner()->regulate_io_events();
	}
	ircproxy::instance()->printlog("DCC Event [%u]: %s: %s\n", id(), strevent(e), str);
	return 0;
}


/**
 * Generate output with information common to all DCCs.
 */
string dcc::full_info() const
{
	time_t _age = age(time(NULL));
	string start_ts;
	string last_ts;
	string age_str;

	util::strings::timestamp_full(start_ts, start_time());
	util::strings::timestamp_full(last_ts, last_event());
	util::strings::duration(age_str, _age, true);

	std::ostringstream out;
	out << "DCC " << type() << " session #" << id() << "\r\n";
	out << "- Current state: " << strstat(status()) << "\r\n";
	out << "- Created: " << start_ts << " (aged " << age_str << ")\r\n";
	out << "- Last event: " << last_ts << "\r\n";
	return out.str();
}

const char * dcc::strstat(dcc_stat t)
{
	switch (t) {
	case DCC_NEW:
		return "new";
	case DCC_CONNECTING:
		return "connecting to";    
	case DCC_CONNECTED:
		return "established";
	case DCC_FINISHED:
		return "finished";
	case DCC_LISTENING:
		return "listening";
	case DCC_ACCEPTED:
		return "accepted";	
	case DCC_CLOSED:
		return "closed";
	}
	return "unknown state";
}

const char * dcc::strevent(dcc_event e)
{
	if (e < 0 || e >= DCC_EVENT_MAX) {
		return "Unknown event";
	}
	static const char * dcc_eventable[] = {
		"DCC event succesful",
		"DCC session closed",
		"DCC Proxy session established",
		"DCC Proxy session closed",
		"DCC Proxy session failed",
		"DCC Send established",
		"DCC Send completed",
		"DCC Send failed",
		"DCC Get established",
		"DCC Get completed",
		"DCC Get failed",
		"DCC session timed out",
		"DCC session failure",
		"DCC Connection accepted",
		"DCC Killed by user request"
	};
	return dcc_eventable[e];
}

/** dcc_with_listener **/
dcc_with_listener::dcc_with_listener(conn * o, const ap_pair& interface)
                                        : dcc(o),
						listener(NULL)
{
	DEBUG("dcc_with_listener::dcc_with_listener() -- [%p]\n", this);
	// set up the listener socket
	try {
		const char * iface = interface.first.c_str();
		unsigned short port = interface.second;
		listener = new dcc_socket(this, LISTENER);
		if (port) { /* listen in port range if necessary */
			listener->listen(iface, port, 1);
		}
		else {
			const string& ports = ircproxy::instance()->config().get<string>(proxy_config::DCC_PORTS);
			listener->listen(iface, ports.c_str(), 1);        
		}
	} 
	catch (...) {
		delete listener;
		throw;
	}
	set_status(DCC_LISTENING);
}

int dcc_with_listener::die(int e, const void * str)
{
	delete listener;
	listener = NULL;
	return dcc::die(e, str);
}

dcc_with_listener::~dcc_with_listener()
{
	DEBUG("dcc_with_listener::~dcc_with_listener() -- [%p]\n", this);
	delete listener;
}


int dcc_with_listener::status_check(time_t now, const void **) const
{
	if ((status() == DCC_LISTENING) &&
			(now - last_event()) >= 90) {
		return DCC_TIMED_OUT;
	}
	if (status() == DCC_CLOSED) {
		return -1;
	}
	return DCC_EVENT_SUCCESS;
}

string dcc_with_listener::info() const
{
	if (status() == DCC_LISTENING) {
		return my_sprintf("Listening on %s port %d", listener->local_addr(), listener->local_port());
	}
	return "[No longer listening]";
}

/**
 * Obtain detailed, multi-line information.
 */
string dcc_with_listener::full_info() const
{
	std::ostringstream out;
	out << dcc::full_info();
	if (status() == DCC_LISTENING) {
		out << "- Listening on " << listener->local_addr() << " port " << listener->local_port() << "\r\n";
	}
	return out.str();
}

/**
 * DCC Send constructor:
 * If construction is successful, the dccsend object takes ownership of the file_entry
 * resource (and the reader it opens) and will automatically release them upon destruction.
 *
 * If constructor fails, an exception is thrown and the provided file_entry resource
 * is untouched.
 */
dccsend::dccsend(conn * o, file_entry * fe, 
			const io::filter_list& flist, 
			off_t offset,
			const ap_pair& interface) 
                        : dcc_with_listener(o, interface),
				receiver(NULL),
				file(fe),
				reader(NULL),
				sent(offset),
				ack(offset),
				filters(flist)
{
	DEBUG("dccsend::dccsend() -- [%p] (sending %s)\n", this, fe->name());
	/**
	 * Perform some sanity checks.
	 */
	if (offset < 0) {
		throw std::out_of_range("file offset must be >= 0");
	}

	// NOTE: the file is opened for IO later.
	assert(status() == DCC_LISTENING);
}

dccsend::~dccsend()
{
	delete receiver;
}

/*
 * Read the next packet and queue it for sending.
 *
 * Return values:
 * -1	 Read error; DCC must be aborted
 *  0    EOF
 * >0    Number of bytes queued
 */
int dccsend::queue_next_packet()
{
	static char buffer[PACKET_SIZE + 1];
	istream& stream = reader->get_stream();
	
	stream.read(buffer, PACKET_SIZE);
	size_t bytesread = stream.gcount();

	if (stream.bad() || (stream.fail() && !stream.eof())) {
		DEBUG("dccsend::queue_next_packet(): Error in read: %s\n", strerror(errno));
		return -1;
	}
	if (bytesread == 0 && stream.eof()) {
		return 0;
	}

	return receiver->queue(buffer, bytesread);
}


int dccsend::socket_event(int r, int events, int extra)
{
	if (r == LISTENER) {
		assert(events == SOCK_READABLE);
		/** accept the connection **/
		try {
			receiver = new dcc_socket(listener->owner(), listener, RECEIVER);
			set_status(DCC_CONNECTED);
			listener->close();
			delete listener;
			listener = NULL;
			/* ack packets are ignored */
			receiver->set_events(io::EVENT_WRITE);

			/* try to open the file now; attach filters */
			reader = file->open_reader(ios::in | ios::binary);
			io::attach_filters(*reader, filters);
			reader->complete();
		} 
		catch (std::exception &e) {
			/** could not accept connection, or open reader **/
			die(DCC_SEND_FAILED, e.what());
			return 0;
		}

		/** reader open, socket ready, advance file pointer **/
		istream& stream = reader->get_raw_stream();
		stream.seekg(ack);
		if (stream.fail()) {
			/** note: die() takes care of freeing resources **/
			die(DCC_SEND_FAILED, "unable to seek file pointer");
			return 0;
		}

		announce_dcc_event(DCC_SEND_ESTABLISHED, "");
		return 0;
	}
	/** 
	 * Receiver events follow 
	 */	
	if (events == SOCK_READABLE) {
		// ignore all
		receiver->clear();                    
	}	
	if (events == SOCK_WRITEABLE) {
		/**
		 * Still have packets to send?
		 */
		const off_t size = file->size();
		if (sent < size) {
			int r = queue_next_packet();
			if (r <= 0) {
				// FIXME: handle EOF better?
				DEBUG("dccsend::socket_event(): killing send due to error: %d\n", errno);
				return die(DCC_SEND_FAILED, strerror(errno));
			}
			sent += r;
		}

		/**
		 * Since we don't wait for acknowledgement counts from the 
		 * receiver, the 'ack' field is updated here with the number of bytes
		 * flushed down the socket.
		 */
		int r = receiver->flushO();
		if (r < 0) {
			DEBUG("dccsend::socket_event(): killing send due to error in flush: %d\n", r);
			return die(DCC_SEND_FAILED, net::strerror(r));
		}

		ack += r;
		if (ack >= size) { 
			set_status(DCC_FINISHED);
			receiver->set_events(io::EVENT_READ);
			set_last_event(ircproxy::instance()->time());
		}
		DEBUG("dccsend::socket_event(): [%p] %lu/%lu bytes of '%s' sent\n", this, ack, size, file->name());
	}
	if (events == SOCK_CLOSED) {
		if (status() == DCC_FINISHED) {
			return die(DCC_SEND_COMPLETE, "");
		}
		// Premature disconnect
		return die(DCC_SEND_FAILED, net::strerror(extra));
	}
	return 1;
}

/**
 * Definition of idle:
 *  Waiting for connections and 90 secs passed
 * 		-OR-
 *  dcc send complete and 30 secs passed 
 */
int dccsend::status_check(time_t now, const void **) const
{
	const bool finished = status() == DCC_FINISHED;
	if (finished && (now - last_event() >= 30)) {
		return DCC_SEND_COMPLETE;
	}
	return dcc_with_listener::status_check(now);
}    
    
int  dccsend::die(int e, const void *str)
{
	/* close *our* sockets */
	delete receiver;

	/* close file descriptor and release VFS resources */
	if (file != NULL) {
		if (reader != NULL) {
			file->close(reader);
		}
		ircproxy::instance()->vfs()->close(file);
	}

	receiver = NULL;
	file = NULL;
	reader = NULL;
	return dcc_with_listener::die(e, str);
}

string dccsend::info() const
{
	if (status() == DCC_LISTENING) {
		return dcc_with_listener::info();
	}
	const char * what = strstat(status());
	if (receiver) {
		return my_sprintf("SEND (%s) [%s port %d] (%u/%u)", what, 
				receiver->peer_addr(), receiver->peer_port(), 
				ack, file->size());
	}
	return my_sprintf("SEND (%s) (%u/%u)", what, ack, file->size());
}

/**
 * Create detailed, multi-line information about this DCC Send.
 */
string dccsend::full_info() const
{
	std::ostringstream out;
	out << dcc_with_listener::full_info();
	if (file != NULL) {
		const size_t size = file->size();
		out << "- File: " << file->name() << "\r\n";
		out << "- Sent: " << ack << "/" << size << " bytes ";
		out << "(" << (float) ack / size * 100 << "%)" << "\r\n";
		out << "- Location: " << file->dir()->rel_path() << "\r\n";
	}
	if (receiver != NULL) {
		out << "- To: " << receiver->peer_addr() << " port " << receiver->peer_port() << "\r\n";
	}
	return out.str();
}

const char * dccsend::type() const 
{
	return "Send";
}

/*
 * Create a dcc pipe object. Fill 'sender' with info given.
 * By default binds to default interface on random port, and
 * waits for the receiver to connect.
 * By supplying something non-null for host_info you can
 * control what port or interface. Also when function completes
 * you will know what IP address the sock was bound.
 *
 * On success: listen_port is assigned non-0 value.
 */
dccpipe::dccpipe(conn * o ,
		const ap_pair& sender_address,
		const ap_pair& listen_address)
                : dcc_with_listener(o, listen_address),
			sender(NULL),
			receiver(NULL),
			s_address(sender_address)
{
	/** 
	  * At this point the constructor for the base class has been called
	  * and we should have a socket setup, waiting for connections.
	  * Perform some sanity checks first.
	  */
	if (sender_address.first.empty()) {
		throw std::invalid_argument("sender address cannot be empty");
	}
	if (sender_address.second == 0) {
		throw std::invalid_argument("invalid TCP port");
	}
	// wait for connections ...
	assert(status() == DCC_LISTENING);
}

int dccpipe::status_check(time_t now, const void **) const
{
	return dcc_with_listener::status_check(now);
}

int dccpipe::die(int e, const void * s2)
{
	delete sender;
	delete receiver;
	sender = receiver = NULL;
	return dcc_with_listener::die(e, s2);
}

string dccpipe::info() const
{
	if (status() == DCC_LISTENING) {
		return dcc_with_listener::info();
	}
	
	const char * what = strstat(dcc_stat(status()));
	if (sender && receiver) {
		return my_sprintf("PROXY (%s) [%s port %d]<-->[%s port %d]", what,
					sender->peer_addr(), sender->peer_port(),
					receiver->peer_addr(), receiver->peer_port());
	}
	return my_sprintf("PROXY (%s)", what);         
}

string dccpipe::full_info() const
{
	std::ostringstream out;
	out << dcc_with_listener::full_info();
	if (sender != NULL) {
		out << "- Endpoint 1 peer : " << sender->peer_addr() << " port " << sender->peer_port() << "\r\n";
		out << "- Endpoint 1 local: " << sender->local_addr() << " port " << sender->local_port() << "\r\n";
	}
	if (receiver != NULL) {
		out << "- Endpoint 2 local: " << receiver->local_addr() << " port " << receiver->local_port() << "\r\n";
		out << "- Endpoint 2 peer : " << receiver->peer_addr() << " port " << receiver->peer_port() << "\r\n";
	}
	return out.str();
}

const char * dccpipe::type() const 
{
	return "Proxy";
}

    
dccpipe::~dccpipe()
{
	// Nothing to do
}

int dccpipe::socket_event(int r, int event, int extra)
{
	DEBUG("dccpipe::socket_event(%d, %d, %d) [%p]\n", r, event, extra, this);
	if (r == LISTENER) {
		assert(event == SOCK_READABLE);
		/** 
		 * Accept the connection.
		 */
		try {
			receiver = new dcc_socket(listener->owner(), listener, RECEIVER);
			set_status(DCC_CONNECTING);

			listener->close();
			delete listener;
			listener = NULL;

			/** 
			 * Now we need to connect to the sender ...
			 */
			sender = new dcc_socket(receiver->owner(), SENDER);
			int r = sender->async_connect(s_address.first.c_str(), "", s_address.second);

			if (r < 0) {
				return die(DCC_PIPE_FAILED, net::strerror(r));
			}
			announce_dcc_event(DCC_CONNECTION_ACCEPTED, receiver->peer_addr());
			// now just wait ...

		} 
		catch (std::exception &e) {
			/** 
			 * Could not accept connection.
			 */
			die(DCC_PIPE_FAILED, e.what());
		}
		return 0;        
	}
	else {
		if (event == SOCK_CONNECTED) {
			assert(r == SENDER);
			/** Proxy is now established **/
			char buffer[256];
			snprintf(buffer, 256, "[%s : %d] <----> [%s : %d]",
					receiver->peer_addr(), receiver->peer_port(),
					sender->peer_addr(), sender->peer_port());                 

			announce_dcc_event(DCC_PIPE_ESTABLISHED, buffer);

			set_status(DCC_CONNECTED);
			sender->set_events(io::EVENT_READ | io::EVENT_WRITE);
			return 1;
		}
		else if (event == SOCK_CLOSED) {
			if (status() == DCC_CONNECTING) {
				// Failed connection
				die(DCC_PIPE_FAILED, net::strerror(extra));
			}
			else {
				die(DCC_PIPE_CLOSED, net::strerror(extra));
			}
			return 0;                
		}
		else if (event == SOCK_READABLE) {
			int i = 0;
			/**
			 * Transfer to the output queue of the other end.
			 */
			if (r == SENDER) {
				i = sender->flush(receiver);
			}
			else {
				i = receiver->flush(sender);
			}

			if (i < 0) {
				return die(DCC_PIPE_FAILED, net::strerror(i));
			}
		}
		else if (event == SOCK_WRITEABLE) {
			int i = 0;
			/* flush what we can down the pipe */
			if (r == SENDER) {
				i = sender->flushO();
			}
			else {
				i = receiver->flushO();
			}

			if (i < 0) {
				return die(DCC_PIPE_FAILED, net::strerror(i));
			}
		}

		/* Now, balance the buffers */
		const size_t snd_queued = sender->obuff_size();
		const size_t rcv_queued = receiver->obuff_size();

		const size_t snd_in_available = sender->buffer_available();
		const size_t rcv_in_available = receiver->buffer_available();

		int snd_flags = 0, rcv_flags = 0;
		if (snd_queued) {
			snd_flags |= io::EVENT_WRITE;
		}
		if (rcv_queued) {
			rcv_flags |= io::EVENT_WRITE;
		}
		if (snd_in_available) {
			snd_flags |= io::EVENT_READ;
		}
		if (rcv_in_available) {
			rcv_flags |= io::EVENT_READ;
		}

		DEBUG("Sender queue: %lu Receiver: %lu Events: S: %d R: %d\n", snd_queued, rcv_queued,
				snd_flags, rcv_flags);		
		assert(snd_flags || rcv_flags);
		sender->set_events(snd_flags);
		receiver->set_events(rcv_flags);
	}
	return 1;
}

/**
  * NOTE: if constructor throws exception, offer and entry are
  * 	  untouched (i.e. offer is still valid, and entry is still
  *	  open for access)
  *
  *	  Otherwise the object assumes ownership of the resource and frees
  *	  it (and closes the writer it opened) upon destruction.
  */
dccget::dccget(conn * owner, file_entry * entry, dcc_offer * offer) 
	: dcc(owner),
		sender(NULL),
		file(entry),
		writer(NULL)
{
	assert(offer != NULL);
	assert(offer->from());

	if (offer->offset() > offer->size()) {
		throw std::out_of_range("starting offset must be less than file size");
	}
	if (offer->port() == 0) {
		throw std::invalid_argument("invalid TCP port");
	}

	/** 
	 * Ready to connect.
	 */
	sender = new dcc_socket(this, SENDER);
	int r = sender->async_connect(offer->address(), "", offer->port());
	if (r < 0) {
		// failed
		sender->close();
		delete sender;
		throw dcc_exception(net::strerror(r));
	}

	/** 
	 * Create file...
	 */
	try {
		writer = file->open_writer(ios::binary | ios::out | ios::app | ios::ate);
		writer->complete();
		std::ostream& stream = writer->get_raw_stream();

		stream.seekp(offer->offset(), ios_base::beg);
		if (stream.fail()) {
			file->close(writer);
			throw dcc_exception("unable to seek file pointer to requested position");
		}
	}
	catch (...) {
		sender->close();
		delete sender;
		throw;
	}

	/**
	 * Steal the offer's ID.
	 */
	swap_dcc_ids(this, offer);

	received = offer->offset();
	expected = offer->size();
	set_status(DCC_CONNECTING);
}

dccget::~dccget()
{
	DEBUG("dccget::~dccget() [%p]\r\n", this);
	delete sender;
}

int dccget::socket_event(int r, int events, int extra)
{
	assert(r == SENDER);

	if (events == SOCK_CONNECTED)  {
		/** ready to receive data **/
		assert(status() != DCC_CONNECTED);
		set_status(DCC_CONNECTED);
		announce_dcc_event(DCC_GET_ESTABLISHED, "");
		sender->set_events(io::EVENT_READ);
	}
	else if (events == SOCK_WRITEABLE) {
		/* send the ack packet */
		assert(status() == DCC_CONNECTED);
		unsigned int bytes = htonl(received);
		sender->write(&bytes, sizeof(unsigned int));

		if (received >= expected)  {
			/* done */
			set_status(DCC_FINISHED);
			set_last_event(ircproxy::instance()->time());
			return die(DCC_GET_COMPLETE, "");
		}
		sender->set_events(io::EVENT_READ);
	}
	else if (events == SOCK_READABLE) {
		/* save the data, check for quota exceeded, etc. */
		assert(status() == DCC_CONNECTED);
		std::ostream& stream = writer->get_stream();
		int written = sender->flush(stream, sender->ibuff_size());
		if (written < 0) {
			return die(DCC_GET_FAILED, net::strerror(written));
		}

		received += written;
		sender->set_events(io::EVENT_READ | io::EVENT_WRITE);
		set_last_event(ircproxy::instance()->time());
	}
	else if (events == SOCK_CLOSED) {      
		if (status() == DCC_FINISHED) {
			return die(DCC_GET_COMPLETE, "");
		}
		return die(DCC_GET_FAILED, net::strerror(extra));
	}
	return 1;
}

int  dccget::die(int e, const void *str)
{
	/* close *our* socket */
	delete sender;

	if (file != NULL) {
		if (writer != NULL) {
			file->close(writer);
			writer = NULL;
		}
		ircproxy::instance()->vfs()->close(file);
	}
	
	sender = NULL;
	file = NULL;
	return dcc::die(e, str);
}

/** 
  * idle when:  
  *		status == DCC_CLOSED (signifying death)
  *             or, nothing has happpened for 1 minute
  */
int dccget::status_check(time_t now, const void **) const
{
	if ((status() == DCC_CONNECTED) && (now - last_event()) >= 60) {
		return DCC_TIMED_OUT;
	}
	if (status() == DCC_CLOSED) {
		return -1;
	}
	return 0;
}

string dccget::info() const
{
	const char * what = strstat(status());
	if (file) {
		return my_sprintf("GET (%s) %s (%ul/%ul received)", what, 
				file->name(), received, expected);
	}
	return my_sprintf("GET (%s) (progress unknown)", what);
}

/**
 * Displayed detailed, multi-line information about this DCC Get.
 */
string dccget::full_info() const
{
	std::ostringstream out;
	out << dcc::full_info();
	if (file != NULL) {
		out << "- File: " << file->name() << "\r\n";
		out << "- Received: " << received << "/" << expected << " bytes ";
		out << "(" << (float) received / expected * 100 << "%)" << "\r\n";
		out << "- Storing in: " << file->dir()->rel_path() << "\r\n";
	}
	if (sender != NULL) {
		out << "- From: " << sender->peer_addr() << " port " << sender->peer_port() << "\r\n";
	}
	return out.str();
}

const char * dccget::type() const 
{
	return "Get";
}

