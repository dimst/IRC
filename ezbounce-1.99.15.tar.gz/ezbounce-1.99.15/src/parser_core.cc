/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * parser_core.cc
 * (c) 2006-2008 Murat Deligonul
 * ----   
 * 7/06 -- Parser core factored out
 * 5/06 -- Resumed work after 8 months
 * 9/05 -- Simplified even further 
 * 8/05 -- Config file parser rewritten.
 * 	    Significantly simpler and more robust.
 *	    Also handles string literals properly.
 */

#include "autoconf.h"

#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cstdarg>
#include <cerrno>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "util/modifying_tokenizer.h"
#include "util/hash.h"
#include "parser_core.h"
#include "debug.h"

using std::list;
using std::vector;
using std::string;
using namespace util::strings;

const int parser_core::CTX_GLOBAL = 0x0001;
const int parser_core::CTX_ARG 	  = 0x0002;
const int parser_core::CTX_ANY 	  = 0xFFFF;

/** IDs for symbols **/
const char parser_core::DELIMETERS[] = " \t\r\n";
const char parser_core::COMMENT[] = "#";

/** These are argument types for the 'set' commands **/
const int parser_core::BOOL_ARG[] = { ARG_TYPE_BOOL  | ARG_TYPE_NUMBER };
const int parser_core::STRING_ARG[] = { ARG_TYPE_STRING | ARG_TYPE_OTHER };
const int parser_core::NUMBER_ARG[] = { ARG_TYPE_NUMBER };

/**
 *  Special symbols THAT DO NOT GET HASHED:
 *
 * SYM_NUMBER:		numbers (e.g. 0, 1, 5, 20)
 * SYM_COMMENT:		the character # or any token starting with #
 * SYM_STRING_LITERAL:	a string enclosed in quotes that is now treated as single symbol.
 * SYM_BOOLEAN:		true or false, not enclosed in quotes.
 * SYM_NEWLINE:		new line character.
 * SYM_UNKNOWN:		any symbol not recognized by the parser (but not necessarily illegal);
 *				not a number, not a boolean, and not a string literal.
 */
const struct parser_core::config_symbol parser_core::special_sym[] = {
	{ NULL,	 		 SYM_UNKNOWN,		CTX_ANY,	ARG_TYPE_OTHER},
	{ NULL,			 SYM_NUMBER,		CTX_ANY,	ARG_TYPE_NUMBER},
	{ COMMENT,		 SYM_COMMENT,		CTX_ANY},
	{ NULL,			 SYM_STRING_LITERAL,	CTX_ANY,	ARG_TYPE_STRING},
	{ NULL,			 SYM_NEWLINE,		CTX_ANY},
	{ NULL,			 SYM_BOOLEAN,		CTX_ANY,	ARG_TYPE_BOOL}
};

parser_core::~parser_core()
{
	DEBUG("parser_core::~parser_core() [%p]\n", this);
	delete[] filename;
}

int parser_core::parse()
{
	/** Open & load into buffer **/
	int fd = open(filename, O_RDONLY);
	struct stat st;
	if (fd < 0) {
		fprintf(stderr, "Unable to open file '%s': %s\n", filename, strerror(errno));
		return -1;
	}
	memset(&st, 0, sizeof(struct stat));
	fstat(fd, &st);

	// XXX: use a scoped array pointer or something else; this is ugly
	char * buffer = new char[st.st_size + 1];
	int bytes = read(fd, buffer, st.st_size);
	close(fd);
	
	if (bytes < 0) {
		delete[] buffer;
		fprintf(stderr, "Unable to read file '%s': %s\n", filename, strerror(errno));
		return -1;
	}	
	assert(bytes == st.st_size);
	buffer[bytes] = 0;

	/* File loaded into memory; tokenize. */
	int i = tokenize(buffer);
       	if (i < 0) {
		delete[] buffer;
		fprintf(stderr, "Error tokenizing\n");
		return -1;
	}

	if (tokens.size() == 1) {
		delete[] buffer;
		fprintf(stderr, "Error: no configuration data found in '%s'!\n", filename);		
		return -1;
	}
	
#ifdef __DEBUG__
	dump_lines();
#endif

	/** 
	 * Process file: the first token is always a 'new line' 
	 * which tells us the line number of the tokens following it 
	 * (until the next newline token) 
	 */
	token_iterator = tokens.begin();
	current_line = (*token_iterator).other_value;
	context ctx = { CTX_GLOBAL, 0 };
	context_stack.push(ctx);
	
	i = process_tokens();
	if (i < 0) {
		delete[] buffer;
		fprintf(stderr, "Error(s) parsing\n");
		return -1;
	}
	i = validate_config();
	if (i < 0) {
		delete[] buffer;
		fprintf(stderr, "Failed to validate configuration\n");
		return -1;
	}
	delete[] buffer;
	return 0;
}

int parser_core::error(const char * format, ...) const
{
	va_list ap;
	int len = fprintf(stderr, "%s: %d: error: ", filename, current_line);
	va_start(ap, format);
	len += vfprintf(stderr, format, ap);
	va_end(ap);
	return len;
}

int parser_core::warning(const char * format, ...) const
{
	va_list ap;
	int len = fprintf(stderr, "%s: %d: warning: ", filename, current_line);
	va_start(ap, format);
	len += vfprintf(stderr, format, ap);
	va_end(ap);
	return len;	
}

/**
  * Return string representation of the context we are in.
  * Should only be 'global' or 'argument'
  */ 
const char * parser_core::str_context(int ctx) const
{
	if (ctx == CTX_GLOBAL) {
		return "global";
	}
	else if (ctx == CTX_ARG) {
		return "argument";
	}
	return "unknown";
}

/**
  * Return string representation of the symbol argument type.
  */
const char * parser_core::str_argtype(int arg) const 
{
	switch (arg) {
	case CREATE_CONTEXT:
		return "context creator";
	case EXIT_CONTEXT: 
		return "context exiter";
	case COMMAND:
		return "command";
	case ARG_TYPE_STRING:
		return "string";
	case ARG_TYPE_NUMBER:
		return "number";
	case ARG_TYPE_BLOCK:
		return "'{ }' block";
	case ARG_TYPE_BOOL:
		return "boolean";
	case ARG_TYPE_OTHER:
		return "other";	
	}
	return NULL;
}

/**
  * Given a set of boolean flags, return a string containing
  * all of their names (separated by OR's).
  */
std::string parser_core::str_argtypes(int args) const
{
	std::string out;

	for (int flag = 1, ctr = 0; 
	 	unsigned(ctr) < sizeof(int) * 8; 
		++ctr, flag <<= 1) {

		if (!(args & flag)) {
			/* nothing matched; this is ok */
			continue;
		}
		
		if (!out.empty()) {
			out += " OR ";
		}
		
		const char * text = str_argtype(flag);
		if (text == 0) {			
			char dummy[25];
			sprintf(dummy, "'0x%x'", flag);
			out += dummy;			
		} 
		else {
			out += text;
		}
	}
	return out;		
}

/**
 * Crude way of checking if a token is possibly an IP address.
 */
/* static */ bool parser_core::is_possible_ip(const char * tok)
{
	int num_dots = 0;
	int num_colons = 0;
	for (const char * p = tok; *p != 0; ++p) {
		char c = *p;
		if (c < '0' && c > '9' 
			&& c != '.' && c != ':') {
			return false;
		}

		if (c == '.') {
			++num_dots;
		}
		if (c == ':') {
			++num_colons;
		}
	}
	return (num_dots == 3) || (num_colons > 3);
}

#ifdef __DEBUG__
void parser_core::dump_lines() const
{	
	using std::list;
	list<config_token>::const_iterator i = tokens.begin();

	while (i != tokens.end()) {
		const config_token &token = *i;
		if (token.symbol->id == SYM_NEWLINE) {
			printf("\n%d: ",  token.other_value);
		}
		else {
			printf("%s [%d] ", token.token, token.symbol->id);
		}
		++i;
	}
	printf("\n");
}
#endif

const parser_core::config_symbol * parser_core::lookup_symbol(const char * tok) const
{
	const config_symbol * c;
	const hash_table_t * chash = symbol_table();	
	hash_table_t::const_iterator i = chash->find(tok);

	if (i != chash->end()) {
		c = (*i).second;
	}
	else {
		/* check if it's a number */
		int a = atoi(tok);
		if (!is_possible_ip(tok) && (a != 0 || tok[0] == '0')) {
			/* number */
			c = &special_sym[1];		
		} 
		else if (tok[0] == COMMENT[0]) {  
			/* comment */
	                c = &special_sym[2];
		} 
		else if (!strcasecmp(tok, "true") || !strcasecmp(tok, "false")) {
		 	/* boolean type */
			c = &special_sym[5];
		} 
		else {
			/* not a number, boolean or comment */
			c = &special_sym[0];			
		}
	}
	return c;
}

int parser_core::tokenize(char * buffer)
{
	int state = 0;		/* determines whether in comment or not */
	char * token = NULL;
	
	static const config_token NEWLINE = {&special_sym[4], "\n", 1};	
	util::strings::modifying_tokenizer tokenizer(buffer, DELIMETERS, 
						modifying_tokenizer::DONT_RESTORE | modifying_tokenizer::COUNT_DELIMS);

	tokens.push_back(NEWLINE);
	current_line = 1;
	
	while ((token = tokenizer.next()) != 0) {
		const config_token& last = tokens.back();
		
		/* did we reach a new line ? */
		int numN = tokenizer.get_count('\n');
		if (numN + 1 > current_line) {
			if (last.symbol->id != SYM_NEWLINE) {
				tokens.push_back(NEWLINE);
			}		
				
			current_line = numN + 1;
			tokens.back().other_value = numN + 1;
			state = 0;
		} 

		if (state == 1)
			continue;

		config_token ct;
		ct.token  = token;
		ct.symbol = lookup_symbol(token);
		ct.other_value = 0;
		if (ct.symbol->id == SYM_COMMENT) {
			state = 1;
			continue;
		} 
		else if (ct.symbol->id != SYM_UNKNOWN) {
			if (ct.symbol->id == SYM_NUMBER) {
				ct.other_value = atoi(ct.token);
			} 
			else if (ct.symbol->id == SYM_BOOLEAN) {
				ct.other_value = !(strcasecmp(ct.token, "true"));
			} 
			tokens.push_back(ct);		
			continue;
		}
		
		/* unknown symbol: parse character by character */
		char *p, *src = token;
		int offset = 0;
		
		tokenizer.set_options(tokenizer.COUNT_DELIMS);
		state = 2;

		while ((p = token++)) {
			if (state == 2) {
				if (*p == 0)
					break;
				else if (*p == '"' && p == src) 
					state = 3;
				else if (*p == '"') {
					error("Unexpected '\"' character in middle of token '%s'\n", src);
					return -1;
				}	
				continue;				
			}
			/* handle string literals */
			if (tokenizer.get_count('\n') + 1 > current_line) {
				error("Unterminated string literal on this line\n");
				return -1;
			}
			if (*p == '\\') {
				if (*(p+1) == 0 || !strchr("\"\\", *(p+1))) {
					error("Illegal escape sequence '\\%c' in token '%s'\n", *(p+1), token-1);
					return -1;
				}
				*(p-offset) = *(p+1);
				++offset;
				++token;						
			} 
			else if (*p == 0) {
				/* end of this token, grab next one to
				 * continue string literal */
				token = tokenizer.next();
				if (token == 0) {
					error("Unexpected EOF\n");
					return -1;
				}
				memmove(p-offset,p, token - p);
				p = token;
			} 
			else if (*p == '"') {
				/* terminating quote. check legality */
				if (*(p+1) != 0) {
					error("Garbage after terminating quote in token '%s'\n", token);
					return -1;
				}	
				*(p-offset) = 0;
				ct.token = src+1;
				ct.symbol = &special_sym[3];	
				break;
			} 
			else {
				*(p-offset) = *p;			
			}
		} 
		state = 0;
		tokenizer.set_options(tokenizer.COUNT_DELIMS | tokenizer.DONT_RESTORE);
		tokens.push_back(ct);
	}
	// Might want to instead check that the last symbol IS a new line 
	if (tokens.back().symbol->id != SYM_NEWLINE) {
		tokens.push_back(NEWLINE);
		tokens.back().other_value = current_line + 1;
	}
	return 0;	
}

int parser_core::process_tokens()
{
	vector<config_token> pre_args;
	vector<config_token> args;
	const config_symbol * hot_sym = 0;
	context &ctx = context_stack.top();
	
	int state = 0;
	
	while (more_tokens()) {
		const config_token &token = next_token();
		const config_symbol * sym = token.symbol;
//		DEBUG("Now processing: %s\n", token.token);				
		switch (state) {
		case 0:	
			/* default context */
			if (!(sym->good_ctx & ctx.state)) {
				error("Symbol '%s' not allowed in this context\n", token.token);
				return -1;
			}
			if (sym->id == SYM_NEWLINE) {
				assert(args.empty());
				assert(!hot_sym);
				args.clear();
				hot_sym = 0;
				current_line = token.other_value;
//				DEBUG("Entering line %d\n", current_line);
			} 
			else if (sym->flags & EXIT_CONTEXT) {
				if (pre_args.size() > 0 
				    && resolve_trailing_args(pre_args) < 0) {
					return -1;			
				}					
				return 0;
			} 
			else if ((sym->flags & COMMAND) || (sym->flags & CREATE_CONTEXT)) {
				DEBUG("parser_core::process_tokens(): Entering state 1 for command/ctx symbol '%s'\n", sym->symbol);	
				hot_sym = sym;
				state = 1;				
			} 
			else {
				/* potential pre-command modifier */
				pre_args.push_back(token);
			}
			break;
		case 1:		
			/* getting arguments for command */
			if (!(sym->good_ctx & CTX_ARG)) {
				error("Symbol '%s' not allowed in this context\n", token.token);
				error(" [Was looking for a proper argument to '%s']\n", hot_sym->symbol);
				return -1;
			}
				
			if (sym->id == SYM_NEWLINE) {			
				if ((hot_sym->arguments > 0) && args.size() < (unsigned) hot_sym->arguments) {
					/* check if arguments HAVE to be on this line */
					if (!(hot_sym->flags & ARGS_SAME_LINE))
						break;		
					error("not enough arguments for command: '%s'\n", hot_sym->symbol);
					return -1;
				} 
				
				// execute it
				if (hot_sym->flags & COMMAND) {
					if (do_command(hot_sym, pre_args, args) < 0) {
						error("error parsing command\n");
						return -1;
					}
					current_line = token.other_value;		
				}
				else {
					/** context-creating symbol **/
					context new_ctx = { 0, NULL };
					if (enter_context(hot_sym, new_ctx, pre_args, args) < 0) {
						error("couldn't enter context [%s]\n", str_context(new_ctx.state));
						return -1;	
					}
					DEBUG("parser_core::process_tokens(): Entered context %d\n", new_ctx.state);
					context_stack.push(new_ctx);
					current_line = token.other_value;
					if (process_tokens() < 0) {
						error("context [%s] parse failed\n", str_context(new_ctx.state));
						leave_context(new_ctx, false);
						return -1;
					}
					context_stack.pop();					
					if (leave_context(new_ctx, true) < 0) {
						error("context [%s] validation failed\n", str_context(new_ctx.state));
						return -1;
					}
					DEBUG("parser_core::process_tokens(): Succesfully left context %d\n", new_ctx.state);
				}
				pre_args.clear();
				args.clear();
				hot_sym = 0;
				state = 0;
				break;				
			} 
			/* not a new line */
			int i = args.size();
			if (hot_sym->arguments > 0) {
			        if (i + 1 > hot_sym->arguments) {
					error("Too many arguments [needed %d, got %d]\n", hot_sym->arguments, i+1);
					return -1;
				} else if (!(hot_sym->arg_types[i] & sym->flags)) {
					error("Illegal argument type for statement '%s'\n", hot_sym->symbol);
					error("  Needed: (%s);\n", str_argtypes(hot_sym->arg_types[i]).c_str());
					error("     Got: (%s)\n", str_argtypes(sym->flags).c_str());
					return -1;
				}
			}
			args.push_back(token);
		}
	}
	/**
	 * We ran out of tokens.. better be at the global level.
	 */
	if (ctx.state != CTX_GLOBAL) {
		error("Unexpected end of file\n");
		return -1;
	} 
	else if (!pre_args.empty()) {
		error("Unknown trailing tokens at end of file\n");
		error("   starting with: '%s'\n", pre_args[0].token);
		return -1;
	}
	
	return 0;
}

