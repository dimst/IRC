/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ruleset.cc
 * (C) 1998-2005 Murat Deligonul
 */

#include "autoconf.h"

#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cctype>
#include <unistd.h>
#include "util/tokenizer.h"
#include "ruleset.h"
#include "debug.h"

using namespace util::strings;

const int  ruleset::UNLIMITED = -1;

/* 
 *  Checks if port is in set 'set'. 
 */
bool ruleset::port_in_set(const char * set, unsigned short port)
{
	if (!set) {
		return false;
	}
	if (strcasecmp(set, "all") == 0) {
		return true;
	}
	/* 
	 * Find tokens seperated by commas.
	 * Will also get the first and only one if there are no commas.
	 */
	using std::vector;
	using std::string;
	vector<string> tokens;
	tokenize(set, ",", tokens);

	for (vector<string>::const_iterator i = tokens.begin(), e = tokens.end();
			i != e; ++i) {
		const string& tok = *i;
		// look for range 
		string values[2];
		tokenize(tok.c_str(), "-", &values[0], 2);

		if (!values[1].empty()) {
			unsigned int min, max;
			/* we are kind enough to trim down min/max if they 
			   are too big */
			min = (unsigned) atoi(tokens[0].c_str()); 
			max = (unsigned) atoi(tokens[1].c_str());
			min = (min > 65536) ? 65536 : min;
			max = (max > 65536) ? 65536 : max;

			if (port >= (unsigned short) min && port <= (unsigned short) max) {
				return true;
			}
		}
		else {
			if (port == (unsigned short) atoi(tok.c_str())) {
				return true;
			}
		}
	}
	return false;
}

/**
 * Tries to determine if a wildcard pattern is meant for matching an IP address
 * or a full hostname.
 */
bool ruleset::is_ip_pattern(const char *address)
{
	bool legal = false;
	
	int num_colons = 0;
	int num_letters = 0;
	int num_wild = 0;
	
	do {
		if (*address >= '0' && *address <= '9') {
			legal = true;
		}	
		else if (toupper(*address) >= 'A' && toupper(*address) <= 'F') {
			++num_letters;
			legal = true;
		}	
		else if (*address == '?' || *address == '*') {
			++num_wild;			
		}
		else if (*address == ':') {
			++num_colons;
		} 
 		else if (*address == '.') {
			continue;
		}
		else {
			return 0;
		}
	} while (*++address);
	
	if (num_letters && !num_colons) {
		legal = false;
	}
	else if (num_wild && !num_letters) {
		legal = true;
	}
	
	return legal; 
}

/**
 * mar 05: updated to not perform dns lookups anymore.
 * 	   change return value to 0 on match
 */
/* static */ int ruleset::smart_match(const char * host, const char * ip, const char *pattern)
{
	bool have_host = (host && *host);
	bool is_pattern_ip = is_ip_pattern(pattern);
	
	/* pattern is of an IP address */
	if (is_pattern_ip)
		return wild_match(pattern, ip);	
	/* pattern was not an IP address and we have host */
	else if (!is_pattern_ip && have_host)
		return wild_match(pattern, host);
	return 1;
}

ruleset::~ruleset()
{
	DEBUG("ruleset::~ruleset(): %p\n", this);
}

/**
 *   Code for allowed_ruleset class:
 *   a config file block can be :
 *  allow {
 *     [num] from (address) [ports] : Num is optional.
 *                                     Max # of clients
 *                                     allowed to connect from that address.
 *                                     Defaults to -1, which means unlimited.
 *                              address:
 *                                    Address to permit clients from
 *                              ports: 
 *                                    What ports should it allow/deny to:
 *                                    "all"
 *                                    "6667"
 *                                    "6660-7000"
 *                                    "7000,4000,40355,29421,500-2403,6660-6666"
 *           
 *     [num] to (address) [ports]  : blah blah
 *   }
 *   There must be at least one `from' and one 'to' entry.
 *   `Reason' arguments to below functions are ignored.
 *              
 */
bool allowed_ruleset::does_match(const char * from, const char * ip, 
					unsigned short port, host_type t) const
{
	const std::vector<rs_host> & l = ((t == FROM) ? from_hosts : to_hosts);
	return std::find(l.begin(), l.end(), rsh_comp_helper(from, ip, port)) != l.end();
}

/**
 *  Checks if this host is allowed entry by this rule list.
 *  return values:  
 *    1 - User is allowed
 *    0 - No matching hosts found
 *   -1 - User is banned - 'buff' is filled w/ the reason.. 
 *        for the case of the allowed_ruleset class, it will only be returned
 *        in case user limit for rule set was exceeded
 *                    
 *  buff = buffer to hold reason for banning, if any.
 *  
 */
int allowed_ruleset::is_allowed(const char * address, const char * ip, unsigned short port,
                                 char *buff, size_t bufflen) const
{
	std::vector<rs_host>::const_iterator i, 
			beg = from_hosts.begin(),
			end = from_hosts.end();
    	rsh_comp_helper h(address, ip, port);
	i = beg;
	
	while (i != end) {
		i = std::find(i, end, h);
		if (i != end) {
			const rs_host& r = *i;
			if (r.num >= r.max && r.max != UNLIMITED) {
				my_strlcpy(buff, "No more connections allowed from your host", bufflen);
				return -1;
			} 
			else if (r.num < r.max || r.max == UNLIMITED) {
				return 1;
			}
		}
	}
	return 0;
}

/** 
 * Like above but checks if it 'from' may connect to 'to' on port.
 * Even though there is a 'from' argument, we assume that the caller 
 * belongs to this rule set (for now)..
 */
int allowed_ruleset::is_allowed_to(const char * to, const char * to_ip,
					unsigned short port, 
					char *buff, size_t bufflen) const
{
	std::vector<rs_host>::const_iterator i, 
			beg = to_hosts.begin(),
			end = to_hosts.end();
	rsh_comp_helper h(to, to_ip, port);
	i = beg;

	while (i != end) {
		i = std::find(i, end, h);
		if (i != end) {
			const rs_host& r = *i;
			if (r.num >= r.max && r.max != UNLIMITED) {
				my_strlcpy(buff, "No more connections allowed to destination from your host", bufflen);
				return -1;
			} 
			else if (r.num < r.max || r.max == UNLIMITED) {
				return 1;
			}
		}
	}
	return 0;
}   

/** 
 *  Return values by register_connection and friends:
 *  0 - success
 * -1 - full ?
 */
int allowed_ruleset::register_connection(host_type t, const char * host, const char *ip,
                                          unsigned short port)
{
	std::vector<rs_host>& target = (t == FROM) ? from_hosts : to_hosts;
	std::vector<rs_host>::iterator i, 
			beg = target.begin(),
			end = target.end();
	rsh_comp_helper h(host, ip, port);
	i = beg;

	while (true) {
		i = std::find(i, end, h);
		if (i == end) {
			break;
		}
		
		rs_host& r = *i;		
		if (r.num >= r.max && r.max != UNLIMITED) {				
			/** check again if limit exceeded **/
			return -1;
		} 
		else {
			++r.num;
	                return ruleset::register_connection(t, host, ip, port);
		}
	}
	return 0;
}

int allowed_ruleset::unregister_connection(host_type t, const char * host, const char * ip, 
						unsigned short port)
{
	std::vector<rs_host>& target = (t == FROM) ? from_hosts : to_hosts;
	std::vector<rs_host>::iterator i, 
				beg = target.begin(),
				end = target.end();
	rsh_comp_helper h(host, ip, port);
	i = beg;

	while (true) {
		i = std::find(i, end, h);
		if (i == end) {
			break;
		}
		
		rs_host& r = *i;		
		--r.num;		
		return ruleset::unregister_connection(t, host, ip, port);
	}
	return 0;
}

bool allowed_ruleset::is_legal() const 
{
	return (from_hosts.size() > 0 && to_hosts.size() > 0);
}

/*
 *  denied_ruleset -- syntax is basically same but:
 *
 *     * A from w/o a to or vice versa is permitted
 *     * In a rule set w/ no from entries is_allowed will always
 *        return 1. is_allowed_to will check as usual. does_match() will
 *        also always return 1 in such case.
 *     * max # nubmers are ignored here
 *     * If a rule set has both from and tos, the tos are only
 *        applied to the from addresses. The addresses in the form fields
 *        will be granted passage
 */

/** 
 *  NOTE: in the case that there are no entries of type 't',
 *        1 will be returned.
 */
bool denied_ruleset::does_match(const char * host, const char * ip, 
				unsigned short port, host_type t) const
{
	const std::vector<rs_host> * l = ((t == FROM) ? &from_hosts : &to_hosts);
	if (l->empty()) {
		return true;
	}
	return std::find(l->begin(), l->end(), rsh_comp_helper(host, ip, port)) != l->end();
}

/**
 *  Returns:
 *    -1 - if banned
 *     0 - not found in list (not banned)
 */
int denied_ruleset::is_allowed(const char * host, const char * ip, unsigned short port,
                                char *buff, size_t bufflen) const 
{
	std::vector<rs_host>::const_iterator i, 
			beg = from_hosts.begin(),
			end = from_hosts.end();
    	rsh_comp_helper h(host, ip, port);
	i = beg;
	
	while (i != end) {
		i = std::find(i, end, h);
		if (i != end) {
			my_strlcpy(buff, (*i).reason , bufflen);
			return -1;
		}
	}
	return 0;
}

/**
 *  return:
 *     -1: not allowed to connect
 *      0: not in list, does not necesssarily mean he may connect there tho
 */
int denied_ruleset::is_allowed_to(const char * to, const char * to_ip, unsigned short port,
                                   char *buff, size_t bufflen) const
{
	std::vector<rs_host>::const_iterator i, 
			beg = to_hosts.begin(),
			end = to_hosts.end();
    	rsh_comp_helper h(to, to_ip, port);
	i = beg;
	
	while (i != end)
	{
		i = std::find(i, end, h);
		if (i != end) {
			my_strlcpy(buff, (*i).reason , bufflen);
			return -1;
		}
	}
	return 0;
}

bool denied_ruleset::is_legal() const 
{
	return (!to_hosts.empty() || !from_hosts.empty());
}

/**
 * Compare two rulesets
 * Ignores num_registered_xxx and obsolete and rs_host.num
 * Note! - Since this operates on the ruleset base class, there
 *     is no way of knowing for sure if the *type* of the object we are being compared
 *     to is the same type as us. (Actually each rs_host of an Allowed_ruleset has
 *     reason set to NULL, and each denined_ruleset should have it set to something
 *     other than that, because the parsing code will give 'No reason was given!'..)
 *
 */
bool ruleset::operator == (const ruleset& r2) const
{

	if (! (from_hosts.size() == r2.from_hosts.size()) ||
		! (to_hosts.size() == r2.to_hosts.size())) {
		return false;
	}
	using std::vector;
	
	const vector<rs_host> *vec1, *vec2;

	vec1 = &from_hosts;
	vec2 = &r2.from_hosts;
	for (int j = 0; j < 2; ++j) {
		vector<const rs_host *> seen;
		for (vector<rs_host>::const_iterator i = vec1->begin(), e = vec1->end(); i != e; ++i) {
			vector<rs_host>::const_iterator ptr = vec2->begin();

			while (ptr != vec2->end()) {	
				vector<rs_host>::const_iterator match = std::find(ptr, vec2->end(), *i);
				if (match == vec2->end()) {
					return false;
				}

				vector<const rs_host *>::const_iterator 
					pos_seen = std::find(seen.begin(), seen.end(), &(*match));
				if (pos_seen != seen.end()) {
					++ptr;
					continue;
				}
				seen.push_back(&(*match));
				break;
			}

		}

		// repeat for 'to' hosts
		vec1 = &to_hosts;
		vec2 = &r2.to_hosts;
	}

	return true;
}

ruleset::rs_host::~rs_host()
{
	delete[] reason;
	delete[] pattern;
	delete[] ports;
	DEBUG("\trs_host::~rs_host(): [%p] destructed\n", this);
}

ruleset::rs_host::rs_host(host_type _type, const char *_addr,
                           const char *_ports , const char *_reason, int _max) :
			   	pattern(my_strdup(_addr)), 
				ports(my_strdup(_ports)), 
			   	reason(my_strdup(_reason)),
			   	type(_type), max(_max), 
				num(0)
{
	DEBUG("\trs_host::rs_host(): [%p] created -- type %d, addr: %s, ports: %s, max: %d reason: %s\n",
				this, type, pattern, 
				ports, max, reason);
}

ruleset::rs_host::rs_host(const ruleset::rs_host &that)
{
	DEBUG("rs_host::[copy constructor] invoked for [%p]\n", this);
	pattern = my_strdup(that.pattern);
	ports = my_strdup(that.ports);
	reason = my_strdup(that.reason);
	type = that.type;
	max = that.max;
	num = that.num;
}


int ruleset::register_connection(host_type t, const char *, const char *, unsigned short)
{
	DEBUG("Increasing %s usage count of %p to %d\n", ((t == FROM) ? "FROM" : "TO"), this, (t == FROM ? num_registered_from + 1 : num_registered_to + 1));
	return (t == FROM) ? ++num_registered_from : ++num_registered_to;
}

int ruleset::unregister_connection(host_type t, const char *, const char *, unsigned short)
{
	DEBUG("Decreasing %s usage count of %p to %d\n", ((t == FROM) ? "FROM" : "TO"), this,(t == FROM ? num_registered_from - 1 : num_registered_to - 1));
	return (t == FROM) ? --num_registered_from : --num_registered_to;
}

int ruleset::add_host_to(const char *address_to, const char *ports,
                                   const char * reason, int max_num)
{
	to_hosts.push_back(rs_host(TO, address_to, ports, reason, max_num));
	return to_hosts.size();
}

int ruleset::add_host_from(const char *address_from, const char *ports,
                                     const char * reason, int max_num)
{
	from_hosts.push_back(rs_host(FROM, address_from, ports, reason, max_num));
	return from_hosts.size();
}


/** 
 * Used during rehash.
 * if a new ruleset:
 *      doesn't exist in the old set, move it over to new list
 *      exists in the old list re-add the old one
 * if an old ruleset:
 *      doesn't exist in the new set:
 *              if it's being used: mark as obsolete, add
 *              if it's not being used: destroy it
 *  post conditions:
 *      newlist -> will be empty; all contents either destroyed
 *                  or moved to list3
 *      oldlist -> empty
 *      list3   -> ready for use
 **/
std::vector<ruleset *> * ruleset::sync_lists(std::vector<ruleset *> * oldlist, std::vector<ruleset *> * newlist)
{
	DEBUG("ruleset::sync_lists(): entering\n");
	using std::vector;
	vector<ruleset *> * out = new vector<ruleset *>();

	for (vector<ruleset *>::iterator i = oldlist->begin();
		i != oldlist->end();
		i = oldlist->erase(i)) {

		ruleset * r = *i;
		
		for (vector<ruleset *>::iterator i2 = newlist->begin();
				i2 != newlist->end();
				++i2) {
			ruleset * r2 = *i2;
			if (*r == *r2) {
				/* Old ruleset exists in new list.
				 * Delete new one, transfer old on to out list. */
                		DEBUG("         RULESET: Found match for %p == %p, keeping\n", r, r2);
				delete r2;
				newlist->erase(i2);
				out->push_back(r);
				goto next;
			}
		}
		
		/* Ruleset no longer exists in the configuration */
		if (r->num_registered_from == 0 && r->num_registered_to == 0) {
			DEBUG("		RULESET: deleting non-matching: %p\n", r);
			delete r;
			continue;
		}

		/* Final case: no longer exists, but we have 
		 * users registered it */
		DEBUG("		RULESET: keeping ruleset as obsolete: %p\n", r);
		r->obsolete = true;
		out->push_back(r);
		next:;
	}
	
	DEBUG("		RULESET: %zd more new rulesets to add\n", newlist->size());	
	std::copy(newlist->begin(), newlist->end(), std::back_inserter(*out));
	
	newlist->clear();

	assert(newlist->empty());
	assert(oldlist->empty());	
	return out;
}
