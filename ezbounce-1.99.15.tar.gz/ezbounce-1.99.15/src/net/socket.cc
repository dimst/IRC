/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 * net/socket.cc
 * (C) 2000-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include "util/strings.h"
#include "util/tokenizer.h"
#include "io/error.h"
#include "net/error.h"
#include "net/socket.h"
#include "net/resolver.h"
#include "net/radaptor.h"
#include "debug.h"

namespace net {

using namespace util::strings; 

/* static */ io::engine * socket::engine 	= NULL;
/* static */ radaptor * socket::radaptor 	= NULL;
/* static */ resolver * socket::resolver 	= NULL;

#ifdef HAVE_SSL
/* static */ SSL_CTX *socket::ssl_ctx 		= NULL;
/* static */ char   *socket::tls_rand_file 	= NULL;
#endif
 
/******************************************************
 * All the constructors throw:
 * socket_exception     -- if socket(), accept() fails
 *                      -- if socket table is full
 *                      -- if SSL initialization fails
 ******************************************************/

/** 
  * Create a new socket from scratch
  * family:     PF_INET
  *             PF_INET6      -- both supported
  *             PF_UNSPEC (0) -- defer creation
  * */
socket::socket(int family, int options, size_t buffMin, size_t buffMax) 
	: r_callback(this),
	  ibuff(buffMin, buffMax), 
	  obuff(buffMin, buffMax),
	  interface_data(NULL)
{
	DEBUG("socket::socket(family: %d, ...)\n", family);
	lookup_id = 0;
	tmp_req = NULL;
	
	if (family != PF_UNSPEC && family != 0)	{
		int f = this->open(family);
		if (f < 0) {
			throw socket_exception(net::strerror(f));
		}
		this->family = family;
		state = OPEN;
		set_nonblocking(f);
		update_addr_info(0);
	} 
	else {
		// defer creation
		this->family = PF_UNSPEC;
		state = NEW;
	}
	this->options = options;

#ifdef HAVE_SSL
	ssl = NULL;
#endif
}

/**
 * Create a socket, by accept()'ing a connection from 'source'
 * SSL accepts are handled automatically (if source->ssl != NULL)
 */
socket::socket(socket * source, size_t buffMin, size_t buffMax)
	: r_callback(this),
		ibuff(buffMin, buffMax), 
		obuff(buffMin, buffMax),
		interface_data(NULL)
{
   	DEBUG("socket::socket(%p, %zd, %zd) [%p]\n", source, buffMin, buffMax, this);
	lookup_id = 0;	
	tmp_req = NULL;	

#ifdef HAVE_SSL
	ssl = NULL;
#endif

	if (!source || !source->get_state() == LISTENING) {
		throw socket_exception("Invalid source for accept()");
	}
	
	struct sockaddr_storage saddr;
	socklen_t addrlen = sizeof saddr;
	int f = accept(source->get_fd(), (sockaddr *) &saddr, &addrlen);
	if (f < 0) {
		throw socket_exception("accept() failed");
	}
	
	set_fd(f);
	int r = engine->add(this);
	if (r < 0) {	
		::close(f);
		throw socket_exception("Socket table is full");
    	}
	set_nonblocking(f);
	
	options = source->options;
	family = source->family;

	// SSL?
#ifdef HAVE_SSL
	if (options & SOCK_SSL) {
		options |= SOCK_SSL;
		state = ACCEPTING;
	} 
	else
#endif
	state = CONNECTED;

	update_addr_info(0);
	update_addr_info(1);
}


/** 
  * Open a new socket and put it in the table.
  * Return:
  *     --  > -1 -- success, and the new file descriptor
  *     --  < 0  -- failures:
  *	 	ERR_ALREADY_OPEN	 ditto
  *		ERR_UNABLE		 open() failed
  *		ERR_TABLE_FULL		 out of space in socket
  */
int socket::open(int domain, int protocol)
{
	DEBUG("socket::open() [%p]\n", this);

	if (get_fd() != -1) {
		return ERR_ALREADY_OPEN;
	}
	
	int f = ::socket(domain, SOCK_STREAM, protocol);
	if (f < 0) {
		return ERR_UNABLE;
	}

	set_fd(f);	
	int r = engine->add(this);	
	if (r < 0) {
		::close(f);
		set_fd(-1);
		return ERR_TABLE_FULL;
    	}
	family = domain;
	state = OPEN;
	assert(get_fd() != -1);
	return f;
}

/**
 * Make socket listen for connections.
 * -- you must specify an interface, "0.0.0.0 or ::0" at the very
 *    least
 * return:
 *      ERR_INTERFACE -- host invalid
 *      ERR_SYSCALL   -- bind() or listen() failure
 *       0                 -- success
 *       other < 0	   -- other socket error codes
 *
 *
 * NOTES: on_readable() is called when connection is waiting
 */
int socket::listen(const char * interface, unsigned short port, int backlog, int opt)
{
	DEBUG("socket::listen() [%p] (%s, %u, %d, %d)\n", this, interface, port, backlog,opt );

	if (state == CLOSED) {
		return ERR_SOCK_CLOSED;
	}	
	if (state == LISTENING) {
		return ERR_LISTENING;
	}	
	if (state != NEW && state != OPEN) {
		return ERR_PROGRESS;
	}
	// FIXME: ensure sock isn't in middle of connect or DNS resolve
	
	struct addrinfo * ai;
	if (resolver::resolve_address(family, AI_ADDRCONFIG, interface, port, &ai)) {
		return ERR_INTERFACE;
	}

	int f = get_fd();
	if (f < 0) {
		f = open(ai->ai_family);
	}
	if (f < 0) {
		freeaddrinfo(ai);
		return -1;
	}
	set_fd(f);
	set_nonblocking(f);
		
	int parm = 1;
	setsockopt(f, SOL_SOCKET, SO_REUSEADDR, (const char * ) &parm, sizeof(int));	
	
	if (::bind(f, ai->ai_addr, ai->ai_addrlen)
		|| ::listen(f, backlog)) {
		// FIXME: close the socket here?
		freeaddrinfo(ai);
		return ERR_SYSCALL;
	}
	freeaddrinfo(ai);

	state = LISTENING;
	options = opt;
	
	set_events(io::EVENT_READ);
	
	update_addr_info(false);
	return 0;
}

/**
 * Attempt to listen on a port randomly selected from a range of
 * ports.
 * Possible returns:
 *      1           -- Success
 *      ERR_DNS
 *      ERR_FAILURE
 */
int socket::listen(const char * hostname, const char * port_range, int backlog, int opt)
{
	using std::string;
	std::vector<string> tokens;

	if (!is_non_empty(port_range)) {
		return this->listen(hostname, (unsigned short) 0, backlog, opt);
	}

	tokenize(port_range, ",", tokens);

	for (std::vector<string>::const_iterator i = tokens.begin(), e = tokens.end();
		i != e;
		++i) {
		unsigned short lbound, ubound = 0;
		const string& tok = *i;
		string bounds[2];

		tokenize(tok.c_str(), "-", &bounds[0], 2);

		lbound = atoi(bounds[0].c_str());
		if (!bounds[1].empty()) {
			ubound = atoi(bounds[1].c_str());
		}

		DEBUG("bind_port(): Testing listen ports lower: %d upper: %d\n", lbound, ubound);
		if (!ubound) {
			ubound = lbound;
		}
		for (int i = lbound; i <= ubound; ++i) {
			DEBUG("bind_port(): Now calling bind() on port %d\n", i);
			int j =  this->listen(hostname, (unsigned short) i, backlog, opt);
			/* bail out if the hostname is bad, or
			 * if we succeeded */
			if (j == ERR_INTERFACE || j == 1) {
				return j;
			}
			/* on non-fatal errors, keep looping */
			if (j != ERR_SYSCALL) {
				return j;
			}
		}
	}
	return ERR_FAILURE;
}


/**
 * Call connect() on this file descriptor to initiate
 * a non-blocking connect()
 *
 * args:
 *      where       -- where to connect
 *      interface   -- what interface to connect to (IPv6 or IPv4)
 *      port        
 *      options     -- currently, only 0 or SSL is supported
 *
 * return:
 *      0                       -- connect now in progress
 *	ERR_PROGRESS 		-- already connecting
 *	ERR_ALREADY_OPEN 	-- already connected
 *
 * With the async. DNS lookup this is a little different.  We don't actually
 * call connect() until both the interface and target addresses have been
 * resolved.  Should these lookups fail, socket::on_connect_fail() is called
 * with the appropriate error message.
 *
 * So really there is nothing too useful returned from this function, the most 
 * useful errors will be detected by on_connect_fail().
 *
 * NOTE: on_connect_fail() may not assume fd != -1 or other properties relating
 *		to a succesful call to socket()
 *
 */
int socket::async_connect(const char * where, const char * interface, unsigned short port,
                        int options)
{
	 DEBUG("socket::connect [%p] (%s, %s, %u, %i)\n", this, where, interface, port, options);
	
	 if (state == CLOSED) {
		 return ERR_SOCK_CLOSED;
	 }
	 if (state == CONNECTED) {
		 return ERR_ALREADY_OPEN;
	 }
	 if (state != NEW && state != OPEN) {
		 return ERR_PROGRESS;
	 }

	 /* Setup async DNS lookup for both 
	  * interface hostname and target hostname */
	 assert(tmp_req == 0);		
	 resolver::request * req1 = NULL, * req2 = NULL;

	 req2 = resolver->create_request(family, where, port, 0, &r_callback);
	 if (is_non_empty(interface)) {
		 /* We have two things to lookup */
		 req1 = resolver->create_request(family, interface, 0, 0, &r_callback);
		 tmp_req = req2;
		 lookup_id = resolver->async_lookup(req1);
	 } 
	 else {
		 lookup_id = resolver->async_lookup(req2);
	 }

#ifdef HAVE_SSL 		
	 /* Set SSL flags if requested */
	 if (options & SOCK_SSL) {
		 this->options = SOCK_SSL;
	 }
	 else
#endif	
		 this->options = 0;			

	 state = CONNECT_RESOLVING;
	 return 0;
}

/** 
 * Close the file descriptor, flush buffers, 
 * minimize buffer memory usage and reset all socket
 * state and option variables 
 */
int socket::close()
{
	DEBUG("socket::close() [%p]\n", this);

	if (get_fd() > -1) {
#ifdef HAVE_SSL
		if (ssl) {
			DEBUG("Shutting down SSL for %p...\n", this);
			SSL_shutdown(ssl);
			SSL_free(ssl);
			ssl = NULL;
  		}
#endif
		if (state == CONNECTED) {
			flushO();
		}
		engine->release(this);
		::close(get_fd());
		set_fd(-1);

		update_addr_info(true);
		update_addr_info(false);
	}

	ibuff.clear();
	obuff.clear();
	optimize_buffers();
	
	/* Clean up resolver state */
	delete tmp_req;
	tmp_req = NULL;
	if (lookup_id != 0) {
		resolver->cancel_async_lookup(lookup_id);
	}
	lookup_id = 0;	
	if (interface_data != NULL) {
		delete[] interface_data->first;
		delete interface_data;
		interface_data = NULL;
	}

	state = CLOSED;
	family = PF_UNSPEC;
	options = 0;
	
#ifdef HAVE_SSL
	assert(get_fd() == -1 && ssl == NULL);
#endif
	return 0;
}

/**
 * Checking for socket close sucks. But we must do it ASAP
 * to simplify work for derived class sockets.
 * This does a recv test to see if the connection is still alive 
 */
int socket::check_for_close() const
{
	int e;
	switch (recv_test(get_fd())) {
	case 0:		/* socket closed */
		e = ERR_CLOSED;
		break;
	case -1:
		e = ERR_SYSCALL;
		break;
	default:
		return 0;
	}
	return e;
}

/** 'pollable' interface **/
int socket::event_callback(int ev) 
{
	int ret = 0;
	/**
	  * Socket readable.
	  */
	if (ev & io::EVENT_READ) {
		if (state != LISTENING) {
			int e = check_for_close();
			if (e < 0) {
				if (state == CONNECTING) {
					on_connect_fail(e);
				} 
				else {
					on_disconnect(e);
				}
				return -1;	
			}
		}		

#ifdef HAVE_SSL
		/** handle special cases for **
		 ** non-blocking SSL setup **/
		if (options & SOCK_SSL)	{
			if (state == CONNECTING) {
				switch (switch_to_ssl()) {
				case ERR_SSL:
					on_connect_fail(ERR_SSL);
					return -1;
				case 0:
					on_connect();
					return 0;

				case ERR_AGAIN:
					break;
				}
			}
			else if (state == ACCEPTING) {
				switch (accept_to_ssl()) {
				case ERR_SSL:
					on_disconnect(ERR_SSL);
					return -1;
				case 0:
					state = CONNECTED;
				case ERR_AGAIN:
					break;
				}
			}
			else {
				ret = on_readable();
			}
		} 
		else
#endif
			if (state == CONNECTING) {
				// usually socket will only be writeable on connect
				// however, if data was immediately sent to it upon connection,
				// it can be marked both readable and writeable
				on_connect();
				return 0;
			}
			else {
				ret = on_readable();
			}
	}

	/**
	  * Socket writeable.
	  */
	if ((ev & io::EVENT_WRITE) && ret >= 0) {
		if (state == CONNECTING) {
			int e = check_for_close();
			if (e < 0) {
				on_connect_fail(e);
				return -1;
			}
#ifdef HAVE_SSL
			if (options & SOCK_SSL)	{
				set_events(io::EVENT_READ);
				switch_to_ssl();
			} 
			else
#endif		
			{
				on_connect();
				return 0;
			}
#ifdef HAVE_SSL			
		} 
		else if (state == ACCEPTING) {
			if (options & SOCK_SSL)	{
				set_events(io::EVENT_READ);
				accept_to_ssl();
			}
#endif		
		} 
		else {
			ret = on_writeable();	
		}
	}

	/**
	  * Weird error condition.
	  */
	if ((ev & io::EVENT_ERROR) && ret >= 0) {
		if (state == CONNECTING) {
			on_connect_fail(ERR_HUP);
		}
		else {
			on_disconnect(ERR_HUP);
		}
		return -1;
	}
	return ret;
}
	

/** resolver callback functions **/
int socket::async_lookup_finished(const resolver::result * req)
{
	/* This means asnyc lookup *succeeded */
	assert(state == CONNECT_RESOLVING 
		|| state == LISTEN_RESOLVING);
	assert(lookup_id == req->id);
	DEBUG("socket::async_lookup_finished() [%p] for %s\n", this, req->name);
	
	lookup_id = 0;	
	if (state == CONNECT_RESOLVING) {
		/** We just got done looking up the interface **/
		if (tmp_req != NULL) {
			/** save the data; we don't bind() till connect()-time **/
			const size_t len =  req->ai->ai_addrlen;

			interface_data = new std::pair<unsigned char *, size_t>( new unsigned char[len], len); 
			memcpy(interface_data->first, req->ai->ai_addr, interface_data->second);
			lookup_id = resolver->async_lookup(tmp_req);
			tmp_req = NULL;
			return 0;
		}
		/* Got the target address, ready to connect */
		tmp_req = NULL;
		
		/* was the resulting socket family different than expected ? */
		if (family != req->ai->ai_family) {
			if (get_fd() != -1) {
				int t = options;		/* close() will clobber this */
				close();
				options = t;
			}
			int i = open(req->ai->ai_family);
			if (i < 0) {
				state = CONNECTING;
				on_connect_fail(i);
				return 1;
			}
		}
		int f = get_fd();
		set_nonblocking(f);
		state = CONNECTING;			

		if (interface_data != NULL) {
			int r = ::bind(f, (const sockaddr *) interface_data->first, interface_data->second);
			delete[] interface_data->first;
			delete interface_data;
			interface_data = NULL;
			if (r < 0) {
				/* bind failed: */
				on_connect_fail(ERR_INTERFACE);
				return 1;
			}
		}
	
            	if (::connect(f, req->ai->ai_addr, req->ai->ai_addrlen) < 0) {
        		if (errno != EINPROGRESS) {
        			on_connect_fail(ERR_SYSCALL);
				return 1;				
			}
		}
			
		update_addr_info(false);
		update_addr_info(true, req->ai->ai_addr, req->ai->ai_addrlen);		
		on_connecting();
		set_events(io::EVENT_READ | io::EVENT_WRITE);
        }
	return 0;
}

int socket::async_lookup_failed(const resolver::result * req)
{
	/* This means asnyc lookup *FAILED* */
	assert(state == CONNECT_RESOLVING || state == LISTEN_RESOLVING);
	assert(lookup_id == req->id);
	
	DEBUG("socket::async_lookup_failed() [%p] for %s\n", this, req->name);
	
	lookup_id = 0;
	if (state == CONNECT_RESOLVING) {
		state = CONNECTING;
		if (tmp_req != NULL) {  /* if this was the interface */
			delete tmp_req;
			tmp_req = NULL;
			on_connect_fail(ERR_INTERFACE);
		} 
		else { 
			tmp_req = NULL;
			on_connect_fail(ERR_DNS);
		}
	}
	return 0;
}

/**
 * Updates the 'peer' and 'local' data fields by calling 
 * getpeername()/getsockname().
 */
int socket::update_addr_info(bool is_peer)
{
	DEBUG("socket::update_addr_info(%d) [%p]\n", is_peer, this);
	
	if (get_fd() < 0) {
		if (is_peer) {
			this->peer = ap_pair("[not connected]", 0);
		}
		else {
			this->local = ap_pair("[not connected]", 0);
		}
		return -1;
	}

	struct sockaddr_storage saddr;
	socklen_t len = sizeof(saddr);

	if (is_peer) {
		if (getpeername(get_fd(), (struct sockaddr *) &saddr, &len)) {
			return -1;
		}
	} 
	else {
		if (getsockname(get_fd(), (struct sockaddr *) &saddr, &len)) {
			return -1;
		}
	}
	return update_addr_info(is_peer, (struct sockaddr *) &saddr, len);	
}

/**
 * Updates the 'peer' and 'local' data fields by populating it from
 * a given network address structure.
 */
int socket::update_addr_info(bool is_peer, const sockaddr * source, size_t len)
{
	assert(family != 0);
	char addrbuff[MAX_ADDRSTRLEN+1] = "";
	unsigned short port;
	if (resolver::raw_to_ip(source, len, addrbuff, sizeof addrbuff, &port) != 0) {
		return -1;
	}

	if (is_peer) {
		this->peer = ap_pair(addrbuff, port);
	}
	else {
		this->local = ap_pair(addrbuff, port);
	}    
	return 0;
}

/** Default Event Handlers **/
void socket::on_disconnect(int)
{
	DEBUG("[%p] socket::on_disconnect()\n", this);
	close();
}

void socket::on_connect_fail(int)
{
	DEBUG("[%p] socket::on_connect_fail()\n", this);
	close();
}

void socket::on_connecting()
{	
}

void socket::on_connect()
{
	DEBUG("[%p] socket::on_connect()\n", this);
	assert(state != CONNECTED);
	state = CONNECTED;
	update_addr_info(0);
	update_addr_info(1);
}

int socket::printf(const char * format, ...)
{
	va_list ap;
	va_start(ap, format);
	int r = printf_raw(format, ap);
	va_end(ap);
	if (r > 0) {
		flushO();
	}
	return r;
}


/** 
 * Like above but does not flush data.
 */
int socket::printfQ(const char * format, ...)
{
	va_list ap;
	va_start(ap, format);
	int r = printf_raw(format, ap);
	va_end(ap);
	return r;
}

/** 
 * Updated 5/04: We will NOT queue incomplete messages.
 * 	   9/07: Flushes buffer to make room, if necessary and possible.
 */ 
int socket::printf_raw(const char * fmt, va_list ap)
{
	char * ptr = NULL;
	int len = my_vasprintf(&ptr, fmt, ap);
	if (len < 0) {
		return ERR_MEM;
	}
	if (buffer_availableO() < size_t(len)) {
		flushO();
	}	
	len = queue(ptr, len);
	delete[] ptr;
	return len;
}

/**
 * Return:
 * -1:      error, socket died
 *  0:      socket closed from eof
 *  1:      socket ok.
 *  2:      socket ok, stuff to read;
 */
/* static */ int socket::recv_test(int fd)
{
	char dummy;
	switch (recv(fd, &dummy, 1, MSG_PEEK))
	{
	case 0:
		return 0;
	case -1:
		if (errno == EAGAIN) {
			return 1;
		}
		return -1;
	}
	return 2;
}


/** SSL-specific code follows **/
#ifdef HAVE_SSL
/* static */ int socket::init_ssl(const char * certfile)
{
	if (ssl_ctx == NULL) {
		DEBUG("Initializing SSL...\n");
		SSL_load_error_strings();
		OpenSSL_add_ssl_algorithms();
		ssl_ctx = SSL_CTX_new(SSLv23_method());

		if (!ssl_ctx)  {
			DEBUG("SSL_CTX_new() failed\n");
			return -1;
		}

		if (seed_PRNG()) {
			DEBUG("Wasn't able to properly seed the PRNG!\n");
			SSL_CTX_free(ssl_ctx);
            		ssl_ctx=NULL;
			return -1;
		}

		SSL_CTX_use_certificate_file(ssl_ctx, certfile,SSL_FILETYPE_PEM);
		SSL_CTX_use_RSAPrivateKey_file(ssl_ctx,certfile,SSL_FILETYPE_PEM);
		if (!SSL_CTX_check_private_key(ssl_ctx)) {
			DEBUG("Error loading private key/certificate, set correct file in options...\n");
			SSL_CTX_free(ssl_ctx);
			ssl_ctx=NULL;
			return -1;
		}
        }
    	return 0;
}

/* static */ int socket::shutdown_ssl()
{
	if (ssl_ctx) {
		DEBUG("Freeing SSL context...");
		SSL_CTX_free(ssl_ctx);
		ssl_ctx = NULL;
	}
	if (tls_rand_file) {
		RAND_write_file(tls_rand_file);
	}
	return 1;
}

/** 
 * Return values for SSL functions:
 *
 * 	0		-- Success
 * 	ERR_SSL  	-- fatal error
 * 	ERR_AGAIN 	-- try again
 */
int socket::switch_to_ssl()
{
	int err;
	assert(get_fd() > -1);
	assert(options & SOCK_SSL);
	DEBUG("socket::switch_to_ssl() [%p] \n", this);
	if (!ssl) {
		ssl = SSL_new(ssl_ctx);
		if (!ssl) {
			DEBUG("socket::switch_to_SSL() [%p] -- SSL_new() failed\n", this);
			return ERR_SSL; /* fatal */
		}
		SSL_set_fd(ssl, get_fd());
	}
	
	err = SSL_connect(ssl);
	
	if (err < 1) {
		err = SSL_get_error(ssl, err);
		if (err != SSL_ERROR_WANT_READ && err != SSL_ERROR_WANT_WRITE) {
			DEBUG("Error while SSL_connect()\n");
			DEBUG("SSL_ERROR: %d\n", SSL_get_error(ssl, err));
			SSL_shutdown(ssl);
			SSL_free(ssl);
			ssl = NULL;
			return ERR_SSL;
		}
		return ERR_AGAIN;   /* try again */
	}
	return 0;
}

int socket::accept_to_ssl()
{
	assert(get_fd() > -1);
	assert(options & SOCK_SSL);
	int err;

	DEBUG("socket::accept_to_ssl() [%p] \n", this);
	if (!ssl) {
		ssl = SSL_new(ssl_ctx);
		if (!ssl) {
			DEBUG("SSL_new() failed\n");
			return ERR_SSL;
		}
		SSL_set_fd(ssl, get_fd());
	}
	err = SSL_accept(ssl);

	if (err < 1) {
		err = SSL_get_error(ssl, err);
		if (err != SSL_ERROR_WANT_READ && err != SSL_ERROR_WANT_WRITE) {
			DEBUG("Error while SSL_accept()\n");
			DEBUG("SSL_ERROR: %d\n", SSL_get_error(ssl, err));
			SSL_shutdown(ssl);
			SSL_free(ssl);
			ssl = NULL;
			return ERR_SSL;
	        }
        	return ERR_AGAIN;   /* try again */
    	}
	return 0;
}

/**
  * Seed the OpenSSL PRNG.
  * Nothing to do if /dev/urandom exists.
  */
int socket::seed_PRNG()
{
	char stackdata[1024];
	static char rand_file[300];

#if OPENSSL_VERSION_NUMBER >= 0x00905100
	if (RAND_status()) {
		return 0;     /* PRNG already well seeded */
	}
#endif
	/** 
	 * If the device '/dev/urandom' is present, OpenSSL uses it by default.
	 * check if it's present, else we have to make random data ourselves.
	 */
	if (access("/dev/urandom", R_OK) == 0) {
		DEBUG("socket::seed_PRNG(): using /dev/urandom() by default\n");
		return 0;
	}
	if (RAND_file_name(rand_file, sizeof(rand_file))) {
		tls_rand_file = rand_file;
	}
	else {
		DEBUG("socket::seed_PRNG(): unable to create random seed file\n");
		return 1;
	}
	if (!RAND_load_file(rand_file, sizeof rand_file)) {
		/* no .rnd file found, create new seed */
		time_t c;
		c = time(NULL);
		RAND_seed(&c, sizeof(c));
		c = getpid();
		RAND_seed(&c, sizeof(c));
		RAND_seed(stackdata, sizeof(stackdata));
	}
#if OPENSSL_VERSION_NUMBER >= 0x00905100
	if (!RAND_status()) {
		return 2;   /* PRNG still badly seeded */
	}
#endif
	return 0;
}
#endif

} /* namespace net */
