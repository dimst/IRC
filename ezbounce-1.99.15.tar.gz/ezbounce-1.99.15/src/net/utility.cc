/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundatnetn; either versnetn 2 of the License, or
 * (at your optnetn) any later versnetn.
 *
 * net/utility.cc
 * (c) 2007 Murat Deligonul
 */

#include "autoconf.h"

#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <cerrno>
#include "net/error.h"
#include "io/error.h"
#include "debug.h"

namespace net {

const char * strerror(int e)
{
	static char errbuff[128];
	if (e > 0) {
		return ::strerror(e);
	}
	switch (e) {
	case ERR_CLOSED:
		return "Connection closed";
	case ERR_AGAIN:
		return "Call failed -- try again";
	case ERR_SYSCALL:
		snprintf(errbuff, sizeof errbuff, "Syscall error (%s)", ::strerror(errno));
		return errbuff;
	case ERR_DNS:
		return "DNS lookup failure or bad address";
	case ERR_SSL:
		return "SSL error";
	case ERR_FAILURE:
		return "Operation failed";
	case ERR_UNABLE:
		return "Unable to create socket";
	case ERR_TABLE_FULL:
		return "Socket table is full";
	case ERR_HUP:
		return "Hangup detected from socket";
	case ERR_MEM:
		return "Out of memory";
	case ERR_CONN_ABORTED :
		return "Non-blocking connect aborted";
	case ERR_LISTENING:
		return "Socket is already listening";
	case ERR_ALREADY_OPEN:
		return "Socket is already open or connected";
	case ERR_INTERFACE:
		return "Unable to bind to requested interface";
	case ERR_PROGRESS:
		return "Non-blocking connect/accept/lookup already in progress";
	case ERR_AUTH:
		return "Authorization error";
	case ERR_SOCK_CLOSED:
		return "Socket has been closed";
	default:
		// could be error from IO framework
		return io::strerror(e);
	}
}

}
