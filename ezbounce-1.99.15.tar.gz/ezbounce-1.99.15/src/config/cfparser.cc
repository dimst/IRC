/**
 * config/cfparser.cc
 *
 * (C) 2005-2008 Murat Deligonul
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * ----   
 * 7/06 -- Parser core factored out
 */

#include "autoconf.h"

#include <vector>
#include <string>
#include <iterator>
#include <algorithm>
#include <exception>
#include <functional>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cstdarg>
#include <cerrno>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "util/generic.h"
#include "util/hash.h"
#include "config/cfparser.h"
#include "config/node_searcher.h"
#include "config/node.h"
#include "logging/chatlog.h"
#include "ruleset.h"

#include "debug.h"

/**
  * TODO:
  * disable debug statements
  * detection of illegal user blocks isn't verbose enough
  * possible off-by-one index error?  ("Illegal argument type" code)
  */ 

using std::vector;
using std::string;

using config::node_searcher;

/* Custom flags for symbol table */
enum {
	OBSOLETE   	= 0x8000,
};

/* IDs for symbols */
enum {
	SYM_OPENBRACE = 	20,
	SYM_CLOSEBRACE,
	CFG_CMD_SET,
	CFG_CMD_LISTEN,     	CFG_CMD_ALLOW,
	CFG_CMD_DENY,		CFG_CMD_USER,
	CFG_CMD_VHOSTS,		CFG_CMD_SSL_LISTEN,
	CFG_CMD_RS_FROM,
	CFG_CMD_RS_TO,
};

const int config_parser::SET_ARG_PATTERN[] = { ARG_TYPE_OTHER | OBSOLETE, 	ARG_TYPE_STRING | ARG_TYPE_NUMBER | ARG_TYPE_BOOL | ARG_TYPE_OTHER };
const int config_parser::LISTEN_ARG_PATTERN[] = { ARG_TYPE_STRING | ARG_TYPE_OTHER | ARG_TYPE_NUMBER};
const int config_parser::BLOCK_ARG_PATTERN[] = { ARG_TYPE_BLOCK };
const int config_parser::USER_ARG_PATTERN[] = { ARG_TYPE_STRING | ARG_TYPE_OTHER, ARG_TYPE_BLOCK};


const struct parser_core::config_symbol config_parser::symtab[] = {
								/* good contexts */	 /* flags to enforce */
	{"SET",                     CFG_CMD_SET,                CTX_GLOBAL | CTX_USER,   COMMAND | ARGS_SAME_LINE,	2, SET_ARG_PATTERN},
	{"LISTEN",                  CFG_CMD_LISTEN,             CTX_GLOBAL,		 COMMAND | ARGS_SAME_LINE,  	1, LISTEN_ARG_PATTERN},
	{"SSL-LISTEN",              CFG_CMD_SSL_LISTEN,         CTX_GLOBAL,		 COMMAND | ARGS_SAME_LINE, 	1, LISTEN_ARG_PATTERN},
	{"ALLOW",                   CFG_CMD_ALLOW,              CTX_USER,		 CREATE_CONTEXT,			1, BLOCK_ARG_PATTERN},
	{"DENY",                    CFG_CMD_DENY,               CTX_GLOBAL | CTX_USER,   CREATE_CONTEXT, 			1, BLOCK_ARG_PATTERN},
	{"USER",                    CFG_CMD_USER,               CTX_GLOBAL,		 CREATE_CONTEXT,			2, USER_ARG_PATTERN},
	{"VHOSTS",                  CFG_CMD_VHOSTS,             CTX_GLOBAL | CTX_USER,	 CREATE_CONTEXT, 			1, BLOCK_ARG_PATTERN},
	{"FROM",		    CFG_CMD_RS_FROM,		CTX_RULESET,		 COMMAND | ARGS_SAME_LINE,	-1},
	{"TO",		    	    CFG_CMD_RS_TO,		CTX_RULESET,		 COMMAND | ARGS_SAME_LINE,	-1},
	{"{",			    SYM_OPENBRACE,		CTX_ARG,		 ARG_TYPE_BLOCK },
	{"}",			    SYM_CLOSEBRACE,		CTX_USER | CTX_RULESET | CTX_VHOSTS,  EXIT_CONTEXT },

	/** obsolete options. will be removed one day. **/
	{ "PREVENT-SELF-CONNECTS",  0,              CTX_ARG,	 OBSOLETE},
	{ "ENABLE-PRIVATE-LOGGING", 0,              CTX_ARG,	 OBSOLETE},
	{ "ENABLE-PUBLIC-LOGGING",  0,              CTX_ARG,	 OBSOLETE},
	{ "ENABLE-SEPARATE-LOGGING",0,              CTX_ARG,	 OBSOLETE},
	{ "ENABLE-SEPERATE-LOGGING",0,              CTX_ARG,	 OBSOLETE},
	{ "NO-REVERSE-LOOKUPS",     0,     	    CTX_ARG,	 OBSOLETE},
	{ "MAX-DNS-WAIT-TIME", 	    0, 		    CTX_ARG,	 OBSOLETE},
	{ "DEFAULT-LOG-OPTIONS",    0,		    CTX_ARG,	 OBSOLETE},
	{ "ALLOWED-LOG-OPTIONS",    0,		    CTX_ARG,	 OBSOLETE}, 
	{ "AUTO-FAKE-IDENTS",       0,         	    CTX_ARG,	 OBSOLETE},
	{ "ENABLE-AUTO-DETACH",     0,         	    CTX_ARG,	 OBSOLETE},
	{ "AUTO-SERVER",    	    0,		    CTX_ARG,	 OBSOLETE},
	{ "DEFAULT-VHOST",          0,              CTX_ARG,	 OBSOLETE},
	{ "DROP-ON-DISCONNECT",     0,              CTX_ARG,	 OBSOLETE},
	{ "MAX-LOGFILE-SIZE",	    0,              CTX_ARG,	 OBSOLETE},
	{ "KILL-ON-FULL-QUEUE",	    0,              CTX_ARG,	 OBSOLETE},
	{ "ENABLE-DCC-FILTER",	    0,              CTX_ARG,	 OBSOLETE}
};

config_parser::config_parser(const char * filename) :
				parser_core(filename),
	       			users(7),
				options("default", true), 
				chash(47)
{
	/** Create symbol table hash **/
	for (unsigned c = 0; c < (sizeof(symtab) / sizeof(struct config_symbol)); ++c) {
		chash.insert(symtab[c].symbol, &symtab[c]);
	}
	/** Make sure these hash tables are ready too */
	node_searcher<user_permissions>::populate_table();
	node_searcher<proxy_options>::populate_table();
}

config_parser::~config_parser()
{
	DEBUG("config_parser::~config_parser() [%p]\n", this);
        using std::for_each;
        for_each(shitlist.begin(), shitlist.end(), util::delete_ptr());
        for_each(users.begin(), users.end(), util::apply_second<util::delete_ptr>());
	node_searcher<user_permissions>::clear_table();
	node_searcher<proxy_options>::clear_table();
}

const parser_core::hash_table_t * config_parser::symbol_table() const
{
	return &chash;
}

const char * config_parser::str_context(int ctx) const 
{
	switch (ctx) {
	case CTX_USER:
		return "user block";
	case CTX_VHOSTS:
		return "vhost block";
	case CTX_ALLOW:
		return "allow block";
	case CTX_DENY:
		return "deny block";
	default:
		break;
	}
	return parser_core::str_context(ctx);
}

const char * config_parser::str_argtype(int arg) const
{
	switch (arg) {
	case OBSOLETE:
		return "obsolete option";
	default:
		break;
	}
	return parser_core::str_argtype(arg);
}
			
/** 
  * Check legality of potential junk arguments right before
  * '}' that ends a block.  Currently legal only in the vhosts
  * block (where each argument is a vhost to add to the list)
  * return: 0 on success
  */
int config_parser::resolve_trailing_args(std::vector<config_token> &pre_args)
{
	context &ctx = context_stack.top();
	if (ctx.state == CTX_VHOSTS) {
		vector<string> * vhosts = (vector<string> *) ctx.data;
		vector<config_token>::const_iterator i = pre_args.begin();
		for (; i != pre_args.end(); ++i) {
			DEBUG("VHOST: inserting '%s' into block %p\n", (*i).token, vhosts);
			vhosts->push_back((*i).token);
		}
		return 0;
	}
	error("unknown tokens before closing brace\n");
	error("   starting with: '%s'\n", pre_args[0].token);
	return -1;	
}

/** 
 * Process a command.
 */
int config_parser::do_command(const config_symbol * sym, 
				std::vector<config_token>& pre_args,
				std::vector<config_token>& args)
{
	switch (sym->id) {
	case CFG_CMD_SET:
		return do_set_command(sym, pre_args, args);
	case CFG_CMD_LISTEN:
	case CFG_CMD_SSL_LISTEN:
		return do_listen_command(sym, pre_args, args);	
	case CFG_CMD_RS_TO:
	case CFG_CMD_RS_FROM:
		return do_rs_command(sym, pre_args, args);	
	}
	error("(!!) no handler for command '%s'\n", sym->symbol);
	return -1;
}

/** 
  * Enter a new context.
  * Parser will ensure proper # and type of arguments before calling, 
  * but we might still fail in some cases. (e.g. username already used)
  */
int config_parser::enter_context(const config_symbol *sym, 
			context &ctx, 
			vector<config_token> &pre_args,
			vector<config_token> &args)
{	
	/* currently none of these support pre-args */
	if (!pre_args.empty()) {
		error("unknown tokens before keyword '%s'\n", sym->symbol);
		error("   starting with: '%s'\n", pre_args[0].token);
		return -1;
	}
	
	switch (sym->id) {
	case CFG_CMD_USER:
		ctx.state = CTX_USER;
		if (users.contains(args[0].token)) {
			error("user '%s' is already defined!\n", args[0].token);
			return -1;
		}
		
		if (!userdef::is_legal_name(args[0].token)) {
			error("'%s' is not a legal username.\n", args[0].token);
			return -1;
		}		
		ctx.data  = (void *) new userdef(args[0].token);
		break;
	case CFG_CMD_VHOSTS:
		ctx.state = CTX_VHOSTS;
		ctx.data = (void *) new vector<std::string>();
		break;
	case CFG_CMD_ALLOW:
		ctx.state = CTX_ALLOW;
		ctx.data = (void *) new allowed_ruleset();
		break;
	case CFG_CMD_DENY:
		ctx.state = CTX_DENY;
		ctx.data = (void *) new denied_ruleset();
		break;
	default:
		return -1;
	}

	return 0;
}


/** 
  * Called after getting done with a user/ruleset/vhost block.
  * ctx refers to context struct just popped off the stack. 
  * Verifies legality of the user/ruleset/vhost block just parsed.
  * Also called to cleanup after a failed parse.  
  *
  * return: 
  *			  0 - no errors.
  *			< 0 - error condition
  *  (note: will always return 0 if success is false)			
  */
int config_parser::leave_context(context &ctx, bool success)
{
	const context& top = context_stack.top();
	ruleset * rs;
	userdef * user;
	vector<string> * v;
	
	switch (ctx.state) {
	case CTX_USER:
		user = (userdef *) ctx.data;
		if (!success) {
			delete user;
			break;
		}
		/** verify and add to user collection **/
		if (validate_user_config(user) < 0) {
			delete user;
			return -1;
		}
		DEBUG("leave_context(): adding user %s\n", user->name());
		users.insert(user->name(), user);						
		break;
		
	case CTX_ALLOW:
	case CTX_DENY:
		rs = (ruleset *) ctx.data;
		if (!success) {
			delete rs;
			break;
		}	
		/** verify and add to user's ruleset list **/
		if (!rs->is_legal()) {
			error("this ruleset is invalid\n");
			error("  'allow' rulesets MUST have at least one 'from' rule and at least one 'to' rule\n");
			error("  'deny' rulesets MUST have at least one rule of either type\n");
			delete rs;
			return -1;
		}

		if (top.state == CTX_GLOBAL) {
			shitlist.push_back(rs);
		} 
		else {
			user = (userdef *) top.data;
			user->rulesets().push_back(rs);		
		}
		break;
		
	case CTX_VHOSTS:
		v = (vector<string> *) ctx.data;
		if (!success) {
			delete v;
			break;
		}
		/** verify **/
		if (v->size() == 0) {
			error("vhost list is empty!\n");
			delete v;
			return -1;
		}
		/** add to proper list **/
		if (top.state == CTX_GLOBAL) {
			std::copy(v->begin(), v->end(), std::back_inserter(vhosts));
		} 
		else {
			user = (userdef *) top.data;
			std::copy(v->begin(), v->end(), std::back_inserter(user->vhosts()));
		}
		delete v;
		break;
	default:
		error("Unknown context '%d' -- unable to continue\n", ctx.state);
		abort();
	}
	return 0;		
}


int config_parser::do_set_command(const config_symbol * sym, 
				vector<config_token> &pre_args,
				vector<config_token> &args)
{
	if (!pre_args.empty()) {	
		error("garbage before command\n");
		return -1;
	}

	const context &ctx = context_stack.top();
	const config_token &var = args[0];
	const config_token &value = args[1];
	const config_symbol * c = var.symbol;
	const config::hash_entry * entry;


	DEBUG("do_set_command(): set %s %s\n", var.token, value.token);

	// XXX: dunno if this works	
	if (c->flags & OBSOLETE) {
		warning("option '%s' is obsolete; it will be ignored\n", c->symbol);
		return 0;
	}
	
	/**
	 * Lookup option being set.
	 */
	bool is_proxy_opt = true;
	entry = node_searcher<proxy_options>::lookup_option(var.token); 
	
	if (entry == NULL) {
		is_proxy_opt = false;
		entry = node_searcher<user_permissions>::lookup_option(var.token);
	}

	if (entry == NULL) {
		error("unknown option '%s'\n", var.token);
		return  -1;
	}

	/* there should not be a 'user' to set this option */
	if (is_proxy_opt && ctx.state != CTX_GLOBAL) {
		error("found proxy option '%s', but not in global context\n", var.token);
        	return -1;
	}

	/* and there better be a 'user' if needed */
	if (!is_proxy_opt && ctx.state != CTX_USER) {
		error("found user option '%s', but not in user context\n", var.token);
        	return -1;
	}

	// verify legality of argument type.
	// kinda messy.
	int mapping = 0;
	switch (entry->type) {
	case config::BOOLEAN:
		mapping = BOOL_ARG[0];
		break;

	case config::INTEGER:
		mapping = NUMBER_ARG[0];
		break;
	
	case config::STRING:
		mapping = STRING_ARG[0];
		break;
	}

	if (!(value.symbol->flags & mapping)) {
		// err:  illegal argument type 
		error("illegal argument type for option '%s'\n", entry->item->name);
		error("	 Needed: (%s);\n", config::stroption(entry->type));
		error("     Got: (%s)\n", str_argtypes(value.symbol->flags).c_str());
		return -1;
	}
	
	const char * const string_value = value.token;
	const int num_value = value.other_value;
	const int opt = entry->option;
	userdef * user = (userdef *) ctx.data;
	using config::traits;

	try {
		switch (entry->type) {
		case config::BOOLEAN:
			if (is_proxy_opt) {
				options.set<bool>( (traits<proxy_config, bool>::identifier_t) opt, num_value );
			}
			else {
				user->config()->set<bool>( traits<user_perms, bool>::identifier_t(opt), num_value );
			}
			break;
			
		case config::INTEGER:
			if (is_proxy_opt) {
				options.set<int>( traits<proxy_config, int>::identifier_t(opt), num_value );
			}
			else {
				user->config()->set<int>( traits<user_perms, int>::identifier_t(opt), num_value );
			}
			break;

		case config::STRING:
			if (is_proxy_opt) {
				options.set<string>( traits<proxy_config, string>::identifier_t(opt), string_value );
			}
			else {
				user->config()->set<string>( traits<user_perms, string>::identifier_t(opt), string_value );
			}
			break;
		}
	}
	catch (std::exception& e) {
		error("exception while setting option '%s':\n", var.token);
		error("illegal value '%s': %s\n", value.token, e.what());
		return -1;
	}	
	return 0;
}


int config_parser::do_listen_command(const config_symbol * sym, 
				vector<config_token> &pre_args,
				vector<config_token> &args)
{
	if (pre_args.size() > 0) {
		error("garbage before '%s' command\n", sym->symbol);
		return -1;
	}	

	config::traits<proxy_config, string>::identifier_t opt = 
						(sym->id == CFG_CMD_LISTEN) ? proxy_config::PORTS : proxy_config::SSL_PORTS;
	if (!options.get<string>(opt).empty()) {
		warning("a value was already set for the '%s' command, ignoring\n", sym->symbol);
		return 0;
	}
	try {
		options.set<string>(opt, args[0].token);
	}
	catch (std::exception& e) {
		error("fatal exception while performing '%s' command\n", sym->symbol);
		error("value '%s' not valid: '%s'\n", args[0].token, e.what());
		return -1;
	}
	return 0;
}

/**
  * Parses indiviual statements inside ruleset blocks.
  * Must handle:
  *	allow { 
  *		2 from *.domain.* on 6667
  *		2 from 192.168.1.1
  *		from *otherdomain*
  *		to * on 6667
  * 		to irc.*
  */
  
int config_parser::do_rs_command(const config_symbol * sym, 
				vector<config_token> &pre_args,
				vector<config_token> &args)
{
	const context &ctx = context_stack.top();
	ruleset * rs = (ruleset *) ctx.data;	
	/** optional pre- arg **/
	const config_token * num_token = 0;
	int num = ruleset::UNLIMITED;

	/** sanity checks **/
	if (args.size() == 0) {
		error("you must specify a hostmask after 'to' or 'from'\n");
		return -1;
	}

	/** sanity checks part II **/
	if (pre_args.size() > 1) {
		error("too many tokens before 'to' / 'from' command\n");
		return -1;
	} 
	else if (pre_args.size() == 1) {
		num_token = &pre_args[0];
		if (num_token->symbol->id != SYM_NUMBER) {
			error("first token on this line must be a number\n");
			return -1;
		}
		if (num_token->other_value < 1) {
			error("must enter a positive value for this number\n");
			return -1;
		}
		num = num_token->other_value;		
	}

	/** mandatory args **/
	const config_token& hostmask = args[0];
	const char * ports = "all";
	std::string reason;

	if (args.size() > 1) {
		unsigned int reason_idx = 1;
		const config_token& ports_token = args[1];
		if (!strcasecmp(ports_token.token, "on")) {
			if (args.size() == 2) {
				error("must specify ports after 'on' statement\n");
				return -1;
			}
			ports = args[2].token;			
			reason_idx = 3;
		}

		if (args.size() >= reason_idx+1) {
			/** Extract the reason for banning from 
			  * the rest of the line **/
			std::vector<config_token>::const_iterator i = args.begin();
			for (i += reason_idx; i != args.end(); ++i) {
				reason += (*i).token;
				reason += ' ';	
			}
		}
	}

	DEBUG("do_rs_command(): %d %s %s ports: %s reason: %s\n", num, sym->symbol, hostmask.token,  ports, reason.c_str());
	if (sym->id == CFG_CMD_RS_FROM) {
		rs->add_host_from(hostmask.token, ports, reason.c_str(), num);
	}
       	else {
		rs->add_host_to(hostmask.token, ports, reason.c_str(), num);
	}
	return 0;
}


/**
 * Ensures sanity of a newly defined user.
 * Sets some default values if possible.
 */
int config_parser::validate_user_config(userdef * user)
{
	int err = 0;

	/** errors **/
	if (user->rulesets().empty()) {
		error("user `%s' has no 'allow' rulesets\n", user->name());
		err = -1;	
	}
	if ( user->config()->get<string>(user_perms::PASSWORD).empty() ) {
		error ("user '%s': a password is required\n", user->name());
		err = -1;
	}
	return err;
}

int config_parser::validate_config() const
{
	int err = 0;

	if (users.empty()) {
		error("No users defined!\n");
		err = -1;   
	}
	if (options.get<string>(proxy_config::LOG_FILE).empty()) {
		error("\"logfile\" option wasn't set\n");
		err = -1;
	}
	if (options.get<string>(proxy_config::PORTS).empty() && 
			options.get<string>(proxy_config::SSL_PORTS).empty()) {
		error("No listening ports defined\n");
		err = -1;
	}
#ifdef HAVE_SSL
	if (options.get<string>(proxy_config::CERT_FILE).empty() && 
			!options.get<string>(proxy_config::SSL_PORTS).empty()) {
		error("SSL listen ports set, but no \"certfile\" defined\n");
		err = -1;
	}
#endif

	const string& vfs_dir = options.get<string>(proxy_config::VFS_DIR);
	if (vfs_dir.empty()) {
		error("No Virtual File System directory defined. Please set the \"vfs-dir\" option\n");
		err = -1;
	}
	else if (access(vfs_dir.c_str(), R_OK | W_OK | X_OK) < 0) {
		error( "Cannot access VFS base dir `%s': %s\n",
				vfs_dir.c_str(), strerror(errno));
		err = -1;
	}
	if (options.get<int>(proxy_config::MAX_BUFFER_SIZE) 
			<= options.get<int>(proxy_config::MIN_BUFFER_SIZE)) {
		error("\"max-buffer-size\" must be greater than \"min_buffer_size\"\n");
		err = -1;
	}

	// other warnings
	// warn about unsafe oident fake ident support
	const string& fmethod = options.get<string>(proxy_config::FAKE_IDENT_METHOD);
	if (users.size() > 1 && strcasecmp(fmethod.c_str(), "oidentd-hack") == 0) {
		warning("\"oidentd-hack\" fake ident support is not reliable with multiple users\n");
	}
	return err;
}

