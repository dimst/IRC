/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * config/ufparser.cc
 * (C) 2007 Murat Deligonul
 */

#include "autoconf.h"

#include <string>
#include <vector>
#include <iterator>
#include <algorithm>
#include <exception>
#include <utility>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cerrno>
#include <unistd.h>
#include <sys/types.h>
#include "util/generic.h"
#include "util/hash.h"
#include "config/ufparser.h"
#include "config/node.h"
#include "config/node_searcher.h"
#include "logging/chatlog.h"
#include "debug.h"

using std::vector;
using std::string;
using config::node_searcher;

typedef std::pair<userdef *, config::target_list> user_data_pair;	

/* IDs for symbols */
enum {
	SYM_OPENBRACE = 	20,
	SYM_CLOSEBRACE,
	CMD_VERSION,
	CMD_USER,
	CMD_USER_OPTIONS,
	CMD_SERVER_LIST,
	CMD_NETWORK,
	CMD_SERVER,
	CMD_CHANNEL,
	CMD_SET
};


const int userfile_parser::SET_ARG_PATTERN[] = { ARG_TYPE_STRING,	ARG_TYPE_STRING | ARG_TYPE_NUMBER | ARG_TYPE_BOOL | ARG_TYPE_OTHER };
const int userfile_parser::BLOCK_ARG_PATTERN[] = { ARG_TYPE_BLOCK };
const int userfile_parser::OPTION_BLOCK_ARG_PATTERN[] = { ARG_TYPE_STRING, ARG_TYPE_BLOCK};

const struct parser_core::config_symbol userfile_parser::symtab[] = {
							/* Good contexts */	 	/* Flags to enforce */
	{ "VERSION",		CMD_VERSION,		CTX_GLOBAL,			COMMAND | ARGS_SAME_LINE,	1,	NUMBER_ARG},
	{ "USER",		CMD_USER,		CTX_GLOBAL,			CREATE_CONTEXT,			2, 	OPTION_BLOCK_ARG_PATTERN},
	{ "USER_OPTIONS",	CMD_USER_OPTIONS,	CTX_USER,			CREATE_CONTEXT,			2, 	OPTION_BLOCK_ARG_PATTERN},	
	{ "NETWORK",		CMD_NETWORK,		CTX_USER_OPTIONS,		CREATE_CONTEXT,			2, 	OPTION_BLOCK_ARG_PATTERN},	
	{ "SERVER",		CMD_SERVER,		CTX_NETWORK,			CREATE_CONTEXT,			2, 	OPTION_BLOCK_ARG_PATTERN},	
	{ "CHANNEL",		CMD_CHANNEL,		CTX_SERVER,			CREATE_CONTEXT,			2, 	OPTION_BLOCK_ARG_PATTERN},	
	{ "SET",		CMD_SET,                CTX_USER_OPTIONS | CTX_NETWORK | CTX_SERVER | CTX_CHANNEL,   COMMAND | ARGS_SAME_LINE,	2, SET_ARG_PATTERN},
	{ "{",			SYM_OPENBRACE,		CTX_ARG,		 	ARG_TYPE_BLOCK },
	{ "}",			SYM_CLOSEBRACE,		CTX_USER | CTX_USER_OPTIONS 
								 | CTX_SERVER_LIST | CTX_NETWORK | CTX_SERVER
								 | CTX_CHANNEL | CTX_SERVER_LIST ,  EXIT_CONTEXT },
};

userfile_parser::userfile_parser(const char * filename, proxy_options& opt, const userdef::hash_table_t& uhash) : 
					parser_core(filename),
					options(opt),
					users(uhash),
					chash(13)
{
	/** Create symbol table hash **/
	for (unsigned c = 0; c < (sizeof(symtab) / sizeof(struct config_symbol)); ++c) {
		chash.insert(symtab[c].symbol, &symtab[c]);
	}
	/** Make sure these hash tables are ready too */
	node_searcher<proxy_options>::populate_table();
	node_searcher<user_config_root>::populate_table();
}

userfile_parser::~userfile_parser()
{
	DEBUG("userfile_parser::~userfile_parser() [%p]\n", this);
}

const util::hash_table<const char *, const parser_core::config_symbol *> * 
	userfile_parser::symbol_table() const
{
	return &chash;
}

const char * userfile_parser::str_context(int ctx) const 
{
	switch (ctx) {
	case CTX_USER:
		return "user block";
	case CTX_USER_OPTIONS:
		return "user options block";
	case CTX_NETWORK:
		return "network block";
	case CTX_SERVER:
		return "server block";
	case CTX_CHANNEL:
		return "channel block";
	case CTX_SERVER_LIST:
		return "server list block";
	default:
		break;
	}
	return parser_core::str_context(ctx);
}

/** 
  * Check legality of potential junk arguments right before
  * '}' that ends a block.  Not legal in any of the current constructs.
  */
int userfile_parser::resolve_trailing_args(std::vector<config_token> &pre_args)
{
	//--------------------------------------------------
	// context &ctx = context_stack.top();
	// if (ctx.state == CTX_VHOSTS) {
	// 	vector<string> * vhosts = (vector<string> *) ctx.data;
	// 	vector<config_token>::const_iterator i = pre_args.begin();
	// 	for (; i != pre_args.end(); ++i) {
	// 		DEBUG("VHOST: inserting '%s' into block %p\n", (*i).token, vhosts);
	// 		vhosts->push_back((*i).token);
	// 	}
	// 	return 0;
	// }
	//-------------------------------------------------- 
	error("unknown tokens before closing brace\n");
	error("   starting with: '%s'\n", pre_args[0].token);
	return -1;	
}

/** 
 * Process a command.
 */
int userfile_parser::do_command(const config_symbol * sym, 
				std::vector<config_token>& pre_args,
				std::vector<config_token>& args)
{
	switch (sym->id) {
	case CMD_VERSION:
		return do_version_command(sym, pre_args, args);
	case CMD_SET:
		return do_set_command(sym, pre_args, args);
	}
	error("(!!) no handler for command '%s'\n", sym->symbol);
	return -1;
}

/** 
  * Enter a new context.
  * Parser will ensure proper # and type of arguments before calling, 
  * but we might still fail in some cases. 
  * ctx refers to context structure to fill.
  */
int userfile_parser::enter_context(const config_symbol *sym, 
			context &ctx, 
			vector<config_token> &pre_args,
			vector<config_token> &args)
{	
	/* currently none of these support pre-args */
	if (!pre_args.empty()) {
		error("unknown tokens before keyword '%s'\n", sym->symbol);
		error("   starting with: '%s'\n", pre_args[0].token);
		return -1;
	}

	/* see where we are right now */
	const context& top = context_stack.top();
	
	/* used below */
	user_data_pair * p = NULL;

	switch (sym->id) {
	case CMD_USER:
	{
		/**
		  * User may not actually exist -- this could happen under legitimate circumstances.
		  * Just warn if it's the case; subsequent commands will be ignored.
		  */
		p = new user_data_pair();
		userdef::hash_table_t::const_iterator i = users.find(args[0].token);
		if (i == users.end()) {
			warning("user '%s' does not exist; ignoring\n", args[0].token);
			p->first = NULL;
		}
		else {
			p->first = (*i).second;
		}

		ctx.state = CTX_USER;
		ctx.data = (void *) p;
		break;
	}

	case CMD_USER_OPTIONS:
		ctx.state = CTX_USER_OPTIONS;
		ctx.data = top.data;
		break;

	case CMD_SERVER_LIST:
		error("Currently unimplemented\n");
		return -1;
	
	case CMD_NETWORK: 
		ctx.state = CTX_NETWORK;
		/* fall thru */
	case CMD_SERVER:
		if (ctx.state == 0) {
			ctx.state = CTX_SERVER;
		}
		/* fall thru */
	case CMD_CHANNEL:
		if (ctx.state == 0) {
			ctx.state = CTX_CHANNEL;
		}
		ctx.data = top.data;

		p = (user_data_pair *) top.data;
		p->second.push_back( config::config_target(args[0].token) );
		break;

	default:
		error("Tried to enter unknown context %s (%d)\n", sym->symbol, sym->id);
		error("Fatal error; unable to continue\n");
		abort();
	}
	return 0;
}


/** 
  * Called after getting done with a user/ruleset/vhost block.
  * ctx refers to context struct just popped off the stack. 
  * Verifies legality of the user/ruleset/vhost block just parsed.
  * Also called to cleanup after a failed parse.  
  *
  * return: 
  *			  0 - no errors.
  *			< 0 - error condition
  *  (note: will always return 0 if success is false)			
  */
int userfile_parser::leave_context(context &ctx, bool success)
{
	/* used below */
	user_data_pair * p = NULL;

	switch (ctx.state) {
	case CTX_USER:
		/* Delete the aggregate structure created */
		p = (user_data_pair *) ctx.data;
		assert(p->second.empty());
		delete p;
		break;

	case CTX_USER_OPTIONS:
		/* nothing to do */		
		break;
	
	case CTX_SERVER:
	case CTX_NETWORK:
	case CTX_CHANNEL:
		/* Remove last entry from the target_list */
		p = (user_data_pair *) ctx.data;
		p->second.pop_back();
		break;
		
	default:
		error("Unknown context '%d' -- unable to continue\n", ctx.state);
		abort();
	}
	return 0;		
}


int userfile_parser::do_version_command(const config_symbol * sym, 
				vector<config_token> &pre_args,
				vector<config_token> &args) 
{
	if (!pre_args.empty()) {	
		error("garbage before command\n");
		return -1;
	}

	return 0;
}

int userfile_parser::do_set_command(const config_symbol * sym, 
				vector<config_token> &pre_args,
				vector<config_token> &args)
{
	if (!pre_args.empty()) {	
		error("garbage before command\n");
		return -1;
	}

	const context &ctx = context_stack.top();
	const config_token &var = args[0];
	const config_token &value = args[1];
	const config::hash_entry * entry = NULL;

	DEBUG("do_set_command(): set %s %s\n", var.token, value.token);

	/* Acquire user name and target list */
	user_data_pair * p = (user_data_pair *) ctx.data;

	if (p->first == NULL) {
		DEBUG("Ignoring set command for non-existent user\n");
		return 0;
	}

	/* Check targets, make sure option is legal. */
	int result = node_searcher<user_config_root>::validate_target_list(p->second, var.token, &entry);
	if (result != config::SUCCESS) {
		warning("failed to process variable '%s': %s\n", var.token, config::strerror( config::config_error(result) ));
		return 0;
	}

	// verify legality of argument type.
	// kinda messy.
	int mapping = 0;
	switch (entry->type) {
	case config::BOOLEAN:
		mapping = BOOL_ARG[0];
		break;

	case config::INTEGER:
		mapping = NUMBER_ARG[0];
		break;
	
	case config::STRING:
		mapping = STRING_ARG[0];
		break;
	}

	if (!(value.symbol->flags & mapping)) {
		// error:  illegal argument type.
		// should not happen unless users messes around with file 		
		error("illegal argument type for option '%s'\n", entry->item->name);
		error("	 Needed: (%s);\n", config::stroption(entry->type));
		error("     Got: (%s)\n", str_argtypes(value.symbol->flags).c_str());
		return -1;
	}
	
	const char * const string_value = value.token;
	const int num_value = value.other_value;
	const int opt = entry->option;
	user_config_root * cf = p->first->options();

	try {
		switch (entry->type) {
		case config::BOOLEAN:
			cf->set<bool>(p->second, opt, num_value);
			break;
			
		case config::INTEGER:
			cf->set<int>(p->second, opt, num_value);
			break;

		case config::STRING:
			cf->set<string>(p->second, opt, string_value);
			break;
		}
	}
	catch (std::exception& e) {
		error("exception while setting option '%s':\n", var.token);
		error("illegal value '%s': %s\n", value.token, e.what());
		return -1;
	}	
	return 0;
}

/**
  * Make sure the configuration settings parsed are sane.
  * Currently does nothing.
  */
int userfile_parser::validate_config() const 
{
	return 0;
}

