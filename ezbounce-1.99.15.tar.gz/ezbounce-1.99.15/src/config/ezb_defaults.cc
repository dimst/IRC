/**
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation; either version 2 of the License, or
  * (at your option) any later version.
  *
  * config/ezb_defaults.cc
  * (c) 2006-2007 Murat Deligonul
  */

#include "autoconf.h"

#include <string>
#include <cstdlib>
#include <climits>
#include "util/strings.h"
#include "config/defaults.h"
#include "config/traits.h"
#include "config/elements.h"
#include "debug.h"

using util::strings::simple_table_lookup;

static const struct config::limits<const char *> DEF_STRING = { NULL, NULL };

// some stuff needed later
static bool check_ident_method(const char *);
static void explain_ident_values(std::string&);

static bool check_greet_method(const char *);
static void explain_greet_values(std::string&);


const char proxy_config::NAME[] = "proxy";

const struct default_set<proxy_config> proxy_config::defaults = {
	/* bool options */
	{ {
		  { SILENT_REJECTION, 		false,	{},	{ "silent-rejection",  		{},	"reject unauthorized connections without sending them any messages" } },
		  { ENCRYPTED_PASSWORDS, 	false,	{},	{ "encrypted-passwords", 	{},	"passwords in the configuration are encrypted using DES or MD5" } }
	  }
	},

	/* int options */
	{ {
		  { MIN_BUFFER_SIZE,		1024,	{1024, INT_MAX},	{ "min-buffer-size",		{},				"minimum size of socket buffers" } },
		  { MAX_BUFFER_SIZE,		262144,	{4096, INT_MAX},	{ "max-buffer-size", 		{}, 				"maximum size of socket buffers" } },
		  { MAX_SOCKETS,		512,	{20,	65500},		{ "max-sockets",		{},				"maximum number of sockets that can be opened at once" } },
		  { MAX_FAILED_PASSWORDS,	3,	{0,	1000},		{ "max-failed-passwords", 	{},				"maximum number of incorrect login attempts allowed" } },
		  { MAX_VFS_AGE,		0,	{0,	INT_MAX},	{ "max-vfs-age",		{ 1, "max-filelib-age"},	"how old a file in the VFS can get before it is automatically erased" } },
		  { MAX_REGISTER_TIME,		30,	{0,	INT_MAX},	{ "max-register-time", 		{ 1, "max-registration-time"},	"maximum time allowed for a newly connected client to log in" } }
	  }
	},

	/* string options */
	{ {
		  { PORTS,		"",		DEF_STRING,	{ "ports", 			{},			"ports to listen for connections on" } },
		  { SSL_PORTS,		"",		DEF_STRING,	{ "ssl-ports", 			{},			"ports to listen for SSL connections on" } },
		  { DCC_PORTS,		"",		DEF_STRING,	{ "dcc-listen-port-range", 	{},			"listening ports to use for DCC" } },
		  { CONFIG_FILE,	"",		DEF_STRING,	{ "config-file", 		{ 1, "configfile"},	"internal use only" } },
		  { LOG_FILE,		"",		DEF_STRING,	{ "log-file",	   		{ 1, "logfile"},	"ezbounce log file" } },
		  { PID_FILE,		"",		DEF_STRING,	{ "pid-file",			{ 1, "pidfile"},	"file to save process id to" } },
		  { CERT_FILE,		"", 		DEF_STRING,	{ "cert-file", 			{ 1, "certfile"},	"file to use for SSL certificates" } },
		  { MOTD_FILE,		"",		DEF_STRING,	{ "motd-file", 			{ 1, "motdfile"},	"file containing the MOTD (Message of the Day" } },
		  { USER_FILE,		"",		DEF_STRING,	{ "user-file", 			{ 1, "userfile"},	"file to save users' customized preferences to" } },
		  { LISTEN_VHOST,	"0.0.0.0",	DEF_STRING,	{ "listen-vhost", 		{},			"interface to listen on" } },
		  { VFS_DIR,		"",		DEF_STRING,	{ "vfs-dir",			{ 1, "filelib-dir"},	"directory where the Virtual File System (VFS) will reside" } },
		  { FAKE_IDENT_METHOD,	"mdidentd",	{ &check_ident_method, &explain_ident_values },	{ "fake-ident-method",		{}, 	"what method to use for fake user idents" } },
		  { GREET_METHOD,	"simple",	{ &check_greet_method, &explain_greet_values },	{ "greet-method",		{},	"controls verbosity of proxy's greeting when new clients send initial USER and NICK commands" } }
	  }
	}
};
		
	
const char user_perms::NAME[] = "user_perms";
const struct default_set<user_perms> user_perms::defaults = {
	/* bool options */
	{ { 
		  { ENABLE_VFS_ACCESS,			true,	{},	{ "enable-vfs-access",			{ 2, "enable-filelib-access\0enable-filelib" },		"enable access to the ezbounce Virtual File System" } },
		  { ENABLE_DCC_STORAGE,			true,	{},	{ "enable-dcc-storage", 		{},					"allow storage of incoming and outgoing DCC file transfers on the proxy's VFS" } },
		  { ENABLE_OUTGOING_DCC_PROXYING, 	false,	{},	{ "enable-outgoing-dcc-proxying",	{},					"allow proxying of outgoing DCC connections" } },
		  { ENABLE_INCOMING_DCC_PROXYING,	false,	{},	{ "enable-incoming-dcc-proxying", 	{},					"allow proxying of incoming DCC connections" } },
		  { ENABLE_CHAT_LOGGING,		true,	{},	{ "enable-chat-logging", 		{},					"allow user to save IRC chat logs on the proxy" } },
		  { ENABLE_PER_CHANNEL_LOGGING,		true,   {},	{ "enable-per-channel-logging", 	{},					"allow user to save chat logs individually for each channel" } },
		  { ENABLE_DETACH_COMMAND,		true,	{},	{ "enable-detach-command",		{},					"enable the user to detach from the proxy while keep his IRC session alive" } },
		  { ENABLE_FAKE_IDENTS,			false,	{},	{ "enable-fake-idents",			{},					"enable user customization of the IDENT reply (requires special identd server" } },
		  { ENABLE_VHOST_COMMAND,		true,	{},	{ "enable-vhost-command",		{},					"enable users to change their connection interface (or vhost)" } },
		  { IS_ADMIN,				false,	{},	{ "is-admin",				{},					"gives administrative access to the user over the proxy" } },
		  { IS_VFS_SUPERUSER,			true,	{},	{ "is-vfs-superuser",			{ 2, "is-filelib-superuser\0is-filelib-admin"},		"gives administrative access to the user over the VFS (requires proxy admin access as well)" } },
		  { ENABLE_COMPRESSION,			true,	{},	{ "enable-compression",			{},					"enable use of compression features in VFS (including chat logs)" } },
	  }
       	},

	/* int options */
	{ { 
		  { MAX_IDLE_TIME,			0,	{0, INT_MAX},	{ "max-idle-time",	{},			"how long the user is permitted to idle on the proxy before being disconnected" } },
		  { MAX_DCCS,				100,	{0, INT_MAX}, 	{ "max-dccs",		{},			"the maximum number of DCCs the user is permitted to have proxied through ezbounce at once" } },
		  { VFS_QUOTA,				0,	{0, INT_MAX},	{ "vfs-quota",		{1, "filelib-quota"},	"user's quota in the VFS (FIXME: currently broken)" } }
	  }
	},

	/* string options */
	{ { 
		  { PASSWORD,				"",	DEF_STRING,	{ "password",		{},	"user's ezbounce account password" } },
		  { HOME_DIR,				"",	DEF_STRING,	{ "home-directory",	{},	"FIXME" } }
	  }
	}
};


const char user_config::NAME[] = "user_options";

const struct default_set<user_config> user_config::defaults = {
	/* bool options */
	{ /* nothing */ },
	
	/* int options */
	{ /* nothing */ },

	/* string options */
	{ { 
		{ AUTO_SERVER, 	"", 		DEF_STRING,	{ "auto-server",  	{},	"IRC server to automatically connect to" }  },
		{ FAKE_IDENT,  	"", 		DEF_STRING,	{ "fake-ident",  	{},	"fake ident reply to use on connect to IRC" } },
		{ VHOST,  	"", 		DEF_STRING,	{ "vhost", 		{},	"interface (or virtual host) to connect on" } },
		{ CHATLOG_DIR,	"logs/",	DEF_STRING,	{ "chatlog-dir",      	{},	"directory to store IRC chat logs in" } },
		{ DCC_IN_DIR,	"dcc-in/",	DEF_STRING,	{ "dcc-in-dir", 	{},	"directory to store incoming dcc file transfers" } },
		{ DCC_OUT_DIR,	"dcc-out/",	DEF_STRING,	{ "dcc-out-dir", 	{},	"directory to store outgoing dcc file transfers" } },
	  }
	}
};



const char irc_network_config::NAME[] = "network";

const struct default_set<irc_network_config> irc_network_config::defaults = {
	/* bool options */
	{ /* nothing */ },
	
	/* int options */
	{ /* nothing */ },

	/* string options */
	{ /* nothing */ }
};


const char irc_server_config::NAME[] = "server";

const struct default_set<irc_server_config> irc_server_config::defaults = {
	/* bool options */
	{ {  
		{ AUTO_DETACH,		true,	{},	{ "auto-detach", 		{},	"automatically detach from IRC server if you disconnect from the proxy" } },	  
		{ PROXY_DCC_IN, 	false,	{},	{ "proxy-dcc-in", 		{},	"proxy incoming DCC connections through ezbounce" } },
		{ PROXY_DCC_OUT,	false,  {},	{ "proxy-dcc-out", 		{},	"proxy outgoing DCC connections through ezbounce" } },
		{ FILTER_DCCS,		false,	{},	{ "filter-dccs",		{},	"enable dcc filtering, which traps incoming and outgoing DCC offers for you to review" } },
		{ LOG_PRIVATE,		true,	{},	{ "enable-private-logging",	{},	"enable logging of private messages"  } },
		{ COMPRESS_PRIVATE_LOG, false,	{},	{ "compress-private-log",	{},	"compress the private message log on disk"  } },
		{ AUTO_RECONNECT,	true,	{},	{ "auto-reconnect",		{},	"automatically reconnect to the IRC server or network if the connection is lost (even while detached)" } },
		{ ANTI_IDLE,		true,	{},	{ "anti-idle",			{},	"enable anti-idle mechanisms" } },
		{ PART_ON_DISCONNECT,	true,	{},	{ "part-chans-on-disconnect",	{},	"makes it appear as if you've parted all your channels when you disconnect from the IRC server" } }
	  }
	},
	
	/* int options */
	{ { 
		{ MAX_RECONNECT_TRIES,	30,	{1, INT_MAX},	{ "max-reconnect-tries", {},	"controls how many times reconnection will be attempted before giving up" } },
		{ RECONNECT_DELAY,	60,	{3, 1800},	{ "reconnect-delay", 	 {},	"specifies, in seconds, how long to wait between server reconnection attempts" } }
	  }
	},

	/* string options */
	{ {
		{ CTCP_VERSION_REPLY,	"",	DEF_STRING,	{ "ctcp-version-reply", {},	"CTCP version reply to send while detached" } },
		{ SERVER_PASSWORD,	"",	DEF_STRING,	{ "server-password", 	{},	"password to use when connecting to this IRC server" } },
		{ DETACH_NICK,		"",	DEF_STRING,	{ "detach-nick",	{},	"nickname to use while detached" } },
		{ DETACH_AWAY_MSG,	"",	DEF_STRING,	{ "detach-away-message",{},	"away message to set while detached" } },
	  }
	}
};

const char irc_channel_config::NAME[] = "channel";

const struct default_set<irc_channel_config> irc_channel_config::defaults = {
	/* bool options */
	{ {
		{ AUTO_REJOIN,		true,	{},	{ "auto-rejoin",	{},	"automatically rejoin the channel if kicked" } },
		{ LOG_DETACHED_ONLY,	true,	{},	{ "log-detached-only",	{},	"log channel ONLY while detached" } },
		{ LOG_ALWAYS,		false,	{},	{ "enable-logging",	{},	"enable logging of this channel" } },
		{ LOG_OWN_FILE,		true,	{},	{ "log-own-file",	{},	"store the channel log in its own separate file" } },
		{ LOG_ADDRESSES,	false,	{},	{ "log-addresses",	{},	"include users' full addresses in the channel log" } },
		{ LOG_TIMESTAMPS,	true,	{},	{ "log-timestamps",	{},	"include timestamps in the channel log" } },
		{ COMPRESS_LOG,		false,	{},	{ "compress-log",	{ 1, "compress-logs" },	"compress channel log on disk" } },
	  }
       	},
	
	/* int options */
	{ /* nothing */ },

	/* string options */
	{ {
		{ CHANNEL_PASSWORD,	"",	DEF_STRING,	{ "channel-password", 	{},	"FIXME" } },
	  }
	}
};


/**
 * Checks input values for certain string-based config options.
 */

static bool check_ident_method(const char * value) 
{
	static const char *values[] = {
		"mdidentd",
		"oidentd-hack",
		"none"
	};
	return simple_table_lookup(value, values, sizeof(values) / sizeof(const char *)) != -1;
}

static void explain_ident_values(std::string& out)	
{
	out = "fake ident method must be 'mdidentd', 'oidentd-hack', or 'none'";
}

static bool check_greet_method(const char * value) 
{
	static const char *values[] = {
		"full",
		"simple",
		"silent"
	};
	return simple_table_lookup(value, values, sizeof(values) / sizeof(const char *)) != -1;
}

static void explain_greet_values(std::string& out)
{
	out = "greet method must be 'full', 'simple', or 'silent'";
}

