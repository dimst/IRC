/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * config/ezb_dependencies.cc
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include <algorithm>
#include "config/ezb_dependencies.h"
#include "debug.h"

/**
  * Specialization for server-level options.
  */
template<> int decide_helper<server_node> (const user_config_root& root, const config::target_list& targets,
					config::traits<server_node::config_type, bool>::identifier_t val,
					const user_permissions& perms)
{
	using config::dependency;
	using config::dependency_expression;
	using config::dummy_expression;

	typedef dependency_expression<user_permissions> D;

	switch (val) {
	/**
	  * Auto detach: make sure detaching is permitted in the config.
	  */
	case irc_server_config::AUTO_DETACH:
		return dependency<user_config_root, 
		       			server_node,
					irc_server_config::AUTO_DETACH,
					user_permissions,
					D::_or<	D::value_of<user_perms::IS_ADMIN>, 
						D::value_of<user_perms::ENABLE_DETACH_COMMAND> 
					       > 
					>::decide(root, targets, perms);
	/**
	  * Incoming DCC proxying.
	  */	  
	case irc_server_config::PROXY_DCC_IN:
		return dependency<user_config_root,
		       			server_node,
					irc_server_config::PROXY_DCC_IN,
					user_permissions,
					D::_or< D::value_of<user_perms::IS_ADMIN>,
						D::value_of<user_perms::ENABLE_INCOMING_DCC_PROXYING>
					       >
					>::decide(root, targets, perms); 

	/**
	  * Outgoing DCC proxying.
	  */	  
	case irc_server_config::PROXY_DCC_OUT:
		return dependency<user_config_root,
		       			server_node,
					irc_server_config::PROXY_DCC_OUT,
					user_permissions,
					D::_or< D::value_of<user_perms::IS_ADMIN>,
						D::value_of<user_perms::ENABLE_OUTGOING_DCC_PROXYING>
					       >
					>::decide(root, targets, perms); 
	/**
	  * Logging of private chats.
	  */
      	case irc_server_config::LOG_PRIVATE:
		return dependency<user_config_root,
       					server_node,
		 			irc_server_config::LOG_PRIVATE,
					user_permissions,
					D::_or< D::value_of<user_perms::IS_ADMIN>,
						D::_and< D::value_of<user_perms::ENABLE_CHAT_LOGGING>,
							 D::value_of<user_perms::ENABLE_VFS_ACCESS>
						       >
						>
					>::decide(root, targets, perms);

	/**
	 * Compression of private log files.
	 */
	case irc_server_config::COMPRESS_PRIVATE_LOG:
		return std::min(decide_helper<server_node>(root, targets, 
								irc_server_config::LOG_PRIVATE, perms),
					dependency<user_config_root,
							server_node,
							irc_server_config::COMPRESS_PRIVATE_LOG,
							user_permissions,
							D::_or< D::value_of<user_perms::IS_ADMIN>,
								D::value_of<user_perms::ENABLE_COMPRESSION> 
							      >
						   >::decide(root, targets, perms));

	default:
		return root.get<server_node, bool>(targets, val);
	}

	return 0;
}

/**
  * Specialization for channel-level options.
  */
template<> int decide_helper<channel_node> (const user_config_root& root, const config::target_list& targets,
					config::traits<channel_node::config_type, bool>::identifier_t val,
					const user_permissions& perms)
{
	using config::dependency;
	using config::dependency_expression;
	using config::dummy_expression;

	typedef dependency_expression<user_permissions> D;

	switch (val) {
	/**
	  * Log only while detached. 
	  */
	case irc_channel_config::LOG_DETACHED_ONLY:
		return dependency<user_config_root,
		       			channel_node,
					irc_channel_config::LOG_DETACHED_ONLY,
					user_permissions,
					D::_or< D::value_of<user_perms::IS_ADMIN>,
						D::_and< D::value_of<user_perms::ENABLE_CHAT_LOGGING>,
							 D::value_of<user_perms::ENABLE_VFS_ACCESS>
							>
						>
					>::decide(root, targets, perms);

	/**
	 * Always log.
	 */
	case irc_channel_config::LOG_ALWAYS:
		return dependency<user_config_root,
		       			channel_node,
					irc_channel_config::LOG_ALWAYS,
					user_permissions,
					D::_or< D::value_of<user_perms::IS_ADMIN>,
						D::_and< D::value_of<user_perms::ENABLE_VFS_ACCESS>,					
							 D::value_of<user_perms::ENABLE_CHAT_LOGGING>							
							>
						>
					>::decide(root, targets, perms);

	/**
	  * Log in own file.
	  */
	case irc_channel_config::LOG_OWN_FILE:
		return dependency<user_config_root,
		       			channel_node,
					irc_channel_config::LOG_OWN_FILE,
					user_permissions,
					D::_or< D::value_of<user_perms::IS_ADMIN>,
						D::_and< D::_and< D::value_of<user_perms::ENABLE_PER_CHANNEL_LOGGING>,
								  D::value_of<user_perms::ENABLE_CHAT_LOGGING>
								>,
							 D::value_of<user_perms::ENABLE_VFS_ACCESS>
							>
						>
					>::decide(root, targets, perms);

	/**
	 * Compress the channel log.
	 */
	case irc_channel_config::COMPRESS_LOG:
		return std::min( 
				std::max(decide_helper<channel_node>(root, targets, 
									irc_channel_config::LOG_DETACHED_ONLY,
									perms),
					 	decide_helper<channel_node>(root, targets,
									irc_channel_config::LOG_ALWAYS,
									perms)),
				dependency<user_config_root,
							channel_node,
							irc_channel_config::COMPRESS_LOG,
							user_permissions,
							D::_or< D::value_of<user_perms::IS_ADMIN>,
								D::value_of<user_perms::ENABLE_COMPRESSION> 
							      >
							>::decide(root, targets, perms));
			
	default: 
		return root.get<channel_node, bool>(targets, val);
	}
	return 0;
}

