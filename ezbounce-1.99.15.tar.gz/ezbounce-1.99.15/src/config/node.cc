/**
  * node.cc
  * (C) 2006-2007 Murat Deligonul
  *
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation; either version 2 of the License, or
  * (at your option) any later version.
  */

#include "autoconf.h"

#include <cstdlib>
#include "config/types.h"
#include "config/errors.h"

#include "debug.h"

namespace config {

//--------------------------------------------------
// int node_base::validate_target(const config_target& target, bool writing) const
// {
// 	if (writing) {
// 		if (strcasecmp(target.second, "all") != 0 && strcasecmp(target.second, name) != 0) {
// 			/* FIXME: throw exception */
// 			abort();
// 		}
// 		return 0;
// 	}
// 	
// 	/**
// 	  * Reading an option:
// 	  * 	Leaf node cannot have "all" as a target.
// 	  * 	Target name must be ours or "default"
// 	  */
// 	if (strcasecmp(target.second, "all") == 0) {
// 		/* FIXME: throw exception */
// 		abort();
// 	}
// 
// 	if (strcasecmp(target.second, get_name()) != 0 && !is_default_node()) {
// 		/* FIXME: throw exception */
// 		abort();
// 	}
// 	return 0;
// }
//-------------------------------------------------- 


/**
  * config::strerror()
  *
  * Convert a config_error id code to a string error message.
  */
const char * strerror(config_error e) 
{
	switch (e) {
	case SUCCESS:
		return "Success";
	case TOO_FEW_ARGS:
		return "Not enough arguments";
	case TOO_MANY_ARGS:
		return "Too many arguments";
	case UNKNOWN_OPTION:
		return "Unknown option";
	case ILLEGAL_OPTION:
		return "Illegal option";
	case UNKNOWN_CLASS:
		return "Unknown configuration node";
	case CLASS_OUT_OF_ORDER:
		return "Configuration node out of order";
	}

	return "Unknown error";
}

/**
 * config::stroption()
 */
const char * stroption(option_type t) 
{
	switch(t) {
	case BOOLEAN:
		return "boolean";
	case STRING:
		return "string";
	case INTEGER:
		return "integer";
	default:
		/* XXX:should not happen */
		abort();	
	}
	return "unknown";
}	
}

