/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/vfs_logfile.cc
 * (c) 2007-2008 Murat Deligonul
 **/

#include "autoconf.h"

#include <string>
#include <iostream>
#include <stdexcept>
#include <algorithm>
#include <numeric>
#include "util/strings.h"
#include "logging/logger.h"
#include "logging/vfs_logfile.h"
#include "fs/file_system.h"
#include "fs/directory.h"
#include "fs/error.h"
#include "proxy.h"
#include "debug.h"

using std::string;

/**
 * vfs_logfile class implementation
 */
namespace logging {

using fs::directory;
using fs::file_entry;
using fs::file_system;
using fs::flib_key;

/**
 * Destructor:
 *  Close writer if necessary, close file_entry, and do not leak exceptions.
 */
vfs_logfile::~vfs_logfile()
{
	if (entry) {
		try {
			entry->close(get_chain());
			ircproxy::instance()->vfs()->close(entry);
		}
		catch (...) {
			DEBUG("%s: ignoring caught exception\n", __PRETTY_FUNCTION__);
		}
	}
#ifdef __DEBUG__
	else {
		assert(get_chain() == NULL);
		assert(get_stream() == NULL);
	}
#endif
}

/**
 * Open the file specified by the file_entry, creating a writer and assigning the 
 * necessary streams/chain fields in the base classes. 
 * Also sets up the filtering and completes the IO chain, making it ready for output.
 *
 * Throws an exception on errors.  If this happens, the object is returned to the state
 * it was in when the function was called.
 *
 * NOTE: The writer will be opened in append mode. Currently the only way to change that
 * 	 behavior is to make sure the file_entry refers to a new file.
 */
void vfs_logfile::set_entry(file_entry * e, const io::filter_list& filters)
{
	using std::ios;

	if (entry != NULL) {
		throw std::logic_error("file entry has already been assigned");
	}

	// make sure user doesn't want anything stupid, like two compressors, or
	// a decrypter instead of an encrypter.	
	string reason;
	if (sanity_check_filters(filters, reason) != 0) {
		throw std::invalid_argument(reason);
	}

	file_entry::writer_t * writer = NULL;
	try {
		// TODO: always appends -- add argument to specify mode?
		writer = e->open_writer(ios::binary | ios::app | ios::ate | ios::out);
		set_chain(writer, filters);
		set_stream(&writer->get_stream());
	}
	catch (...) {
		e->close(writer);
		throw;
	}
	// if we got this far, everything should have succeeded
	entry = e;

	assert(get_chain() != NULL);
	assert(get_stream() != NULL);
}

/**
 * Complete the IO chain, making it ready for writing.
 */
void vfs_logfile::complete(vfs_logfile::chain_t * chain) 
{
	chain->complete();
}

/**
 * Flush to disk, using filtered chain's member function.
 */
void vfs_logfile::flush()
{
	filtered_logger<file_entry::writer_t>::flush();
}

/**
 * Return the VFS filename of the log.
 */
string vfs_logfile::filename() const
{
	const string& out = util::strings::my_sprintf("%s/%s", entry->dir()->rel_path(), entry->name());
	return out;
}

/**
 * Create a file on-disk as close as possible to the desired name.
 * Create necessary directory hierarchy.
 * Attach necessary file extensions to name to represent filter configuration.
 * Use existing file if possible; create new one if necessary (already in use
 * or binary file-writing filters requested)
 *
 * NOTE: provided file name must be absolute path
 */
file_entry * vfs_logfile::create_file_entry(const std::string& desired_name, 
						flib_key * fs_key,
						const io::filter_list& filters,
					       	bool want_append,	
						std::string& error)
{
	using std::string;
	using std::accumulate;
	using util::strings::my_sprintf;
	assert(ircproxy::instance()->has_vfs());

	if (desired_name.empty()) {
		error = "invalid filename";
		return NULL;
	}

	if (desired_name[0] != '/') {
		error = "must specify full path to desired file";
		return NULL;
	}

	const size_t slash_pos = desired_name.find_last_of('/'); 
	string name(desired_name, slash_pos+1);
	if (name.empty()) {
		error = "invalid filename";
		return NULL;
	}

	string dir(desired_name, 0, slash_pos);
	if (dir.empty()) {
		dir = "/";
	}
	if (validate_directory(dir, fs_key, error) != 0) {
		return NULL;
	}

	// get file ending
	size_t dot_pos = name.find_last_of('.');
	if (dot_pos == string::npos) {
		dot_pos = name.size();
	}
	string ending(name, dot_pos);
	name.resize(dot_pos);

	// assemble full name with all needed extensions.
	const string& filter_ext = accumulate(filters.begin(), filters.end(), 
							string(""), 
							io::filter_ending_appender());
	ending += filter_ext;

	const bool can_append = count_if(filters.begin(), filters.end(), 
					io::is_filter_io_mode(io::BINARY_MODE)) == 0;

	// Now try creating ..
	file_entry * entry = NULL;
	string candidate = dir + "/" + name + ending;
	file_system * lib = ircproxy::instance()->vfs();
	int open_flags = O_WRONLY | O_APPEND | O_CREAT;
	int err = 0;

	// set exclusive creation flag if needed
	want_append = want_append && can_append;
	if (!want_append) {
		open_flags |= O_EXCL;
	}
	
	for (unsigned count = 1; count <= 50; ++count) {
		entry = lib->open(fs_key, candidate.c_str(), open_flags, 0600, &err);
		if (entry != NULL) {
			if (!entry->is_writing()) {
				// success
				// set file permissions and special 'private flag'
				entry->set_mode(0600);
				entry->set_flags(fs::FE_PRIVATE);
				lib->save(fs_key, entry);
				return entry;
			}
			lib->close(entry);
		}
		else {
			// TODO: check for more serious error codes
		}
		
		// increment one field and try again
		// eg: /path/to/file/xxx.5.log.gz
		my_sprintf(candidate, "%s/%s.%u%s", dir.c_str(), name.c_str(), count, ending.c_str());
	}
	// if we got here, unable to create anything
	error = "unable to create a unique file entry (gave up after 50 tries)";
	return NULL;
}

/**
 * Validate sanity of filter list
 */
int vfs_logfile::sanity_check_filters(const io::filter_list& filters, std::string& error)
{
	const io::filter_kind_stats& stats = for_each(filters.begin(), filters.end(),
							io::filter_kind_stats());
	// TODO: implement
	return 0;
}

/**
 * Make sure requested directory exists or can be created and has
 * proper permissions.
 */
int vfs_logfile::validate_directory(const std::string& dir, flib_key * fs_key, std::string& error)
{
	file_system * lib = ircproxy::instance()->vfs();
	int err = 0;
	directory * d = lib->mkdirs(fs_key, dir.c_str(), 0700, &err);
	if (d == NULL && err != fs::ERR_EXISTS) {
		error = "unable to create directory: " + dir + ": ";
		error += fs::strerror(err);
		return -1;
	}

	err = lib->access(fs_key, dir.c_str(), W_OK | X_OK);
	if (err != 0) {
		error = "unable to access directory: " + dir + ": ";
		error += fs::strerror(err);
		return -1;
	}
	return 0;
}

} /* namespace logging */
