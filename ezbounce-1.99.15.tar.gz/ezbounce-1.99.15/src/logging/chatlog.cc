/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/chatlog.cc
 * (c) 2006-2008 Murat Deligonul
 **/

#include "autoconf.h"

#include <string>
#include <cstdlib>
#include <cctype>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <limits.h>
#include <fcntl.h>
#include "util/strings.h"
#include "logging/chatlog.h"
#include "logging/exceptions.h"
#include "irc/address.h"
#include "fs/file_system.h"
#include "fs/entry.h"
#include "proxy.h"

#include "debug.h"

using std::string;
using util::strings::timestamp;
using util::strings::timestamp_full;
using util::strings::my_strdup;
using util::strings::my_vasprintf;
using util::strings::my_sprintf;

namespace logging {

/**
 * Constructor for chatlog.
 *
 * handle		-- logger handle
 * desired_name		-- desired on-disk name for this chatlog
 * log_type		-- PRIVATE or PUBLIC
 * options		-- logging options
 * filters		-- filters to attach 
 */
chatlog::chatlog(const handle_t& handle, 
			const std::string& desired_name,
			fs::flib_key * fs_key,
			log_type t, 
			int options,
			const io::filter_list& filters)
	: logger(handle),
		vfs_logfile(handle),
		type(t)
{
	using namespace fs;
	std::string error;
	file_system * lib = ircproxy::instance()->vfs();
	file_entry * entry = create_file_entry(desired_name, fs_key, filters, true, error); 

	if (entry == NULL) {
		throw logging_exception(error);
	}

	try {
		// construct io chain from this entry and attach filters
		set_entry(entry, filters);
	}
	catch (...) {
		lib->close(entry);
		throw;
	}
	set_options(options);
	mark_start();
}

/**
  * Stop logging
  */
chatlog::~chatlog() 
{
	DEBUG("chatlog::~chatlog() [%p] destructed\n", this);
	mark_stop();
}

void chatlog::start_message(string& out) const 
{
	string ts;
	timestamp_full(ts);
	my_sprintf(out, "Logfile '%s' started at %s", identifier(), ts.c_str());
}

void chatlog::stop_message(string& out) const 
{
	string ts;
	timestamp_full(ts);
	my_sprintf(out, "Logfile '%s' stopped at %s", identifier(), ts.c_str());
}

/**
 * Log an IRC message.
 *
 * @param event		IRC event
 * @param source	who it's coming from (in a full irc::address structure)
 * @param target	who it's going to
 * @param text		chat text, or part & quit part messages
 * @param extra		for anything that don't fit; for example in KICK, who got kicked
 *			or in CTCPs, the CTCP itself, like CLIENTINFO or VERSION or whatever
 */
int chatlog::write(irc::event event, const irc::address * source, const char * target, const char * text, const char * extra)
{    
	/** 
	 * First: check legality of log requests 
	 */
	const bool is_private = irc::is_private_event(event);
	if (is_private && type != LOG_PRIVATE) {
		//DEBUG("chatlog::write(): [%p] (%s): requested log of private event, but non-private log\n", this, name);
		return -1;
	}
	if (!is_private && type != LOG_CHANNEL) {
		//DEBUG("chatlog::write(): [%p] (%s): requested log of public event, but non-public log\n", this, name);
		return -1;
	}

	const int options = get_options();
	int written = 0;
	char * copy = NULL;
	string header;
	
	/** 
	 * Strip mIRC color crap and prepare log entry header.
	 */
	if (text) {
		strip_color_codes(text, &copy);
		if (copy != NULL) {
			text = copy;
		}
	}
	if (!is_private) {
		my_sprintf(header, "[%s] ", target);
	}

	switch (event) {
	case irc::PUBLIC_NOTICE:
	case irc::PRIVATE_NOTICE:
		written = printf("-%s!%s@%s:%s- %s\n", source->nick(),
				source->user(), source->host(), target, text);
		break;

	case irc::JOIN:
		written = printf("*** %s (%s@%s) has joined %s\n", source->nick(),
				source->user(), source->host(), target);
		break;

	case irc::PART:
		written = printf("*** %s (%s@%s) has parted %s (%s)\n", source->nick(),
				source->user(), source->host(), target, text);
		break;
	
	case irc::TOPIC:
		written = printf("*** %s changes %s topic to: %s\n", source->nick(), target, text);
		break;

	case irc::KICK:
		written = printf("*** %s (%s@%s) has kicked %s from %s (%s)\n", source->nick(), source->user(),
				source->host(), extra, target, text);
		break;

	case irc::MODE:
		written = printf("*** %s changes %s mode to: %s\n", source->nick(), target, text);
		break;

	case irc::QUIT:
		written = printf("*** %s (%s@%s) has quit IRC (%s)\n", source->nick(), source->user(),
				source->host(), text);
		break;

	case irc::NICK_CHANGE:
		written = printf("*** %s changes nick to %s\n", source->nick(), extra);
		break;
	
	case irc::PRIVATE_CTCP:
	case irc::PUBLIC_CTCP:
		written += printf("*** CTCP %s [%s] from %s (%s@%s) to %s\n", extra, text, source->nick(),
				source->user(), source->host(), target);
		break;

	case irc::PUBLIC_ACTION:
		if (options & LOG_FULL_ADDRS) {
	case irc::PRIVATE_ACTION:
			written += printf("%s* %s!%s@%s %s\n", header.c_str(), source->nick(), 
					source->user(), source->host(), text);
		}
		else {
			written += printf("%s* %s %s\n", header.c_str(), source->nick(), text);
		}
		break;

	case irc::PUBLIC_PRIVMSG:
		if (options & LOG_FULL_ADDRS) {
	case irc::PRIVATE_PRIVMSG:
			written += printf("%s<%s!%s@%s> %s\n", header.c_str(), source->nick(), 
								source->user(), source->host(), text);
		} 
		else {	
			written += printf("%s<%s> %s\n", header.c_str(), source->nick(), text);
		}
		break;

	default:
		// ??
		break;
	}
	delete[] copy;
	return written;
}

/**
 * Remove Bold, Underline, Reverse, and Color codes from
 * the text. Copy on write semantics are used.  If the text must be modified,
 * a copy is created and stored in the out pointer.
 */
void chatlog::strip_color_codes(const char * text, char ** out)
{
	static const char BOLD  = 2,
		     COLOR = 3,
		     RESET = 15,
		     REVERSE = 22,
		     UNDERLINE = 31;

	*out = NULL;

	const char * p = text;
	char * o = NULL;
	int s = 0;
	while (*p) {
		if (s == 0) {
			// Initial state
			switch (*p) {
			case COLOR:
				s = 1;
			case RESET:
			case BOLD:
			case UNDERLINE:
			case REVERSE:
				if (!o) {
					o = *out = my_strdup(text);
					memcpy(o, text, p-text);					
				}
				break;
			default:
				goto copy;
			}
		}
		else if (s == 1) {
			 // mIRC Color code found:
			 // Unfortunately, this is the most ambiguous, piece of crap
			 // "standard" ever.
			if (*p == '0') {
				s = 2;
			}
			else if (*p == '1') {
				s = 3;
			}
			else if (*p >= '2' && *p <= '9') {
				s = 4;
			}
			else {
				s = 0;
				goto copy;
			}
		}
		else if (s == 2) {
			// sequence ^C0
			if (*p >= '0' && *p <= '9') {
				s = 4;
			}
			else if (*p == ',') {
				s = 5;
			}
			else {
				s = 0;
				--p;
				goto copy;
			}
		}
		else if (s == 3) {
			// sequence ^C1
			if (*p >= '0' && *p <= '5') {
				s = 4;
			}
			else if (*p == ',') {
				s = 5;
			}
			else {
				s = 0;
				--p;
				goto copy;
			}
		}
		else if (s == 4) {
			// sequences:
			// ^C0[0-9]
			// ^C1[0-5]
			// ^C[2-9]
			if (*p == ',') {
				s = 5;
			}
			else {
				s = 0;
				goto copy;
			}
		}
		else if (s == 5) {
			// comma after legal start
			if (*p >= '2' && *p <= '9') {
				// transition to initial state,
				// without copying this character
				s = 0;
			}
			else if (*p == '0') {
				s = 6;
			}
			else if (*p == '1') {
				s = 7;
			}
			else {
				s = 0;
				--p;
				goto copy;
			}
		}
		else if (s == 6) {
			// sequence ^Cxx,0
			if (*p >= '0' && *p <= '9') {
				s = 0;
			}
			else {
				s = 0;
				p -= 2;
				goto copy;
			}
		}
		else if (s == 7) {
			// sequence ^Cxx,1
			if (*p >= '0' && *p <= '5') {
				s = 0;
			}
			else {
				s = 0;
				p -= 2;
				goto copy;
			}
		}
		++p;
		continue;			

copy:
		// normal iteration; copy to target
		if (o != NULL) {
			*o++ = *p;
		}
		++p;
	}
	if (o != NULL) {
		*o = 0;
	}
}

} /* namespace logging */
