/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * logging/logging.cc
 * (c) 2007 Murat Deligonul
 **/

#include "autoconf.h"

#include <vector>
#include <ostream>
#include <iterator>
#include <ctime>
#include "util/generic.h"
#include "util/strings.h"
#include "util/tokenizer.h"
#include "logging/logger.h"
#include "logging/ostream_logger.h"
#include "debug.h"

using util::strings::timestamp;
using util::strings::timestamp_full;

namespace logging {

const time_t * logger::time_ptr = NULL;

/**
 * Initialize the logging system.
 */
/* static */ void logger::initialize(const time_t * ptr) 
{
	time_ptr = ptr;	
}

/**
 * Fill a logger::message struct with default values.
 */
/* static */ void logger::init_message(logger::message * msg, level level, int options) 
{
	msg->time 	= time_ptr ? *time_ptr : time(NULL);
	msg->level 	= level;
	msg->options 	= options;		// defaults to -1
	msg->header 	= NULL;
	msg->message 	= "";
}

/**
 * Translate log level
 */
/* static */ const char * logger::strlevel(level level)
{
	switch (level) {
	case DEBUG:
		return "DEBUG";
	case FINE:
		return "FINE";
	case NORMAL:
		return "INFO";
	case WARNING:
		return "WARNING";
	case SEVERE:
		return "SEVERE";
	case NONE:
		return "[you should not be seeing this]";
	}
	return "UNKNOWN";
}

/**
 * Display a message indicating that logging has started.  
 * Return number of bytes written.
 */
int logger::mark_start()
{
	std::string msg;
	start_message(msg);
	return this->printf("%s\n", msg.c_str());
}

int logger::mark_stop()
{
	std::string msg;
	stop_message(msg);
	return this->printf("%s\n", msg.c_str());
}

/**
 * Display a message announcing the present time in full format.
 */
int logger::mark_timestamp()
{
	std::string ts;
	timestamp_full(ts);	
	return this->printf("the time is now: %s\n", ts.c_str());
}

void logger::set_options(int o)
{
	options = o;
}

/**
 * printf()-like output with logging level.
 * Returns the number of bytes printed, or -1 on error.
 */
int logger::printf(level level, const char * fmt, ...)
{
	if (!is_loggable(level)) {
		return 0;
	}
	va_list ap;
	va_start(ap, fmt);
	int r = this->vprintf(level, fmt, ap);
	va_end(ap);
	return r;
}

/**
 * printf()-like output, default to none.
 */
int logger::printf(const char * fmt, ...)
{
	if (!is_loggable(NORMAL)) {
		return 0;
	}
	va_list ap;
	va_start(ap, fmt);
	int r =	this->vprintf(NORMAL, fmt, ap);
	va_end(ap);
	return r;
}

int logger::vprintf(level level, const char * fmt, va_list ap)
{
	using namespace util::strings;
	struct message msg;
	init_message(&msg, level);

	char * ptr = NULL;
	int r = my_vasprintf(&ptr, fmt, ap);
	if (ptr == NULL) {
		return -1;
	}

	msg.message = ptr;
	r = write_message(&msg);
	delete[] ptr;
	return int(r);
}

/**
 * Log a single message.
 * The message struct contains all the information needed: level, timestamp, etc.
 * Should the message contain newlines, the result will be correctly formatted to
 * not mess up the output.  Also, a newline is automatically added if missing, and 
 * extraneous newlines are ignored.
 *
 * Return number of bytes return, or -1 on error.
 */
ssize_t logger::write_message(const message * msg)
{
	using std::vector;
	using std::string;

	if (!is_loggable(msg->level)) {
		return 0;
	}
	vector<sl_pair> out;
	string ts;
	
	// print out timestamp first, then handle and info level
	if (options & LOG_TIMESTAMP) {
		// make timestamp here 
		timestamp(ts, "[%H:%M]", msg->time);
		ts += ' ';
		out.push_back(sl_pair(ts.c_str(), ts.size()));
	}
	else if (options & LOG_FULL_TIMESTAMP) {
		timestamp_full(ts, msg->time);	
		ts += ' ';
		out.push_back(sl_pair(ts.c_str(), ts.size()));
	}

	if (options & LOG_HANDLE) {
		out.push_back(sl_pair("[", 1));
		out.push_back(sl_pair(handle.c_str(), handle.size()));
		out.push_back(sl_pair("] ", 2));
	}

	if (options & LOG_LEVEL) {
		const char * str = strlevel(log_level);
		size_t len = strlen(str);
		out.push_back(sl_pair(str, len));
		out.push_back(sl_pair(" ", 1));
	}

	const size_t head_size = out.size();

	// header? 
	if (msg->header != NULL) {
		out.push_back(sl_pair(msg->header, strlen(msg->header)));
		out.push_back(sl_pair(" ", 1));
	}

	// finally, the message
	using util::strings::tokenizer;
	using util::strings::delimeter_seeker;

	typedef tokenizer<delimeter_seeker<>, const char *, sl_pair> 	message_tokenizer;

	message_tokenizer splitter(msg->message, msg->message + strlen(msg->message), 
					delimeter_seeker<>("\r\n"));
	bool first = true;
	for (message_tokenizer::const_iterator i = splitter.begin(), e = splitter.end();
						i != e;
						++i) {
		if (first) {
			first = false;
		}
		else {
			out.reserve(out.size() + head_size + 2);
			util::copy_n(out.begin(), head_size, std::back_inserter(out));
		}
		out.push_back(*i);
		out.push_back(sl_pair("\n", 1));
	}
	
	ssize_t r = writev(out);
	if (options & ALWAYS_FLUSH) {
		flush();
	}
	return r;
}


/**
 * Default implementation of writev(): simply call write() for
 * each member of the array.
 */
ssize_t logger::writev(const std::vector<sl_pair>& vec)
{
	using std::vector;
	ssize_t out = 0;
	for (vector<sl_pair>::const_iterator i = vec.begin(), e = vec.end();
			i != e;
			++i) {
		const sl_pair& v = *i;
		int r = this->write(v.first, v.second);
		if (r < 0) {
			return r;
		}
		out += r;
	}
	return out;
}

void logger::start_message(std::string& out) const
{
	out = "logging started";
}

void logger::stop_message(std::string& out) const
{
	out = "logging stopped";
}

/******************************************
 *
 * Implementation of ostream_logger
 *
 ******************************************/
void ostream_logger::flush() 
{
	get_stream()->flush();
}

ssize_t ostream_logger::write(const char * data, size_t len)
{
	std::ostream * out = get_stream();
	out->write(data, len);
	
	if (out->bad()) {
		return -1;
	}
	return len;
}

ssize_t ostream_logger::writev(const std::vector<sl_pair>& vec)
{
	ssize_t written = 0;
	std::ostream * out = get_stream();
	for (std::vector<sl_pair>::const_iterator i = vec.begin(), e = vec.end();
						i != e;
						++i) {
		const sl_pair& s = *i;
		out->write(s.first, s.second);
		if (out->bad()) {
			return -1;
		}
		written += s.second;
	}
	return written;		 
}

} /* namespace logging */
