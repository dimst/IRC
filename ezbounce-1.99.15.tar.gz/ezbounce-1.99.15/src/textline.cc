/**************************************************************************
 *                                                                        *
 *  This program is free software; you can redistribute it and/or modify  *
 *  it under the terms of the GNU General Public License as published by  *
 *  the Free Software Foundation; either version 2 of the License, or     *
 *  (at your option) any later version.                                   *
 *                                                                        *
 **************************************************************************
 * textline.cc
 * (c) 2006 Murat Deligonul
 */

/**
  * Stores a line of IRC text and allows easy tokenization.  Tokenization is on-demand,
  * meaning the string won't be tokenized until an actual token is requested.  The source string
  * is not modified, and not copied until tokenization is requested.
  *
  * Supports tokenization of string literals.  Inside string literals, escape characters 
  * like \\ and \" are supported.  The resulting literal is returned as a single token.
  * The string should be legally terminated, (i.e. with a proper " and no trailing 
  * characters in that token), but these rules aren't actually enforced. If a string literal 
  * turns out to be ill-formed, it is treated as raw text.
  */

#include "autoconf.h"
#include <cstdlib>
#include <cstring>
#include "util/strings.h"
#include "textline.h"
#include "debug.h"

using util::strings::my_strdup;
using util::strings::non_null;

const char textline::DELIMS[] = " \t";

/**
  * Create a new textline and tokenize it if requested.
  */
textline::textline(const char * source, int tokens)
	: str(non_null(source)), 
	  buffer(NULL),
	  tokens_found(0),
	  tokens(1, (char *) NULL),
	  properties(1, int(OTHER))
{
	//DEBUG("textline::textline() [%p]: %s\n", this, source);
	tokenize(tokens);
}

/**
  * Tokenize so that we have 'max' tokens.
  * If we already have more, return number of tokens we have.
  * If there are no more tokens, return number of tokens we could find.
  * The table is padded with NULL pointers for each requested token that doesn't exist.
  *
  * Special Argument: MAX: tokenizes the string completely.
  */
unsigned int textline::tokenize(unsigned int max) const 
{
	if (max != MAX && max <= tokens_found) {
		return tokens_found;
	}

	if (!buffer) {
		buffer = my_strdup(str);
	}
	
	DEBUG("textline::tokenize() [%p]: retokenizing to accomodate %d tokens\n", this, max);

	char * start;
	char ** current;
	int * current_flags;
	
	current = &tokens[tokens_found];
	current_flags = &properties[tokens_found];

	if (*current == NULL) {
		if (tokens_found == 0) {
			start = buffer;
		}
		else {
			char * last = tokens[tokens_found-1];
			start = last+strlen(last);
		}
	}
	else {
		start = *current;
	}

	char * p = start;
	int state = 0;
	int sl_offset = 0;		/** to account for escape characters in string literals **/

	while (*p) {
		if (state == 0) {
			if (!strchr(DELIMS, *p)) {   
				/** Found non delimeter: check for string literal start **/
				*current = p;
				if (*p == '\"') {
					*p = 0;
					++*current;
					*current_flags = (int) STRING_LITERAL;
					sl_offset = 0;
					state = 2;
				} 
				else {
					state = 1;
				}
				tokens.push_back(NULL);
				properties.push_back((int) OTHER);
				current = &tokens[++tokens_found];
				current_flags = &properties[tokens_found];
			}
		} 
		else if (state == 1) {
			if (strchr(DELIMS, *p)) {   /* found delimeter */
				*p = 0;
				state = 0;
				if (tokens_found == max) {
					/** position offset of next token to next character **/					  
					*current = p+1;
					assert((unsigned int)tokens_found + 1 == tokens.size());
					assert(tokens.size() == properties.size());
					return tokens_found;
				}
			}
		} 
		else {
			/** Handle string literal. **/
			char peek = *(p+1);
			if (*p == '\\') {
				/* Escape character */
				*(p-sl_offset) = peek;
				++sl_offset;
				++p;	
			} 
			else if (*p == '\"') {
				if (peek == 0 || strchr(DELIMS, peek)) {
					/**
					  * String literal legally terminated.
					  */
					*(p-sl_offset) = 0;
					state = 0;
					if (tokens_found == max) {
						*current = (p+1);
						assert((unsigned int)tokens_found + 1 == tokens.size());
						assert(tokens.size() == properties.size());
						return tokens_found;
					}
				}
				else {
					// *NOT* legally terminated -- not a valid string literal; 
					// back up and undo this mess. (including escape sequences)
					char *& lstart = tokens[tokens_found-1];
					int& prop = properties[tokens_found - 1];
					
					--lstart;
					prop = (int) OTHER;
					ptrdiff_t offset = (lstart - buffer); 
					memcpy(lstart, str + offset, (p-buffer)-offset);
					state = 1;
				}

			} 
			else {
				*(p-sl_offset) = *p;						
			}
		}
		++p;
	}

	/* NULL character reached */
	if (state == 2) {
		/** 
		  * Found null character while parsing string literal.
		  * Back up and fix the mess.
		  */
		char *& lstart = tokens[tokens_found-1];
		int& prop = properties[tokens_found-1];

		--lstart;
		prop = (int) OTHER;
		ptrdiff_t offset = (lstart - buffer); 
		memcpy(lstart, str + offset, (p-buffer)-offset);
	}

	*current = NULL;

	/**
	  * Insert padding up until the requested amount of tokens with NULL pointers.
	  */
	if (max != MAX && tokens_found < max) {
		std::fill_n(back_inserter(tokens), max - tokens.size() + 1, (char *) NULL);
		std::fill_n(back_inserter(properties), max - properties.size() + 1, int(OTHER));
	}

	assert(tokens.size() == properties.size());
	return tokens_found;				
}


/** 
 * Get all text including the n'th token (0 based) and afterward
 * (as one string, ignoring tokenization).
 */
const char * textline::get_rest(unsigned n) const 
{
	const char * start = operator[](n); 
	if (start == NULL) {
		return NULL;
	}
	if (start != buffer && start[-1] == '\"') {
		--start;
	}
	return &str[start-buffer];
}

#ifdef __DEBUG__
void textline::dump()  const
{
	fprintf(stderr, "complete string:   %s\n", str);
	if (tokens.size() == 1) {
		fprintf(stderr, "hasn't been tokenized yet\n");
		return;
	}

	fprintf(stderr, "num tokens so far: %d\n", tokens_found);
	for (unsigned i = 0; i < tokens.size(); ++i) {
		fprintf(stderr, "token %u: \t\t%s\n", i, tokens[i]);
	}
	return;	
}
#endif

//--------------------------------------------------
// int main(int argc, const char ** argv) {
// 	if (argc < 2) {
// 		printf("Enter arguments\r\n");
// 		exit(1);
// 	}
// 	textline args(argv[1]);
// 	args.tokenize(50);
// 	args.dump();
// }
//-------------------------------------------------- 
