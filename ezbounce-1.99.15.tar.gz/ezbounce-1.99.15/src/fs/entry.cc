/***************************************************************************
 * Part of ezbounce
 * (c) 2006-2008 Murat Deligonul
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 */

#include "autoconf.h"

#include <stdexcept>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "util/strings.h"
#include "fs/entry.h"
#include "fs/directory.h"

#include "debug.h"

using namespace util::strings;

namespace fs {

/**
  * In-memory representation of a file in the VFS.
  * Obtained through file_system open() member function.
  * Must be discarded through file_system close() member function.
  *
  * File can be open()'ed for IO through file_entry::open()
  *		-however-
  *	1) only one writer is permitted at a time (io chain is stored
  *		as data member) 
  *     2) multiple simultaneous readers are permitted, even when
  *	   there is a writer
  * 	3) the 'usage_count' member variables keeps track of how many
  *  	   references to this object exist.
  *     4) upon completion of IO, call file_entry::close(writer)
  *
  * @param d		directory that the entry is a child of.
  * @param fname	name of the file
  * @param owner	owner id of the file
  * @param group	group id of the file
  */
file_entry::file_entry(directory * d, const char * fname, const char * owner, const char * group)
			: _dir(d),
			_usage_count(0),
			fwriter(NULL)
{
	set_name(fname);
	set_owner(owner);
	set_group(group);

	data.mode = 0;
	data.creation = 0;
	data.size = 0;
	data.flags = 0;
	
	DEBUG("%s [%p] Constructed in directory [%p]: %s\n", __PRETTY_FUNCTION__, this, d, fname);	
}

/**
 * Create a new file_entry belong to a specific directory, with default values for 
 * all other fields.
 */
file_entry::file_entry(directory * d)
		: _dir(d),
		_usage_count(0),
		fwriter(NULL)
{
	DEBUG("%s [%p] Constructed in directory [%p]: (default!)\n", __PRETTY_FUNCTION__, this, d);	

	data.mode = 0;
	data.creation = 0;
	data.size = 0;
	data.flags = 0;
}

/**
  * Open file for reading.  Exception thrown if error occurs.
  */
file_entry::reader_t * file_entry::open_reader(reader_t::openmode mode)
{
	const std::string& path = my_sprintf("%s/%s", dir()->abs_path(), name());
	reader_t * reader = new reader_t(path.c_str(), mode);
	update_size();
	return reader;
}

/**
 * Open file for writing.  Exception thrown if error occurs, or if file is 
 * already being written to.
 */
file_entry::writer_t * file_entry::open_writer(writer_t::openmode mode)
{
	if (fwriter != NULL) {
		throw std::logic_error("file is locked (currently being written to)");	
	}

	const std::string& path = my_sprintf("%s/%s", dir()->abs_path(), name());
	fwriter = new writer_t(path.c_str(), mode);
	update_size();
	DEBUG("file_entry::open(): Write access granted for %s\n", path.c_str());
	return fwriter;
}

/**
  * Close reader that has been opened for IO.  Also deletes the object; the
  * pointer provided will no longer be valid after this call.
  * NOTE: no way of checking whether the reader belonged to this file_entry.  It just
  * 	  deletes whatever reader it gets.  (Thus, NULL values are automatically ignored)
  */
void file_entry::close(reader_t * reader) 
{
	delete reader;
}

/**
 * Close writer that has been opened for IO.  The writer must belong to this file_entry,
 * but NULL values are ignored.
 * The writer object is also deleted; the pointer will no longer be valid after this call.
 */
void file_entry::close(writer_t * writer) 
{
	if (writer == NULL) {
		return;
	}
	if (writer != fwriter) {
		throw std::invalid_argument("writer doesn't belong to this file entry");
	}
	DEBUG("file_entry()::close(): Write access closed for %s/%s\n",
			dir()->abs_path(), name());
	delete fwriter;
	fwriter = NULL;	
}

/**
  * Uses stat(2) to determine size of the file we point to.
  * Set to 0 if file doesn't yet exist.
  */
void file_entry::update_size()
{
	struct stat st;
	memset(&st, 0, sizeof(st));
	char * path = my_strdup3(dir()->abs_path(), "/", name());
	int r = stat(path, &st);
	delete[] path;

	if (r >= 0) {
		set_size(st.st_size);
	} 
	else {
		set_size(0);
	}
}

/* static */ const char * file_entry::strerror(int err) 
{
	switch (err) {
	case ERR_LOCKED:
		return "File is locked (currently being written to)";
	case ERR_OPEN:
		return "Unable to open file for I/O";
	}
	return "Unknown error";
}

} // namespace fs
