/***************************************************************************
 * Part of ezbounce
 * (c) 2006-2008 Murat Deligonul
 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 *
 *  * 3/08 - Implemented Unix-style permissions with user/group credentials.
 *  * 3/06 - Completely rewritten.  Class renamed.  
 *	     Several new features including support for directories.
 *	     Several features ditched to rely on inherent OS support instead.
 *	     Database format is mostly backwards compatible. 
 *	     Database no longer fully loaded into memory.
 */

#include "autoconf.h"

#include <vector>
#include <string>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cerrno>
#include <climits>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

// FIXME: check for these includes
#include <sys/param.h>

#ifdef HAVE_SYS_SYSLIMITS_H
#include <sys/syslimits.h>
#endif
#include "util/tokenizer.h"
#include "util/strings.h"
#include "util/generic.h"
#include "fs/file_system.h"
#include "fs/directory.h"
#include "fs/credentials.h"
#include "fs/entry.h"
#include "fs/error.h"
#include "fs/key.h"
#include "debug.h"

// XXX XXX XXX XXX XXX XXX XXX
// TODO:
// XXX XXX XXX XXX XXX XXX XXX
// need better error message from directory class if looking up blank name
// implement import
// create more tests
// automatically import files in a new directory?
// set rehash parameters for the hash tables
// can we suspend rehash during prunes?
// ls doesn't report all errors properly

using std::string;
using namespace util::strings;

namespace fs {

/**
  * Construct a new VFS in the directory 'p'.
  * Will automatically convert an older database file to our
  *  current version.
  */  
file_system::file_system(const char * p) : 
	directories(13),
	root(NULL)
{
	// check if we can access it.
	if (::access(p, R_OK | W_OK | X_OK) != 0) {
		// complain
		throw flib_exception("Unable to access requested path", errno);
	}

	// is it a dir ? 
	struct stat st;
	memset(&st, 0, sizeof(st));
	::stat(p, &st);
	if (!S_ISDIR(st.st_mode)) {
		// complain	
		throw flib_exception("Requested path is not a directory");
	}

	root = new directory(p, "root", "root");
	directories.insert("/", root);

	// brand new VFS?
	if (!root->exists()) {
		DEBUG("file_system::file_system(): Detected new filesystem; creating root database\n");
		root->create();
	}

	int j = root->validate();
	if (j < 0) {
		// errors
		DEBUG("file_system::file_system(): Unable to validate root directory: %s\n", strerror(j));
		delete root;
		throw flib_exception("Unable to validate root directory", j);	
	}
	
	/** setup 'root' user and file access key **/
	root_creds = new credentials("root", "root");
	root_creds->set_flag(credentials::SUPER_USER);
	root_key = new flib_key(root_creds, root); 

	/** setup ownership and basic directories if needed **/
	root->entry()->set_mode(0755);

	int err = 0;
	file_entry * fe = open(root_key, "/home", O_RDWR, 0755, &err);
	if (fe == NULL) {
		/** create /home directory **/
		DEBUG("file_system::file_system(): creating brand new /home/ directory\n");
		directory * d = mkdir(root_key, "/home", 0755, &err);
		if (d == NULL) {
			delete root_key;
			delete root_creds;
			delete root;
			throw flib_exception("Unable to create '/home' directory");
		}
		d->entry()->set_mode(0755);
		assert(strcmp(d->entry()->owner(), "root") == 0);
		/** success **/
		return;	
	}

	if (!(fe->flags() & FE_DIRECTORY)) {
		this->close(fe);
		delete root_key;
		delete root_creds;
		delete root;
		throw flib_exception("'/home' must be a directory");		
	}

	// success
	DEBUG("file_system::file_system(): detected existing /home directory\n");
	this->close(fe);	
}

/**
 * Destroy active directory objets one by one, starting 
 * with the leaf nodes.
 */
file_system::~file_system() 
{
	using std::for_each;
	using util::delete_ptr;
	using util::counted_object;

	delete root_key;
	delete root_creds;

	std::vector<directory *> dirs;
	root->level_order_traverse(dirs);		
	assert(dirs.size() == directories.size());

#ifdef __DEBUG__
	string str;
	util::print_into(dirs.rbegin(), dirs.rend(), str);
	DEBUG("%s: destroying in this order: %s\n", __PRETTY_FUNCTION__, str.c_str());
#endif
	assert(counted_object<flib_key>::count() == 0);
	for_each(dirs.rbegin(), dirs.rend(), delete_ptr());
}

/**
 * Allocate and return a key object used for accessing the VFS.
 * Also ensures that a home directory exists for the user. 
 *
 * @param c		pointer to fs::credentials object
 * @param err		pointer to int to store potential error codes
 * @return a new fs::flib_key object, or NULL on error.
 */ 
flib_key * file_system::create_key(const credentials * c, int * err)
{
	resolved_path rp;
	char * buf = my_strdup2("/home/", c->user());
	*err = resolve_path(root_key, buf, &rp);
	directory * dir = rp.dir();	
	
	if (*err == 0) {
		dir = load_directory(root_key, rp.dir(), rp.name(), err);
	}
	
	if (*err != 0) {
		if (*err != ERR_DOESNT_EXIST) {
			// unusual error -- usually database access problem or 
			// file already existing on disk
			delete[] buf;
			return NULL;
		}

		/** 
		 * Didn't exist: could be first time accessing, so create
		 * his home directory. 
		 */
		DEBUG("file_system::create_key(): Creating new home directory for %s\n", c->user());
		dir = mkdir(root_key, buf, 0700, err);
		if (dir == NULL) {
			/** Ok, this shouldn't happen at all. **/
			delete[] buf;
			return NULL;
		}	
		dir->entry()->set_owner(c->user());
		dir->entry()->set_group(c->group());
		dir->entry()->set_flags(FE_DIRECTORY);
		
		save(root_key, dir->entry());
	}			
	delete[] buf;
	
	flib_key * key = new flib_key(c, dir);
	DEBUG("file_system::create_key(): constructed key for '%s' in directory: '%s'\n", c->user(), dir->rel_path());
	return key;
}

/**
 * Access a file with requested mode.  Doesn't open() it, per se, but 
 * succeeds only if requested modes match (as listed in the database file).
 * Increaes usage count of found file entry.
 *
 * This will also open directories.  
 *
 * Returns a file_entry pointer which must be released with file_system::close()
 * Returns NULL on error with err set to the appropriate error code.  
 */
file_entry * file_system::open(const flib_key * key, const char * name, int flags,
					mode_t mode, int * err)
{
	resolved_path rp;
	
	*err = resolve_path(key, name, &rp);
	if (*err < 0) {
		return NULL;
	}

	directory * const dir = rp.dir();
	file_entry * entry = rp.cached_entry();
	
	if (entry == NULL) {
		*err = dir->batch_start();
		if (*err < 0) {
			return NULL;
		}

		entry = dir->disk_lookup(rp.name(), err);		
		if (entry == NULL) {
			if (!(flags & O_CREAT)) {
				*err = ERR_DOESNT_EXIST;
				dir->batch_end();
				return NULL;
			}
			/**
			 * File creation requested: check 
			 * permissions of parent directory and create here.
			 */
			int j = this->access_entry_only(key, dir->entry(), X_OK | W_OK);
			if (j < 0) {
				*err = ERR_ACCESS;
				dir->batch_end();
				return NULL;
			}

			/** 
			 * Create on disk. It wasn't in the VFS, so it had better not 
			 * exist on disk already.  We can check this with the O_EXCL flag.
			 */
			flags |= O_EXCL;
			char * buff = my_strdup3(dir->abs_path(), "/", rp.name()); 
			j = ::open(buff, flags, 0600);
			delete[] buff;
			
			if (j < 0) {				
				*err = errno == EEXIST ? ERR_EXISTS_ON_DISK : ERR_CREATION;
			       	dir->batch_end();
				return NULL;
			}
			::close(j);
			
			/** 
			 * Create new file_entry and save to disk. 
			 */
			entry = new file_entry(dir, rp.name(), key->creds()->user(), key->creds()->group());
			entry->set_mode(mode & ~key->umask());
			j = dir->write(entry, true);
			if (j < 0) {
				delete entry;
				*err = j;
				dir->batch_end();
				return NULL;				
			}			
		}
	       	else if (flags & (O_EXCL)) {
			/**
			 * Exclusive create requested, but file exists. 
			 */
			delete entry;
			*err = ERR_EXISTS;
			dir->batch_end();
			return NULL;
		}
		dir->cache_insert(entry);
		dir->batch_end();
	}

	// translate open flags to access() flags
	int access_flags = 0;
	if (flags & O_RDWR || flags & O_RDONLY) {
		access_flags |= R_OK;
	}
	if (flags & O_RDWR || flags & O_WRONLY) {
		access_flags |= W_OK;
	}

	int r = this->access_entry_only(key, entry, access_flags);
	if (r < 0) {
		*err = r;
		return NULL;
	}

	entry->inc_count();	
	entry->update_size();
	return entry;
}

/**
 * 'Closes' a file by decrementing usage count of its
 * file_entry. 
 */
int file_system::close(file_entry * entry) 
{
	directory * dir = entry->dir();
	assert(dir);

	file_entry * orig = entry;
	entry = dir->cache_lookup(entry->name());

	if (entry == NULL || entry != orig) {
		return ERR_BADFILE;
	}
	assert(entry->usage_count() > 0);
	entry->dec_count();
	
	// remove entries whose counts have reached zero
	if (entry->usage_count() == 0) {
		dir->cache_remove(entry->name());
		delete entry;
	}
	return 0;
}

/**
 * Save a file_entry to disk. 
 * 
 * @param key		VFS access key
 * @param entry		entry to save to disk
 */
int file_system::save(const flib_key * key, file_entry * entry) 
{
	if (entry == root->entry()) {
		// entry for "/", currently not stored on disk
		return 0;
	}
	int r = entry->dir()->write(entry);
	if (r < 0) {
		return r;
	}
	return 0;
}


/**
 * Check whether access is allowed.  This is similar to the UNIX access() system call.
 *
 * @param key		VFS access key
 * @param entry		file entry to attempt access to
 * @param mode		like UNIX access() call, bitmask containing R_OK, W_OK and X_OK
 * @return 0 on success, error code otherwise. 
 */
int file_system::access(const flib_key * key, file_entry * entry, int mode) 
{
	const credentials * c = key->creds();

	const bool super_user = c->flags() & credentials::SUPER_USER;
	const bool uname_match = strcmp(c->user(), entry->owner()) == 0;
	const bool is_private = (entry->flags() & FE_PRIVATE) &&
					!(entry->flags() & FE_DIRECTORY);

	// first rule: "private files"
	// certain files can be marked with this flag which prevents anyone (even superuser) from
	// accessing them except for the owner.
	// NOTE: "private" flag on directories is ignored
	if (is_private && !uname_match) {
		return ERR_PRIVATE_FILE;
	}

	// super user access
	if (super_user) {
		return 0;
	}

	// walk directory structure
	if (entry != root->entry()) {
		directory * p = entry->dir();
		int r = access(key, p->entry(), X_OK);
		if (r != 0) {
			return r;
		}
	}
	return access_entry_only(key, entry, mode);
}

/**
 * Alternate version of access() that operates on a string path.
 */
int file_system::access(const flib_key * key, const char * name, int mode)
{
	resolved_path rp;
	
	int err = resolve_path(key, name, &rp);
	if (err < 0) {
		return err;
	}

	directory * const dir = rp.dir();

	file_entry * entry = rp.cached_entry();
	if (entry == NULL) {
		// entry not cached; load it
		err = dir->batch_start();
		if (err < 0) {
			return err;
		}

		entry = dir->disk_lookup(rp.name(), &err);
		if (entry == NULL) {
			dir->batch_end();
			return err;
		}
		dir->cache_insert(entry);
		dir->batch_end();
	}
	return access_entry_only(key, entry, mode);
}

/**
 * Helper (private) function for access() that considers the entry only (without walking path).
 * This is useful for cases where access to the directory was already confirmed, and another
 * access() call is needed to check an entry in the directory.
 */
int file_system::access_entry_only(const flib_key * key, file_entry * entry, int mode)
{
	const credentials * c = key->creds();

	const bool super_user = c->flags() & credentials::SUPER_USER;
	const bool uname_match = strcmp(c->user(), entry->owner()) == 0;
	const bool is_private = (entry->flags() & FE_PRIVATE) &&
					!(entry->flags() & FE_DIRECTORY);

	// again the first rule checks the private flag
	if (is_private && !uname_match) {
		return ERR_PRIVATE_FILE;
	}

	// super user access
	if (super_user) {
		return 0;
	}
	// finally, check permissions
	int file_mode = entry->mode();

	if (uname_match) {
		file_mode >>= 6;
	}
	else if (c->has_group(entry->group())) {
		file_mode >>= 3;
	}

	if ((file_mode & mode & (R_OK | W_OK | X_OK)) == mode) {
		return 0;
	}
	return ERR_ACCESS;
}


/**
 * Remove a file from the VFS. 
 *
 * @param key		VFS access key
 * @param name		path to file to delete
 * @return 0 on success, error code otherwise.
 */
int file_system::unlink(const flib_key * key, const char * name) 
{
	resolved_path rp;
	int err = resolve_path(key, name, &rp);
	if (err < 0) {
		return err;
	}		
	
	directory * const dir = rp.dir();

	file_entry * cached = rp.cached_entry();
	if (cached != NULL) {
		if (cached->usage_count() > 0) {
			return ERR_BUSY;
		}
		if (cached->flags() & FE_DIRECTORY) {
			return ERR_DIRECTORY;
		}
	}

	// set name to final element of path
	name = rp.name();

	// find entry and delete in single database access
	err = dir->batch_start();
	if (err) {		
		return err;	
	}

	file_entry * e = dir->disk_lookup(name, &err);
	if (e == NULL) {		
		dir->batch_end();
		return err;
	}
	if (e->flags() & FE_DIRECTORY) {
		delete e;
		dir->batch_end();
		return ERR_DIRECTORY;
	}
	
	delete e;

	// found it; now check permissions: erasing is always permitted if the user has 
	// write access to the directory.
	// Exception: 'restricted deletion flag' like in /tmp requires user to own file
	// TODO: check for sticky
	err = access_entry_only(key, dir->entry(), W_OK | X_OK);
	if (err < 0) {
		dir->batch_end();
		return err;
	}

	// everything checked out -- can actually delete now
	// if cached, remove from cache and deallocate
	if (cached != NULL) {
		dir->cache_remove(name);
		delete cached;
	}
	
	// finally, remove from disk
	dir->unlink(name, true);
	dir->batch_end();
	return 0;
}
	

/**
 * Change to requested directory.
 * Check permissions -- must have read and execute access to the directory.
 * Update usage counts.
 * 
 * @param key		VFS access key
 * @param path		path to directory
 * @return 0 on success, error code otherwise
 */
int file_system::chdir(flib_key * key, const char * path) 
{
	resolved_path rp;
	int err = resolve_path(key, path, &rp);
	if (err < 0) {
		return err;
	}

	directory * old_dir = key->dir();
	directory * new_dir = load_directory(key, rp.dir(), rp.name(), &err);

	if (new_dir == NULL) {
		return err;
	}
			
	DEBUG("file_system::chdir(): to '%s' (trying %s -> %s)\n", 
			path, old_dir->rel_path(), new_dir->rel_path());
	
	if (new_dir == old_dir) {
		return 0;	
	}

	err = access(key, new_dir->entry(), X_OK);
	if (err < 0) {
		return err;
	}	
	key->set_dir(new_dir);
	return 0;
}

/**
 * Create a new directory.
 *
 * @param key		VFS access key
 * @param name		path of directory to create
 * @param mode		mode to create teh directory with
 * @param err		pointer to int to store any error codes.
 * @return pointer to new fs::directory object; NULL on error.
 */
directory * file_system::mkdir(const flib_key * key, const char * name, mode_t mode, int * err)
{
	resolved_path rp;
	int r = resolve_path(key, name, &rp); 
	if (r < 0) {
		*err = r;
		return NULL;
	}

	directory * const parent = rp.dir();
	name = rp.name();
	
	r = parent->batch_start();
	if (r < 0) {
		*err = r;
		return NULL;
	}

	file_entry * e = parent->disk_lookup(name, err);
	if (e != NULL) {
		// already exists!
		*err = ERR_EXISTS;
		parent->batch_end();
		delete e;
		return NULL;
	}
	
	// check for other weird errors
	if (*err != ERR_DOESNT_EXIST) {
		parent->batch_end();
		return NULL;
	}

	// ensure permissions allow file creation
	r = access_entry_only(key, parent->entry(), W_OK | X_OK);
	if (r < 0) {
		*err = r;
		parent->batch_end();
		return NULL;
	}

	// create it on disk
	char * fp = my_strdup3(parent->abs_path(), "/", name);
	r = ::mkdir(fp, 0700);
	delete[] fp;

	if (r < 0) {
		*err = (errno == EEXIST) ? ERR_EXISTS_ON_DISK : ERR_MKDIR_FAILURE;
		parent->batch_end();
		return NULL;
	}
		 
	e = new file_entry(parent, name, key->creds()->user(), key->creds()->group());
	e->set_flags(parent->entry()->flags() | FE_DIRECTORY);
	e->set_creation(time(NULL));
	e->set_mode(mode & ~key->umask());

	// create directory database first, then try to write to disk.
	directory * new_dir = new directory(parent, e);
	new_dir->create();
	r = new_dir->validate();
	if (r == 0) {
		r = parent->write(e, true); 
	}		
	if (r < 0) {
		*err = r;
		delete new_dir;
		delete e;
		parent->batch_end();
		return NULL;
	} 

	// success
	directories.insert(new_dir->rel_path(), new_dir);
	parent->cache_insert(e);
	parent->batch_end();
	return new_dir;
}

/**
 * Attempt to remove a directory.  First deletes the database file and
 * removes it from the VFS, then makes a call to rmdir().  
 */
int file_system::rmdir(const flib_key * key, const char * name)
{
	resolved_path rp;
	int err = resolve_path(key, name, &rp);
	if (err < 0) {
		return err;
	}

	directory * const parent = rp.dir();
	name = rp.name();
	
	directory * dir = load_directory(key, parent, name, &err);
	if (dir == NULL) {
		// doesn't exist?
		return err;
	}
	
	// access check:
	// can always remove files in directory which you can write to.
	// TODO: check for sticky
	err = access_entry_only(key, parent->entry(), W_OK | X_OK);
	if (err < 0) {
		return err;
	}
	
	// other sanity checks 
	if (dir->usage_count() > 1 || !dir->is_empty()) {
		return ERR_BUSY;
	}
	if (dir->cache_num_open() > 0) {
		return ERR_OPEN_FILES;
	}

	err = parent->unlink(dir->name(), false);
	if (err < 0) {
		return err;
	}

	// save this ...
	std::string dir_name = dir->name();
	
	dir->cache_prune();
	dir->destroy();
	err = ::rmdir(dir->abs_path());
	
	/**
	 * Since the database file has been erased by now, a failed rmdir()
	 * due to other reasons is ignored.  The directory object is destroyed
	 * and removed from the cache. 
	 */
	directories.erase(dir->rel_path());
	delete dir;
  	  
	/**
	 * And remove file_entry from parent's cache if necessary 
	 * (should always be)...
	 */
	file_entry * fe = parent->cache_lookup(dir_name.c_str());
	if (fe != NULL) {
		assert(fe->usage_count() == 0);
		parent->cache_remove(dir_name.c_str());
		delete fe;
	}

	if (err < 0) {
		return ERR_RMDIR_FAILURE;
	}
	return 0;
}

/**
 * chmod()
 */
int file_system::chmod(const flib_key * key, const char * name, mode_t mode)
{
	resolved_path rp;
	
	int err = resolve_path(key, name, &rp);
	if (err < 0) {
		return err;
	}

	directory * const dir = rp.dir();

	file_entry * entry = rp.cached_entry();
	if (entry == NULL) {
		// entry not cached; load it
		err = dir->batch_start();
		if (err < 0) {
			return err;
		}

		entry = dir->disk_lookup(rp.name(), &err);
		if (entry == NULL) {
			dir->batch_end();
			return err;
		}
		dir->cache_insert(entry);
		dir->batch_end();
	}
	// required access:
	// ownership of file or super user
	const bool uname_match = strcmp(key->creds()->user(), entry->owner()) == 0;
	const bool is_super_user = key->creds()->flags() & credentials::SUPER_USER;

	if (!uname_match && !is_super_user) {
		return ERR_NOT_PERMITTED;
	}
	entry->set_mode(mode & 07777);
	return save(key, entry);
}

/**
 * lame stat() wannabe
 */
int file_system::stat(const flib_key * key, const char * name, entry_data& out)
{
	resolved_path rp;
	
	int err = resolve_path(key, name, &rp);
	if (err < 0) {
		return err;
	}

	directory * const dir = rp.dir();

	file_entry * entry = rp.cached_entry();
	if (entry == NULL) {
		// entry not cached; load it
		err = dir->batch_start();
		if (err < 0) {
			return err;
		}

		entry = dir->disk_lookup(rp.name(), &err);
		if (entry == NULL) {
			dir->batch_end();
			return err;
		}
		dir->cache_insert(entry);
		dir->batch_end();
	}
	out = *entry->raw_data();
	return 0;
}

/**
 * rename()
 */
int file_system::rename(const flib_key * key, const char * source, const char * target)
{
	return -1;
}

/**
  * ls: still needs a bit of work
  */
int file_system::ls(const flib_key * key, const char * pattern, std::vector<entry_data>& results)
{
	resolved_path rp;
	int err = resolve_path(key, pattern, &rp); 
	if (err < 0) {
		return err;
	}

	pattern = rp.name();
	directory * dir = rp.dir();
	directory * possible = load_directory(key, dir, pattern, &err);
	if (possible != NULL) {
		// FIXME: not the best error reporting 
		dir = possible;
		pattern = "*";
	}
	err = this->access(key, dir->entry(), R_OK | X_OK);
	if (err < 0) {
		return err;
	}
	
	err = dir->ls(pattern, results);
	if (err < 0) {
		return err;
	}
	return 0;	
}

/**
 * Creates a directory, creating any subdirectories that don't exist along the way.
 * Returns the new directory iff:
 * 	- it didn't already exist
 * 	- any previous directories along the way already existed or were successfully created.
 */
directory * file_system::mkdirs(const flib_key * key, const char * target, mode_t mode, int * err)
{
	using std::string;
	resolved_path rp;

	// initial check -- at the very least clean up the path.
	*err = resolve_path(key, target, &rp); 
	if (*err < 0 && *err != ERR_DOESNT_EXIST) {
		return NULL;
	}

	// This is a bit slow and naive; start from the base of the path and keep
	// trying to create directories.
	std::vector<string> tokens;
	tokenize(rp.full_path(), "/", tokens);

	std::vector<string>::const_iterator i = tokens.begin(),
						e = tokens.end();

	// start at "/" and keep appending tokens
	string path = "";
	directory * d = NULL;
	*err = ERR_EXISTS;
	for (; i != e; ++i) {
		int err2 = 0;
		path += '/';
		path += *i;
		d = mkdir(key, path.c_str(), mode, &err2);
		if (d == NULL && err2 != ERR_EXISTS) {
			DEBUG("file_system::mkdirs('%s'): bailing out with: %s\n", target, strerror(err2));
			*err = err2;
			return NULL;
		}
	}
	DEBUG("file_system::mkdirs('%s'): returning '%s'\n", target, path.c_str());
	return d;
}

/**
 * Given a parent directory, returns the 
 * directory object associated with name. 
 * (NOTE: name must not be terminated with a slash)
 */
directory * file_system::load_directory(const flib_key * key, directory * parent, 
						const char * name, int * err)
{
	const char * slash = (parent == root) ? "" : "/";

	// first check: parent directory must have search permissions
	*err = access_entry_only(key, parent->entry(), X_OK);
	if (*err < 0) {
		return NULL;
	}

	// is it already in the cache?
	char * full_path = my_strdup3(parent->rel_path(), slash, name);
	hash_table_t::iterator i = directories.find(full_path);
	delete[] full_path;
	if (i != directories.end()) {
		return (*i).second;
	}

	file_entry * entry = parent->cache_lookup(name);
	if (entry == NULL) {
		entry = parent->disk_lookup(name, err);
		if (entry == NULL) {
			// not on disk, or other error occurred
			// (err set by disk_lookup() call)
			return NULL;
		}
		parent->cache_insert(entry);
	}
	if (!(entry->flags() & FE_DIRECTORY)) {
		// not a directory
		*err = ERR_NOT_DIRECTORY;
		return NULL;
	}

	directory * result = new directory(parent, entry);
	*err = result->validate();
	if (*err < 0) {
		delete result;
		return NULL;
	}
	directories.insert(result->rel_path(), result);		
	return result;
}

/**
 * Deletes stale file entries from the cache
 */
int file_system::prune_cache()
{
	DEBUG("file_system::prune_cache() -- entering\n");

	// level order traversal -- visit each leaf and prune its cache,
	// deleting unused directories and working our way up
	std::vector<directory *> dirs;
	root->level_order_traverse(dirs);

	for (std::vector<directory *>::const_reverse_iterator i = dirs.rbegin(),
								e = dirs.rend();
								i != e;
								++i) {
		directory * d = *i;
		d->cache_prune();
		if (d->cache_num_open() == 0 && d->usage_count() == 1) {
			directories.erase(d->rel_path());
			delete d;
		}
	}
	return 0;
}

/**
 * Translates a path into a resolved_path.  
 *
 * This normalizes the path and fills the rp structure with the directory containing
 * the entry, and the name of the file in that directory.  In addition, if the requested
 * file's file_entry was in the directory's cache, it is also stored and accessible via 
 * rp->cached_entry().
 *
 * Also ensures that all directories in the path are searchable (have +x permission set).
 *
 * @param key		VFS access key
 * @param name		path to resolve
 * @param rp		pointer to resolved_path object to store results in
 * @return 0 on success, error code otherwise.
 */
int file_system::resolve_path(const flib_key * key, const char * name, resolved_path * rp)
{
	/** temporarily set cwd to filesystem root **/
	int old_dir = ::open(".", O_RDONLY); 
	char * resolved = rp->buffer();
	::chdir(root->abs_path());
	int err = normalize_path(key, name, resolved);
	fchdir(old_dir);
	::close(old_dir);
	
	if (err < 0) {	
		// error
		return err;
	}

	DEBUG("file_system::resolve_path(): normalization returned: %s --> %s\n", name, resolved);
	assert(strchr(resolved, '/') != 0);
	
	// get last slash 
	char * slash = strrchr(resolved, '/');
	rp->name_ptr = slash + 1;
	
	// check for "/" case
	if (slash == resolved) {
		rp->_dir = root;
		if (*rp->name_ptr == 0) {
			// full path was "/"
			rp->_entry = root->entry();
		}
		else {
			rp->_entry = root->cache_lookup(rp->name_ptr);
		}
		return access(key, rp->_dir->entry(), X_OK);
	}
	// temporarily cut string at last slash
	*slash = 0;
	
	// see if it's in the cache	
	hash_table_t::const_iterator i = directories.find(resolved);
	if (i != directories.end()) {
		directory * d = (*i).second;
		rp->_dir = d;
		rp->_entry = d->cache_lookup(rp->name_ptr);
		*slash = '/';
		return access(key, rp->_dir->entry(), X_OK);
	}

	// directory was not found in the cache, and there's no guarantee 
	// that it is even in the VFS
	tokenizer<> tok(resolved, resolved+strlen(resolved), delimeter_seeker<>("/"));

	err = 0;
	directory * pwd = root;
	for (tokenizer<>::const_iterator j = tok.begin(), e = tok.end();
					j != e;
					++j) { 
		const string& current = *j;
		pwd = load_directory(key, pwd, current.c_str(), &err);
		if (pwd == NULL) {
			*slash = '/';
			return err;
		}
	}

	rp->_dir = pwd;
	rp->_entry = pwd->cache_lookup(rp->name_ptr);
	*slash = '/';

	// NOTE: No access() check needed for this execution path.
	// 	 The path walking code above checks search permissions for each directory it
	// 	 attempts to load.  Attempts to access files in "/" are also handled by the case
	// 	 at the beginning.
	return 0;
}

/**
  * Determines the true path provided (i.e. resolving '.' and '..')
  * Removes extra '/' characters.
  * Ensures that it does not attempt to leave virtual root directory  
  * or follow symbolic links.
  * The returned path is guaranteed not to have a '/' at the end, unless
  *  it is the full path "/"
  * NOTE: calls stat() and access() and thus assumes current working directory is 
  * file system's on-disk root directory.
  *  	rel_cwd   -- current directory, relative to virtual root of VFS
  *	p 	  -- requested pathname to resolve
  *     resolved  -- buffer to store result in. must be >= PATH_MAX.
  *
  * return: 
  *		  0 on success
  *		< 0 otherwise
  */
/* static */ int file_system::normalize_path(const flib_key * key, const char * p, char * resolved)
{
	// XXX: PATH_MAX ? why?
	char path[PATH_MAX+1];
	/** Check for home directory access character **/
	if (p[0] == '~') {
		snprintf(path, PATH_MAX, "/home/%s/%s", key->creds()->user(), p+1);
	} 
	/** Other absolute or relative path **/
	else {
		const char * rel_cwd = (p[0] == '/') ? "" : key->cwd->rel_path();
		snprintf(path, PATH_MAX, "%s/%s", rel_cwd, p);
	}

	p = path;
	*resolved = 0;
	int s = 0;	

	do {
		switch (s) {
		case 0:
			if (*p == '.') {
				s = 1;
			}
			else if (*p != 0 && *p != '/') {
				strcat(resolved, "/");
				s = 3;
			}
			break;

		/** Got '.' **/
		case 1:
			if (*p == '.') {
				s = 2;
			}
			else if (*p == '/') {
				s = 0;
			}
			else if (*p != 0) {
				/** file names like ".file" **/
				strcat(resolved, "/.");
				s = 3;
			}
			break;

		/** Got ".." **/
		case 2:
			if (*p == '/' || *p == 0) {
				char *beg = strrchr (resolved, '/');
				if (beg != 0)
					*beg = 0;
				s = 0;
			} 
			else {
				/** messed up file names like "..file" **/
				strcat(resolved, "/..");
				s = 3;
			}
			break;

		/** Got potential directory name **/
		case 3:
			const char *end = strchr(p, '/');
			if (end == 0) { 
				end = p + strlen(p);
			}
			strncat (resolved, p - 1, end - p + 1);
			/** make sure it's not a symlink **/
			struct stat st;
			memset(&st, 0, sizeof(st));
			int r = lstat(resolved+1, &st);
			if (r >= 0 && S_ISLNK(st.st_mode)) {
				return ERR_SYMLINK;			
			}
			p = end;
			s = 0;
		}
	} while (*p++);	

	if (*resolved == 0) {
		strcpy(resolved, "/");
	}

	assert(strcmp(resolved, "/") == 0 || *(strrchr(resolved, '/')+1) != 0);
	return 0;
}

} // namespace fs

