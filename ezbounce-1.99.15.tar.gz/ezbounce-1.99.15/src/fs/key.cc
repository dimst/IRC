/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/key.cc
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include "fs/key.h"
#include "fs/credentials.h"
#include "fs/directory.h"

#include "debug.h"

namespace fs {

flib_key::flib_key(const credentials * c, directory * d) 
		: fs_creds(c), cwd(d), fs_umask(DEFAULT_UMASK)
{
	DEBUG("flib_key::flib_key(): Creating [global count: %zu]..\n", count());
        assert(cwd != NULL);
	cwd->inc_count();
}

flib_key::~flib_key() 
{
	DEBUG("flib_key::~flib_key(): Destructing [global count: %zu]...\n", count()-1);
        assert(cwd->usage_count() > 0);
        cwd->dec_count();
}

void flib_key::set_dir(directory * new_dir)
{	
	assert(cwd->usage_count() > 0);	
        assert(new_dir != NULL);
	new_dir->inc_count();
	cwd->dec_count();
        cwd = new_dir;
}

} // namespace fs
