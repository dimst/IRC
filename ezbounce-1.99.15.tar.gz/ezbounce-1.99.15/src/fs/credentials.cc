/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/credentials.cc
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include <algorithm>
#include <stdexcept>
#include "fs/credentials.h"

#include "debug.h"

using std::vector;
using std::string;

namespace fs {

/**
 * Add a group to the credentials group list.
 * The group must not already exist in the group list
 */
void credentials::add_group(const char * g)
{
	if (has_group(g)) {
		// already exists
		throw std::logic_error("group already exists");
	}
	groups.push_back(g);
}

/**
 * Remove a group from credentials group list.
 * The group must exist in the list, and it must not be the only 
 * remaining group in the list.
 * XXX: should removing the first group be prohibited, at all times?
 */
void credentials::remove_group(const char * g)
{
	vector<string>::iterator i = std::find(groups.begin(), groups.end(), g);
	if (i == groups.end()) {
		// not found
		throw std::invalid_argument("unknown group");
	}
	if (groups.size() == 1) {
		// cannot remove last group
		throw std::logic_error("cannot remove only remaining group");
	}
	groups.erase(i);
}

} // namespace fs
