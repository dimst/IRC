/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * fs/utility.cc
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include <ostream>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include "gnu/filemode.h"
#include "gnu/modechange.h"
#include "util/strings.h"
#include "fs/utility.h"
#include "fs/directory.h"
#include "fs/entry_data.h"
#include "fs/error.h"
#include "fs/key.h"

#include "debug.h"

using std::ostream;
using std::vector;

namespace fs {

/**
 * Translate a VFS error code.
 */
const char * strerror(int e)
{
	switch (e) {
	case ERR_BADFILE:
		return	"Unknown file pointer";
	case ERR_CREATION:
		return	"Unable to create file";
	case ERR_NOT_PERMITTED:
		return  "Operation not permitted";
	case ERR_PRIVATE_FILE:
		return	"Permission denied: private file";
	case ERR_ACCESS:
		return	"Permission denied";
	case ERR_DIRECTORY:
		return	"File is a directory";
	case ERR_NOT_DIRECTORY:
		return	"File is not a directory";
	case ERR_BUSY:
		return	"File or directory is busy";
	case ERR_FAILURE:
		return	"Operation failed";
	case ERR_OPEN_FILES:
		return	"Directory has open files";
	case ERR_RMDIR_FAILURE:
		return	"Unable to remove directory from disk";
	case ERR_MKDIR_FAILURE:
		return  "Unable to create directory on disk";
	case ERR_SYMLINK:
		return	"Path contains a symlink";
	case ERR_EXISTS:
		return	"File exists";
	case ERR_DOESNT_EXIST:
		return	"File not found";
	case ERR_EXISTS_ON_DISK:
		return  "File not in database, but already exists on disk";
	case ERR_CONFIG:
		return	"You don't have permission to use the VFS";
	case ERR_BAD_KEY:
		return	"Invalid VFS access key";
	case ERR_NO_VFS:
		return	"The VFS doesn't exist; or failed to initialize";
	case ERR_IO_READ:
		return  "IO Error (while reading)";
	case ERR_IO_WRITE:
		return  "IO Error (while writing)";
	}
	return directory::strerror(e);
}

/**
 * Translate numeric file mode (permissions) into a readable string. 
 * This uses some code from GNU Coreutils.	
 *
 * @param data		entry_data to read from
 * @param out		char buffer of length >= 12 (including null character)
 */
void translate_file_mode(const entry_data * data, char * out)
{
	int mode = data->mode;
	// apply directory flag if needed	
	if (data->flags & FE_DIRECTORY) {
		mode |= S_IFDIR;
	}
	else {
		mode |= S_IFREG;
	}

	strmode_alt(mode, out);	
}


/**
 * Given a chmod mode change string and entry_data, return new file mode.
 *
 * @return new permissions, or -1 on error.
 */
int translate_chmod_str(const flib_key * key, const entry_data * data, const char * str)
{
	struct mode_change * c = mode_compile(str);
	if (c == NULL) {
		// couldn't be parsed		
		return -1;
	}

	const bool is_dir = data->flags & FE_DIRECTORY;
	mode_t new_mode = mode_adjust(data->mode, is_dir, key->umask(), 
					c, NULL); 

	free(c);
	return new_mode;
}


/**
 * Print basic 'ls' output into a ostream.
 */
void print_full_ls(const vector<entry_data>& entries, const char * sep)
{
}


/**
 * Print full 'ls' output into a ostream.
 */
void print_full_ls(const vector<entry_data>& entries, std::ostream& out, const char * sep)
{
	vector<entry_data>::const_iterator i = entries.begin(), 
						end = entries.end();

	for (; i != end; ++i) {
		std::string ts;
		char mode_str[12] = "";
		const entry_data &e = *i;
		const char * dir = "";

		if (e.flags & fs::FE_DIRECTORY) {
			dir = "/";
		}

		fs::translate_file_mode(&e, mode_str); 
		util::strings::timestamp(ts, "%Y-%m-%d %H:%M", e.creation);

		out << mode_str << "1 " << e.strings[OWNER] << ' ' << e.strings[GROUP] << ' ';
		out << e.size << ' ' << ts << ' ' << e.strings[NAME] << dir;
		out << sep;
	}
}

}
