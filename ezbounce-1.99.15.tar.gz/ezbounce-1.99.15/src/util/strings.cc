/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * util/strings.cc
 * (c) 1998-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <string>
#include <algorithm>
#include <new>
#include <cerrno>
#include <cstring>
#include <cstdarg>
#include <cstdio>
#include <ctime>
#include <cctype>
#ifdef HAVE_SYS_TIME_H
#include <sys/time.h>
#endif
#include "util/strings.h"
#include "debug.h"

using std::string;

// needed on GCC 4.3 -- overloaded version of toupper() and tolower() ?
typedef int (*case_fn)(int);

namespace util {
  namespace strings {

/**
 * Returns pointer to string without leading ':' or whitespace.
 * Be careful to remove only the first leading ':' 
 */
const char * no_leading(const char *orig)
{
	if (orig) {
		while (*orig == ' ' || *orig == '\t') {
			++orig;
		}
		if (*orig == ':') {
			++orig;
		}
	}
	return orig;
}

/**
 * Format a string with the requested timestamp format.
 * See strftime(3).
 */
string& timestamp(string& out, const char * format, time_t t)
{
	if (t == 0) {
		t = time(NULL);
	}

	char tmpbuff[128] = "";
	struct tm tm;
	memset(&tm, 0, sizeof tm);
	localtime_r(&t, &tm);

	strftime(tmpbuff, sizeof tmpbuff, format, &tm);
	out = tmpbuff;
	return out;
}

/**
 * Return a full timestamp as produced by ctime()
 */
string& timestamp_full(string& out, time_t t) 
{
	if (t == 0) {
		t = time(NULL);
	}
	char tmpbuff[40] = "";
	ctime_r(&t, tmpbuff);
	out = tmpbuff;

	// get rid of trailing newline
	size_t s = out.size();
	if (out[s-1] == '\n') {
		out.resize(s-1);
	}
	return out;
}

char * to_uppercase(char * s)
{
	std::transform(s, s+strlen(s), s, (case_fn) std::toupper);
	return s;
}

char * to_lowercase(char * s)
{
	std::transform(s, s+strlen(s), s, (case_fn) std::tolower);
	return s;
}

/**
 * Alternate versions for string
 */
string& to_uppercase(string& s)
{
	std::transform(s.begin(), s.end(), s.begin(), (case_fn) std::toupper);
	return s;
}

string& to_lowercase(string& s)
{
	std::transform(s.begin(), s.end(), s.begin(), (case_fn) std::tolower);
	return s;
}

/**
 * Like strdup(), but uses operator new.
 */
char *my_strdup(const char *src)
{
	if (!src) {
		return NULL;
	}

	size_t len = strlen(src);
	char * z = new char[len + 1];
	strncpy(z, src, len);
	z[len] = 0;
	return z;
}

/**
 * Escape " quotes by prefixing them with a \
 */
string escape_quotes(const string& in) 
{
	string out;
	out.reserve(in.size());
	for (string::const_iterator i = in.begin(), e = in.end();
			i != e;
			++i) {
		if (*i == '\"') {
			out += '\\';
		}
		out += *i;
	}
	return out;
}


/* ...from ircd-hybrid 5.2. Slightly modified */
/*
** _match()
** Iterative matching function, rather than recursive.
** Written by Douglas A Lewis (dalewis@acsu.buffalo.edu)
*/
int wild_match(const char *mask, const char *name)
{
    const unsigned char *m = (const unsigned char *) mask, *n = (const unsigned char *) name;
    const char   *ma = mask, *na = name;
    int  wild = 0, q = 0;

    while (1)
    {
        if (*m == '*')
        {
            while (*m == '*')
                m++;
            wild = 1;
            ma = (char *)m;
            na = (char *)n;
        }

        if (!*m)
        {
            if (!*n)
                return (0);
            for (m--; (m > (unsigned char *)mask) && (*m == '?'); m--)
                ;
            if ((*m == '*') && (m > (unsigned char *)mask) &&
                (m[-1] != '\\'))
                return (0);
            if (!wild)
                return (1);
            m = (unsigned char *)ma;
            n = (unsigned char *)++na;
        }
        else if (!*n)
        {
            while (*m == '*')
                m++;
            return (*m != 0);
        }
        if ((*m == '\\') && ((m[1] == '*') || (m[1] == '?')))
        {
            m++;
            q = 1;
        }
        else
            q = 0;

        if ((tolower(*m) != tolower(*n)) && ((*m != '?') || q))
        {
            if (!wild)
                return (1);
            m = (unsigned char *)ma;
            n = (unsigned char *)++na;
        }
        else
        {
            if (*m)
                m++;
            if (*n)
                n++;
        }
    }
}


/**
 * Take seconds, turn to human readable duration text.
 * 
 * @param out		std::string to store it in
 * @param howlong	duration in seconds
 * @param verbose  	include days, not just hours:min
 * @return out
 */
string& duration(string& out, time_t howlong, bool verbose)
{
	int hours = 0;
	howlong /= 60;
	for (; howlong > 59; howlong -= 60) {
		++hours;
	}
	// howlong now stores minutes 
	if (verbose && hours > 23) {
		int days = 0;
		for (; hours > 23; hours -=24) {
			days++;
		}
		my_sprintf(out, "%d day(s) %02d:%02d", days, hours, (int) howlong);
	}
	else {
		my_sprintf(out, "%02d:%02d", hours, (int) howlong);
	}
        return out;
}

/**
 * NOTE: from Linux kernel, lib/string.c
 *
 * strlcpy - Copy a %NUL terminated string into a sized buffer
 * @dest: Where to copy the string to
 * @src: Where to copy the string from
 * @size: size of destination buffer
 *
 * Compatible with *BSD: the result is always a valid
 * NUL-terminated string that fits in the buffer (unless,
 * of course, the buffer size is zero). It does not pad
 * out the result like strncpy() does.
 */
size_t my_strlcpy(char *dest, const char *src, size_t size)
{
	size_t ret = strlen(src);

	if (size) {
		size_t len = (ret >= size) ? size - 1 : ret;
		memcpy(dest, src, len);
		dest[len] = '\0';
	}
	return ret;
}

/**
 * Returns a new string that has s1 and s2 concatenated.
 */
char * my_strdup2(const char * s1, const char * s2) 
{
	size_t len1 = strlen(s1);
	size_t len2 = strlen(s2);

	char * str = new char[len1+len2+1];
	memcpy(str, s1, len1);
	memcpy(str + len1, s2, len2);
	str[len1+len2] = 0;
	return str;
}

/**
 * Returns a new string that has s1, s2, and s3 concatenated.
 */
char * my_strdup3(const char * s1, const char * s2, const char *s3)
{
	size_t len1 = strlen(s1), 
	       	len2 = strlen(s2),
		len3 = strlen(s3);

	char * str = new char[len1+len2+len3+1];
	memcpy(str, s1, len1);
	memcpy(str+len1, s2, len2);
	memcpy(str+len1+len2, s3, len3);
	str[len1+len2+len3] = 0;
	return str;
}

/**
  * Doesn't blow up on null pointers, useful for some cases.
  * Same return values as strcasecmp; for comparison purposes, 
  * (null pointer) lexicographically < ""
  */
int safe_strcasecmp(const char * s1, const char * s2) 
{
	if (s1 == s2) {
		return 0;
	} 
	else if (s1 == 0 && s2 != 0) {
		return 1;
	}
	else if (s1 != 0 && s2 == 0) {
		return -1;
	}

	return strcasecmp(s1, s2);
}

/**
  * Check if a string contains a boolean value.
  * Permitted values: 
  *	0, false		-> false
  *	1, true			-> true
  *
  * NOTE: does not account for whitespace.
  */
bool check_bool(const char * str, bool * out) 
{
	if (strcasecmp(str, "false") == 0 || strcmp(str, "0") == 0) {
		*out = false;
		return true;
	}

	if (strcasecmp(str, "true") == 0 || strcmp(str, "1") == 0) {
		*out = true;
		return true;
	}
	return false;
}


/**
  * Check if a string contains a on/off.  Stores value in a boolean as 
  * true or false.
  * Permitted values: 
  *	off		-> false
  *	on		-> true
  *
  * NOTE: does not account for whitespace.
  */
bool check_on_off(const char * str, bool * out) 
{
	if (strcasecmp(str, "off") == 0) {
		*out = false;
		return true;
	}

	if (strcasecmp(str, "on") == 0) {
		*out = true;
		return true;
	}
	return false;
}

/**
  * Check if a string contains an integer value.  Handles negative numbers.
  */
bool check_int(const char * str, int * out)
{
	const char * s = str;
	if (*s == '-') {
		++s;
	}
	if (*s == 0) {
		return false;
	}
	while (*s) {
		if (!isdigit(*s++)) {
			return false;
		}
	}
	*out = atoi(str);
	return true;
}

/**
  * Checks if a string is non-NULL and not empty.
  */
bool is_non_empty(const char * str) 
{
	return (str != NULL) && (*str != 0);
}

/**
 * Like asprintf(), but allocates memory with operator new instead of malloc()
 */
int my_asprintf(char ** out, const char * fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	int ret = my_vasprintf(out, fmt, ap);
	va_end(ap);
	return ret;
}

/**
 * Format a string and place the result in a string.
 */
int my_sprintf(string &out, const char * fmt, ...)
{
	assert(fmt != NULL);
	char * ptr = NULL;
	va_list ap;
	va_start(ap, fmt);
	int ret = my_vasprintf(&ptr, fmt, ap);
	va_end(ap);

	if (ret > -1) {
		out = ptr;
		delete[] ptr;
	}
	return ret;
}

/**
 * Alternate form of my_sprintf(); returns string object.
 * Throws an exception if the my_vasprintf() operation failed.
 */
string my_sprintf(const char * fmt, ...) 
{
	assert(fmt != NULL);
	char * ptr = NULL;
	va_list ap;
	va_start(ap, fmt);
	int ret = my_vasprintf(&ptr, fmt, ap);
	va_end(ap);

	if (ret < 0) {
		throw std::bad_alloc();
	}
	string out(ptr);
	delete[] ptr;
	return out;
}


# if defined(va_copy)
#	define MY_VA_COPY(dst, src)	va_copy((dst), (src))
# elif defined(__va_copy)
#	define MY_VA_COPY(dst, src)	__va_copy((dst), (src))
# else
#	warning "no va_copy() or __va_copy() defined; assuming basic assignment"
# 	define MY_VA_COPY(dst, src)	(dst) = (src)
# endif

/** 
 * This is based on the sample in the Linux printf(3) man page.  It is modified
 * to allocate memory with new instead of malloc().
 * Like vasprintf(), return the number of bytes printed, or -1 on failure.  Also, if a 
 * failure occurs, out will point to NULL.
 */
int my_vasprintf(char ** out, const char * fmt, va_list orig_ap)
{
	assert(fmt != NULL);
	assert(out != NULL);
	using std::nothrow;
	/* Guess we need no more than 256 bytes. */
	int n, size = 256;
	char *p;

	while (1) {
		/* First obtain memory */
		p = new(nothrow) char[size];
		if (p == NULL) {
			break;
		}
		/* Try to print in the allocated space. */
		va_list ap;
		MY_VA_COPY(ap, orig_ap);
		n = vsnprintf (p, size, fmt, ap);
		va_end(ap);
		/* If that worked, return the string. */
		if (n > -1 && n < size) {
			*out = p;
			return n;
		}
		/* Else try again with more space. */
		if (n > -1)    /* glibc 2.1 */
			size = n+1; /* precisely what is needed */
		else           /* glibc 2.0 */
			size *= 2;  /* twice the old size */

		delete[] p;
	}
	*out = NULL;
	return -1;
}

  } /* namespace strings */
} /* namespace util */
