/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 * hash.cc
 * (c) 2001-2007 Murat Deligonul
 */

#include "autoconf.h"

#include <cstdlib>
#include <cstring>
#include <cctype>
#include <cassert>

#include "util/hash.h"

namespace util {

// This was for testing only.
//--------------------------------------------------
// static hash_table<const char *, int, cstring_hash_fn, default_predicate<const char*> > test(20, string_hash);
// typedef hash_table<const char *, int, cstring_hash_fn, default_predicate<const char *> > htest;
// 
// void test_fun() 
// {
// 	test.insert("hello", 5);
// 	test.erase("hello");
// 	test.replace("hello", 20);
// 	test.exists("hello");
// 	test.find("hello");
// 	test.erase(test.begin());
// 
// 	htest::iterator i = test.begin(), e = test.end();
// 	hash_table<const char *, int, cstring_hash_fn, default_predicate<const char *> > ::const_iterator i2 = test.begin(); // e2 = test.end();
// }
//-------------------------------------------------- 

/* Borrowed from `Algorithms in C' by O'Reilly Publishing */
/* static */ unsigned int string_hash(const char * key)
{
	const char *ptr;
	unsigned int val;

	val = 0;
	ptr = key;

	while (*ptr != '\0') {
		int tmp;
		val = (val << 4) + toupper(*ptr);

		if ((tmp = (val & 0xf0000000))) {
			val = val ^ (tmp >> 24);
			val = val ^ tmp;
		}
		ptr++;
	}

	return val;
}


/** prime number helper functions **/
/* static */ bool is_prime(unsigned int num)
{
	unsigned int z;
  
  	/* check if it's divisible by any common nums to avoid the 
     	 loop sometimes */
  	if ((num == 1) || 
		(num % 2 == 0 && num != 2) ||
		(num % 3 == 0 && num != 3) ||
		(num % 4 == 0) ||
		(num % 5 == 0 && num != 5) ||
      		(num % 6 == 0) ||
      		(num % 10 == 0)) {
	    	return 0;
	}

  	/* start at square root of number. */
  	for (z = /* (int) sqrt((double) */ num-1 /*)*/; z > 1; --z) {
	    	if ((num % z) == 0) {
      			return 0;
		}
	}
	return 1;
}

/* static */ unsigned int nearest_prime(unsigned int p)
{
	while (1) {
		if (is_prime(p)) {
			return p;
		}
		++p;
	}
}

} /* namespace util */
