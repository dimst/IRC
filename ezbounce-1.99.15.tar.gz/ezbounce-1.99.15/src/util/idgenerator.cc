/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *
 * idgenerator.cc
 * Part of ezbounce
 * (c) 2003-2007 Murat Deligonul                                           *
 ***************************************************************************/

#include "autoconf.h"

#include <climits>
#include <cstddef>
#include "util/idgenerator.h"
#include "debug.h"

namespace util {

const unsigned int id_generator::CHUNK = sizeof(unsigned int) * 8;

/* find the lowest id, i.e. the first 0 bit */
unsigned int id_generator::generate()
{
	unsigned int * current = base;

	for (unsigned int idx = 0; idx < alloced; ++idx) {
		if (current[idx] == UINT_MAX) { /* full */
			continue;
		}

		/* find the lowest zero bit */
		unsigned int mask = 1;
		for (unsigned int x = 0; x < CHUNK; ++x, mask <<= 1) {
			if (!(current[idx] & mask)) {
				current[idx] |= mask;
				return idx * CHUNK + x;
			}
		}
	}
	/* need to allocate more memory */
	current = new unsigned int[alloced * 2];
	memset(current, 0, sizeof(unsigned int) * alloced * 2);
	memcpy(current, base, alloced * sizeof(unsigned int));
	delete[] base;
	base = current;
	current[alloced] |= 1;
	alloced *= 2;
	return (alloced / 2) * 8 * sizeof(unsigned int);
}

unsigned int id_generator::get(unsigned int where) const
{
	unsigned int idx = where / sizeof(unsigned int);
	unsigned int bit = where % sizeof(unsigned int);
	if (idx >= alloced * sizeof(unsigned int)) {
		return 0xFFFFFFFF;
	}

	return (base[idx] & (1 << bit)) != 0;
}

void id_generator::set(unsigned int where, bool what)
{
	unsigned int idx = where / (CHUNK);
	unsigned int bit = where % (CHUNK);
	assert(idx < alloced * sizeof(unsigned int));

	if (what) {
		base[idx] |= (1 << bit);
	}
	else {
		base[idx] &= ~(1 << bit);
	}
}

}	/* namespace util */

