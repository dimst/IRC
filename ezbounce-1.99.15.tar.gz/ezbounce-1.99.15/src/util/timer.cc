/***************************************************************************
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 ***************************************************************************
 * util/timer.cc
 * (c) Murat Deligonul 2002-2007
 * revised may 2003: now synchronizes itself with the system clock.
 *	   may 2004: GCD-based crappy scheduler scrapped.
 *	   may 2005: simplify interface, use STL priority queue for scheduling		
 *	   apr 2007: even simpler
 */

#include "autoconf.h"
#include "util/timer.h"
#include "debug.h"

namespace util {

std::priority_queue<timer::ticket, std::vector<timer::ticket>, 
			std::greater<timer::ticket> > timer::timers;
time_t timer::_now = time(NULL);
time_t timer::last_poll = 0;

timer::timer(int _int, int _opt, int _id) : id(_id), interval(_int), 
					options(_opt), epoch(_now), scheduled(0)
{
	DEBUG("timer::timer() -- %p started at %lu, [interval: %d options: %d]\n",
		this, now(), _int, _opt);
	assert(_int != 0);
}

void timer::enable()  
{ 
	if (!(options & TIMER_ENABLED)) {
		DEBUG("timer::enable() [%p]\n", this); 
		options |= TIMER_ENABLED;
		schedule_next();
		timers.push( ticket(this, scheduled) ); 
	} 
}

/* Determine when we are to run next
 * relative to now */
time_t timer::schedule_next()
{
	if (options & TIMER_ABSOLUTE) {
		scheduled = now() + (interval - (now() % interval));
	} 
	else {
		scheduled = now() + interval;
	}
#ifdef __DEBUG__
	char * text = ctime(&scheduled);
	text[strlen(text)-1] = 0;
	DEBUG("timer::schedule_next() [%p] @ %lu (%s)\n", this, scheduled, text);
#endif
	return scheduled;
}

/**
  * Kill the timer, and free the allocated memory now if possible.
  * There are # cases where this may be called:
  *	- Timer on execution queue:	[ENABLED, not EXPIRED]
  *		- mark as expired so that it may be deleted later.
  *	- Timer not on execution queue:
  *		- can disable and free memory immediately.
  *	- Inside timer procedure (bad):
  *		- mark as expired so that it may be deleted later.
  *		- return -1 from procedure to ensure immediate deletion; otherwise
  *		  it will be scheduled once more and finally deleted then.
  */
void timer::die()  
{ 
	if (!(options & TIMER_EXPIRED) && !(options & TIMER_ENABLED)) {
		options |= TIMER_EXPIRED;
		delete this;
	}
	else {
		options &= ~TIMER_ENABLED;
		options |= TIMER_EXPIRED;
	}
}

/**
 * Poll the timers. Reschedule them if necessary.
 * FIXME: I think one shot timers should be deleted after firing ... 
 */
int timer::poll()
{
	time_t realtime = now();
	/* prevent duplicate timer events in the same second ! */
	if (realtime == last_poll) {
        	return 0;
	}
	DEBUG("timer::poll() @ time %lu\n", realtime);

	while (!timers.empty())	{
		/**
		 * Call the handler:
		 * Check for < 0 return value, and remove that
		 * timer if necessary 
		 */
		const ticket t = timers.top();
		if (t.owner->get_scheduled() <= realtime ) {
			timers.pop();
			if (t.owner->options & TIMER_EXPIRED) {	
				delete t.owner;
				continue;
			}
		
			/**
		  	  * Disable timers requesting it, or any one shot timer.
			  */
			if ( (t.owner->timer_proc(realtime) < 0) ||
			     (t.owner->options & TIMER_ONESHOT)) {
				t.owner->options &= ~TIMER_ENABLED;	
				/**
				 * Check if die() was called in the context of the
 				 * timer proc.
				 */
				if (t.owner->options & TIMER_EXPIRED) {
					delete t.owner;
					continue;
				}
			}
			else {
				/**
				 * Calculate next execution time & re-add to the
				 * queue 
				 */				
				t.owner->schedule_next();
				timers.push(ticket(t.owner, t.owner->get_scheduled()));
			}
		}
		else {
			break;
		}
	}
	last_poll = realtime;
	return 1;
}

} /* namespace util */

