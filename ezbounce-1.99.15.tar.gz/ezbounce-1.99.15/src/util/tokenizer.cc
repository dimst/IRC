/** 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * util/tokenizer.cc 
 * (c) 2004-2005 Murat Deligonul
 * ---
 * 8/05 --  added option to count delimeters encountered
 *		NOTE: we don't count a delimeter until we've 
 *		      "walked over" it.  i.e. the delimeter used as the
 *		      end of a token isn't counted until the next 
 *		      token is grabbed. 
 **/

#include "autoconf.h"

#include <cstring>
#include "util/modifying_tokenizer.h"
#include "debug.h"

namespace util {
  namespace strings {

modifying_tokenizer::modifying_tokenizer(char * s, const char * d, int o) : 
			start(s), end(NULL), 
			end_char(0), 
			delim(d), 
			count(0) 
{
	set_options(o);	
}

void modifying_tokenizer::set_options(int o) 
{
	options = o;
	if ((options & COUNT_DELIMS) && !count) {
		count = new int[strlen(delim)];
		memset(count, 0, sizeof(int) * strlen(delim));
	}
}

char * modifying_tokenizer::next()
{
	int state = 0;
	char * p;
	const char * d;

	if (end) {
		if (end_char == 0)
			return 0;
		if (count)
			++count[strchr(delim, end_char) - delim];
		if (!(options & DONT_RESTORE))
			*end = end_char;
		p = end+1;
	} 
	else {
		p = start;
	}

	while (*p) {
		d = strchr(delim, *p);
		if (state == 0) {
			if (!d) { /* found non-delimiter */
				state = 1;
				start = p;
			} else if (count) 	/* keep track of stats */
				++count[d - delim];

		} else if (state == 1) {
			if (d) { /* found delimeter */
				end_char = *p;
				end = p;
				*end = 0;
				return start;
			}
		}
		++p;
	}
	/* loop terminated by null character */
	end = p;
	end_char = 0;
	if (state == 0) {
		return NULL;
	}
	return start;
}

  } /* namespace strings */
} /* namespace util */
