/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/engine.cc
 * (c) 2007 Murat Deligonul
 */

#include "autoconf.h"

#include "io/engine.h"
#include "io/error.h"
#include "debug.h"

namespace io {

engine::engine(unsigned size, time_t * time_ptr) : objects(size, NULL), 
						last_event(NULL), 
						dummy_time(0)
{
	DEBUG("engine::engine(): [%p] constructed\n", this);
	if (time_ptr == NULL) {
		last_event = &dummy_time;
	}
	else {
		last_event = time_ptr;
	}
}

engine::~engine() 
{
	DEBUG("engine::~engine(): [%p] destructed\n", this);
}

/**
  * Add a pollable object to the io engine with the requested events.
  */
int engine::add(pollable * p, int events)
{
	assert(p != NULL);
	assert(events >= 0);

	int fd = p->get_fd();

	if (fd < 0) {
		return INVALID_FD;
	}

	/**
	  * Resize table if needed 
	  */
	if (unsigned(fd) >= objects.size()) {
		objects.resize( unsigned(fd)+1, NULL);
	}

	/**
	  * Make sure this isn't a duplicate.
	  */
	if (objects[fd] != NULL) {
		return DUPLICATE_FD;
	}

	objects[fd] = p;
	p->set_events(events);
	return 0;
}

/**
  * Remove object from the io engine.
  */
int engine::release(pollable * p) 
{
	assert(p != NULL);
	int fd = p->get_fd();

	if (fd < 0 || unsigned(fd) >= objects.size()) {
		return INVALID_FD;
	}

	if (objects[fd] != p) {
		return INVALID_FD;
	}

	objects[fd] = NULL;
	return 0;
}

void engine::set_events(pollable * p, int events)
{
	assert(p != NULL);
	assert(objects[p->get_fd()] == p);
	assert(events >= 0);

	p->set_events(events);
}

/**
  * Attempt to reduce memory usage.
  */
void engine::compress()
{
}

}  /* namespace io */
