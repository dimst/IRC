/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/utility.cc
 * (c) 2007 Murat Deligonul
 */

#include "autoconf.h"

#include <cstdarg>
#include <unistd.h>
#include <fcntl.h>
#include "util/strings.h"
#include "io/utility.h"
#include "io/error.h"
#include "debug.h"

namespace io {

/**
 * Translate IO-framework error codes.
 */
const char * strerror(int e)
{
	switch (e) {
	case SUCCESS:
		return "Success";
	case INVALID_FD:
		return "Invalid file descriptor";
	case DUPLICATE_FD:
		return "File descriptor already exists";
	case READ_ERROR:
		return "Read error";
	case WRITE_ERROR:
		return "Write error";
	case BUFFER_FULL:
		return "Buffer is full";
	default:
		break;
	}
	return "Unknown error";
}

/**
 * printf()-like function to write to file descriptor.
 */
int fdprintf(int fd, const char *fmt, ...)
{
	using util::strings::my_vasprintf;
	char * ptr = NULL;
	va_list ap;
	va_start(ap, fmt); 
	int len = my_vasprintf(&ptr, fmt, ap); 
	va_end(ap);

	if (len < 0) {
		return -1;
	}
	len = write(fd, ptr, len);
	delete[] ptr;
	return len;
}

}
