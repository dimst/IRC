/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/buffer.cc
 * (c) 2007 Murat Deligonul
 */

#include "autoconf.h"

#include <ostream>
#include <exception>
#include <stdexcept>
#include <cerrno>
#include <sys/types.h>
#include <unistd.h>
#ifdef HAVE_SYS_FILIO_H
#   include <sys/filio.h>
#endif
#ifdef HAVE_SYS_IOCTL_H
#   include <sys/ioctl.h>
#endif
#include "util/generic.h"
#include "io/buffer.h"
#include "io/error.h"
#include "debug.h"

using util::clamp;

namespace io {

// page size on this system
const size_t buffer::SYS_PAGE_SIZE = sysconf(_SC_PAGESIZE);

/**
 * Construct a new buffer.
 */
buffer::buffer(size_t _min, size_t _max) :
	buff(NULL), 
	start(NULL),
	min(_min), 
	max(_max),
	alloced(0), in(0) 
{
	assert(min <= max);
	assert(SYS_PAGE_SIZE > 0);

	if (min > max) {
		throw std::logic_error("buffer size minimum is greater than its maximum");
	}
	if (min < MINIMUM) {
		throw std::logic_error("minimum buffer size too small");
	}

	start = buff = new char[min];
	alloced = min;
}

/**
 * Insert raw bytes into the buffer.
 * Fails if 'len' space is not available.
 */
ssize_t buffer::insert(const void * data, size_t len)
{
	if (len > available()) {
		return BUFFER_FULL;
	}
	reserve(size()+len);
	memcpy(end(), data, len);
	in += len;
	return len;
}

/**
 * Read from a file descriptor and insert into buffer.
 * Attempts to insert upto 'len' bytes, but doesn't actually resize buffer
 * until exact amount read is determined.
 *
 * Fails if 'len' space is not available.
 * 'len' may be zero, in which case it will be set to the maximum available space,
 * or the number of bytes waiting in the socket, whichever is lesser.
 */
ssize_t buffer::insert(int fd, size_t len)
{
	if (!len) {
		// determine how much available from fd
		ioctl(fd, FIONREAD, &len);
		len = std::min(len, available());
	}
	if (len > available()) {
		return BUFFER_FULL;
	}

	reserve(size()+len);

	// read directly into the free space in the buffer
	int r = read(fd, end(), len);
	if (r < 0) {
		return (errno == EAGAIN) ? 0 : READ_ERROR;
	}	
	else if (r == 0) {
		return READ_ERROR;
	}
	in += r;
	return r;
}

#ifdef HAVE_SSL 
/**
 * Insert from an SSL source.
 * 
 * Fails if 'len' space is not available.
 * 'len' may be zero, in which case it will be set to the maximum available space,
 * or the number of bytes waiting in the socket, whichever is lesser.
 */
ssize_t buffer::insert(SSL * ssl, size_t len) 
{
	if (!len) {
		if (!available()) {
			return BUFFER_FULL;
		}
		// determine how much available to read from fd
		ioctl(SSL_get_fd(ssl), FIONREAD, &len);
		len = std::min(len, available());
		if (!len) {		
			return 0;
		}
	}
	if (len > available()) {
		return BUFFER_FULL;
	}
	reserve(size()+len);

	// read directly into the free space in the buffer
	int r = SSL_read(ssl, end(), len);
	if (r <= 0) {
		r = SSL_get_error(ssl, r);
		if (r != SSL_ERROR_WANT_READ &&
				r != SSL_ERROR_WANT_X509_LOOKUP) {
			DEBUG("buffer::insert(): SSL_read() error: %d\n", r);
			return READ_ERROR;
		}
		DEBUG("buffer::insert(): SSL_read() -- try again?\n");
		return 0;
	}
	DEBUG("buffer::insert(): SSL_read() -- read %d\n", r);
	in += r;
	return r;
}
#endif


/**
 * Dump buffer contents into a file descriptor.
 * Return number of bytes written, or a value < 0 on error.
 */
ssize_t buffer::flush(int fd, size_t len)
{
	clamp<size_t>(len, 0, size());

	int w = write(fd, data(), len);
	if (w < 0) {
		return WRITE_ERROR;
	}
	remove(w);
	return w;
}

/**
 * Dump buffer into ostream.
 */
ssize_t buffer::flush(std::ostream& out, size_t len)
{
	clamp<size_t>(len, 0, size());

	out.write((const char *) data(), len);
	if (out.fail()) {
		return WRITE_ERROR;
	}

	// i guess with ostream we assume everything was written ?
	remove(len);
	return len;
}

/**
 * Dump buffer contents into another.
 * [Similar to transfer() function in old system]
 */
ssize_t buffer::flush(buffer * out, size_t len)
{
	clamp<size_t>(len, 0, size());
	if (len > out->available()) {
		// this will fail
		return WRITE_ERROR;
	}

	if (out->empty() && len == size()) {
		// easy case.
		delete[] out->buff;
		out->buff  = buff;
		out->start = start;
		out->in    = in;
		out->alloced = alloced;

		in = 0;
		alloced = min;
		start = buff = new char[min];
		return out->in;
	}
	int w = out->insert(data(), len);
	remove(w);
	return w;
}

/**
 * Flush requested amount of buffer contents to nowhere.
 */
ssize_t buffer::flush(size_t len)
{
	clamp<size_t>(len, 0, size());
	remove(len);
	return len;
}

#ifdef HAVE_SSL
/**
 * Flush buffer into SSL fd.
 * Return number of bytes written.
 */
ssize_t buffer::flush(SSL * ssl, size_t len)
{
	clamp<size_t>(len, 0, size());

	if (!len) {
		// OpenSSL screws up with 0 byte write attempts (?)
		return 0;
	}

	int r = SSL_write(ssl, data(), len);
	if (r <= 0) {
		int err = SSL_get_error(ssl, r);
		switch(err) {
		case SSL_ERROR_WANT_READ:
		case SSL_ERROR_WANT_WRITE:
		case SSL_ERROR_WANT_X509_LOOKUP:	
		case SSL_ERROR_NONE:
			DEBUG("buffer::flush(): SSL_write(): try again?\n");
			return 0;
		
		default:
			DEBUG("buffer::flush(): SSL_write() error: %d %s\n", err, strerror(errno));
		}
		return WRITE_ERROR;
	}
    	DEBUG("buffer::flush(): SSL_write() wanted %zu, wrote: %d\n", len, r);
	remove(r);
	return r;
}
#endif /* HAVE_SSL */

/**
 * Reduce memory usage as much as possible.
 */
void buffer::optimize() 
{
	if (size() <= min && capacity() > min) {
		char * new_buff = new char[min];
		memcpy(new_buff, start, size());
		delete[] buff;
		alloced = min;
		start = buff = new_buff;
	}
}

/**
 * Reserve space for requested number of bytes.
 * If amount is greater than absolute maximum, throw an exception.
 * Tries to find an ideal size close the requested value; currently looks for
 * power of two closest and higher than requested value.
 *
 * Also ensures that the additional requested bytes can be written safely to the 
 * end of the existing data.  Moves data to beginning of buffer if necessary.
 */
void buffer::reserve(size_t new_size)
{
	if (new_size <= capacity()) {
		if (new_size <= size()) {
			return;
		}
		// ensure needed space at the end
		size_t extra = new_size - size();
		size_t at_end = capacity() - ((start-buff) + size());
		if (extra > at_end) {
			memmove(buff, start, size());
			start = buff;
		}
		return;
	}
	if (new_size > max_capacity()) {
		throw std::logic_error("reserve(): amount requested exceeds maximum limit");
	}

	// currently look for nearest (higher) power of two
	const size_t ideal_size = nearest_power_of_2(new_size);
	new_size = ideal_size;
	clamp<size_t>(new_size, min_capacity(), max_capacity());
	DEBUG("%s [%p]: increasing size from %zu -> %zu\n", __PRETTY_FUNCTION__, this, 
								size(), new_size);

	assert(new_size >= min);
	char * new_buff = new char[new_size];
	memcpy(new_buff, data(), size());
	delete[] buff;

	start = buff = new_buff;
	alloced = new_size;

	assert(capacity() >= new_size);
}

/**
 * Remove data from the beginning of the buffer.
 */
void buffer::remove(size_t len)
{
	assert(len <= in);
	if (len > size()) {
		throw std::logic_error("remove() - trying to remove beyond end of buffer");
	}
	DEBUG("%s [%p]: reducing size: %zu -> %zu\n", __PRETTY_FUNCTION__, this, size(), size()-len);

	in -= len;
	start+=len;
	// NOTE: could also move start pointer back to 
	// beginning if buffer is now empty
	assert(start <= buff + capacity());
}

/**
 * Utility function to calculate the nearest power of two.
 * Works for 32-bit integers only.
 */
/* static */ unsigned buffer::nearest_power_of_2(unsigned x)
{
	--x;    
	x |= x >> 1;
	x |= x >> 2;    
	x |= x >> 4;    
	x |= x >> 8;    
	x |= x >> 16;    
	return ++x;
}

}
