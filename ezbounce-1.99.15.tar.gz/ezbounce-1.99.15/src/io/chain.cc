/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/chain.cc -- part of the ezbounce IRC proxy.
 * (C) 2007 Murat Deligonul
 */
#include "autoconf.h"

#include <iostream>
#include "io/chain.h"
#include "io/filters.h"
#include "debug.h"

namespace io {
#ifdef __DEBUG__
#ifdef HAVE_BOOST_IOSTREAMS
// function used for testing only
void test()
{
	io::chain<io::input, true> x("input-true.txt", std::ios::binary);

	io::chain<io::output, false> y("output-false.txt", std::ios::binary);

	io::chain<io::input, false> x2("input-false.txt", std::ios::binary);

	io::chain<io::output, true> y2("output-true.txt", std::ios::binary);

	io::filter_list filters;
	
	io::attach_filters(x, filters);

//	y2.push_filter(boost::iostreams::newline_filter(boost::iostreams::newline::dos));
	y2.push(boost::iostreams::gzip_compressor());
	y.push(boost::iostreams::gzip_compressor());

	y2.complete();
	
	x2.complete();
	y.complete();
	x.complete();
//	x.complete();

	y2.get_stream().write("te\n\n\nstingasdfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff\n", 20);

	y.get_stream().write("haha!\n", 5);

	std::string dummy;
	x.get_stream() >> dummy;

	std::cout << dummy;
	//--------------------------------------------------
	// y2.close();
	// x2.close();
	// y.close();
	// x.close();
	//-------------------------------------------------- 
}

#endif
#endif

} /* namespace io */

