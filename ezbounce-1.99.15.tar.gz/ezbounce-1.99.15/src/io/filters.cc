/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/filters.cc
 * (c) 2007-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <cstring>
#include "io/filters.h"
#include "debug.h"

namespace io {

#ifdef HAVE_BOOST_IOSTREAMS
const char filter_traits<GZIP_COMPRESSOR>::EXTENSION[] = "gz";
const char filter_traits<GZIP_DECOMPRESSOR>::EXTENSION[] = "gz";
#endif

/**
 * Return file extension associated with this filter type.
 */
const char * filter_file_extension(filter_t ft) 
{
	switch (ft) {
	case GZIP_DECOMPRESSOR:
	case GZIP_COMPRESSOR:
		return "gz";

	case BZIP2_COMPRESSOR:
	case BZIP2_DECOMPRESSOR:
		return "bz2";
	
	case BLOCK_ENCRYPTION_FILTER:
	case BLOCK_DECRYPTION_FILTER:
		return "enc";
	default:
		break;
	}	
	return "";
}

/**
 * Return name of this filter.
 */
const char * filter_name(filter_t ft)
{
	// TODO
	return "";	
}

/**
 * Return whether filter is intended to operate in text
 * mode or binary mode.
 */
filter_mode filter_io_mode(filter_t ft) 
{
	switch (ft) {
	case GZIP_DECOMPRESSOR:
	case GZIP_COMPRESSOR:
	case BZIP2_COMPRESSOR:
	case BZIP2_DECOMPRESSOR:
	case BLOCK_ENCRYPTION_FILTER:
	case BLOCK_DECRYPTION_FILTER:
		return BINARY_MODE;
	default:
		break;
	}
	return TEXT_MODE;
}

/**
 * Try to categorize the filter into compressor/encrypter/etc.
 */
filter_kind filter_work_kind(filter_t ft)
{
	switch (ft) {
	case GZIP_COMPRESSOR:
	case BZIP2_COMPRESSOR:
		return COMPRESSOR;
	case GZIP_DECOMPRESSOR:
	case BZIP2_DECOMPRESSOR:
		return DECOMPRESSOR;
	case BLOCK_ENCRYPTION_FILTER:
		return ENCRYPTER;
	case BLOCK_DECRYPTION_FILTER:
		return DECRYPTER;	
	default:
		break;
	}
	return OTHER;
}

/**
 * Given extension, return filter type (for output filters)
 * The extension may include the leading '.'
 */
template<> filter_t get_filter_by_extension<io::output>(const char * ext) 
{
	filter_t res = INVALID_FILTER;
	if (*ext == '.') {
		++ext;
	}
//	if (strcmp(ext, filter<GZIP
	// XXX: not quite yet
	// return for_each_filter(find_with_extension(ext, FILTER_END)).result();
	return res;
}

/**
 * Given extension, return filter type (for input filters)
 * The extension may include the leading '.'
 */
template<> filter_t get_filter_by_extension<io::input>(const char * ext) 
{
	static const filter_t candidates[] = { 
		GZIP_DECOMPRESSOR
	};
	if (*ext == '.') {
		++ext;
	}

	for (unsigned i = 0; i < sizeof(candidates) / sizeof(filter_t); ++i) {
		filter_t ft = candidates[i];
		if (strcmp(ext, filter_file_extension(ft)) == 0) {
			return ft;
		}		
	}
	return INVALID_FILTER;
}

}
