/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * io/poll_engine.cc
 * (c) 2007 Murat Deligonul
 */


#include "autoconf.h"
#include <ctime>
#include "io/poll_engine.h"
#include "debug.h"

namespace io {

// FIXME: the named initializer isn't portable
const struct pollfd poll_engine::blank_pollfd = { 
	fd: -1, 
	events: 0, 
	revents: 0 
};	

poll_engine::poll_engine(unsigned size, time_t * time_ptr) : engine(size, time_ptr), 
					pollfds(size, blank_pollfd),
					highest_fd(-1)
{
	DEBUG("poll_engine::poll_engine(): [%p] constructed\n", this);
}

poll_engine::~poll_engine() 
{
	DEBUG("poll_engine::~poll_engine(): [%p] destructed\n", this);
}

int poll_engine::add(pollable * p, int events)
{
	int r = engine::add(p, events);
	if (r < 0) {
		return r;
	}

	int fd = p->get_fd();

	/**
	  * Resize pollfd table if needed 
	  */
	if (unsigned(fd) >= pollfds.size()) {
		pollfds.resize( unsigned(fd)+1, blank_pollfd);
	}

	struct pollfd& pfd = pollfds[fd];
	assert(pfd.fd == -1);

	pfd.fd = fd;
	pfd.revents = 0;
	pfd.events = to_poll_events(events);
	highest_fd = std::max(fd, highest_fd);
	return 0;

	// XXX: old stuff; alternate storage method
	//--------------------------------------------------
	// std::vector<pollfd>::iterator i = std::find(pollfds.begin(), pollfds.end(), blank_pfd);
	// if (i != pollfds.end()) {
	// 	pollfd &p = *i;
	// 	p.fd = fd;
	// 	p.revents = p.events = 0;
	// 	idx = (&p - &pollfds[0]);
	// } else {
	// 	pollfd p;
	// 	p.fd = fd;
	// 	p.revents = p.events = 0;
	// 	pollfds.push_back(p);
	// 	idx = pollfds.size() - 1;
	// }
	// 
	// fds[fd] = p;
	//-------------------------------------------------- 
}

int poll_engine::release(pollable * p) 
{
	int r = engine::release(p);
	if (r < 0) {
		return r;
	}

	int fd = p->get_fd();
	struct pollfd& pfd = pollfds[fd];
	assert(pfd.fd != -1);
	pfd = blank_pollfd;

	return 0;
}

void poll_engine::set_events(pollable * p, int events)
{
	int fd = p->get_fd();
	struct pollfd& pfd = pollfds[fd];
	assert(pfd.fd == fd);

	pfd.events = to_poll_events(events);
	engine::set_events(p, events);
}

void poll_engine::compress()
{
	engine::compress();

	// XXX: old stuff
//--------------------------------------------------
// 
// 	unsigned old_size = pollfds.size();
// 	pollfds.erase(std::remove(pollfds.begin(),
// 				pollfds.end(),
// 				blank_pfd),
// 	           	pollfds.end());
// 			
// 	if (old_size != pollfds.size())
// 		for (unsigned i = 0; i < pollfds.size(); ++i)
// 			fds[pollfds[i].fd]->set_idx(i);
//-------------------------------------------------- 
}

int poll_engine::poll(int wait)
{
	int r = ::poll(&pollfds[0], highest_fd + 1, wait);
	const std::vector<pollable *> & table = get_table();
	engine::update_time();

	if (r > 0) {
		for (unsigned i = 0; i <= unsigned(highest_fd); ++i) {
			if (pollfds[i].fd == -1 || pollfds[i].revents == 0) {
				continue;
			}

			pollable * p = table[pollfds[i].fd];
			int events = to_io_events(pollfds[i].revents);
			p->event_callback(events);
		}
	}	
	else if (r < 0) {
		// FIXME: detailed error code
		return -1;
	}

	return r;
}

}  /* namespace io */
