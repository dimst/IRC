/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "autoconf.h"

#include "messages.h"
#include "debug.h"

HELP_ENTRY(command_list,
                   "\002Available commands\002:\r\n"
                   "    user        nick        pass        login\r\n"
                   "    conn        cancel      vhost       vhosts\r\n"
                   "    detach      log         ident       reattach\r\n"
                   "    quit        prefs       echo        disconnect\r\n"
                   "    traffic     allowed     trace       sessions\r\n"
                   "    motd        ezb         help        status\r\n"
		   "    set         get         unset       isset\r\n"
                   "    options     version     about       debug\r\n"
		   "    chaninfo    servinfo    acache\r\n"
                   "---\r\n"
                   "\002Available admin commands\002\r\n"
                   "    status      kill        die         dienow\r\n"
                   "    rehash      reload      write       hash\r\n"
                   "    save        whois\r\n"
		   "---"
	 	   "\r\n"
	 	   "\002Other general topics\002\r\n"
		   "    logging     config      vfs\r\n"
		   "    reconnecting\r\n");
		   

HELP_ENTRY(user,   "user <arguments>\r\n"
                   "    Just like the standard IRC command, your client\r\n"
                   "    sends this to begin the process of logging into ezbounce\r\n" );

HELP_ENTRY(nick,   "nick <nickname>\r\n"
                   "    Just like the standard IRC command, this changes your\r\n"
                   "    nickname.\r\n");

HELP_ENTRY(pass,   "pass <username>:<password> [auto-server]\r\n"
                   "    Logs you into ezbounce\r\n"
                   "    You must specify a username to login as. \r\n"
                   "    e.g. 'pass bob:mypassword'\r\n");

HELP_ENTRY(login,  "login <username> <password> [auto-server]\r\n"
                   "    Logs you into the proxy. You can specify an optional server\r\n"
                   "    to connect to\r\n");
#ifdef HAVE_SSL
HELP_ENTRY(conn,   "conn [-ssl] <server> [port] [password]\r\n"
                   "    Connects you to an IRC server\r\n"
                   "    You can use the -ssl switch to create an SSL connection\r\n");
#else
HELP_ENTRY(conn,   "conn <server> [port] [password]\r\n"
                   "    Connects you to an IRC server\r\n");
#endif

HELP_ENTRY(cancel, "cancel\r\n"
                   "    Cancels a connection attempt\r\n");

HELP_ENTRY(help,   "help <command>\r\n"
                   "    Provides helpful information about commands\r\n");

HELP_ENTRY(vhost,  "vhost <interface>\r\n"
                   "    Changes the connection interface (or virtual host) used\r\n"
                   "    when you connect to an IRC server\r\n");

HELP_ENTRY(vhosts, "vhosts\r\n"
                   "    Displays a list of virtual hosts available for your use\r\n");

HELP_ENTRY(detach, "detach\r\n"
                   "    Detaches you from the proxy. This means you will be\r\n"
                   "    disconnected from ezbounce, but your connection to\r\n"
                   "    the IRC server will remain alive.\r\n");

HELP_ENTRY(reattach, "reattach [--force] [--real-id | -r] <session number or connection ID>\r\n"
                   "    Attaches you back to an IRC session\r\n"
		   "      --real-id (or -r):  use real connection ID instead of session number\r\n"
		   "      --force          :  force reattach, even if connection isn't ready\r\n");  

HELP_ENTRY(disconnect, "disconnect\r\n"
                   "    Disconnects you from the IRC server -- You will remain\r\n"
                   "    connected to ezbounce\r\n");

HELP_ENTRY(ident,   "ident <fake-ident>\r\n"
                   "    Sets a fake ident reply\r\n");

HELP_ENTRY(log,    "log <command> [arguments]\r\n"
		   "    Displays information about the chat logging system\r\n"
                   "-------------------------------------------\r\n"
                   "- Available LOG Commands:\r\n"
		   "-\r\n"
		   "- STATUS [channel]\r\n"
		   "-      Displays the logging status in general, or for a specific channel\r\n"
		   "-\r\n"
		   "-\002NOTE\002: The chat logging system has changed in ezbounce 2.0\r\n"
		   "-    : For help with setting up chat logging, try `\002help logging\002'\r\n");

HELP_ENTRY(file,   "file <command> <arguments>\r\n"
                   "    Allows access to the ezbounce VFS\r\n"
                   "------------------------------------------------\r\n"
                   "- Available FILE Commands:\r\n"
                   "-\r\n"
                   "- LS [options] [pattern]\r\n"
                   "-      Lists files in in the current directory, or matching the given wildcard pattern.\r\n"
		   "-\r\n"
		   "- CD [new directory]\r\n"
		   "-	   Changes the current working directory.\r\n"
                   "-\r\n"
		   "- PWD\r\n"
		   "-	   Displays the current working directory.\r\n"
                   "-\r\n"
                   "- INFO <name>\r\n"
                   "-      Displays detailed information about a file, such as\r\n"
                   "-      size, owner, timestamp, and description.\r\n"
                   "-\r\n"
                   "- SEND [target] <filename>\r\n"
                   "-      Sends a file via DCC Send.  If target is specified, sends to user on IRC.\r\n"
                   "-\r\n"
                   "- SHOW [target] <filename>\r\n"
                   "-      Sends a file via DCC *Chat*.  If target is specified, sends to user on IRC.\r\n"
                   "-\r\n"
                   "- RM  <name>\r\n"
                   "-      Removes a file from the database and erases it from disk.\r\n"
                   "-\r\n"
                   "- DESC <name> [new description]\r\n"
                   "-      Allows you to view or change the description of a file\r\n"
                   "-      in the database.\r\n"
                   "-\r\n");


HELP_ENTRY(motd,   "motd\r\n"
                   "    Shows the message of the day (if available)\r\n");

HELP_ENTRY(quit,   "quit <reason>\r\n"
                   "    If auto-detach is enabled, use `/quote ezb quit'\r\n"
                   "    to quit from the IRC server and not detach\r\n");

HELP_ENTRY(ezbounce, "ezb <command> [args]\r\n"
                   "    Lets you use proxy commands while connected to an IRC server\r\n");

HELP_ENTRY(sessions, "sessions\r\n"
                   "    Displays your current detached IRC sessions\r\n");

HELP_ENTRY(traffic,"traffic\r\n"
                   "    Displays some stats about amount of data transferred from\r\n"
                   "    the proxy to/from clients and IRC servers\r\n");

HELP_ENTRY(set,    "set [target] <variable> <value>\r\n"
                   "    Allows you configure various personal preferences\r\n");

HELP_ENTRY(get,	   "fixme\r\n");

HELP_ENTRY(unset,  "fixme\r\n");

HELP_ENTRY(isset,  "fixme\r\n");

HELP_ENTRY(prefs,  "fixme\r\n");

HELP_ENTRY(options,	"options\r\n"
			"    Displays the available configuration options that you may set\r\n");   

HELP_ENTRY(about,  "about\r\n"
                    "   Displays some information about this program\r\n");

HELP_ENTRY(version,"version\r\n"
                    "   Displays the ezbounce and OS version\r\n");

HELP_ENTRY(debug,  "debug\r\n"
                    "   Displays some debug information\r\n"
                    "   NOTE: Not enabled by default\r\n");

HELP_ENTRY(echo,   "echo <text>\r\n"
                   "    ditto\r\n");

HELP_ENTRY(save,   "save\r\n"
                   "    Saves all user preferences to disk\r\n");

HELP_ENTRY(trace,  "trace <id>\r\n"
                   "    Displays network details about a user's connections\r\n");

HELP_ENTRY(allowed,"allowed\r\n"
                   "    Displays access settings for your user\r\n");

HELP_ENTRY(status, "status\r\n"
                   "    Displays proxy uptime and list of users\r\n"
                   "    The 'STAT' field contains one or more of the following flags:\r\n"
                   "     r  -- registered (user/nick received)   \r\n"
                   "     p  -- logged in\r\n"
                   "     a  -- administrator\r\n"
                   "     c  -- connecting to IRC server\r\n"
                   "     b  -- bounced\r\n"
                   "     d  -- detached\r\n"
                   "     w  -- waiting (newly connected)\r\n");

HELP_ENTRY(kill,   "kill <id> <reason>\r\n"
                   "    Kills a user off the proxy\r\n");

HELP_ENTRY(die,    "die <reason>\r\n"
                   "    Terminates the IRC proxy gracefully\r\n");

HELP_ENTRY(rehash, "rehash\r\n"
                   "    Attempts to reload the configuration file\r\n");

HELP_ENTRY(dienow, "dienow <reason>\r\n"
                   "    Terminates the IRC proxy immediately\r\n");

HELP_ENTRY(whois,  "whois <username or id>\r\n"
                   "    Displays information about a particular user\r\n");

HELP_ENTRY(hash,   "hash <table #>\r\n"
                   "    Displays performance statistics for the internal hash tables\r\n");

HELP_ENTRY(write,  "write <id> <message>\r\n"
                   "    Sends a message to user 'id'\r\n");

HELP_ENTRY(reload,  "reload\r\n"
                   "    Reloads the user preferences file from disk\r\n");

HELP_ENTRY(dcc, "dcc <command> [options]\r\n"
		"    Displays information about active DCC sessions and offers\r\n"
                " -- Available commands: --\r\n"
                "    list\r\n"
                "    info <id>\r\n"
                "    kill <id>\r\n"
                "    accept <id>\r\n"
                "    proxy  <id>\r\n"
                "    send  <id>\r\n"
                "    relay <id>\r\n");


HELP_ENTRY(servinfo,	"servinfo\r\n"
			"displays some information about the IRC server you are connected to\r\n");

HELP_ENTRY(chaninfo,	"chaninfo <channel>\r\n"
			"displays some information about a channel you are currently in\r\n");
/**
  * General topics
  */
HELP_ENTRY(logging, 	"\002ezbounce Chat Logging System\002\r\n"
			"FIXME: add content\r\n");

HELP_ENTRY(config,	"\002Configuring Personal Preferences\002\r\n"
			"FIXME: add content\r\n"
			"For a list of available options, try the 'options' command.\r\n"
			"For help with a specific option, try 'help option <option name>'\r\n");

HELP_ENTRY(vfs, 	"\002Using the ezbounce VFS\002\r\n"
				"FIXME: add content\r\n");

HELP_ENTRY(reconnection,	"\002IRC Server Reconnection\002\r\n"
				"ezbounce can automatically reconnect to IRC for you if the connection dies,\r\n"
				"even if you are currently detached from the proxy.  You just need to set a few options.\r\n"
				"-\r\n"
				"-     \002auto-reconnect\002 <on|off>\r\n" 
				"-     This must be set to 'on' to enable auto reconnection\r\n"
				"-\r\n"
				"-     \002max-reconnect-tries\002 <limit>\r\n"
				"-     Specifies how many times the reconnection will be attempted before giving up.  Must be at least 1.\r\n"	
				"-\r\n"
				"-     \002reconnect-delay\002 <time>\r\n"
				"-     Specifies in seconds how long to wait between reconnection attempts.  Permitted values range from 3-1800.\r\n"
				"-\r\n"
				"-\r\n"
				"These are all server level options, so you may configure them for specific IRC networks or servers.  Examples:\r\n"
				"      set  auto-reconnect on\r\n"
				"      set  network efnet  auto-reconnect off\r\n"
				"      set  server irc.dummy.net  reconnect-delay 15\r\n");

/* end */

