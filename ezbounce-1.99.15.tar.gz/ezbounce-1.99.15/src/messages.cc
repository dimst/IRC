/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * messages.cc
 * (C) 2007 Murat Deligonul
 */

#include "autoconf.h"

#include "messages.h"
#include "debug.h"

const char MSG_BANNED[]			= "You are banned from this server: %s\r\n:ezbounce 465 * :You are banned from this server: %s\r\n";
const char MSG_CONN_SUCCESSFUL[]	= "Now connected to %s.\r\n";
const char MSG_NOT_AUTHORIZED[]		= "Closing Link: %s (No authorization)\r\n";
const char MSG_INSUFFICIENT_ARGS[]	= "%s - Not enough parameters.\r\n";

const char MSG_STATUS_UPTIME[]		= "%s server up %s\r\n";
const char MSG_STATUS_CONNECTIONS[]	= "%d active connections\r\n";
const char MSG_STATUS_CPUTIME[]		= "CPU time used: %s\r\n";
const char MSG_STATUS_LISTHEADER[]	= ":" EZBOUNCE_HEADER   " NOTICE %s :ID    TIME  HANDLE     FROM            TO              STAT\r\n";

const char MSG_DIEING[] 		= "Waiting for proxy to shut down..\r\n";
const char MSG_DIEING_NOW[]		= "Ok, killing the proxy now.\r\n";

const char MSG_TOO_MANY_FAILURES[] 	= "Sorry, too many failed password attempts!\r\n";

