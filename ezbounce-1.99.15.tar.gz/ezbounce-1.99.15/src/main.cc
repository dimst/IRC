/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 * main.cc
 * (C) 1998-2009 Murat Deligonul
 */

#include "autoconf.h"

#include <string>
#include <cstdio>
#include <ctime>
#include <cerrno>
#include <csignal>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include "config/cfparser.h"
#include "config/proxy.h"
#include "net/resolver.h"
#include "io/utility.h"
#include "proxy.h"
#include "ezbounce.h"
#include "logos.h"
#include "debug.h"

const char EZBOUNCE_VERSION[] = "ezbounce v1.99.15";
const char EZBOUNCE_BUILD[] = "r????";

static const char EZBOUNCE_BANNER[] = "Internet Relay Chat (IRC) Proxy\n"
				      "(c) 1998-2009 by Murat Deligonul (murat@linuxftw.com)\n\n";

static void display_banner();
static void sig_handler(int);
static void setup_signals();
static void usage(const char *);
static bool parse_cmdline(int, char **, char **, bool *, int *);

static void setup_signals()
{
	struct sigaction sv;
	memset(&sv, 0, sizeof(sv));
	sv.sa_flags = 0;
	sv.sa_handler = SIG_IGN;
	sigaction(SIGPIPE, &sv, NULL);
	sv.sa_handler = &sig_handler;
	sigaction(SIGINT, &sv, NULL);
	sigaction(SIGTERM, &sv, NULL);
	sigaction(SIGHUP, &sv, NULL);
	sigaction(SIGALRM, &sv, NULL);
	/*    sigaction(SIGSEGV, &sv, NULL); */
}

int main(int argc, char *argv[])
{  
	using std::string;

	pid_t pid;
	bool nobg = false;            /* goto the background? */
	char *iface_listen = NULL;    /* interface to bind to for listening */
	int confidx  = 0;             /* argv[confidx] is the config file */


	bool result = parse_cmdline(argc, argv, &iface_listen, &nobg, &confidx);	
	
	display_banner();
	if (argc < 2 || !result) {
		usage(argv[0]);
		return 1;
	}

	/** 
	 * We will not run as root. get this stupidity check out of the 
	 * way as soon as possible 
	 */
	if (getuid() == 0 || geteuid() == 0) {
		fprintf(stderr, "This program will not run as root.\n");
		return 1;
	}

	const char * cf = argv[confidx];
	config_parser parser(cf);
	printf("Reading config file '%s' ...\n", cf);

	int r = parser.parse();
	if (r < 0) {
		fprintf(stderr, "Unable to load config file, exiting.\n");
		return 1;
	}
	/* FIXME: Potential issues with	this? */
	chmod(cf, 0600);	

	printf("Config file successfully loaded.\n");

	/** Do listen vhost stuff **/
	if (iface_listen) {
		parser.get_options().set<string>(proxy_config::LISTEN_VHOST, iface_listen);
	}

	/** Create new proxy object and transfer settings **/
	ircproxy * proxy = ircproxy::create();
	proxy->set_config_data(parser.get_options(), parser.get_users(), 
				parser.get_vhosts(), parser.get_shitlist());
	proxy->set_config_file(cf);
	
	r = proxy->setup_sockets();
	if (r < 0) {
		fprintf(stderr, "Fatal error setting up sockets.  Exiting.\n");
		return 1;
	}
	proxy->start_sockets();
	
#ifdef HAVE_SSL
	r = proxy->setup_ssl();
	if (r < 0) {
		printf("SSL: cannot initialize SSL! (check your cert-file '%s')\n", proxy->config().get<string>(proxy_config::CERT_FILE).c_str());
	}
	else {
		printf("SSL: subsystem initialized\n");
		proxy->start_ssl_sockets();
	}
#endif

	if (!proxy->num_ports()) {
		fprintf(stderr, "Could not open any ports for listening.\n" 
				"Please check your config and try other ports.\n");
		return 1;
	}

	printf("Listening on total of %d ports\n", proxy->num_ports());

	/* start the log file */
	if (proxy->startlog() < 0) {
		perror("WARNING: Unable to open log file");
	}

	/** forgot if this was mandatory **/
	const string& ufile = proxy->config().get<string>(proxy_config::USER_FILE);
	if (!ufile.empty() && !access(ufile.c_str(), W_OK | R_OK)) {
		printf("Loading user preferences from disk (%s) .... \n", ufile.c_str());
		int i = proxy->load_prefs();
		if (i < 0) {
//			printf("(!) Errors parsing user preferences file, ignoring\n");
			fprintf(stderr, "Unable to load user preferences file, exiting\n");
			return 1;
		}
	}

	const string& fdir = proxy->config().get<string>(proxy_config::VFS_DIR);
	if (!fdir.empty()) {
		printf("Setting up Virtual File System in '%s' ....", fdir.c_str());
		std::string reason;
		if (proxy->setup_vfs(reason) != 0) {
			printf("failed: %s\n", reason.c_str());
			fflush(stdout);
			fprintf(stderr, "Unable to setup VFS, exiting\n");
			return 1;
		} 
		else {
			printf("OK\n");		
		}
	}

	if ((nobg) || ((pid = fork()) == 0)) { 
		setsid();
		/* redirect stderr to proxy log file.
		   close stdin & stdout. */
		close(STDIN_FILENO);
		/* close(STDOUT_FILENO); -- config file reloading will output to stdout */
		if (!nobg) {
			proxy->redir_stdxxx();
		}

		setup_signals();

		srand(time(NULL));

		/* Write out pid-file if needed */
		const string& pidfile = proxy->config().get<string>(proxy_config::PID_FILE);
		if (!pidfile.empty()) {
			int f = open(pidfile.c_str(), O_CREAT | O_WRONLY, 0644);
			io::fdprintf(f, "%d", getpid());
			close(f);
		}
		if (nobg) {
			printf("Starting IRC proxy ...\n");
		}
		proxy->event_loop();

		/* Server is finished. */
		proxy->stoplog();
		delete proxy;
		proxy = NULL;
		exit(0);
	}
	else if (pid < 0) {
		perror("Can't go into the background");
	} 
	else {
		printf("IRC Proxy started -- pid: %d\n", pid);
	}
	return 0;
}

static void sig_handler(int sig)
{
	ircproxy * proxy = ircproxy::instance();
	if (!proxy) {
		/** probably still parsing config, so just exit. **/
		exit(0);		
	}
	
	switch (sig) {
	case SIGHUP:
		proxy->printlog("Got SIGHUP; reloading configuration file\n");
		proxy->request_rehash();
		break;
	case SIGTERM:
		proxy->printlog("Got terminate signal, killing server now\n");
		proxy->request_shutdown(true, "got terminate signal");
		break;
	case SIGSEGV:
		proxy->printlog("Got SIGSEGV: terminating\n");
		break;
	case SIGINT:
		proxy->printlog("Interrupt signal: waiting for server to shut down\n");
		proxy->request_shutdown(false, "keyboard interrupt");
	default:
		break;
	}
}

static void usage(const char *bname)
{
	fprintf(stderr, "Usage:\n%s [options] <configuration file>\n", bname);
	fprintf(stderr, "Available options:\n");
	fprintf(stderr, "  -f              don't go into the background\n");
	fprintf(stderr, "  -b <hostname>   listen for connections on a different interface\n");
}

static bool parse_cmdline(int argc, char **argv, char **iface_listen,
                          bool * nobg, int *index)
{
	for (int z = 1; z < argc; ++z) {
		switch (argv[z][0]) {
		/* a -flag, next char must be -B or -F */
		case '-':
			switch (argv[z][1]) {
			case 'f':
			case 'F':
				*nobg = true;
				break;
			case 'b':
			case 'B':              
				if (z + 1 < argc) {
					*iface_listen = argv[++z];
				}
				continue;
			case '-':
				if (strcasecmp(&argv[z][2], "help") != 0) {
					continue;
				}
			case 'h':
				return false;
			default:
				break;
			}
		default:
			*index = z;
		}	/* switch (argv[z][0]) */
	} 	/* for loop */

	return (*index != 0);
}


static void display_banner()
{
	srand(time(NULL));
	// int i = rand() % NUM_EZB_LOGOS;
	// I like this logo better.
	const int i = 1;
	printf("%s\n", ezb_logos[i]);
	printf("%s\n", EZBOUNCE_VERSION);
	printf("%s", EZBOUNCE_BANNER);
}

