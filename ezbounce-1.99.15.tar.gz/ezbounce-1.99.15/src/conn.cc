/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * conn.cc -- part of the ezbounce IRC proxy.
 * (C) 1998-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <list>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <cerrno>
#include <cstdarg>
#include <sys/types.h>
#ifdef HAVE_SYS_TIME_H
    #include <sys/time.h>
#endif
#include <sys/stat.h>
#include <unistd.h>
#include <pwd.h>
#include "util/strings.h"
#include "util/lib_mdidentd.h"
#include "util/generic.h"
#include "util/iterators.h"
#include "util/tokenizer.h"
#include "config/ezb_dependencies.h"
#include "io/event.h"
#include "io/error.h"
#include "irc/address.h"
#include "irc/server_info.h"
#include "irc/cache.h"
#include "irc/flood.h"
#include "irc/ignore.h"
#include "fs/entry.h"
#include "fs/error.h"
#include "fs/file_system.h"
#include "fs/directory.h"
#include "fs/key.h"
#include "logging/chatlog.h"
#include "net/error.h"
#include "conn.h"
#include "commands.h"
#include "textline.h"
#include "ezbounce.h"
#include "dcc.h"
#include "dcc_offer.h"
#include "proxy.h"
#include "messages.h"
#include "reconnect.h"
#include "user.h"

#include "debug.h"

using std::vector;
using std::list;
using std::string;

using irc::address_cache;
using irc::server_entry;
using irc::server_info;
using irc::channel;
using irc::ignore_list;
using irc::flood_protector;

using fs::file_entry;
using fs::file_system;

using net::socket_exception;
using net::resolver;
using net::resolver_callback_wrapper;

using util::timer;
using util::delete_ptr;
using util::map_value_iterator;
using util::make_value_iterator;
using namespace util::strings;

ircproxy * conn::proxy = NULL;

unsigned conn::bytes_tos   = 0;
unsigned conn::bytes_froms = 0;
unsigned conn::bytes_toc   = 0;
unsigned conn::bytes_fromc = 0;

util::id_generator conn::idgen(4);

conn::hash_table_t		conn::cmdhash(41);
conn::hash_table_t		conn::incoming_hash(7);
conn::help_hash_table_t		conn::help_table(37);

conn::conn(net::socket * source) : 	r_callback(this),
					_id(idgen.generate()),
					stat(0),
					irc(NULL),
					acache(NULL),
					servinfo(NULL),
					ignores(NULL),
					floodp(NULL),
					key(NULL),
					connect_time(0), last_recved(0), 
					detach_time(0), reattach_time(0),
					lookup_id(-1),
					chan_log(NULL), priv_log(NULL),
					qtimer(NULL), dtimer(NULL), rtimer(NULL),
					rinfo(NULL),
					failed_passwords(0),
					server(NULL),					
					client(NULL)					
{
	assert(source != NULL);
	last_recved = connect_time = proxy->time();
	try {
		client = new client_sock(this, source,
				proxy->config().get<int>(proxy_config::MIN_BUFFER_SIZE),
				proxy->config().get<int>(proxy_config::MAX_BUFFER_SIZE));
	} 
	catch (socket_exception& e) {
		proxy->printlog("Cannot create socket: %s (errno: %s)\n", e.what(),
				strerror(errno));
#ifdef HAVE_SSL
		/* FIXME: why is this SSL error check here ? */
		if (ERR_get_error()) {
			proxy->printlog("ssl_accept() failed: %s\n", ERR_error_string(ERR_get_error(), NULL));
		}
#endif
		throw;
	}

	irc = new irc::address("(unknown)");
	update_client_address();

	proxy->printlog("Client Connected: %s%s on port %d (assigned id %d)\n",
#ifdef HAVE_SSL
			client->get_options() & net::socket::SOCK_SSL ?
			"[SSL] " :
#endif
			"",
			client->peer_addr(), client->local_port(), id());

	/* Authorization step 1:  reverse lookup the IP address */
	setf(REGISTERING);
	client->set_events(0);
	auth.set(authorizer::FROM_IP, client->peer_addr());
	auth.set(authorizer::FROM_PORT, client->peer_port());
	lookup_id = client->get_resolver()->async_lookup(client->get_family(), client->peer_addr(), 0,
			resolver::OPT_REVERSE_LOOKUP, &r_callback);

	assert(lookup_id != 0);
	assert(!is_dead());
}


conn::~conn()
{
	DEBUG("conn::~conn() [%p]\n", this);
	auth.logout_connection(this);
	delete key;
	delete irc; 	// could be done elsewhere
	idgen.clear(_id);
	assert(!client && !server);		/* we should NEVER be destructed directly */
}

/* static */ void conn::set_proxy_instance(ircproxy * p) 
{
	assert( proxy == NULL );
	proxy = p;
}

/**
 * Look up conn object by its id.
 */
/* static */ conn * conn::lookup(unsigned int i) 
{
	const std::list<conn *>& conn_list = proxy->conn_list();
	std::list<conn *>::const_iterator f = std::find_if(conn_list.begin(), conn_list.end(),
								id_match_helper(i));
	return (f != conn_list.end()) ? *f : NULL;
}

/**
 * Convenience function; convert string argument to int and 
 * then look it up.
 */
/* static */ conn * conn::lookup(const char * str) 
{
	int j;
	if (!check_int(str, &j)) {
		return NULL;
	}
	return conn::lookup((unsigned)j);
}

/**
 * Effectively puts the conn in a zombie state
 */
int conn::die(int r, const void * reason)
{
	DEBUG("conn::die() -- %p\n", this);
        if (is_dead()) {
                return 0;
        }
	assert(client || server || is_detached());
	
	if (r == KILLED && client != NULL) {
		cprintf("Your connection has been killed: %s\r\n", reason);
		client->flushO();
	}
	
	proxy->printlog("Client Disconnected: %s: %s\n", addr(), reason);
	
	abort_reconnect();
	server_lost();
	client_lost();
	disown_dccs(NULL);
	clearf(ADMIN);
	clearf(DETACHED);
	assert(is_dead());
	return 0;
}


//
// Socket event handlers
//

/**
 * Called when server socket connects.
 */
void conn::on_server_connect()
{
	/**
	 * If connection ok, update internal variables ...
	 */
	clearf(CONNECTING);
	setf(BOUNCED);
	server->set_events(io::EVENT_READ);
	servinfo = new server_info(strings[SERVER].c_str());
	acache   = new address_cache(servinfo, 37);
	ignores  = new ignore_list();
	floodp   = new flood_protector(servinfo, ignores, 37); 

	cprintf(MSG_CONN_SUCCESSFUL, strings[SERVER].c_str());
	
	// Now register with the server 
	if (!strings[IRCPASS].empty()) {
		server->printf("PASS :%s\r\n", strings[IRCPASS].c_str());
	}
	server->printf("USER %s\r\nNICK %s\r\n", strings[USERCMD].c_str(), irc->nick());

	proxy->printlog("IRC Connection Successful: %s to %s port %d\n",
			addr(), strings[SERVER].c_str(), server->peer_port());
	user()->printlog("IRC Connection Successful: %s to %s port %d\n",
			addr(), strings[SERVER].c_str(), server->peer_port());
	strings.unset(IRCPASS);
	
	if (is_detached()) {
		// this might be the case during an IRC server reconnection
		assert(is_reconnecting());
		detach_time = proxy->time();

		setup_anti_idle();
		setup_irc_logs(DETACH);
	}
	else {
		setup_irc_logs(IRC_CONNECT);
	}
	regulate_io_events(); 
}

/**
  * Server address resolved; non-blocking connect now in progress.
  */
void conn::on_server_connecting()
{
	setup_fake_ident();
}

/**
  * Connection failed, possibly because of DNS lookup failure or connect()
  * error.
  */
void conn::on_server_connect_fail(int err)
{
	const char * error = net::strerror(err);

	cprintf("\002[connect]\002: connection attempt FAILED: %s\r\n", error);
	proxy->printlog("IRC Connection Failed: %s to %s port %d: %s\n", addr(), 
			strings[SERVER].c_str(), server->peer_port(), error);
	user()->printlog("IRC Connection Failed: %s to %s port %d: %s\n", addr(), 
			strings[SERVER].c_str(), server->peer_port(), error);

	server_lost();

	if (is_reconnecting()) {
		/* Try again, if we still can. */		
		if (rinfo->get_tries() >= rinfo->get_max_tries()) {
			if (is_detached()) {
				/* Worthless at this point; just quit 
				 * NOTE: this will also call abort_reconnect() to free its resources */				
				die(0, "too many failed reconnection attempts; giving up");
				return;
			}
			cprintf("[\002connect\002]: too many failed attempts; giving up.\r\n");
			abort_reconnect();
		}
		else {
			/* Fire timer again */			  
			rtimer->enable();
			cprintf("[\002connect\002]: trying again in %d seconds.\r\n", rinfo->get_delay());
		}
	}
	else if (is_detached()) {
		/* Client died during IRC server connect and was auto-detached.
		 * Now worthless */
		die(0, "detached, and connection to IRC server failed");
		return;
	}

	regulate_io_events();
}

void conn::on_server_disconnect(int err)
{
	string msg = my_sprintf("IRC Connection Lost: [%s]<--->[%s port %d] %s\n", addr(),
								server->peer_addr(),
								server->peer_port(),
								net::strerror(err));
	proxy->printlog("%s", msg.c_str());
	user()->printlog("%s", msg.c_str());

	cprintf("Lost connection to server [%s port %d]: %s\r\n", server->peer_addr(),
								server->peer_port(),
								net::strerror(err));

	const bool want_part_all = decide<server_node>(servinfo->server_target(), 
						irc_server_config::PART_ON_DISCONNECT) == 1;
	if (want_part_all && !is_detached()) {
		show_part_all();
	}

	/**
	  * Check if reconnect was already in progress.
	  */
	if (is_reconnecting()) {
		/* Try again, if we still can. */		
		if (rinfo->get_tries() >= rinfo->get_max_tries()) {
			user()->printlog("Reconnect: giving up -- too many failed attempts (%s to %s)\n",
						addr(), rinfo->get_server().name().c_str());
			if (is_detached()) {
				/* Worthless at this point; just quit 
				 * NOTE: this will also call abort_reconnect() to free its resources */				
				die(0, "too many failed reconnection attempts; giving up");
				return;
			}
			cprintf("[\002connect\002]: too many failed attempts; giving up.\r\n");
			abort_reconnect();
		}
		else {
			/* Fire timer again */			  
			rtimer->enable();
			user()->printlog("Reconnect: %s to %s trying again in %d seconds.\n",
						addr(), rinfo->get_server().name().c_str(), rinfo->get_delay());
			cprintf("[\002connect\002]: trying again in %d seconds.\r\n", rinfo->get_delay());
		}		
	}
	/**
	 * Otherwise, figure out what we're doing ...
	 */
	else {
		const bool want_reconnect = decide<server_node>(servinfo->server_target(), 
						irc_server_config::AUTO_RECONNECT) == 1;

		if (want_reconnect) {
			start_reconnect();
		}
		else if (is_detached()) {
			die(0, "detached server connection died");
			return;
		}
	}

	server_lost();
	regulate_io_events();
}

/**
  * Socket writeable.
  */
int conn::on_server_writeable()
{
	DEBUG("server_sock::on_writable() [%p]\n", this);
	/** SSL writes can sometimes fail **/
	int ret = server->flushO();
	if (ret < 0) {
		on_server_disconnect(io::WRITE_ERROR);
		return -1;
	}

	regulate_io_events();
	return 0;
}

/**
  * Socket readable.  Also check for read errors indicating disconnect.
  */
int conn::on_server_readable()
{
	DEBUG("server_sock::on_readable() [%p]\n", this);
	const bool full = server->buffer_available() == 0;

	if (!full) {
		int ret = server->read();
		if (ret < 0) {
			on_server_disconnect(ret);
			return -1;
		} 
		conn::bytes_froms += ret;
	}

	if (!ignoring_input()) {
		if (parse_from_server() < 0) {
			die(0, "shutdown requested from server parse");
			return -1;
		}
		// data should have been relayed or discarded
		// if we were marked as full, make sure it's not the case anymore
		if (full && is_bounced() && !server->buffer_available()) {
			on_server_disconnect(io::BUFFER_FULL);
			return -1;
		}
	}

	regulate_io_events();
	return 0;
}


/**
  * Client socket disconnect
  */
void conn::on_client_disconnect(int err)
{
	assert(!is_dead());	
	proxy->printlog("Client Disconnect: [%s] %s\n", addr(), net::strerror(err));

	if ((is_bounced() || is_reconnecting() || is_connecting())) {
		const bool want_auto_detach = decide<server_node>(get_server_target(), 
							irc_server_config::AUTO_DETACH) == 1;
		if (want_auto_detach && do_auto_detach() == 0) {
			regulate_io_events();
			return; 
		}
	}
	/* If client died, terminate server connection as well */
	die(0, "read/write error on client");
}

int conn::on_client_readable()
{
	assert(!is_dead());
	DEBUG("conn::on_client_readable() [%p]\n", this);

	int ret = client->read();

	if (ret < 0) {  
		// buffer full or other errors 
		on_client_disconnect(ret);
		return -1;
	}

	conn::bytes_fromc += ret;

	if (!ignoring_input()) {
		if (parse() < 0) {
	        	die(0, "shutdown requested");
			return -1;
		}
	}
	regulate_io_events();
	return 0;
}

int conn::on_client_writeable()
{
	assert(!is_dead());
	DEBUG("conn::on_client_writable() [%p]\n", this);
	int ret = client->flushO();
	/**
	 * Send queued data.
	 */
	if (ret < 0) {
		on_client_disconnect(io::WRITE_ERROR);
		return -1;
	}
	
	if (!rfuncs.empty()) {
		process_restartable();
	}
		
	regulate_io_events();
    	return 0;
}

/**
 * Return values for parse() and parse_from_server():
 *   1: OK
 *  -1: something occured requring destruction of the object
 */
int conn::parse()
{
	typedef tokenizer<delimeter_seeker<char>, char *, io::byte_length_pair> buffer_tokenizer;

	io::buffer& buffer = client->get_ibuff();
	buffer_tokenizer tokenizer(buffer.begin(), buffer.end(), 
					delimeter_seeker<char>("\r\n", true));

	last_recved = proxy->time();

	io::byte_length_pair last_block(buffer.begin(), 0);
	for (buffer_tokenizer::iterator i = tokenizer.begin(),
					e = tokenizer.end();
					i != e;
					++i) {
		// Obtain each line of IRC input and prepare it for string operations.
		const io::byte_length_pair& p = *i;
		char * data = p.first;
		const size_t len  = p.second;

		/**
		 * Check if we have room in the out buffer to send this.
		 */
		if (server != NULL && server->buffer_availableO() < len + 3) {
			DEBUG("conn::parse() -- detected full server buffer\r\n");
			break;
		}
		last_block = p;
		data[len] = 0;

		string command;
		tokenize<string>(data, data+len, " ", &command, 1);
		to_uppercase(command);

		const cmd * c = lookup_command(cmdhash, command.c_str(),
				stat | ((stat & BOUNCED) ? NDM : 0));

		if (c) {
			const char * start = no_leading(no_leading(data) + command.size());
			textline args(start);

			DEBUG(">>>>>> HANDLER: %s(%d, %s)\n", c->msg, c->id, args.all());
			int r = (this->*(c->handler))(c->id, args);

			/**
			 * See what happened ...
			 */
			if (ignoring_input()) {
				// only possible if restartable functions were created
				// e.g. outgoing /who right after detach
				break;
			}
			if (is_detached()) {
				// definitely possible
				return 1;
			}
			if (r < 0) {
				// fatal error
				return -1;
			} 
			else if (r > 0)	{
				continue;
			}
		}
		if (is_bounced()) {
			/**
			 * If we get here, we are sending it to the server.
			 */
			server->queue(data, len);
			server->queue("\r\n", 2);
		}
	}

	/**  
	 * Remove everything that we've sent from the buffer. 
	 * Leave the trailing delimeter (\r\n) sequence in there for now.
	 */
	const size_t to_remove = last_block.first - buffer.begin() + last_block.second;
	buffer.flush(to_remove);
	return 1;
}

/** 
 * Start a connection attempt.  The process is as follows:
 *	1) determine type of target address (IP or not)
 *	2) perform reverse lookup
 *	3) when lookup is done verify we are allowed to connect
 *		and register connections.
 *	4) call async_connect (with auth.TO_IP)
 *	5) when on_connecting() is we know local port so setup fake ident
 *	6) either on_connect() or on_connect_fail() will be called
 */
int conn::setup_connect(const char * where, unsigned short port, const char * pass, bool ssl)
{
	setf(CONNECTING);
	strings.set(IRCPASS, non_null(pass));
	strings.set(SERVER, non_null(where));
	int options = ssl ? net::socket::SOCK_SSL : 0;
	server = new server_sock(this, PF_UNSPEC, options,
		       			proxy->config().get<int>(proxy_config::MIN_BUFFER_SIZE), 
					proxy->config().get<int>(proxy_config::MAX_BUFFER_SIZE));

	resolver::request * req;
	auth.set(authorizer::TO_PORT, port);

	if (resolver::is_ip_address(AF_UNSPEC, where)) {
		auth.set(auth.TO_IP, where);
		req = resolver::create_request(AF_UNSPEC, where, port, resolver::OPT_REVERSE_LOOKUP, &r_callback);
	}
       	else {
		auth.set(auth.TO_HOST, where);
		req = resolver::create_request(AF_UNSPEC, where, port, 0, &r_callback);
	}
	lookup_id = server->get_resolver()->async_lookup(req);

	server->set_events(0);	
	return 0;	// awaiting result of DNS lookup
}


/**
 * Set up fake ident:
 * Currently only mdidentd (old method) is supported.
 */
void conn::setup_fake_ident()
{
	const bool can_fake = is_allowed(user_perms::ENABLE_FAKE_IDENTS);
	const string& fake = user()->options()->get<string>(user_config::FAKE_IDENT);
	const string& method = proxy->config().get<string>(proxy_config::FAKE_IDENT_METHOD);

	if (!can_fake || fake.empty()) {
		return;
	}

	const char * f = fake.c_str();
	const char * m = method.c_str();
	/**
	 * Right about to connect.. we have local port and remote port
	 * so we register the fake ident if needed.
	 */
	if (!strcasecmp(m, "mdidentd")) {
		int r = register_fake_ident(MDIDENTD_PATH, f, server->local_port(), server->peer_port());
		if (r != IDENT_OK) {
			cprintf("Error registering fake ident '%s' for you (but continuing anyway): %s\r\n",
					f, ident_error(r));
			proxy->printlog("Fake Ident Failed: '%s' for %s: %s\n",
					f, addr(), ident_error(r));
		} 
		else {
			proxy->printlog("Fake Ident Registered: '%s' for %s\n", f, addr());
		}
	}
	else if (!strcasecmp(method.c_str(), "oidentd-hack")) {
		/**
		 * This is really stupid.
		 * But everyone wants it.
		 */
		cprintf("Registering fake ident via unsafe oidentd-hack method...\r\n");

		struct passwd * pwd = getpwuid(getuid());
		if (pwd == NULL) {
			cprintf("Error registering fake ident '%s': %s\r\n", f, strerror(errno));
		}

		string filename=pwd->pw_dir;
		filename += "/.oidentd.conf";

		std::ofstream out;
		out.open(filename.c_str());
		out <<  "global { reply \"" << f << "\" }\n";
		out.close();
	}
}


/** 
 * Make sure we are allowed to connect and register connection.
 * TODO: log errors in user/proxy logs?
 */
int conn::authorize_connect()
{
	if (is_admin()) {
		return 0;
	}
	
	int i = auth.register_outgoing_connection();
	switch (i) {
	case authorizer::SUCCESS:
		return 0;
	case authorizer::ERR_NOT_ALLOWED:
		cprintf("\02[connect]\02: DENIED: %s\r\n", auth.get(authorizer::FAILURE_REASON));
		break;
	case authorizer::ERR_NO_MATCH:
		cprintf("\02[connect]\02: ERROR: You are not allowed to connect to %s\r\n", 
				auth.get(authorizer::TO_IP));
	}
	return -1;	
}

/** 
 * Called when we authorized, registered and ready to connect.
 * After this point either on_connect_fail() or on_connect() will be called
 * NOTE: on_connecting() is called right after a succesful call to ::connect() 
 */
void conn::start_connect()
{
	const string& vhost = user()->options()->get<string>(user_config::VHOST);
	int r = server->async_connect(auth.get(authorizer::TO_IP), 
					vhost.c_str(),
					auth.get(authorizer::TO_PORT),
					(net::socket::sock_option) server->get_options());
	if (r < 0) {
		server->on_connect_fail(r);
	} 
	else {
		cprintf("\02[connect]\02: binding to vhost\r\n");
	}
	regulate_io_events();
}


/**
 *  Return:
 *          0 -- Not idle
 *          1 -- Idle too long
 *          2 -- Idle too long; didn't register in time
 *
 *  Idle time limits do not apply to admins.
 *  Idle time limits do not apply when when connected to an irc server.
 */
int conn::status_check(time_t now, const void ** extra) const
{
	if (is_dead()) {
		return -1;
	}
	if (checkf(ADMIN | BOUNCED | DETACHED | RECONNECTING | CONNECTING)) {
		return 0;
	}

	/* User not registered */
	if (!is_logged_in()) {
		const int max_time = proxy->config().get<int>(proxy_config::MAX_REGISTER_TIME);
		if ( (now - connect_time) > max_time && max_time > 0 ) {
			*extra = "Failed to register in time";
			return 1;
		}
	}
	if (is_logged_in()) {
		const int max_time = user()->config()->get<int>(user_perms::MAX_IDLE_TIME);
		if ( (now - last_recved) > max_time && max_time > 0 ) {
			*extra = "Idle time limit exceeded";
			return 1;
		}
	}
	return 0;
}

// XXX: size of the message cannot exceed 512 bytes
int conn::cprintf(const char *message, ...) const
{
	static const char hdr[] = ":" EZBOUNCE_HEADER " NOTICE ";
	if (!client) {
		return -1;
	}

	/**
	 * To avoid two printf() calls we consolidate our standard 
	 * header and the outgoing message.
	 */
	char * format = NULL;
	my_asprintf(&format, "%s%s :%s", hdr, irc->nick(), message);
	
	char * out = NULL;
	va_list ap;
	va_start(ap, message);
	my_vasprintf(&out, format, ap);
	va_end(ap);
	delete[] format;

	/**
	 * Limit to 512 bytes, including \r\n sequence.
	 */
	size_t len = strlen(out);
#ifdef __DEBUG__
	assert(strcmp(&out[len - 2], "\r\n") == 0); 
	if (len > 512) {
		DEBUG("conn::cprintf() [%p]: message too long (%zu bytes), had to truncate: %s\r\n", 
						this, len, out);
	}
#endif
	len = std::min<size_t>(512, len);
	out[len-2]='\r';
	out[len-1]='\n';

	/**
	 * Make buffer space if needed.
	 */
	if (client->buffer_availableO() < len) {
		client->flushO();
	}

	/**
	 * And write...
	 */
	int i = client->queue(out, len);
	delete[] out;
	if (i > 0) {
		bytes_toc += i;
		return i;
	}
	DEBUG("conn::cprintf() [%p] didn't have enough buffer space!\n", this);
	return -1;
}

/**
  * Allows sending of multi-lined messages. \r\n is the separator.
  * FIXME: does not allow formatting, so should probably be renamed.
  */
int conn::cprintf_multiline(const char * message) const
{
	int total = 0;
	if (!client || !is_registered()) {
		return -1;
	}
	tokenizer<> tok(message, message + strlen(message), delimeter_seeker<>("\r\n"));
	for (tokenizer<>::iterator i = tok.begin(), e = tok.end();
					i != e;
					++i) {
		const string& s = *i;
		total += cprintf("%s\r\n", s.c_str());
	}
	return total;
}

/**
 * Detach client from proxy but keep his connection to server alive.
 *
 * client must:
 *    be connected to a server, connecting or a server, in a reconnect attempt
 *    not already be detached
 *
 * NOTE: client may detach in the 'CONNECTING' state
 */
int conn::detach()
{
	if (!is_bounced() && !is_reconnecting() && !is_connecting()) {
		return -1;
	}
	if (is_detached()) {
		return -1;
	}

	/**
	 * Change nickname and set away, if requested..
	 */
	if (is_bounced()) {
		const string& detach_nick = user()->options()->get<server_node, string>(
				servinfo->server_target(), 
				irc_server_config::DETACH_NICK);
		const string& away_msg = user()->options()->get<server_node, string>(
				servinfo->server_target(), 
				irc_server_config::DETACH_AWAY_MSG);

		if (!detach_nick.empty()) {
			server->printf("NICK :%s\r\n", detach_nick.c_str());
		}
		if (!away_msg.empty()) {
			server->printf("AWAY :%s\r\n", away_msg.c_str());
		}
	}

	cprintf("Detach successful.\r\n");
	cprintf("Use the 'sessions' command after reconnect to reattach to session.\r\n");
	cprintf("---> Closing connection to you...\r\n");
	client->printf("ERROR :Closing Link: %s (Detaching)\r\n", addr());
	client->flushO();

	if (is_bounced()) {	
		proxy->printlog("Client Detached: %s from connection to %s port %d\n",
				addr(), servinfo->name(), server->peer_port());
	}
	else {
		proxy->printlog("Client Detached: %s (during connection or reconnection attempt)\n", addr());
	}
	user()->printlog("Client detached: %s\n", addr());

	disown_dccs(NULL);
	detach_time = proxy->time();

	setf(DETACHED);

	if (is_bounced()) {
		setup_anti_idle();
		setup_irc_logs(DETACH);
	}

	/* Pretend user has disconnected. */
	delete client;
	client = NULL;
	return 0;
}

/**
  * validate_reattach()
  * 
  * Ensures sanity before a reattach can be performed.
  *	target:			reattach target to check
  *	force:			try to force reattach if possible
  */
int conn::validate_reattach(conn * target, bool force) const
{
	// Can only reattach while disconnected
	if (is_reconnecting()) {
		cprintf("REATTACH: Cannot reattach right now; reconnecting to IRC.\r\n");
		return -1;
	}
	if (is_connecting() || is_bounced()) {
		cprintf("REATTACH: Must be disconnected from IRC before reattaching.\r\n");
		return -1;
	}			
	// Only reattach to connection of same user!
	if (target->user() != user()) {
		cprintf("REATTACH: Invalid target user.\r\n");
		return -1;
	}

	if (!target->is_detached()) {
		cprintf("REATTACH: Target is not detached.\r\n");
		return -1;
	}

	// Do not reattach to reconnecting clients by default.
	if (!force && target->is_reconnecting()) {
		cprintf("REATTACH: Target is currently reconnecting to IRC (server '%s', %zd/%zd channels joined).  Try again in a few minutes.\r\n", 
				target->rinfo->get_server().name().c_str(),
				target->rinfo->num_succeeded(), target->rinfo->channels().size() );
		cprintf("REATTACH:    (use '--force' option to force reattach anyway)\r\n");
		return -1;
	}

	// Do not reattach yet if some channels have incomplete data
	if (!force && target->is_bounced()) {		
		const size_t incomplete_chans = std::count_if(make_value_iterator(target->acache->channels_begin()), 
								make_value_iterator(target->acache->channels_end()), 
								not1(std::mem_fun(&channel::has_all_data)));
		if (incomplete_chans > 0) {
			cprintf("REATTACH: Target is waiting on channel information from the IRC server.  Try again in a moment.\r\n");
			cprintf("REATTACH:    (use '--force' option to force reattach anyway)\r\n");
			return -1;
		}
	}
	return 0;
}

/**
 * The reattaching process:
 *
 * 1) We simulate connection to server by sending numerics 000-005
 * 2) We then send a dummy motd
 * 3) A bunch of JOINS, MODEs, and TOPICs
 * 4) Queue up NAME and WHO information.
 *
 * 04/2007 -- Reattach rules relaxed; can now reattach to reconnecting client
 */
int conn::reattach(conn * c2)
{
	if (!c2->is_detached()) {
		return -1;
	}

	if (user() != c2->user()) {
		return -1;
	}

	if (c2->is_connecting() || (c2->is_reconnecting() && !c2->is_bounced())) {
		// "light" reattaches
		// not quite connected to IRC yet, due to reconnecting client, or amazing timing to 
		// catch client still in CONNECTING state
		if (c2->is_reconnecting()) {
			cprintf("REATTACH: It looks like there is a reconnection in progress (attempt %d of %d; %d second delay)...\r\n",
					c2->rinfo->get_tries(),
					c2->rinfo->get_max_tries(),
					c2->rinfo->get_delay());
			cprintf("REATTACH: Server: %s; %zd channels to join\r\n",
					c2->rinfo->get_server().name().c_str(),
					c2->rinfo->channels().size());
		}
		else {
			cprintf("REATTACH: It looks like there is a connection in progress ...\r\n");
			cprintf("REATTACH: Connecting to %s (%s)\r\n", 
					c2->strings[SERVER].c_str(),
					c2->auth.get(authorizer::TO_IP));
		}
	}
	else if ( !is_non_empty(c2->servinfo->name()) || !is_non_empty(c2->servinfo->version()) ) {
		// Reattached in a weird state:
	        // No numerics received from server yet; still logging in.	
		// Not much we can do here.
		assert(c2->is_bounced());
		cprintf("REATTACH: Hmm, your connection still appears to be registering with the IRC Server ...\r\n");
		client->printf(":%s!%s@%s NICK :%s\r\n", irc->nick(), user()->name(), client->peer_addr(), c2->irc->nick());
		client->flushO();
	}
	else {
		// Full reattach
		assert(!c2->is_connecting());
		assert(c2->is_bounced());

		const char * server = c2->servinfo->name();
		const char * nick =   c2->irc->nick();
		assert(server && nick);

		/* Sync nickname first */
		client->printf(":%s!%s@%s NICK :%s\r\n", irc->nick(), user()->name(), client->peer_addr(), nick);
		client->flushO();

		/*
		 * First: send fake numerics and pretend client has connected to an irc server
		 */
		client->printfQ(":%s 001 %s :Welcome to the Internet Relay Network %s\r\n",
				server, nick, nick);
		client->printfQ(":%s 002 %s :Your host is %s, running version %s\r\n",
				server, nick, server, c2->servinfo->version());
		client->printfQ(":%s 003 %s :This server was created %s\r\n",
				server, nick, c2->servinfo->created());
		client->printfQ(":%s 004 %s %s %s %s\r\n",
				server, nick, server, c2->servinfo->version(), c2->servinfo->modes());
		client->flushO();
		/* Numeric 005 */
		client->printf(":%s 005 %s %s\r\n", server, nick, non_null(c2->servinfo->numeric_005_1()) );
		client->printf(":%s 005 %s %s\r\n", server, nick, non_null(c2->servinfo->numeric_005_2()) );
		client->printf(":%s 005 %s %s\r\n", server, nick, non_null(c2->servinfo->numeric_005_3()) );
		client->flushO();
		/* Dummy MOTD */
		client->printfQ(":%s 375 %s :-%s Message of the Day -\r\n", server, nick, server);
		client->printfQ(":%s 372 %s :This is a dummy MOTD\r\n", server, nick);
		client->printfQ(":%s 376 %s :End of /MOTD command.\r\n", server, nick);
		client->flushO();

		//c2->server->printfQ("LUSERS\r\n");
		c2->server->printfQ("AWAY\r\n");
		c2->server->printfQ("MODE %s\r\n", nick);
		c2->server->flushO();

		/** 
		 * For each channel:
		 * Simulate the join
		 * Request mode/topic info from server
		 * Create the restartable procedure to send NAMES data to client
		 */
		assert(c2->rfuncs.empty());
		address_cache::channel_hash_t::const_iterator i = c2->acache->channels_begin(),
			e = c2->acache->channels_end();

		for (; i != e; ++i) {
			std::string chan_mode;
			channel * chan = (*i).second;
			chan->get_all_modes(c2->servinfo, chan_mode);

			client->printfQ(":%s!%s@%s JOIN :%s\r\n",
					nick, c2->irc->user(), c2->irc->host(), chan->name());
			client->printfQ(":%s 324 %s %s %s\r\n", server, nick, chan->name(), chan_mode.c_str());
			client->flushO();

			if (chan->has_topic()) {
				client->printfQ(":%s 332 %s %s :%s\r\n",
						server, nick, chan->name(), chan->topic());
				client->printfQ(":%s 333 %s %s %s %s\r\n",
						server, nick, chan->name(), 
						chan->topic_setter(), chan->topic_time());
				client->flushO();
			}

			rfunc * rf = c2->acache->create_rfunc(acache->RFUNC_NAMES, client,
					chan->name(), nick);
			assert(rf != NULL);

			c2->rfuncs.push_back(rf);
			c2->server->flushO();
		}
	}

	/**
	 * Now transfer settings.
         *  Actual reattaching happens here... 
	 */
	clearf(ADMIN);
	c2->clearf(DETACHED);
	c2->strings.set(USERCMD, this->strings[USERCMD]);
	this->strings.unset(USERCMD);
	
	c2->client        = this->client;
	c2->client->set_owner(c2);
	this->client      = NULL;
	c2->update_client_address();
	disown_dccs(c2);

	c2->reattach_time = proxy->time();
	c2->detach_time = 0;

	/** Destroy the detached anti-idle timer */
	c2->stop_anti_idle();

	/** 
	 * Connected-only settings: setup logging nad
	 * activate restartable functions. 
	 */	  
	if (c2->is_bounced()) {
		c2->setup_irc_logs(REATTACH);
		string msg = my_sprintf("Client Reattached: %s ----> id %d; is now %s on server %s [%s port %d]\r\n",
				addr(), c2->id(), c2->irc->nick(), 
				c2->servinfo->name(),
				c2->server->peer_addr(), c2->server->peer_port());

		proxy->printlog("%s", msg.c_str());
		user()->printlog("%s", msg.c_str());
			
		c2->cprintf("Reattach successful: you are now %s!%s@%s on %s [%s port %d]\r\n",
			c2->irc->nick(), c2->irc->user(), c2->irc->host(),
			c2->servinfo->name(), 
			c2->server->peer_addr(), c2->server->peer_port());
	}
	/**
	 * Not much we can say here.
	 */
	else {
		assert(c2->is_reconnecting() || c2->is_connecting());
		proxy->printlog("Client Reattached: %s ----> id: %d\r\n", addr(), c2->id());
		user()->printlog("Client Reattached: %s ----> id: %d\r\n", addr(), c2->id());
		c2->cprintf("Reattach successful: you now have connection id '%d'\r\n", c2->id());
	}

	c2->regulate_io_events();
	client_lost(); 			// We don't exist anymore.. 

	assert(!c2->is_detached());
	assert(is_dead());
	return 0;
}

/**
 * Responds to server pings, handles numeric stuff, and
 * does incoming dcc proxying.
 */
int conn::parse_from_server()
{
	typedef tokenizer<delimeter_seeker<char>, char *, io::byte_length_pair> buffer_tokenizer;

	io::buffer& buffer = server->get_ibuff();
	buffer_tokenizer tokenizer(buffer.begin(), buffer.end(), 
					delimeter_seeker<char>("\r\n", true));

	io::byte_length_pair last_block(buffer.begin(), 0);
	for (buffer_tokenizer::iterator i = tokenizer.begin(),
					e = tokenizer.end();
					i != e;
					++i) {
		// Obtain each line of IRC text and prepare it for string operations
		const io::byte_length_pair& p = *i;
		char * data = p.first;
		const size_t len  = p.second;

		/* ensure that we have room */
		if (client != NULL && client->buffer_availableO() < len + 3) {
			DEBUG("conn::parse_from_server() -- detected full client buffer\r\n");
			break;
		}
		last_block = p;
		data[len] = 0;

		string tokens[2];
		tokenize<string>(data, data+len, " ", &tokens[0], 2);
		to_uppercase(tokens[0]);
		to_uppercase(tokens[1]);

		const char * command = tokens[1].c_str();
		const struct cmd * c = lookup_command(incoming_hash, command, stat);
		if (c == NULL)	{
			/* Didn't match. It could be a server ping, or a pong
			 * or an ERROR string. In that case the command is the first
			 * token. So try the hash lookup again on that */
			command = tokens[0].c_str();
			c = lookup_command(incoming_hash, command, stat | PPE);
		}

		if (c != NULL) {
			textline args(data);

			DEBUG("<<<<<< HANDLER: %s(%d, %s)\n", c->msg, c->id, args.all());
			int r = (this->*(c->handler))(c->id, args);
			/**
			 * See what happened ...
			 */
			if (r < 0) {
				return -1;
			}
			else if (r > 0) {
				continue;
			}
		}

		if (!is_detached()) {
			/**
			 * Wasn't handled or intercepted: relay.
			 */
			client->queue(data, len);
			client->queue("\r\n", 2);
		}
	}

	/**  
	 * Remove everything that we've sent from the buffer. 
	 */
	const size_t to_remove = last_block.first - buffer.begin() + last_block.second;
	buffer.flush(to_remove);
	return 1;
}


/** 
 * Handle trapped DCCs, proxy, filter, or accept send requests.  Also handle
 * general retardness of DCC protocol.
 *
 * @param incoming	true if dcc is coming IRC to the client
 * @param source	originator
 * @param target	nickname of target
 * @param dcc_type	type of the DCC
 * @param args		arguments provided to the DCC CTCP
 * @return 0 - not handled; relay to IRC server
 * @return 1 - handled; will not relay to IRC server
 */
int conn::handle_dcc(bool incoming, const irc::address * source, const char * target,
			const char * dcc_type, const char * args)
{
	static const char *dcc_types[] = {
		"SEND",
		"CHAT",
		"TSEND",
		"TVIDEO",
		"TVOICE",
		/* mIRC DCC RESUME is NOT yet supported */
		NULL
	};

	net::socket * out = server, * in = client;
	if (incoming) { 
		// coming from IRC server to the proxy
		in = server;
		out = client;
	}

	/*
	 * Format is:
	 * DCC [TYPE] [FILENAME] [IP] [PORT] [size]
	 */
	char dcc_arg[256], sender_addr[100];
	unsigned short sender_port;
	unsigned long size = 0;

	int num_args = sscanf(args, "%255s %99s %hu %lu",
			dcc_arg, sender_addr, &sender_port, &size);
	if (num_args < 3) {
		// XXX: error condition
		return 0;
	}

	/**
	 * Find out first what type of dcc this is.
	 */
	int t = 0;
	do {
		if (strcasecmp(dcc_type, dcc_types[t]) == 0) {
			break;
		}
	} while (++t && dcc_types[t]);

	if (!dcc_types[t]) {
		return 0;
	}

	/** 
	 * Verify the address.
	 * NOTE: for outgoing dccs, we ignore whatever
	 * 	 the client thinks its address is... 
	 */
	if (!incoming) {
		my_strlcpy(sender_addr, client->peer_addr(), sizeof(sender_addr));
	}
	else {
		/** 
		 * DCC 'spec' doesn't really say how to handle IPv6 addresses.
		 * We assume they are transmitted in the address field in human-readable text form.
		 * IPv4 addresses are tranmitted in raw form as 32-bit unsigned integers.
		 */		  
		struct sockaddr_storage buff;
		if (resolver::ip_to_raw(sender_addr, 0, (sockaddr *) &buff, sizeof (struct sockaddr_in)) != 0) {
			/**
			 * Invalid address, or a valid IPv6 address that did not fit into 
			 * provided standard sockaddr_in structure.  Try something different.
			 */
			if (resolver::ip_to_raw(sender_addr, 0, (sockaddr *) &buff, sizeof (struct sockaddr_in6)) != 0) {
				/** 
				 * This didn't work either -- can't figure this address out.
				 */
				return 0;
			}
		}
		else {
			/**
			 * Appears to be a valid IPv4 address.  Now convert address structure to a 
			 * more readable format (dot-decimal notation) for output purposes.
			 */
			resolver::raw_to_ip((sockaddr *) &buff, sizeof(struct sockaddr_in), 
					sender_addr, sizeof(sender_addr));
		}
	}

	/**
	 * We want to bind to and send the ip of the interface that
	 * we are either connected to IRC to (if outgoing)
	 * or the client connected to us on (if it's incoming)
	 */
	dcc * d = NULL;
	dcc_offer * offer = NULL;
	const bool is_send = strcasecmp(dcc_type, "SEND") == 0;
	string err;
	try {
		if (is_send) {
			offer = new dcc_offer(this,
					dcc_type, 
					net::ap_pair(sender_addr, sender_port),
					source->nick(), target,
					dcc_arg,
					size, 0,
					(int) (incoming ? dcc_offer::INCOMING : dcc_offer::OUTGOING));
		}
		else {
			offer = new dcc_offer(this, 
					dcc_type,
					net::ap_pair(sender_addr, sender_port),
					source->nick(), target, 
					(int) (incoming ? dcc_offer::INCOMING : dcc_offer::OUTGOING));
		}

	} 
	catch (std::exception &e) {
		cprintf("DCC: Unable to create `%s' offer from %s to %s: %s\r\n", 
						dcc_type, source->nick(), target, e.what());
		return 0;
	}

	const bool want_dcc_filter = decide<server_node>(get_server_target(), irc_server_config::FILTER_DCCS) > 0;
	const bool dcc_proxy_in  = decide<server_node>(get_server_target(), irc_server_config::PROXY_DCC_IN) > 0;
	const bool dcc_proxy_out = decide<server_node>(get_server_target(), irc_server_config::PROXY_DCC_OUT) > 0;
	const bool can_store = is_allowed(user_perms::ENABLE_DCC_STORAGE);

	/**
	 * Filter the offer, allowing the user to decide later.
	 */
	if (want_dcc_filter) {
		cprintf("Filtered DCC Offer[%d]: (%s) %s (%s port %d) ---> %s [%s %u]\r\n",
				offer->id(), dcc_type, source->nick(), sender_addr, sender_port, target,
				dcc_arg, size);
	} 
	/**
	 * Store it directly on the proxy.
	 */
	else if (can_store && strcasecmp(target, "(ezbounce)") == 0) {
		if (incoming) {
			delete offer;
			return 0;
		}
		d = receive_dcc_offer(offer, err);
		if (!d) {
			cprintf("DCC: Unable to receive file '%s': %s\r\n", offer->filename(), err.c_str());
			delete offer;
			return 1;
		}
		// Success
		delete offer;
		offer = NULL;
	}
	/**
	 * Automatically proxy it?
	 */
	else if (is_bounced() && 
			((dcc_proxy_in && incoming) || (dcc_proxy_out && !incoming))) {
		d = proxy_dcc_offer(offer, err);
		if (!d) {
			cprintf("DCC: Unable to setup auto-proxy: error %s\r\n", err.c_str());
			delete offer;
			return 0;
		}
		cprintf("DCC: Proxy Session Started\r\n");
		delete offer;
		offer = NULL;
	} 
	/**
	 * None of the above:
	 * Don't proxy, don't store, don't filter; just pass on to IRC.
	 */
	else {
		delete offer;
		return 0;
	}

	assert((offer || d) && !(offer && d));
	// the new object is automatically added to the proper list
	return 1;
}

/**
 * Process (and respond to) CTCP messages.
 */
int conn::handle_ctcp(const irc::address * source, const char * ctcp, const char * ctcp_args)
{
	if (strcmp(ctcp, "PING") == 0) {
		server->printf("NOTICE %s :\001PING %s\r\n", source->nick(), ctcp_args);
		return 1;
	}
	else if (strcmp(ctcp, "VERSION") == 0) {
		const string& reply = user()->options()->
					get<server_node, string>(servinfo->server_target(), 
								irc_server_config::CTCP_VERSION_REPLY);
		const char * p = reply.empty() ? EZBOUNCE_VERSION : reply.c_str();
		server->printf("NOTICE %s :\001VERSION %s\001\r\n", source->nick(), p);
		return 1;
	} 
	return 0;
}

/** 
 * Start a proxy session for a DCC offer.
 */
dccpipe * conn::proxy_dcc_offer(dcc_offer * offer, std::string& err)
{
	assert(offer);
	assert(client && server);

	dccpipe * d = NULL;
	const char * listen_addr;
	if (offer->flags() & dcc_offer::INCOMING) {
		listen_addr = client->local_addr();
	}
	else {
		listen_addr = server->local_addr();
	}

	try {
		const net::ap_pair sender(offer->address(), offer->port()),
					listener(listen_addr, 0);
			
		d = new dccpipe(this, sender, listener);

		proxy->printlog("DCC Proxy Started: (%s) for %s: (sender) %s:%hu\n",
				offer->type(),
				addr(), offer->address(), offer->port());
		proxy->printlog("     (me) %s:%hu \n", d->addr(), d->port());

		offer->set_host_data(net::ap_pair(d->addr(), d->port()));
		relay_dcc_offer(offer, offer->to(), err);
		return d;
	} 
	catch (std::exception &e) {
		proxy->printlog("DCC Proxy Failed: (%s) for %s: [%s port %hu] (reason: %s)" ,
				offer->type(), addr(), offer->address(), offer->port(), e.what());
		delete d;
		err = e.what();
	}
	return NULL;
}

/**
 * Start a DCC get session for a dcc offer.
 * 
 * @param offer		offer to process
 * @param err		string to store error messages in
 * @return 0 on success
 */
dccget * conn::receive_dcc_offer(dcc_offer * offer, string& err)
{
	assert(offer);

	int idx = 0;
	const char * dir;
	file_entry * fe = NULL;

	if (!proxy->has_vfs() || key == NULL) {
		err = "Unable to access VFS";
		return NULL;
	}

	if (offer->flags() & dcc_offer::INCOMING) {
		dir = user()->options()->get<string>(user_config::DCC_IN_DIR).c_str();
	} 
	else {
		assert(offer->flags() & dcc_offer::OUTGOING);
		dir = user()->options()->get<string>(user_config::DCC_OUT_DIR).c_str();
	}

	// sanity check filename
	const char * filename = offer->filename();
	if (!fs::directory::is_legal_name(filename)) {
		err = "Illegal filename";
		return NULL;
	}

	// try to create this file
	string filebuff = my_sprintf("%s/%s", dir, offer->filename());

	int r = 0;    
	do {
		fe = proxy->vfs()->open(key, filebuff.c_str(), O_WRONLY | O_CREAT | O_EXCL, 0600, &r);

		if (!fe && r != fs::ERR_EXISTS) {
			/**
			 * Serious error: not just 'file already exists'
			 */
			cprintf("DCC Get: Unable to receive '%s' from %s: %s\r\n",
					filename, offer->from(), fs::strerror(r));
			err = fs::strerror(r);
			return NULL;
		} 
		if (fe == NULL) {
			/** 
			 * Couldn't create because file already exists. Try with different name 
			 */
			my_sprintf(filebuff, "%s/%s.%d", dir, offer->filename(), ++idx);
			continue;
		}

		/** 
		 * It worked... 
		 */
		dccget * d = NULL;
		try {
			d = new dccget(this, fe, offer);
			if (idx) {
				cprintf("DCC Get: filename was in use, saving as %s\r\n", fe->name());
			}
			cprintf("DCC Get: receiving '%s' from %s [%s port %d]\r\n", fe->name(), offer->from(), offer->address(), offer->port());
			cprintf("DCC Get: storing in '%s' (expected size: %u)\r\n", fe->dir()->rel_path(), offer->size());	
			
			string msg = my_sprintf("DCC Get: receiving and storing '%s' in directory '%s' (expected size: %lu) from %s [%s port %d]\r\n",
					fe->name(), fe->dir()->rel_path(), offer->size(), offer->from(), offer->address(), offer->port());
			proxy->printlog("%s", msg.c_str());
			user()->printlog("%s", msg.c_str());
			return d;
		} 
		catch (std::exception &e) {
			/** 
			 * Socket error: remove new file from disk.
			 */
			cprintf("DCC Get: Unable to receive %s from %s: %s\r\n", 
					fe->name(), offer->from(), e.what());
			proxy->vfs()->close(fe);	    
			proxy->vfs()->unlink(key, filebuff.c_str());
			err = e.what();
			return NULL;
		}
	} while (idx < 100);    

	err = "Could not save file!";
	return NULL;
}

/**
 * Relay a dcc_offer, unmodified to the client, or to a user on IRC.
 *
 * @param offer		offer to relay
 * @param whom		target for offer
 * @param err		reference to string to store any error messages in
 * @return 0 on success
 */
int conn::relay_dcc_offer(dcc_offer * offer, const char * whom, string& err)
{
	bool incoming = offer->flags() & dcc_offer::INCOMING;
	net::socket * out = (incoming) ? (net::socket *) client : (net::socket *) server;
	struct sockaddr_in sin;

	DEBUG("conn::relay_dcc_offer(%p,%s)\r\n", this, whom);

	assert(!incoming ? out != 0 : true);

	if (incoming) {  
		// From IRC server to proxy
		out->printf(":%s PRIVMSG %s :\001DCC", offer->from(), whom);
	}
	else {
		out->printf("PRIVMSG %s :\001DCC", whom);
	}
	
	const bool is_chat = (strcasecmp(offer->type(), "CHAT") == 0);
	const char * filename = is_chat ? "CHAT" : offer->filename();

	if (resolver::ip_to_raw(offer->address(), offer->port(), (sockaddr *) &sin, sizeof (sin)) == 0) {
		out->printf(" %s %s %lu %hu",
				offer->type(), filename,
				ntohl(sin.sin_addr.s_addr), offer->port());
	}
	else  { 
		// failed: IPv6 address? 
		out->printf(" %s %s %s %hu",
				offer->type(), filename,
				offer->address(), offer->port());
	}
	if (!is_chat) {
		out->printf(" %lu", offer->size());
	}
	out->printf("\001\r\n");
	return 0;
}

/**
 * Transfer ownership of DCCs to another conn object.
 */
void conn::disown_dccs(conn * target) const
{
	DEBUG("%s: transfering DCC ownership of %p to %p\n", __PRETTY_FUNCTION__, this, target);

	const std::list<dcc *>& dcc_list = proxy->dcc_list();
	for (std::list<dcc *>::const_iterator i = dcc_list.begin(), 
						e = dcc_list.end();
					       	i != e; 
						++i) {
		dcc * d = *i;
		if (d->owner() == this) {
			d->set_owner(target);
		}
	}

	const std::list<dcc_offer *>& dcc_offer_list = proxy->dcc_offer_list();
	for (std::list<dcc_offer *>::const_iterator i = dcc_offer_list.begin(),
							e = dcc_offer_list.end();
						       i != e; 
						       ++i) {
        	dcc_offer * d = *i;
		if (d->owner() == this) {
			d->set_owner(target);
		}
	}
}

/**
 * Start a DCC Send of a file in the VFS.
 *
 * @param fe		file_entry representing the file
 * @param whom		target to send the file to. If NULL, send to ezb user.
 * @param send_as	file name to advertise. If NULL, use default name of file.
 * @param as_chat	whether to send the file as DCC Chat instead
 * @return the new dccsend object, or NULL on error
 */
dccsend * conn::dcc_send_file(file_entry * fe, const char * whom,
                                const char * send_as, bool as_chat)
{
	assert(fe);
	assert(proxy->vfs());

	dccsend * d = NULL;
	net::socket * out = client;

	if (whom) {
		out = server;
		if (!out) {
			return NULL;
		}
	}

	try {
		io::filter_list filters;
		char address[100];

		/**
		 * Try to get a more accurate file size if currently writing to 
		 * this file..
		 */
		if (fe->is_writing()) {
			fe->writer()->flush();
			fe->update_size();
		}

		setup_dcc_filters(as_chat ? "CHAT" : "SEND", fe, filters);

		d = new dccsend(this, fe, filters, 0, 
				net::ap_pair(client->local_addr(), 0));
		
		unsigned short port = d->port();
		int family = d->sock_family();

		snprintf(address, sizeof address, "%s", d->addr());

		/**
		 * Determine address string to send. 
		 * For IPv4 address it is the raw 32-bit numeric address.
		 * For IPv6 transmit human readable IP address.
		 */
		if (family == AF_INET) {
			struct sockaddr_in sin;
			resolver::ip_to_raw(address, port, (sockaddr *) &sin, sizeof(sin));
			snprintf(address, sizeof address, "%u", ntohl(sin.sin_addr.s_addr));
		}
		cprintf("OK ... DCC Sending %s %s -- listening on port %d\r\n",
				(send_as ? send_as : fe->name()),
				(as_chat ? "(as a DCC CHAT)" : ""),
				port);

		// Where is it going to?
		if (whom) {
			out->printf("PRIVMSG %s :\001DCC", whom);
		} 
		else {
			out->printf(":%s PRIVMSG %s :\001DCC", EZBOUNCE_HEADER, irc->nick());
		}

		// As CHAT or SEND?
		if (as_chat) {
			out->printf(" CHAT CHAT %s %hu\001\r\n", address, port);
		}
		else {
			out->printf(" SEND %s %s %hu %lu\001\r\n",
					(send_as ? send_as : fe->name()),
					address,
					port,
					fe->size()
				   );
		}
		proxy->printlog("DCC Send: Sent %s %s to %s\n",
				fe->name(),
				(as_chat ? "(as DCC CHAT)" : ""),
				(whom ? whom : addr()));
	} 
	catch (std::exception &e) {
		// failed
		cprintf("DCC SEND: fatal error: %s\r\n", e.what());
	}
	return d;
}


/**
 * Setup IO filters to be used by DCC sends and gets.
 */
void conn::setup_dcc_filters(const char * type, const file_entry * fe, io::filter_list& out) const
{
	using io::filter_pair;
	using io::filter_kind;
	using io::filter_t;

	// TODO: not sure about what order to add filters 
	// (when encryption filters are available)
	const bool is_chat = strcasecmp(type, "CHAT") == 0;
	const bool is_send = strcasecmp(type, "SEND") == 0;
	const bool need_input_filters = is_chat || is_send;
	const bool need_decompression = is_chat;

	const char * filename = fe->name();
	std::vector<string> endings;
	
	tokenize(filename, ".", endings);

	for (vector<string>::const_iterator i = endings.begin(),
						e = endings.end(); 
						i != e;
						++i) {
		const string& ext = *i;
		filter_t filter;

		if (need_input_filters) {
			filter = io::get_filter_by_extension<io::input>(ext.c_str());
		}
		else {
			filter = io::get_filter_by_extension<io::output>(ext.c_str());		
		}

		const filter_kind fk = io::filter_work_kind(filter);

		if (filter != io::INVALID_FILTER) {
			// make sure to only add decompression filter when needed
			if (!need_decompression && fk == io::DECOMPRESSOR) {
				continue;
			}
			out.push_back(filter_pair(filter, ""));
		}
	}			
}


void conn::client_lost()
{
	// FIXME: possible issues with detached clients here, check
	auth.unregister_connection();
	if (client != NULL) {
		client->flushO();
	}
	delete client;
	client = NULL;
	for_each(rfuncs.begin(), rfuncs.end(), delete_ptr());
	rfuncs.clear();

	reattach_time = 0;
	clearf(REGISTERING | LOGGED_IN | NICKED | USERED | CONNECTING);
}

void conn::server_lost()
{
	// XXX: ideally this function won't be called in the first place
	//  	  if we aren't connected to IRC
	if (!is_admin() && server != NULL) {
		auth.unregister_outgoing_connection();
	}	

	// stop logging
	if (is_bounced()) {
		setup_irc_logs(IRC_DISCONNECT);
	}

	delete server;
	delete servinfo;
	delete acache;
	delete floodp;
	delete ignores;
	
	for_each(rfuncs.begin(), rfuncs.end(), delete_ptr());
	rfuncs.clear();

	acache = NULL;
	servinfo = NULL;
	server = NULL;
	floodp = NULL;
	ignores = NULL;

	detach_time = 0;
	reattach_time = 0;
	strings.unset(SERVER);
	auth.set(auth.TO_PORT, 0);
	auth.set(auth.TO_HOST, "");
	auth.set(auth.TO_IP, "");

	while (!cqueue.empty()) {
		cqueue.pop();
	}
	
	if (dtimer) {
		stop_anti_idle();
	}
	
	if (qtimer) {
		qtimer->die();
		qtimer = NULL;
	}
	
	clearf(BOUNCED | CONNECTING);

	assert(dtimer == NULL);
	assert(qtimer == NULL);
}

/**
 * Greet client that has just connected to the proxy and
 * successfully issued the USER/NICK command sequence.
 */
void conn::greet_client()
{
	const string& val = proxy->config().get<string>(proxy_config::GREET_METHOD);
	const char * method = val.c_str();
	
	if (strcasecmp(method, "silent") == 0) {
		return; 
	}
	if (strcasecmp(method, "full") == 0) {
		// needed for some clients, who reject all commands (even /quote) until
		// numeric 001 is received
		const char * nick = irc->nick();
		client->printf(":%s 001 %s :Welcome, %s\r\n", EZBOUNCE_HEADER, nick, nick);
	}
	
	cprintf("[awaiting login/pass command]\r\n");
}

/**
 * Greet user that has successfully logged in.
 */
void conn::greet_login()
{
	update_client_address();
	proxy->printlog("Client Login: %s as user `%s'\n", addr(), user()->name());

	/* MOTD */
	show_motd();
	
	num_dccs = 0;

	/* Greet user */
	string ts;
	timestamp_full(ts);
	cprintf("  \r\n");
	cprintf("             [%s]\r\n", EZBOUNCE_VERSION);
	cprintf("  \r\n");
	cprintf("\02login\02:       %s\r\n", user()->name());
	cprintf("\02from\02:        %s@%s\r\n", irc->nick(), client->peer_addr());
	cprintf("\02time\02:        %s\r\n", ts.c_str());

	/* Establish a few settings */
	if (user()->config()->get<bool>(user_perms::IS_ADMIN)) {
		/* Admins get all privs */
		setf(ADMIN);
		cprintf("\02privs\02:       admin!\r\n");
		proxy->printlog("Admin Login: Granted admin privileges to %s\n", addr());
	}

	/* Show detached connections */
	cprintf("  \r\n");
	textline dummy("");
	do_sessions_cmd(CMD_SESSIONS, dummy);
	cprintf(" \r\n");
	cprintf("[use /quote CONN <server> to connect]\r\n");

	clearf(REGISTERING);

	/* Auto-detach crap */
	if (decide<server_node>(server_info::default_server_target(), irc_server_config::AUTO_DETACH) == 1) {
		cprintf("[auto-detach is \002on\002]\r\n");
	}

	/* Now, do Automatic server connection */
	const string& auto_server = user()->options()->get<string>(user_config::AUTO_SERVER);
	if (!auto_server.empty()) {
		textline args(auto_server.c_str());
		cprintf("Automatically connecting you to: %s\r\n", auto_server.c_str());
		proxy->printlog("IRC Connection Attempt: Attempting auto connect of %s to %s\n", addr(), auto_server.c_str());
		user()->printlog("IRC Connection Attempt: %s to %s\n", addr(), auto_server.c_str());
		do_conn_cmd(CMD_CONN, args);
	}
}

/**
 * Display the MOTD.
 */
void conn::show_motd() const
{
	const string& filename = proxy->config().get<string>(proxy_config::MOTD_FILE);
	
	if (filename.empty()) {
		cprintf("MOTD: No MOTD available:\r\n");
		return;
	}

	int fd = open(filename.c_str(), O_RDONLY);
	if (fd < 0) {
		cprintf("MOTD: Error accessing file\r\n");
		proxy->printlog("MOTD: Request for %s failed: %s\r\n", filename.c_str(), strerror(errno));
		return;
	}

	struct stat st;
	memset(&st, 0, sizeof(st));
	int i = fstat(fd, &st);
	if (i < 0) {
		cprintf("MOTD: Error accessing file\r\n");
		proxy->printlog("MOTD: Request for %s failed: %s\r\n", filename.c_str(), strerror(errno));
		close(fd);
		return;
	}

	char * buff = new char[st.st_size+1];
	int r = read(fd, buff, st.st_size);
	close(fd);

        r = std::min<int>(r, st.st_size);
        buff[r]=0;

	cprintf("- Message of the day -\r\n");
	cprintf_multiline(buff);
	delete[] buff;

	cprintf("  \r\n");
	cprintf("End of MOTD\r\n");
	return;
}

int conn::do_auto_detach()
{
	proxy->printlog("Client Detached: Auto-detaching %s\n", addr());
	user()->printlog("Auto-detaching %s\n", addr());
	return detach();
}

/**
 * Called upon client connection:
 *  - make sure not on global ban list
 *  - make sure there exists a matching user definition
 * Return:
 *		 0 	- permitted
 *	       < 0	- not permitted
 */
int conn::authorize_client()
{
	DEBUG("conn::is_client_authorized() -- checking %s (%s)\n", auth.get(auth.FROM_IP), auth.get(auth.FROM_HOST));
	int i = auth.recognize_connection();
	unsigned short port = client->local_port();
	const bool silent_reject = proxy->config().get<bool>(proxy_config::SILENT_REJECTION);

	switch (i) {
	case 0:		/* success */
		return 0;
		
	case authorizer::ERR_NO_MATCH:
		if (!silent_reject) {
			cprintf("No Authorization.\r\n");
		}
		proxy->printlog("Connection Denied: (no authorization) from %s (%s) on port %d\n", 
						auth.get(auth.FROM_IP), auth.get(auth.FROM_HOST), port);
		break;
	
	case authorizer::ERR_NOT_ALLOWED:
		if (!silent_reject) {
			cprintf(MSG_BANNED, auth.get(auth.FAILURE_REASON), auth.get(auth.FAILURE_REASON));
		}
		proxy->printlog("Connection Denied: (banned) from %s (%s) on port %d\n", 
						auth.get(auth.FROM_IP), auth.get(auth.FROM_HOST), port);
	}
	return -1; 	
}


/**
 * Convert numeric flags to something human
 * readable.
 */
char * conn::mkstat(char * str_stat) const
{
	int z = 0;
	if ((stat & NICKED) && (stat & USERED))  
				str_stat[z++] = 'r';
	if (stat & LOGGED_IN)   str_stat[z++] = 'L';
	if (stat & ADMIN)    	str_stat[z++] = 'a';
	if (stat & BOUNCED)    	str_stat[z++] = 'b';
	if (stat & CONNECTING) 	str_stat[z++] = 'c';
	if (stat & DETACHED)   	str_stat[z++] = 'd';
	if (stat & RECONNECTING) str_stat[z++] = 'E';
	if (stat & REGISTERING) str_stat[z++] = 'w';        /* (waiting) */
	if (is_dead()) {
		strcpy(str_stat, "(zombie)");
		z = 8;
	}
	str_stat[z] = 0;

	return str_stat;
}

/**
 * Continue the restartable functions (NAMES, WHO data dumping)
 * We will wait for one function to totally complete before beginning the next
 * one.
 */
void conn::process_restartable()
{
	vector<rfunc *>::iterator i = rfuncs.begin();
	while (i != rfuncs.end()) {
		rfunc *rf = *i;
		int r = rf->execute(0);
		
		if (!r) { /* finished */
			i = rfuncs.erase(i);
			delete rf;
		} 
		else {
			break;
		}
		client->flushO();
	} 
}

/**
 * Called every so often so we can dump a random message
 * for anti-idling purposes
 */
int  conn::detached_timer_proc(const timer::generic_timer_data * data)
{
	DEBUG("conn::detached_timer_proc() -- %p\n", data);
	assert(is_detached());
	if (!is_bounced()) {
		// may occur during reconnect
		return 1;
	}
	const bool want_anti_idle = user()->options()->get<server_node, bool>(
						servinfo->server_target(), irc_server_config::ANTI_IDLE);
	if (!want_anti_idle) {
		return 1;
	}

	static const char *anti_idle[5] = {
		"2md :hey, whats up?",
		"~habib :i need to crash",
		"987987 :somebody set up us the bomb!",
		"@^542 :fool",
		".ds :my fellow americans"
	};
	server->printf("PRIVMSG %s\r\n", anti_idle[random()%5]);
	return 1;
}

/**
 * Update address string. Example:
 * 43:murat@192.168.1.1 
 */
void conn::update_client_address()
{
	const char * host = client ? client->peer_addr() : "[detached]";
	const char * u = user() ? user()->name() : "(unknown)";
	char * buff = NULL;
	my_asprintf(&buff, "%u:%s@%s", id(), u, host);
	strings.set(FULLADDR, buff);
	delete[] buff;
}

void conn::regulate_io_events()
{
	/**
	 * Logic for determining what to poll for:
	 * - client checked for readable if: -
	 *   	no restartable functions queued.
	 *
	 * - client checked for writable if -
	 *	output buffer contains data
	 *	restartable functions are queued
	 *
	 * - server checked for readable if -
	 *	input buffer is not full
	 *	no restartable functions queued
	 *
	 * - server checked for writable if -
	 *	output buffer contains data
	 *	in connection attempt
	 *
	 * FIXME: deadlock still possible in some situations, e.g. full server buffer while detached
	 * 		
	 */
	int server_events = 0;
	int client_events = 0;

	const bool ignoring = ignoring_input();

	size_t c_out_available = 0, c_in_available = 0;
	size_t s_out_available = 0, s_in_available = 0;

	size_t c_queued = 0;
	size_t s_queued = 0;	

	if (client) {
		c_queued = client->obuff_size();
		c_out_available = client->buffer_availableO();
		c_in_available  = client->buffer_available(); 
		
		client_events |= !ignoring 		? io::EVENT_READ : 0;
		client_events |= (c_queued || ignoring) ? io::EVENT_WRITE : 0;
		client->set_events(client_events);
	}
	if (server) {
		s_queued = server->obuff_size();
		s_out_available = server->buffer_availableO();
		s_in_available  = server->buffer_available();

		server_events |= (!ignoring && (!client || c_out_available)) ? io::EVENT_READ : 0;
		server_events |= s_queued ? io::EVENT_WRITE : 0;
		server_events |= server->get_state() == net::socket::CONNECTING ? io::EVENT_WRITE : 0;
		server->set_events(server_events);
	}

	DEBUG("@@@ listening for: client [read: %s write: %s] server [read: %s write %s]\n",
		yesno(client_events & io::EVENT_READ), yesno(client_events & io::EVENT_WRITE),
		yesno(server_events & io::EVENT_READ), yesno(server_events & io::EVENT_WRITE));
	assert(server_events || client_events || is_reconnecting() || is_dead());	// we can't have any deadlocks !!
}

/** 
 * Queue an IRC server command for execution on the 5-second
 * throttle timer.
 */
void conn::queue_command(const char * fmt, ...)
{
	if (!qtimer) {
		qtimer = timer::create_generic_timer(5, std::bind1st(std::mem_fun(&conn::throttle_timer_proc), this));
	}
	char * ptr = NULL;
	va_list ap;
	va_start(ap, fmt);
	my_vasprintf(&ptr, fmt, ap);
	va_end(ap);

	if (ptr != NULL) {	
		qtimer->enable();
		cqueue.push(ptr);
		DEBUG("conn::queue_command(): Command queued: %s", ptr);
		delete[] ptr;
	}
}

/** 
 * Async lookup callback functions for:
 * 	- Reverse lookup of IP on client connect succesful/failed
 *	- [reverse or normal] lookup of connect destination succesful/failed
 */
int conn::async_lookup_finished(const resolver::result * res)
{
	assert(lookup_id != 0);
	char buffer[256];
	resolver::result_to_string(res, buffer, sizeof buffer);

	if (checkf(REGISTERING)) {
		assert(!is_connecting());
		auth.set(auth.FROM_HOST, buffer);
		lookup_id = 0; 
		
		if (!authorize_client()) {
			client->set_events(io::EVENT_READ);
		} 
		else {
			client_lost();
		}
	}
 	else if (is_connecting()) {
		lookup_id = 0;
		if (res->options & resolver::OPT_REVERSE_LOOKUP) {
			auth.set(authorizer::TO_HOST, buffer);				
		} 
		else {
			auth.set(authorizer::TO_IP, buffer);
		}

		if (!authorize_connect()) {
			start_connect();
		}
	       	else {
			server->on_connect_fail(net::ERR_AUTH);
		}
	}
	return 0;
}

int conn::async_lookup_failed(const resolver::result * res)
{
	assert(lookup_id != 0);
	if (checkf(REGISTERING)) {
		assert(!is_connecting());
		lookup_id = 0;
		if (!authorize_client()) {
			client->set_events(io::EVENT_READ);
		} 
		else {
			client_lost();
		}
	}
 	else if (is_connecting()) {
		lookup_id = 0;
		if (!(res->options & resolver::OPT_REVERSE_LOOKUP)) {
			server->on_connect_fail(net::ERR_DNS);
		} 
		else {
			if (!authorize_connect()) {
				start_connect();
			} 
			else {
				server->on_connect_fail(net::ERR_AUTH);
			}
		}
	}
	return 0;
}

int conn::throttle_timer_proc(const struct timer::generic_timer_data *)
{
	assert(server != NULL);
	/** 
	 * Get the next command off the queue and send it to the server
	 * .. if there are no commands left turn us off
	 */
	const string& command = cqueue.front();
	server->queue(command.c_str(), command.size());
	server->set_events(server->events() | io::EVENT_WRITE);

	DEBUG("conn::throttle_timer_proc() [%p] @ %lu relayed command `%s'", this, timer::now(), command.c_str());

	cqueue.pop();

	if (cqueue.empty()) {
		DEBUG("conn::throttle_timer_proc() -- finished!\n");
		return -1;
	}
	return 1;
}

/**
  * Setup IRC logging based on the event that occurred.
  * This will involve starting and possibly stopping logging.
  *
  * NOTES:
  * 		- this is also called when logging options are changed, which could occur at any moment. 
  *		- no logging shall be setup unless a connection to the IRC server is active
  *			(thus, for disconnect events, the log setup must be performed before the socket is destroyed)
  */
int conn::setup_irc_logs(event event)
{
	using logging::logger;
	using logging::chatlog;

	// FIXME: more friendly error reporting here?
	if (!is_bounced()) {
		return -1;
	}
	if (!is_registered()) {
		return -1;
	}
	if (!proxy->has_vfs()) {
		return -1;
	}
	if (key == NULL) {
		// this could also happen
		return -1;
	}

	// NOTE: these permissions also verify VFS access permissions
	const bool want_private_logging = decide<server_node>(get_server_target(), irc_server_config::LOG_PRIVATE) == 1;
	const bool want_chan_always = decide<channel_node>(get_default_channel_target(),  irc_channel_config::LOG_ALWAYS) == 1;
	const bool want_chan_detached_only = decide<channel_node>(get_default_channel_target(), irc_channel_config::LOG_DETACHED_ONLY) == 1;

	/**
	  * Controls what will happen to these logs; could have clumped everything
	  * in the switch block with fall-thru's, but this is a bit cleaner.
	  */
	int for_private = 0;
	int for_channel = 0;

	switch (event) {
	case IRC_CONNECT:
		/* Start all logs, unless we are logging while detached, only. */
		for_private = 1;
		for_channel = 1;
		break;
	
	case IRC_DISCONNECT:
		/* All logs should be stopped. */
		for_private = -1;
		for_channel = -1;
		break;
	
	case DETACH:
		/* New logs might need to be set up. */
		for_private = 1;
		for_channel = 1;
		break;
	
	case REATTACH:
		/* Logs might need to be stopped. */
		for_private = 1;
		for_channel = 1;
		break;
	
	default:
		/* Should not be called for any other events */
		return -1;
	}

	/**
	  * Check option sanity.
	  */
	if (for_private == 1 && !want_private_logging) {
		for_private = -1;
	}
	if (for_channel == 1) {
	        if (!want_chan_always && !want_chan_detached_only) {
			for_channel = -1;
		}
		if (want_chan_detached_only && !is_detached()) {
			for_channel = -1;
		}
	}

	/**
	  * Setup private logging.
	  */
	if (for_private == 1) {
		if (want_private_logging && priv_log == NULL) {
			io::filter_list filters;
			setup_log_filters(filters);

			const string& name = user()->make_log_path("private", servinfo, "private", "");
			try {
				priv_log = new chatlog("private", name,	key,							 
							chatlog::LOG_PRIVATE, 
							chatlog::LOG_FULL_ADDRS | logging::LOG_TIMESTAMP,
							filters);
			}
			catch (std::exception &e) {
				cprintf("error: Unable to start private logfile: %s\r\n", e.what());
			}
		}
	}
	else if (for_private == -1) {
		/* stop the logging */
		delete priv_log;
		priv_log = NULL;
	}

	if (for_channel == 1 && chan_log == NULL) {
		/**
		  * Set up the 'default' channel log (where stuff goes if per-channel logging
		  * isn't requested)...
		  */
		bool want_timestamps = user()->options()->get<channel_node, bool>(get_default_channel_target(), irc_channel_config::LOG_TIMESTAMPS);
		bool want_addrs = user()->options()->get<channel_node, bool>(get_default_channel_target(), irc_channel_config::LOG_ADDRESSES);

		io::filter_list filters;
		setup_log_filters((channel *) NULL, filters);

		int options = 0;
		if (want_timestamps) {
			options |= logging::LOG_TIMESTAMP;
		}
		if (want_addrs) {
			options |= chatlog::LOG_FULL_ADDRS;
		}

		const string& name = user()->make_log_path("channel", servinfo, "channel", "");
		try {
			chan_log = new chatlog("channel", name, key,
					chatlog::LOG_CHANNEL,
					options,
					filters);
		}
		catch (std::exception &e) {
			cprintf("error: Unable to start channel logfile: %s\r\n", e.what());
		}
	}
	else if (for_channel == -1) {
		// Stop default channel logging
		delete chan_log;
		chan_log = NULL;
	}

	/**
	  * Since each channel can have its own logging options, we must call this for
	  * each one ... 
	  */
	if (for_channel != 0) {
		address_cache::channel_hash_t::const_iterator i = acache->channels_begin(),
								e = acache->channels_end();
		for (; i != e; ++i) {
			setup_channel_log((*i).second, event);
		}
	}
	return 0;
}

/**
  * Forcibly shut down all IRC logs, including all channel logs, and 
  * free all memory and file resources.
  * Actually, everything should already be closed by the time this is called.
  */
int conn::stop_irc_logs(const char * message)
{
	DEBUG("conn::stop_irc_logs() [%p]: %s\n", this, message);
	if (priv_log != NULL) {
		priv_log->printf("stopping log: %s\n", message);
		delete priv_log;
		priv_log = NULL;
	}
	if (chan_log != NULL) {
		chan_log->printf("stopping log: %s\n", message);
		delete chan_log;
		chan_log = NULL;
	}
	
	/* Stop individual channel logs */
	if (acache != NULL) {
		address_cache::channel_hash_t::const_iterator i = acache->channels_begin(),
			e = acache->channels_end();
		for (; i != e; ++i) {
			stop_channel_log((*i).second, message);
		}
	}
	return 0;
}


/**
  * Setup logging for a channel.  Note that depending on the event that occurred
  * and options set, an active logfile may actually be closed by this function.
  */
int conn::setup_channel_log(channel * chan, event event)
{
	using logging::logger;
	using logging::chatlog;

	if (!proxy->has_vfs() || key == NULL) {
		return -1;
	}

	const config::target_list& target = chan->channel_target();
	const bool want_chan_always = decide<channel_node>(target, irc_channel_config::LOG_ALWAYS) == 1;
	const bool want_chan_detached_only = decide<channel_node>(target, irc_channel_config::LOG_DETACHED_ONLY) == 1;
	const bool want_own_file  = decide<channel_node>(target, irc_channel_config::LOG_OWN_FILE) == 1;

	int operation = 0;

	switch (event) {
	case CHANNEL_JOIN:
	case IRC_CONNECT:
		operation = 1;
		break;
	case CHANNEL_PART:
	case IRC_DISCONNECT:
		operation = -1;
		break;
	case DETACH:
		operation = 1;
		break;
	case REATTACH:
		operation = 1;
		break;
	default:
		/* Invalid */
		return -1;
	}

	if (operation == 1) {
		if (!want_chan_always && !want_chan_detached_only) {
			operation = -1;
		}
		if (want_chan_detached_only && !is_detached()) {
			operation = -1;
		}
	}

	/**
	  * Start logging; create own log file if necessary.
	  */
	if (operation == 1) {
		bool want_timestamps = user()->options()->get<channel_node, bool>(target, irc_channel_config::LOG_TIMESTAMPS);
		bool want_addrs = user()->options()->get<channel_node, bool>(target, irc_channel_config::LOG_ADDRESSES);

		int options = 0;
		if (want_timestamps) {
			options |= logging::LOG_TIMESTAMP;
		}
		if (want_addrs) {
			options |= chatlog::LOG_FULL_ADDRS;
		}

		if (!want_own_file) {
			chatlog * old = chan->get_chatlog();
			delete old;
			chan->set_chatlog(NULL);
		}
		else if (chan->get_chatlog() == NULL) {
			char * channame = servinfo->to_lowercase(my_strdup(chan->name()));
			const string& logname = user()->make_log_path("channel", servinfo, channame, "");
			io::filter_list filters;
			setup_log_filters(chan, filters);

			try {
				chatlog * own = new chatlog(channame, logname, key,
								chatlog::LOG_CHANNEL, 
								options,
								filters);
				chan->set_chatlog(own);
			}
			catch (std::exception& e) {
				// XXX: what else to do here?
				// 	set logging flag to false?
				cprintf("error: Unable to start channel '%s' logfile: %s\r\n", channame, e.what());
			}
			delete[] channame;
		}
		chan->set_logging(true);
		chan->set_log_options(options);
	}
	else if (operation == -1) {
		/* Delegate to another function */
		stop_channel_log(chan, "closing logfile");
	}

	return 0;
}

/**
  * Stop logging for a channel and free resources associated with it.
  */
int conn::stop_channel_log(channel * chan, const char * message)
{
	logging::chatlog * log = chan->get_chatlog();
	if (log != NULL) {
		log->printf("%s\n", message);
		delete log;
	}
	chan->set_chatlog(NULL);
	chan->set_log_options(0);
	chan->set_logging(false);
	return 0;
}

/**
 * Prepare list of filters as requested in logging options
 * for the private chat logfile.
 */
void conn::setup_log_filters(io::filter_list& filters) const
{
	const bool compress = decide<server_node>(get_server_target(), irc_server_config::COMPRESS_PRIVATE_LOG) == 1;
	if (!compress) {
		return;
	}

	filters.push_back(io::filter_pair(io::GZIP_COMPRESSOR, ""));
}

/**
 * Prepare filters for channel log(s).
 */
void conn::setup_log_filters(channel * c, io::filter_list& filters) const
{
	const config::target_list& target = (c == NULL) ? get_default_channel_target() : c->channel_target();
	const bool compress = decide<channel_node>(target, irc_channel_config::COMPRESS_LOG) == 1;
	if (!compress) {
		return;
	}
	
	filters.push_back(io::filter_pair(io::GZIP_COMPRESSOR, ""));
}

/**
  * Main function to handle IRC logging.
  */
int conn::log_irc_event(irc::event event, const irc::address * address, 
			const char * target, const char * text, const char * extra) 
{
	using logging::chatlog;
	if (!irc::is_private_event(event)) {
		/**
		  * Public events:
		  * Certain public events may have a NULL target (e.g. QUIT and NICK), so log
		  * these for channels that have this nick.
		  */
		if (target == NULL) {
			bool logged_global = false;
			address_cache::channel_hash_t::const_iterator i = acache->channels_begin(),
									e = acache->channels_end();
			for (; i != e; ++i) {
				channel * c = (*i).second;
				if (!c->is_logging()) {
					// if not logging, don't bother
					continue;
				}
				bool own_log = c->get_chatlog() != NULL;
				if (!own_log && logged_global) {
					// prevent logging of event to shared channel
					// file multiple times
					continue;
				}
				if (c->has_nick(address->nick())) {		
					int ret = log_irc_event(event, address, c, text, extra);
					if (!own_log && ret == 0) {
						logged_global = true;
					}
				}
			}
			return 0;
		}

		channel * c = acache->lookup_channel(target);
		if (c == NULL) {
			DEBUG("conn::log_irc_event(): unknown channel '%s'\n", target);
			return -1;
		}
		return log_irc_event(event, address, c, text, extra);
	}

	if (priv_log != NULL) {
		priv_log->write(event, address, target, text, extra);
	}
	return 0;		
}

/**
  * Specialized version to handle channel events.  
  */
int conn::log_irc_event(irc::event event, const irc::address * address, 
			channel * target, const char * text, const char * extra) 
{
	if (!target->is_logging()) {
		return -1;
	}

	logging::chatlog * out = target->get_chatlog();
	int saved_options = 0;
	if (out == NULL) {
		/**
		  * No channel-specific log.  Use 'default' channel log, and temporarily set its 
		  * logging options to the channel's.  But first check if 'default' log exists;
		  * it may have failed to create.
		  */
		if (chan_log == NULL) {			
			return -1;
		}
		out = chan_log;
       		saved_options = chan_log->get_options();
		chan_log->set_options(target->get_log_options());
	}
	
	out->write(event, address, target->name(), text, extra);

	if (out == chan_log) {
		/* Restore options. */
		chan_log->set_options(saved_options);
	}
	return 0;
}

/**
 * Print a message into all active logs.
 */
void conn::print_all_logs(const char * message)
{
	if (!is_bounced()) {
		return;
	}
	if (priv_log != NULL) {
		priv_log->printf("%s\n", message);
	}
	if (chan_log != NULL) {
		chan_log->printf("%s\n", message);
	}
	assert(acache != NULL);
	for (address_cache::channel_hash_t::const_iterator i = acache->channels_begin(),
								e = acache->channels_end();
								i != e;
								++i) {
		const channel * chan = (*i).second;
		if (chan->get_chatlog() != NULL) {
			chan->get_chatlog()->printf("%s\n", message);
		}
	}
}

/**
  * Make it appear to the user that he parted all of his channels.
  */
void conn::show_part_all() const 
{
	address_cache::channel_hash_t::const_iterator i = acache->channels_begin(),
							e = acache->channels_end();
	for (; i != e; ++i) {
		client->printf(":%s!%s@%s PART %s\r\n", irc->nick(), irc->user(), irc->host(), (*i).second->name());
	}
}

/**
  * Starts the reconnection process.
  */
void conn::start_reconnect()
{
	assert(!is_reconnecting());
	assert(server != NULL);
	assert(rinfo == NULL);
	assert(rtimer == NULL);

	const char * s_server = servinfo->name();
	const char * password = strings[IRCPASS].c_str();
	if (!is_non_empty(s_server)) {
		s_server = servinfo->unofficial_name();
	}

	/**
	  * Cache the reconnection settings -- max tries and reconnect delay,
	  * as well as details of the last known good server.  
	  * Save the channels we were on.
	  */
	const int max_tries = user()->options()->get<server_node, int>
				(servinfo->server_target(), irc_server_config::MAX_RECONNECT_TRIES);
	const int delay = user()->options()->get<server_node, int>
				(servinfo->server_target(), irc_server_config::RECONNECT_DELAY);
	const bool ssl = (server->get_options() & net::socket::SOCK_SSL);
        
	assert(is_non_empty(s_server));
        assert(server->peer_port() != 0);
	server_entry this_server(s_server, servinfo->network(), server->peer_port(), password, ssl);

	rinfo = new reconnect_info(this_server, max_tries, delay);
	rinfo->add_channels(make_value_iterator(acache->channels_begin()), 
				make_value_iterator(acache->channels_end()));

	/**
	 * Setup the timer.
	 */
	rtimer = timer::create_generic_timer(delay, std::bind1st(std::mem_fun(&conn::reconnect_timer_proc), this));
	rtimer->enable();
	
	cprintf("Reconnecting to IRC server in %d seconds...\r\n", delay);
	user()->printlog("Reconnect: %s reconnecting to %s in %d seconds...\n", addr(), s_server, delay);
	setf(RECONNECTING);
	assert(is_reconnecting());
}

/**
  * Returns the next candidate server to try in the reconnection attempt.
  */
server_entry conn::get_next_reconnect_server() const
{
	assert(is_reconnecting());
	return rinfo->get_server();
}

/**
  * Immediately frees all resources and timers for a reconnection attempt.
  * Does nothing if there is no reconnection attempt.
  */
void conn::abort_reconnect()
{
	if (!is_reconnecting()) {
		return;
	}
	
	rtimer->die();
	rtimer = NULL;

	delete rinfo;
	rinfo = NULL;

	clearf(RECONNECTING);

	assert(!is_reconnecting());
}

/**
  * Finish a reconnection attempt.
  */
void conn::finish_reconnect()
{
	assert(is_reconnecting());

	cprintf("Reconnect finished! [joined %zd/%zd channels]\r\n", rinfo->num_succeeded(), 
									rinfo->channels().size());

	user()->printlog("Reconnect: %s finished reconnect to %s [joined %zd/%zd channels]\n",
			addr(), rinfo->get_server().name().c_str(), 
			rinfo->num_succeeded(), rinfo->channels().size());
			
	rtimer->die();
	rtimer = NULL;

	delete rinfo;
	rinfo = NULL;

	clearf(RECONNECTING);
	assert(!is_reconnecting());
}

/**
  * Timer for reconnection attempts.
  * Return  < 0 to disable the timer.
  *	   >= 0 to reschedule it for another firing.
  */
int conn::reconnect_timer_proc(const timer::generic_timer_data *) 
{
	assert(is_reconnecting());
	assert(!is_connecting());
	assert(!is_bounced());

	/**
 	 * Get the next candidate server and attempt reconnection ...
	 */	 	
	const server_entry &entry = get_next_reconnect_server();
	const unsigned short port = entry.get_random_port();
	rinfo->reset_succeeded();
	rinfo->reset_failed();
	rinfo->inc_tries();
	setup_connect(entry.name().c_str(), port, entry.password().c_str(), entry.is_ssl()); 
	cprintf("[\002Reconnect attempt #%d\002]: %s port %d\r\n", rinfo->get_tries(), entry.name().c_str(), port);
	return -1;
}

/**
 * Create the anti-idle timer.
 * Currently fires every 5 minutes.
 */
void conn::setup_anti_idle() 
{
	assert(dtimer == NULL);
	if (dtimer == NULL) {
		dtimer = timer::create_generic_timer(300, 
						std::bind1st(std::mem_fun(&conn::detached_timer_proc), this));
		dtimer->enable();
	}
}

void conn::stop_anti_idle()
{
	if (dtimer != NULL) {
		dtimer->die();
		dtimer = NULL;
	}
}

/**
 * True if reattached to connection in the last 90 seconds.
 */
bool conn::recently_reattached() const
{
	return (proxy->time() - reattach_time) <= 90;
}

/**
 * Perform some periodic clean up tasks.
 */
void conn::prune_caches()
{
	if (floodp) {
		floodp->clear_expired(proxy->time());
	}
	if (ignores) {
		ignores->clear_expired(proxy->time());
	}
}

/**
  * Dummy functions needed as placeholders for some callbacks.
  */
void conn::dummy_callback() 
{
}

void conn::dummy_callback1(int) 
{
}

