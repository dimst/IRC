/**
  * This program is free software; you can redistribute it and/or modify
  * it under the terms of the GNU General Public License as published by
  * the Free Software Foundation; either version 2 of the License, or
  * (at your option) any later version.
  *
  * irc/server_entry.cc
  * (c) 2007-2008 Murat Deligonul
  */

#include "autoconf.h"

#include "irc/server_entry.h"
#include "debug.h"

using std::string;

namespace irc {

server_entry::server_entry(const char * nam, const char * net, const char * p, const char * pw, bool s)
	: s_name(nam), s_network(net),
	  s_password(pw),
	  ssl(s)
{
	/* FIXME: validate input */
	set_ports(p);
}

server_entry::server_entry(const char * name, const char * net, unsigned short p, const char * pw, bool s)
	: s_name(name), s_network(net),
	  s_password(pw),
	  ssl(s)
{
//	set_ports(p)
	temp_port = p;
}

server_entry::server_entry(const string& nam, const string& net, const string& p, const string& pw, bool s)
	: s_name(nam), s_network(net),
	  s_password(pw),
	  ssl(s)
{
	/* FIXME: validate */
	set_ports(p.c_str());
}

/**
  * Assign the ports field.  Validates input.
  * FIXME: implement
  */
void server_entry::set_ports(const char * p) 
{
	temp_port = 6667;
}

/**
  * Return a random port from the server's port list.
  * FIXME: return the correct port
  */
unsigned short server_entry::get_random_port() const 
{
	return temp_port;
}

} // namespace irc
