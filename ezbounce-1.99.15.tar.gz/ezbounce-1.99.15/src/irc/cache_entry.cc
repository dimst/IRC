/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/cache_entry.cc
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include <list>
#include <vector>
#include <algorithm>
#include <functional>
#include "irc/cache_entry.h"
#include "irc/channel.h"
#include "debug.h"

namespace irc {

/**
 * Update nickname for a cache_entry.
 * This requires going through all referenced channels, 
 * finding nickname entry in hash table and updating pointer of 
 * old key to new one.
 */
void cache_entry::change_nick(const char * new_nick)
{
	DEBUG("acache::change_nick(): updating old channel pointers of '%s'->'%s' [%zd channels]\n", 
				addr.nick(), new_nick, channels.size());
	std::vector<int> flags;
	std::list<channel *>::const_iterator iter = channels.begin(), 
						e = channels.end();

	while (iter != e) {
		channel * c = *iter;
		flags.push_back(c->nick_flags(this));
		c->del_nick(this);
		++iter;
	}

	addr.set_nick(new_nick);

	int i = 0;
	iter = channels.begin();
	for (; iter != e; ++iter) {
		(*iter)->add_nick(this, flags[i++]);
	}
}

/**
 * Destructor:
 *  Remove all references to this cache_entry
 */
cache_entry::~cache_entry()
{
	DEBUG("cache_entry::~cache_entry() [%p]\n", this);
	std::for_each(channels.begin(), channels.end(), 
		std::bind2nd(std::mem_fun(&channel::del_nick), this));
}

} // namespace irc
