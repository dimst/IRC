/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/ignore.cc -- IRC ignore list.
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include <algorithm>
#include "util/strings.h"
#include "irc/address.h"
#include "irc/ignore.h"
#include "debug.h"

using namespace util::strings;

namespace irc {

/**
 * Allows comparison of ignore_entry's by mask and flag only.
 */
struct mask_flag_equals {
	const std::string& mask;
	const event_flagset_t& flags;

	mask_flag_equals(const std::string& s, const event_flagset_t& f) :
		mask(s), flags(f) {}

	bool operator()(const ignore_entry& e) const {
		return e.mask == mask && e.flags == flags;
	}
};

/**
 * Compare if ignore entry's expiration time is before or at 
 * specified time.
 */
struct entry_expired {
	const time_t when;

	explicit entry_expired(time_t w) : when(w) {}

	bool operator()(const ignore_entry& e) const {
		return when >= e.expiration;
	}
};

/**
 * Check if an event from an address is ignored.
 */
bool ignore_list::is_ignored(const address * addr, event ev, time_t now) const
{
	std::string source;
	if (addr->has_user_host()) {
		my_sprintf(source, "%s!%s@%s", addr->nick(), addr->user(), addr->host());
	}
	else {
		my_sprintf(source, "%s", addr->nick());
	}
	return is_ignored(source.c_str(), ev, now);
}

/**
 * Check if an event from an (string) address is ignored.
 */
bool ignore_list::is_ignored(const char * addr, event ev, time_t now) const
{
	for (container_type::const_iterator i = ignores.begin(),
						e = ignores.end();
						i != e;
						++i) {
		const ignore_entry &entry = *i;
		if (now >= entry.expiration) {
			// old, expired entry
			continue;
		}
		if (!entry.flags.test(ev)) {
			// flags didn't match
			continue;
		}
		if (wild_match(entry.mask.c_str(), addr) == 0) {
			// found a match!
			return true;
		}
	}
	return false;
}

/**
 * Check if an ignore entry exists.
 *
 * @param mask		ignore mask to look for
 * @param flags		flags to match
 * @return true if the requested entry exists
 */
bool ignore_list::contains(const char * mask, const event_flagset_t& flags) const
{
	container_type::const_iterator i = std::find_if(ignores.begin(), ignores.end(), 
						mask_flag_equals(mask, flags));

	return (i != ignores.end());
}


/**
 * Add an entry to the ignore list, using raw ignore mask.
 *
 * @param mask		ignore mask
 * @param flags		set of irc events to ignore
 * @param expiration	expiration time
 */
void ignore_list::add(const char * mask, const event_flagset_t& flags, time_t expiration) 
{
	const ignore_entry e = {
		mask,
		flags,
		expiration
	};

	add(e);
}

/**
 * Add entry to the ignore list, creating ignore mask from address object.
 *
 * @param addr		IRC address to analyze
 * @param flags		set of irc events to ignore
 * @param expiration	expiration time
 */
void ignore_list::add(const address * addr, const event_flagset_t& flags, time_t expiration)
{
	ignore_entry e;

	if (addr->has_user_host()) {
		my_sprintf(e.mask, "*!*@%s", addr->host());
	}
	else {
		my_sprintf(e.mask, "%s!*@*", addr->nick());
	}

	e.flags = flags;
	e.expiration = expiration;

	add(e);
}

/**
 * Add an ignore_entry to the list.  If a matching one exists (mask and flags), then update 
 * it.  Otherwise create a new entry.
 *
 * XXX: no sanity checking performed on the entry.
 */
void ignore_list::add(const ignore_entry& e)
{
	container_type::iterator i = std::find_if(ignores.begin(), ignores.end(), 
						mask_flag_equals(e.mask, e.flags));

	if (i != ignores.end()) {
		ignore_entry &orig = *i;
		
		DEBUG("ignore_list::add() [%p]: updating ignore '%s' with flags %lu and (new) exp %ld\n",
			this, e.mask.c_str(), e.flags.to_ulong(), e.expiration);
		orig.expiration = e.expiration;
		return;
	}

	// not found, add new entry.
	DEBUG("ignore_list::add() [%p]: adding new ignore '%s' with flags %lu and exp %ld\n",
			this, e.mask.c_str(), e.flags.to_ulong(), e.expiration);
	ignores.push_back(e);	
}

/**
 * Remove entries that have expired.
 *
 * @param now	the current time
 */
void ignore_list::clear_expired(time_t now)
{
	container_type::iterator i = std::remove_if(ignores.begin(), ignores.end(),
							entry_expired(now));
	ignores.erase(i, ignores.end());
}

}
