/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/address.cc -- part of the ezbounce IRC proxy.
 * (C) 2007-2008 Murat Deligonul
 */
#include "autoconf.h"

#include <stdexcept>
#include <cstring>
#include <cstdio>
#include "util/strings.h"
#include "irc/address.h"
#include "debug.h"

namespace irc {

using util::strings::my_strdup;
using util::strings::is_non_empty;
using util::strings::my_asprintf;

/**
  * Construct an address from a single string, which may be just a
  * nickname, or a "nick!user@host" string.
  *
  * Does not perform verification of the nickname for legality.  This may
  * be ircd-dependent and should be performed outside.
  */ 
address::address(const char * str) 
	: nickname(NULL), user_host(NULL)
{
	if (!is_non_empty(str)) {
		throw std::invalid_argument("invalid IRC address string");
	}
	assert(str[0] != ':');

	const char * bang = strchr(str, '!');
	if (bang == NULL) {
		// easy case, just a nickname;
		nickname = my_strdup(str);
		return;
	}

	// assume full address
	// first grab the nickname
	const int nicklen = bang - str;
	nickname = new char[nicklen+1];
	memcpy(nickname, str, nicklen);
	nickname[nicklen] = 0;

	const char * at = strrchr(bang, '@');
	if (at == NULL || (at-bang == 1)) {
		// ill-formed
		// ignore the rest
		assert(false);
		return;
	}

	user_host = my_strdup(bang+1);
	const int user_len = at-(bang+1);
	user_host[user_len] = 0;
}

/**
  * Set the user and hostname field.
  * Both values must be non-NULL and non-empty, or the call does nothing.
  */
void address::set_user_host(const char * h, const char * u)
{
	if (!is_non_empty(h) || !is_non_empty(u)) {
		return;
	}
	delete[] user_host;
	my_asprintf(&user_host, "%s%c%s", h, '\0', u);
}

} // namespace irc
