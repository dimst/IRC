/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/message.cc -- IRC message-related utilities.
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include <string>
#include <stdexcept>
#include <cstring>
#include "util/strings.h"
#include "irc/event.h"
#include "textline.h"
#include "debug.h"

using std::string;
using util::strings::no_leading;

namespace irc {

/**
 * Given a PRIVMSG or NOTICE message, determine if it is a type
 * of CTCP message (or a CTCP reply).
 * NOTE: Exception is thrown for invalid events.
 *
 * @param ev 		The IRC event to analyze.  Only PRIVMSG or NOTICE messages are accepted.
 * @param args  	Arguments to the event.
 * @param start 	Argument # where parameters start
 * @param type		string to store CTCP type in, left empty otherwise	
 * @param subtype	string to store CTCP subtype in (only used for DCCs)
 * @param message	string to store remaining CTCP arguments in
 * @throw invalid_argument if ev was not a PRIVMSG or NOTICE message
 * @return the CTCP event found, or the original event if no CTCP message was found.
 */
event extract_ctcp(event ev, const textline& args, unsigned start, 
			string& type, string& subtype, string& message)
{
	if (ev != PUBLIC_PRIVMSG && ev != PRIVATE_PRIVMSG 
			&& ev != PUBLIC_NOTICE && ev != PRIVATE_NOTICE) {
		throw std::invalid_argument("invalid event type; cannot contain a CTCP");
	}

	const char * all = no_leading(args.get_rest(start));
	const size_t len = strlen(all);
	const char * last = all+len-1;
	if (len < 3 || all[0] != '\001' || *last != '\001') {
		// not interested in this
		return ev;
	}

	if (strchr(all+1, '\001') != last) {
		// invalid: too many 001 characters
		return ev;
	}

	event out = ev;
	int m_index = start + 1;
	const char * first = no_leading(args[start]);

	subtype.clear();
	type = first+1;
	if (type[type.size()-1] == '\001') {
		type.resize(type.size()-1);			
	}
	if (type.empty()) {
		// invalid CTCP
		return ev;
	}

	if (type == "DCC") {
		// only permitted for PRIVATE_PRIVMSG
		if (ev != PRIVATE_PRIVMSG) {
			return ev;
		}

		// we need a subtype as well.. and more
		// sample DCC: "DCC SEND file.txt <address> <port> [size]"
		if (args < start + 5) {
			return ev;
		}

		subtype = args[start + 1];
		m_index = start + 2;
		
		out = DCC;
	}
	else if (type == "ACTION") {
		// '/me' commands
		if (ev == PRIVATE_PRIVMSG) {
			out = PRIVATE_ACTION;
		}
		else if (ev == PUBLIC_PRIVMSG) {
			out = PUBLIC_ACTION;
		}
		else {
			// not valid in NOTICEs
			return ev;
		}
	}
	else {
		// normal CTCP 
		// determine if public or private, or if CTCP reply
		if (ev == PRIVATE_NOTICE) {
			out = CTCP_REPLY;
		}
		else if (ev == PUBLIC_PRIVMSG) {
			out = PUBLIC_CTCP;
		}
		else if (ev == PRIVATE_PRIVMSG) {
			out = PRIVATE_CTCP;
		}
		else {
			// public NOTICE, not valid for anything
			return ev;
		}
	}

	message.clear();
	if (args > m_index) {
		message = args.get_rest(m_index);		
		assert(message[message.size()-1] == '\001');
		message.resize(message.size()-1);
	}
	
	assert(out != PUBLIC_PRIVMSG && out != PRIVATE_PRIVMSG 
			&& out != PUBLIC_NOTICE && out != PRIVATE_NOTICE);
	return out;
}

/**
 * Determine is an IRC event is a 'private' event.
 */
bool is_private_event(event e)
{
	switch (e) {
	case PRIVATE_PRIVMSG:
	case PRIVATE_NOTICE:
	case PRIVATE_ACTION:
	case PRIVATE_CTCP:
	case DCC:
	case CTCP_REPLY:
		return true;
	default:
		break;
	}
	return false;
}

}
