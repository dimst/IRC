/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/cache.cc	-- IRC address/channel/nickname caching system
 * (c) 2003-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <list>
#include <algorithm>
#include <functional>
#include <cstdlib>
#include <cstdio>
#include "util/generic.h"
#include "util/tokenizer.h"
#include "util/strings.h"
#include "irc/cache.h"
#include "irc/server_info.h"
#include "net/socket.h"
#include "textline.h"

#include "debug.h"

namespace irc {

using util::delete_ptr;
using util::apply_second;
using namespace util::strings;

/**
 * Construct an address_cache.
 *
 * @param s		pointer to server_info object describing server settings
 * @param size		initial size of hash table
 */
address_cache::address_cache(const server_info * s, size_t size) :
		nick_hash(size, s->nick_hash_func(), s->casecmp_func()),
		channel_hash(5, s->channel_hash_func(), s->casecmp_func()),
		server(s)
{ 
	nick_hash.set_rehash_trigger(0,3); 
}

/**
 * Destructor for the address cache.
 * Before destroying the hash tables, we must destroy
 * each indiviual member.
 */
address_cache::~address_cache()
{
	std::for_each(nick_hash.begin(), nick_hash.end(), apply_second<delete_ptr>());
	std::for_each(channel_hash.begin(), channel_hash.end(), apply_second<delete_ptr>());
}

/**
 * Add a channel to the cache.  The channel must not already
 * exist in the cache.
 *
 * @param chan		name of channel to add
 * @return 0 on success
 */
int address_cache::add_channel(const char * chan)
{
	DEBUG("address_cache::add_channel(): [%p] %s\n", this, chan);
	if (channel_hash.contains(chan)) {
		// channel already exists in the cache
		DEBUG("address_cache::add_channel(): channel already exists: %s\n", chan);
		return -1;
	}
	if (!server->is_channel(chan)) {
		// illegal channel name
		DEBUG("address_cache::add_channel(): illegal channel name: %s\n", chan);
		return -1;
	}

	channel * c = new channel(server, chan, 7);
	channel_hash.insert(c->name(), c);
	assert(channel_hash.contains(c->name()));
	return 0;
}

/**
 * Remove a channel from the cache.
 * We must remove all references to this channel. This means:
 * going through the channel's nick_hash and for each nickname:
 *	- Removing reference to this channel.
 *	- If nickname has no more references, delete it too.
 *
 * @param chan		name of channel to remove
 * @return 0 on success
 */
int address_cache::delete_channel(const char * chan)
{
	DEBUG("address_cache::delete_channel() [%p]: %s\n", this, chan);
	channel * c = lookup_channel(chan); 
	if (!c)	{
		DEBUG("address_cache::delete_channel(): unknown channel: %s\n", chan);
		return -1;
	}
	channel_hash.erase(chan);

	// remove all users' references to this channel
	channel::hash_table_t::iterator i = c->nicks_begin(),
					 e = c->nicks_end(); 

	for ( ; i != e; ++i) {
		cache_entry * e = (*i).second.first;

		e->del_chan(c);

		if (e->references().empty()) {
			DEBUG("address_cache::delete_channel(): deleting stale cache_entry %p\n", e);
			nick_hash.erase(e->nick());
			delete e;
		}
	}

	delete c;
	assert(!lookup_channel(chan));
	return 0;
}

/**
 * Add a new nickname to a channel's user list.  This is wrapper for add_entry()
 * which creates the address object locally.
 *
 * @param nick		nickname of user.
 * @param chan		channel to add him to; must be non-NULL and exist in the cache.
 * @param mode		initial channel modes for the user.  May be zero.
 */
int address_cache::add_nick(const char * nick, const char * chan, server_info::mode_flag_t mode)
{
	address ia(nick);
	return add_entry(&ia, chan, mode);
}

/**
 * Add a new nickname to a channel's user list from an irc::address object with potentially a
 * full address.  The nickname need not already exist in the cache.  The function will verify
 * legality of the nickname.
 *
 * @param ia		irc::address object containing partial or full information about the user.
 * @param chan		channel to add him to; must be non-NULL and exist in the cache.
 * @param mode		initial chan modes for the user.  May be zero.
 * @return 0 on success
 */
int address_cache::add_entry(const address * ia, const char * chan, server_info::mode_flag_t mode)
{
	const char * n = ia->nick();
	if (!server->is_legal_nick(n)) {
		// illegal nick
		DEBUG("address_cache::add_entry(): attempting to add illegal nick: %s to %s\n", n, chan);
		return -1;
	}

	channel * c = lookup_channel(chan);
	if (!c)	{
		// channel doesn't exist
		return -1;
	}

	if (c->has_nick(n)) {
		// nickname already in the channel user list for some reason ??
                DEBUG("address_cache::add_entry(): IRC logic problem: user already contains on channel? (%s-->%s)\n", n, chan);
		return -1;
	}

	/**
	 * Do we already know this user?
	 */
	cache_entry * e = lookup_nick(n);
	if (!e) {
		e = new cache_entry(ia->nick(), ia->user(), ia->host());
		nick_hash.insert(e->nick(), e);
		//DEBUG("address_cache::add_nick() -- new entry: %s on %s\n", e->nick(), chan);
	}

	e->add_chan(c);
	c->add_nick(e, mode);

	assert(c->has_nick(e->nick()));
	return 0;
}


/**
 * Remove a nickname from a channel.
 * If channel is not given, then remove it from all channels
 * and purge its entry from the address cache.
 *
 * @param n		nickname to remove.
 * @param chan		channel to remove from; NULL to purge from address cache.
 * @return 0 on success
 */
int address_cache::delete_nick(const char * n, const char * chan)
{
	channel * c = chan ? lookup_channel(chan) : NULL;
	if (chan && !c) {
		// unknown channel
		return -1;
	}

	cache_entry * e = lookup_nick(n);
	if (!e) {
		// don't know this user
		DEBUG("address_cache::delete_nick(): trying to remove non-existent user %s from %s\n", n, chan);
		return -1;
	}

	if (c) {
		if (!c->has_nick(e->nick())) {
			// user not in this channel
			DEBUG("address_cache::delete_nick(): trying to remove user %s from %s where he wasn't known\n", n, chan);
			return -1;
		}
		DEBUG("address_cache::delete_nick(): removing %s from %s\n", e->nick(), c->name());
		c->del_nick(e);
		e->del_chan(c);
		assert(c->lookup_nick(e->nick()) == NULL);
	}
	if (!c || e->references().empty()) {
		// Remove from all channels
		// cache_entry destructor takes care of cleaning up its references
		DEBUG("address_cache::delete_nick(): removing %s from ALL channels\n", e->nick());
		nick_hash.erase(e->nick());
		delete e;
	}

	return 0;
}

/**
 * Change a nickname.
 * This is a little tricky: all of the entries in each channel's nick hash are 
 * pointing to the same thing. So once the nickname is changed, all 
 * the references to it must also be updated.
 *
 * @param old		nickname to change.
 * @param _new		nickname to change it to.
 * @return 0 on success
 */
int address_cache::change_nick(const char * old, const char * _new)
{
	DEBUG("address_cache::change_nick(): %s->%s\n", old, _new);
	cache_entry * e = lookup_nick(old);
	if (!e) {
		// don't know this user
		DEBUG("address_cache::change_nick(): original not found! (%s)\n", old);
		return -1;
	}

	/**
	 * Users are permitted to change nicknames to the same one, but with different case.
	 * Check for this condition.
	 */
	if (server->strcasecmp(old, _new) != 0) {
		if (lookup_nick(_new) != NULL) {
			// new nickname already exists
			DEBUG("address_cache::change_nick(): new nickname already exists! (%s)\n", _new);
			return -1;
		}

		if (!server->is_legal_nick(_new)) {
			// new nickname is invalid
			DEBUG("address_cache::change_nick(): new nickname is invalid (%s)\n", _new);
			return -1;
		}
	}

	nick_hash.erase(e->nick());

	// this will take care of updating its references
	e->change_nick(_new);

	nick_hash.insert(e->nick(), e);
	return 0;
}

/**
 * Bind a nick to its (newly discovered) address.
 *
 * @param nick		nickname to change
 * @param user		user to set
 * @param host		host to set
 * @return 0 on success
 */
int address_cache::set_nick_user_host(const char * nick, const char * user, const char * host)
{
	DEBUG("address_cache::set_nick_user_host(): %s -> %s@%s\n", nick, user, host);
	cache_entry * e = lookup_nick(nick);
	if (!e) {
		// unknown entry
		DEBUG("address_cache::set_nick_user_host(): unknown nickname\n");
		return -1;
	}
	e->set_user_host(user, host);
	return 0;
}

int address_cache::flag_operator(int param, const char * nick, const char * chan, server_info::mode_flag_t flags)
{
	cache_entry * e = lookup_nick(nick);
	if (!e) {
		// unknown entry
		return -1;
	}

	channel * c = lookup_channel(chan);
	if (!c) {
		// unknown channel
		assert(false);
		return -1;
	}

	switch (param) {
	case 0:		/* GET */
		return c->nick_flags(e);
	case 1:		/* SET */
		c->set_nick_flags(e, flags);
		return 0;
	case 2: 	/* CLEAR */
		c->clear_nick_flags(e, flags);
		return 0;
	}

	abort();
	return 0;	/* this should never be reached */
}

/**
 * Obtain hash table statistics.  One (or both) params may be NULL.
 *
 * @param nt		hash_stats for nick_hash.
 * @param ct		hash_stats for channel_hash.
 */
void address_cache::stats(struct util::hash_stats * nt, util::hash_stats * ct) const
{
	if (nt) {
		nick_hash.stat(nt);
	}
	if (ct) {
		channel_hash.stat(ct);
	}
}

/**
 * Parse numeric 353 -- /NAMES message.
 *
 * Requirements:
 *  	must be on the channel
 *  	must not have already finished a NAMES parse.
 *
 * Raw Numeric looks like this:
 * 	:irc.avalonworks.ca 353 druglord @ #channel :+Xfig moofo fiend- Fizzter ryan[WIN] +shea_
 *
 * Args needs to be in the format:
 * 	nick1 +nick2 @nick3 @nick4 %nick5 nick6 etc
 *
 * NOTES:
 * 	1 - Original RFC 1459 doesn't have '@|=|*' character proceeding nickname.  These symbols mean:
 * 		        - "@" is used for secret channels, "*" for private
 *           		  channels, and "=" for others (public channels).
 * 	2 - NAMESX-style messages are automatically handled.
 * 	3 - UHNAMES-style messages are also handled. Example:
 * 		:katana.webchat.org 353 murat0 = #indonesia :@Halim!Real@=AE608.250.48.60.klj03-home.tm.net.my 
 *
 * @param channel	name of the channel the message was received for
 * @param args		arguments to message
 * @param num_seen	(optional) pointer to int, to store number of potential nicks recognized in message
 * @return number of names successfully added (compare this to num_seen), or -1 for errors
 */
int address_cache::parse_names_block(const char * channel, const textline& args, unsigned int * num_seen)
{
	class channel * c = lookup_channel(channel);
	/**
	 * Make sure we are on the channel,
	 * and that we haven't already parsed all the NAMES data for it.
	 */
	if (!c || (c->chan_flags() & channel::NAMES_DATA_RECVED)) {
                return -1;
	}

	args.tokenize(textline::MAX);

	const char * nick;
	unsigned int count = 0;
	unsigned int success = 0;

	while ( (nick = args[count++]) != NULL ) {
		server_info::mode_flag_t codes = 0;
		nick = server->strip_prefix_symbols(nick, &codes);

		DEBUG("address_cache::parse_names_block(): adding %s to %s with codes %u\n", nick, channel, codes);
		address ia(nick);
		if (add_entry(&ia, channel, codes) == 0) {
			++success;
		}
	}
	if (num_seen != NULL) {
		*num_seen = count;
	}
	return (int) success;
}

/** 
 * Parses numeric 366, which signifies that the NAMES block is completed.
 *
 * @param channel	channel for which the message was received
 * @return 0 on success, < 0 otherwise
 */
int address_cache::end_names_block(const char * channel)
{
	class channel * c = lookup_channel(channel);
	if (!c || (c->chan_flags() & channel::NAMES_DATA_RECVED)) {
		// not on this channel, or already have its data
		return -1;
	}
	c->set_chan_flag(channel::NAMES_DATA_RECVED);
	return 0;
}

/**
 * example syntax:
 * :irc.avalonworks.ca 352 druglord #quickbasic ~murat xxxx.address.com irc.avalonworks.ca druglord H :0 yes
 * :irc.avalonworks.ca 315 druglord #quickbasic :End of /WHO list.
 * --> We are given text after channel field
 */
int address_cache::parse_who_block(const char * channel, const textline& args)
{
	class channel * c = lookup_channel(channel);
	if (!c || (c->chan_flags() & channel::WHO_DATA_RECVED)) {
		// unknown channel, or already have its data
		return -1;
	}

	if (args < 5) {
		// unknown input		
		DEBUG("address_cache::parse_who_block() -- confused by bogus input\n");
		return -1;
	}

	const char * user = args[0]; 
	const char * host  = args[1];
	const char * nick  = args[3]; 

	if (set_nick_user_host(nick, user, host) < 0) {
		DEBUG("address_cache::parse_who_block() -- set_nick_user_host() failed on %s\n", nick);
		return -1;
	}

	return 0;
}

int address_cache::end_who_block(const char * channel)
{
	class channel * c = lookup_channel(channel);
	if (!c || (c->chan_flags() & channel::WHO_DATA_RECVED)) {
		// unknown channel, or already have its data
		return -1;
	}
	c->set_chan_flag(channel::WHO_DATA_RECVED);
	return 0;
}


/**
 * Parse a MODE line from IRC server
 * format of data: +/-modes [nick1] [xxxx] [xxx] [xxx] etc..A
 *                 where data[0]...data[n] refer to individual token
 *
 * FIXME: doesn't properly reject invalid input like "++++o"
 */
int address_cache::parse_mode_line(const char * chan, const textline& data)
{
	channel * c = lookup_channel(chan);
	if (!c) {
	        return -1;
	}

	const char *pos = no_leading(data[0]);
	char plus = *pos;
	int cur_arg = 1;
	int processed = 0;

	if (plus != '+' && plus != '-') {
	        DEBUG("address_cache::parse_mode_line(%s) [%p]: Unknown mode string %s\n", chan, this, data[0]);
		return -1;
        }
	bool set = (plus == '+');

	++pos;
	for (; *pos; ++pos) {
		if (*pos == '+') {
			set = true;
			continue;
		}
		else if (*pos == '-') {
			set = false;
			continue;
		}

	        server_info::chan_mode mode_flag = server->chan_mode_type(*pos);
		const char * param = NULL;
				
	        switch (mode_flag) {		
		case  server_info::CHAN_MODE_A:
			// always a parameter, but we're not interested in these.
			// example: bans, exempt lists
			++cur_arg;
			break;

		case  server_info::CHAN_MODE_B:		
			// always a parameter.
			// usually only channel mode +k
			param = data[cur_arg++];
			if (param == NULL) {
				DEBUG("address_cache::parse_mode_line(): missing required parameter for mode '%c'\n", *pos);
				break;
			}
			if (set) {
				c->set_valued_mode(*pos, param);
			}
			else {
				c->clear_valued_mode(*pos);
			}
			++processed;
			break;

		case  server_info::CHAN_MODE_C:
			// parameter only when setting. 
			// example: +l
			if (set) {
				param = data[cur_arg++];
				if (param == NULL) {
					DEBUG("address_cache::parse_mode_line(): missing required parameter for (type C) mode '%c'\n", *pos);
					break;
				}
				c->set_valued_mode(*pos, param);
			}
			else {
				c->clear_valued_mode(*pos);
			}
			++processed;
			break;

		case  server_info::CHAN_MODE_D:
		   {
			// no parameters.  common channel modes like +tns
			server_info::mode_flag_t flag = server->mode_to_flag(mode_flag, *pos);
			if (!flag) {
				// unknown mode
				DEBUG("address_cache::parse_mode_line(): unknown mode '%c'!\n", *pos);
				break;
			}
			if (set) {
				c->set_chan_mode(flag);
			}
			else {
				c->clear_chan_mode(flag);
			}
			++processed;
			break;
		   }

		case server_info::CHAN_MODE_PREFIX:		   
		   {
			// +o, +v and the like. always a parameter.
			// parameter is a nickname
			param = data[cur_arg++];
			if (param == NULL) {
				DEBUG("address_cache::parse_mode_line(): no target nickname for mode '%c'!\n", *pos);
				break;
			}

			/**
			 * First verify mode and target.
			 */
			server_info::mode_flag_t flag = server->mode_to_flag(mode_flag, *pos);
			if (!flag) {
				// unknown mode
				DEBUG("address_cache::parse_mode_line(): unknown nickname mode '%c'!\n", *pos);
				break;
			}

			cache_entry * e = lookup_nick(param);
			if (!e) {
				// doesn't exist in the cache
				DEBUG("(!) address_cache::parse_mode_line() [%p] -- dunno what to do with %s on %s [mode line: %s]\n",
					   this, param, chan, data.all());
				break;
			}
			
			if (!c->has_nick(e->nick())) {
				// nick not in channel
				DEBUG("(!) address_cache:parse_mode_line() [%p] -- %s is not on %s! [mode line: %s]\n", 
						this, param, chan, data.all());
				break;
			}

			if (set) {
				c->set_nick_flags(e, flag);
			}
			else {
				c->clear_nick_flags(e, flag);
			}
			DEBUG("  ---> processed MODE change on %s for %s %c%d\n", chan, e->nick(), plus, flag);
			++processed;
			break;
		   }

		default:
			// shouldn't get here.
			DEBUG("(!) address_cache::parse_mode_line() [%p] -- unexpected character '%c'\r\n", this, *pos);
			break;
		}
        }
	return processed;
}

} // namespace irc
