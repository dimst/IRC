/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/channel.cc -- part of the ezbounce IRC proxy.
 * (C) 2007-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <vector>
#include "irc/channel.h"
#include "debug.h"

namespace irc {

using std::map;
using std::vector;
using std::string;
using util::strings::my_strdup;

/* static */ config::target_list channel::default_target_list(3, config::config_target("default"));

/**
 * Create a new channel object:
 * Copy the name, set logfile and flags to default values,
 * Copy network and server names into target list from server_info,
 * Initialize hash table with proper case-mapping specific functions.
 */
channel::channel(const server_info * s, const char * n, int i) :
	_name(my_strdup(n)),
	flags(0),
	log(NULL),
	logging(false),
	log_options(0),
	modes(0),
	channel_target_list( s->server_target() ),	
	nick_hash(i, s->nick_hash_func(), s->casecmp_func()) 
{ 
	nick_hash.set_rehash_trigger(0,3); 
	channel_target_list.push_back( config::config_target(_name) );
}

/**
 * NOTE: We don't remove references to us in the users
 *	 data structures. That's up to the caller.
 */
channel::~channel() 
{
	DEBUG("channel::~channel(): [%p] %s destroyed\n", this, _name);
	delete[] _name;
}

/**
 * Get a combined string of ALL channel modes.
 */
void channel::get_all_modes(const server_info * servinfo, std::string& out) const
{	
	map<char, string>::const_iterator i = valued_modes.begin(),
					e = valued_modes.end();
	vector<string> 	mlist;

	mlist.reserve(valued_modes.size() + 2);

	mlist.push_back("+");
	string& front = mlist.front();

	for (; i != e; ++i) {
		front += (*i).first;
		mlist.push_back((*i).second);		
	}

	// now get regular modes
	char buffer[server_info::MAX_FLAGS + 1];
	servinfo->str_flags(server_info::CHAN_MODE_D, modes, buffer);
	front += buffer;

	// consolidate output into one string
	util::print_container(mlist, out, " ", NULL);
}

int channel::nick_flags(const cache_entry * n) const
{
	hash_table_t::const_iterator i = nick_hash.find(n->nick());
	if (i == nick_hash.end()) {
		throw std::invalid_argument("nickname is not in channel");
	}
	return (*i).second.second;
}

void channel::set_nick_flags(const cache_entry *n, server_info::mode_flag_t f) 
{
	hash_table_t::iterator i = nick_hash.find(n->nick());
	if (i == nick_hash.end()) {
		throw std::invalid_argument("nickname is not in channel");
	}
	server_info::mode_flag_t &target =  (*i).second.second;
	target |= f;
}

void channel::clear_nick_flags(const cache_entry *n, server_info::mode_flag_t f) 
{
	hash_table_t::iterator i = nick_hash.find(n->nick());
	if (i == nick_hash.end()) {
		throw std::invalid_argument("nickname is not in channel");
	}
	server_info::mode_flag_t &target = (*i).second.second;
	target &= ~f;
}

} // namespace irc
