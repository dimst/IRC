/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/flood.cc	-- Basic IRC flood protection.
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"

#include <algorithm>
#include <functional>
#include "util/generic.h"
#include "irc/address.h"
#include "irc/flood.h"
#include "irc/ignore.h"
#include "irc/server_info.h"
#include "debug.h"

using util::apply_second;
using util::delete_ptr;
using util::compose_f_gx_hx;

namespace irc {

/**
 * flood_protector constructor.
 */
flood_protector::flood_protector(const server_info * s, ignore_list * i, size_t size) :
		nick_hash(size, s->nick_hash_func(), s->casecmp_func()),
		ignores(i),
		ignore_time(DEF_IGNORE_TIME),
		global_ignore_time(DEF_GLOBAL_IGNORE_TIME)
	       	
{
	assert(i != NULL);
	global.name = "global";

	set_priv_msg_rate(DEF_PRIV_MSGS, DEF_PRIV_SECS);
	set_auto_resp_rate(DEF_AUTO_RESP_MSGS, DEF_AUTO_RESP_SECS);
	set_global_priv_msg_rate(DEF_GLOBAL_PRIV_MSGS, DEF_GLOBAL_PRIV_SECS);
	set_global_auto_resp_rate(DEF_GLOBAL_AUTO_RESP_MSGS, DEF_GLOBAL_AUTO_RESP_SECS);
}

/**
 * Destructor.
 * Delete all allocated objects.
 */
flood_protector::~flood_protector()
{
	clear();
}

/**
 * Update the flood protection state.
 * First translates the event into one of the basic handled message types.
 *
 * @param addr		irc::address object representing the message source
 * @param ev		event type
 * @param now		the current time
 * @return 0 if the update succeded
 */
int flood_protector::in(const address * addr, event ev, time_t now)
{
	message_type m = determine_message_type(ev);
	if (m == PRIVATE) {
		return priv_msg_in(addr, now);
	}
	else if (m == AUTO_RESPONSE) {
		// TODO: should these update PRIVATE counters too?
		return auto_resp_msg_in(addr, now);
	} 
	return INVALID_EVENT;
}

/**
 * Update flood protection state given a simple private message.
 */
int flood_protector::priv_msg_in(const address * addr, time_t now)
{
	flood_entry * e = find_or_create(addr->nick());

	// check this nick's rate
	e->priv_msgs.push_back(now);
	bool nick_ok = is_rate_ok(e->priv_msgs, priv_rate, now);

	// check global rate
	global.priv_msgs.push_back(now);
	bool global_ok = is_rate_ok(global.priv_msgs, global_priv_rate, now);

	if (global_ok && nick_ok) {
		// yay! no flooding
		return UPDATE_OK;
	}

	// flooding detected
	event_flagset_t events;
	events.set(PUBLIC_CTCP); 
	events.set(PRIVATE_CTCP);
	events.set(DCC);
	events.set(CTCP_REPLY);
	events.set(PRIVATE_PRIVMSG);
	events.set(PRIVATE_ACTION);
	events.set(PRIVATE_NOTICE);

	if (!global_ok) {
		ignores->add("*!*@*", events, now + global_ignore_time);
	}
	if (!nick_ok) {
		// completely ignore the user
		events.set(PUBLIC_PRIVMSG);
		events.set(PUBLIC_ACTION);  
		events.set(PUBLIC_NOTICE);  

		ignores->add(addr, events, now + global_ignore_time);
	}	
	return NOW_IGNORING;
}

/**
 * Update flood protection state for auto response messages.
 */
int flood_protector::auto_resp_msg_in(const address * addr, time_t now)
{
	flood_entry * e = find_or_create(addr->nick());
	
	// check this nick's rate
	e->auto_resp_msgs.push_back(now);
	bool nick_ok = is_rate_ok(e->auto_resp_msgs, auto_resp_rate, now);

	// check global rate
	global.auto_resp_msgs.push_back(now);
	bool global_ok = is_rate_ok(global.auto_resp_msgs, global_auto_resp_rate, now);

	if (global_ok && nick_ok) {
		// yay! no flooding
		return UPDATE_OK;
	}

	// flooding detected
	event_flagset_t events;
	events.set(PUBLIC_CTCP);
	events.set(PRIVATE_CTCP);
	events.set(DCC);

	if (!global_ok) {
		ignores->add("*!*@*", events, now + global_ignore_time);
	}
	if (!nick_ok) {
		// completely ignore this user
		events.set(CTCP_REPLY);
		events.set(PUBLIC_PRIVMSG); events.set(PRIVATE_PRIVMSG);
		events.set(PUBLIC_ACTION);  events.set(PRIVATE_ACTION);
		events.set(PUBLIC_NOTICE);  events.set(PRIVATE_NOTICE);

		ignores->add(addr, events, now + global_ignore_time);
	}	
	return NOW_IGNORING;	
}


/** 
 * Advise the flood protection mechanism of a nick change.
 * Due to the nature of IRC, the client will not be able to see all
 * nick changes, so this call may not always work.  If the flood protection
 * cache is not in a valid state for the nick change, the request will be ignored.
 *
 * @param old_nick	nickname of client
 * @param new_nick	the new nickname
 * @return 0 if the nick change succeeds, -1 otherwise
 */
int flood_protector::nick_change(const char * old_nick, const char * new_nick)
{
	// TODO: implement
	return -1;
}

/**
 * Delete cache of all allocated objects.
 */
void flood_protector::clear()
{
	std::for_each(nick_hash.begin(), nick_hash.end(), apply_second<delete_ptr>());
	nick_hash.clear();
}

/**
 * Delete cache of expired objects.
 */
void flood_protector::clear_expired(time_t now)
{	
	// Determine maximum age for entries
	const seconds_t vals[] = {
		priv_rate.second,
		auto_resp_rate.second,

		global_priv_rate.second,
		global_auto_resp_rate.second
	};

	const size_t n = sizeof(vals) / sizeof(vals[0]);
	const seconds_t &max = *std::max_element(vals, vals+n) + 1;

	for (nick_hash_t::const_iterator i = nick_hash.begin(),
					e = nick_hash.end();
					i != e;
					++i) {
		flood_entry& e = *i->second;

		DEBUG("floodp::clear_expired(): starting prune for '%s' (sizes: %zd, %zd)\n", (*i).first,
								e.priv_msgs.size(), e.auto_resp_msgs.size());
		clear_expired_msgs(e.priv_msgs, max, now);
		clear_expired_msgs(e.auto_resp_msgs, max, now);		
		DEBUG("floodp::clear_expired(): finished prune for '%s' (new sizes: %zd, %zd)\n", (*i).first,
								e.priv_msgs.size(), e.auto_resp_msgs.size());
	}
}


/**
 * Look up entry in the flood entry cache.  If it doesn't exist,
 * create a new one.
 */
flood_entry * flood_protector::find_or_create(const char * key)
{
	nick_hash_t::iterator i = nick_hash.find(key);
	if (i != nick_hash.end()) {
		return i->second;
	}
	
	flood_entry * out = new flood_entry;
	out->name.assign(key);
	nick_hash.insert(out->name.c_str(), out);
	return out;
}

/**
 * Given a list of messages times and the rate limits, determine if 
 * a flooding event has occurred.
 *
 * @param times		vector<time_t> listing the times of the messages (sorted?)
 * @param limits	msg_rate_t pair describing the num/time limit	
 * @param now 		the current time
 * @return true if the message rate is OK (i.e. NOT flooding)
 */
/* static */ bool flood_protector::is_rate_ok(const std::vector<time_t>& times, 
						const msg_rate_t& limits, time_t now)
{
	using std::bind2nd;
	using std::greater;
	using std::less_equal;

	// find times x such that
	// 	x > (now - secs) && x <= now
	const time_t bottom = now - limits.second;
	const size_t msgs = std::count_if(times.begin(), times.end(), 
					compose_f_gx_hx(std::logical_and<bool>(),
								bind2nd(greater<time_t>(), bottom),
								bind2nd(less_equal<time_t>(), now)));
	return (msgs <= limits.first);
}

/**
 * Given list of times, remove the message timestamps that can no longer 
 * generate flood events.
 */
/* static */ void flood_protector::clear_expired_msgs(std::vector<time_t>& times, unsigned max_age, time_t now)
{
	using std::bind2nd;
	using std::less_equal;

	std::vector<time_t>::iterator i = std::remove_if(times.begin(), times.end(),
							bind2nd(less_equal<time_t>(), now - max_age));
	times.erase(i, times.end());
}

/**
 * Determine the type of flood protection message an IRC event is.
 *
 * @param ev	the event to translate
 */
/* static */ flood_protector::message_type flood_protector::determine_message_type(event ev)
{
	switch (ev) {
	case PRIVATE_PRIVMSG:
	case PRIVATE_NOTICE:
	case PRIVATE_ACTION:
	case CTCP_REPLY:
		return PRIVATE;
	
	case PRIVATE_CTCP:
	case PUBLIC_CTCP:
	case DCC:
		return AUTO_RESPONSE;

	default:
		break;
	}

	return OTHER;	
}
}
