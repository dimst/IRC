/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * irc/rfunc.cc -- Restartable functions for IRC address cache data access.
 * (c) 2008 Murat Deligonul
 */

#include "autoconf.h"
#include <cstring>
#include "util/strings.h"
#include "irc/cache.h"
#include "rfunc.h"
#include "debug.h"

using util::strings::my_strdup;

namespace irc {

/**
 * Restartable functions for IRC address cache.
 */
class acache_rfunc : public rfunc {
protected:
	net::socket * target;

	channel * chan;
	char * nick;

	int  written;
	int  current_idx;		/* where we stopped */
	int  current_flags;		/* misc data of current item */

	const server_info * server;

	address_cache * acache;
	cache_entry * current;

	channel::hash_table_t::const_iterator i, e;

public:
	acache_rfunc(net::socket * t, channel * c,
			const char * n, const server_info * s) : 
		target(t), chan(c),
	  	nick(my_strdup(n)), 
		written(0),
	  	current_idx(0), 
		current_flags(0),
	  	server(s),
	  	current(0),
	  	i(c->nicks_begin()),
	  	e(c->nicks_end()) { }

	~acache_rfunc() {
		delete[] nick;
	}

	virtual int execute(int) = 0;

private:
	acache_rfunc(const acache_rfunc &);
	acache_rfunc & operator= (const acache_rfunc &);
};

class names_rfunc : public acache_rfunc {
public:
	names_rfunc(net::socket * t,channel * c, const char * n, const server_info * s)
		: acache_rfunc(t,c,n,s) { }

	virtual int execute(int arg);

private:
	char irc_buffer[511];
};

class who_rfunc : public acache_rfunc {
public:
	who_rfunc(net::socket *t, channel *c, const char *n, const server_info * s)
		: acache_rfunc(t,c,n,s) { }
	virtual int execute (int arg);
};


rfunc * address_cache::create_rfunc(address_cache::rfunc_t t, net::socket * target,
					const char * chan, const char * n) 
{
	channel * c = lookup_channel(chan);
	assert(n != NULL);
	assert(chan != NULL);
	assert(target != NULL);

	if (!c) {
		return NULL;
	}

	if (t == RFUNC_WHO) {
		return new who_rfunc(target, c, n, server);
	}
	else if (t == RFUNC_NAMES) {
		return new names_rfunc(target, c, n, server);
	}

	DEBUG("acache::create_rfunc() -- Requested for unknown type %d\n", t);
	return NULL;
}

 /** 
  ** Return values for restartable functions:
  ** 	0 - operation finished
  **	    iterator deleted and set to 0
  **	    other relevant fields set to zero
  **
  **    >0 - operation to be resumed later
  **	    [return value] represents current position
  **	    iterator, current, current_idx updated with current position
  **		NOTE: current_idx and return value are 1 based
  **
  **    <0 - fatal error, invalid arguments given or other unrecoverable error
  **	    data will not be modified
  */
int names_rfunc::execute(int)
{
	char flag_buffer[33];    /* to store '@+%' etc. */

	/* :irc.avalonworks.ca 353 druglord @ #channel :+Xfig moofo fiend- Fizzter ryan[WIN] +shea_ */
	/* FIXME: this totally disregards whether the channel is secret/private/public whatever
	 * (i.e. the @ or = character after the nickname) */

	while (current || i != e) {
	        if (!current) {
			current       = (*i).second.first;
		        current_flags = (*i).second.second; 
			++i;
			server->str_prefix_symbols(current_flags, flag_buffer);
			assert(current_flags ? *flag_buffer != 0 : true);
                }

		if (!written) {
		        /* print the header */
			written = snprintf(irc_buffer, sizeof(irc_buffer), ":%s 353 %s @ %s :",
			        server->name(),
				nick,
				chan->name());
		}

		const size_t needed = written + strlen(flag_buffer) + strlen(current->nick()) + 4;
		if (needed > target->buffer_availableO()) {
			/**
			 * No space available, so save state and 
			 * resume later.
			 */
			return current_idx+1;
		}

		if (needed >= sizeof(irc_buffer)) {
			/**
			 * Filled up an IRC text line. Queue what we have, create
			 * new IRC line in next iteration.
			 */
			DEBUG("writing: %s\n", irc_buffer);
			assert(irc_buffer[0] == ':');
			target->queue(irc_buffer, written);
			target->queue("\r\n", 2);
			written = 0;
			continue;
		}
		
		/**
		 * Insert the next nickname ... 
		 */
                written += snprintf(irc_buffer + written, 
				sizeof(irc_buffer) - written, "%s%s ",
		                flag_buffer,
		                current->nick());

		assert(written > 0);
		assert(written <= 510);
		++current_idx;
		current = NULL;
		current_flags = 0;
	}

	/** 
	 * All nicks should have been processed 
	 */
	if (written) {
		assert(irc_buffer[0] == ':');
	        target->queue(irc_buffer, written);
		target->queue("\r\n", 2);
        }

	/**
	 * Make sure there's room for numeric 366 data 
	 */
	const size_t LEN_366 = 30 + strlen(server->name()) + strlen(nick) + strlen(chan->name());

	if (target->buffer_availableO() < LEN_366) {
		DEBUG("Ack! No room for numeric 366 on channel %s\n", chan->name());
		current = NULL;
		written = 0;
		return current_idx + 1;		/* FIXME: is the +1 needed (or correct?) */
	}

	target->printfQ(":%s 366 %s %s :End of /NAMES list.\r\n",
				server->name(), nick, chan->name());
	current = 0;
	assert(chan->population() == (unsigned) current_idx);
	return 0;	/* DONE ! */
}

/**
 * Like above but deals with WHO data instead,
 * with slight differences in the algorithm
 *
 * Sample text:
 *
 * >> :irc.Prison.NET 352 druglord0 #channel muratd stanchion.cs.utexas.edu irc.Prison.NET druglord0 H :0 mmm, donuts
 * >> :irc.Prison.NET 352 druglord0 #channel ~fetish ip68-2-139-54.ph.ph.cox.net irc.arcti.ca thekeepr^ H :6 Gray   would be the color if I had a heart
 * >> :irc.Prison.NET 352 druglord0 #channel stuff c213-100-41-49.swipnet.se efnet.xs4all.nl SirGoblin H :4 lollerskates   <3
 * >> :irc.Prison.NET 352 druglord0 #channel ~jookz 216-160-192-241.phnx.qwest.net irc.inet.tele.dk jookz H :5 jookz
 * >> :irc.Prison.NET 352 druglord0 #channel jedi jagdsl-13.smig.net irc.blessed.net infoe G :4 Obi-Wan Kanblomi
 */
int who_rfunc::execute(int)
{
	char flag_buffer[server_info::MAX_FLAGS+1];    /* to store '@+%' etc. */
	char irc_buffer[511];    /* RFC1459 says 512 max, including CRLF;
				  * so 510 effective + 1 for NULL */

	const char * const dummy_server = "unknown.server";
	const char * const dummy_info =  "user information unknown";
	const char * const dummy_status = "H";
	const int dummy_hops = 1;

	while (current || i != e) {
	        if (!current) {
			current	      = (*i).second.first;
		        current_flags = (*i).second.second;
			++i;
			server->str_prefix_symbols(current_flags, flag_buffer);
			assert(current_flags ? *flag_buffer != 0 : true);
                }

		/* :irc.Prison.NET 352 druglord #channel ~jedi jagdsl-13.smig.net irc.blessed.net infoe G :4 Obi-Wan 			  *   Kanblomi */

		written = snprintf(irc_buffer, sizeof(irc_buffer), ":%s 352 %s %s %s %s %s %s %s :%d %s",
			server->name(), nick, chan->name(),
			current->user(),
			current->host(),
			dummy_server, 	  /* IRC Server he's on */
			current->nick(),  /* his nickname */
			dummy_status,	  /* status, e.g. here, gone, IRC Operator ... */
			dummy_hops,	  /* the hop count */
			dummy_info	  /* user information */
		);

		/**
		 * NOTE: snprintf() returns not how many bytes were written,
		 * but how many bytes *would have been* written had buffer length limit
		 * not been reached
		 */
		if (written < 0 || written > 510) {
			written = 510;
		}

		if (unsigned (written + 2) > target->buffer_availableO()) {
			// resume later
			written = 0;
			return current_idx+1;
		}

		/**
		 * Ready to queue this line.
		 */
		target->queue(irc_buffer, written);
		target->queue("\r\n", 2);
		written = 0;
		current = 0;
		current_flags = 0;
		++current_idx;
	}

	/** 
	 * Make sure there's room for numeric 315 data.
	 */
	// >> :irc.Prison.NET 315 nickname #ezb :End of /WHO list.
	unsigned LEN_315 = 28 + strlen(server->name()) + strlen(nick) + strlen(chan->name());
	if (target->buffer_availableO() < LEN_315) {
		DEBUG("Ack! No room for numeric 315 on channel %s\n", chan->name());
		current = NULL;
		return current_idx + 1;		/* FIXME: is the +1 needed (or correct?) */
	}

	target->printfQ(":%s 315 %s %s :End of /WHO list.\r\n",
				server->name(), nick, chan->name());
	current = NULL;
	assert(chan->population() == (unsigned) current_idx);
	return 0;	/* DONE ! */
}

} // namespace irc

