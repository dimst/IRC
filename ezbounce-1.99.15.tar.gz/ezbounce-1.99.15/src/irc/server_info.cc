/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
 * irc/serverinfo.cc
 * (c) 2003-2008 Murat Deligonul
 *
 * does: keeping track of server capabilities and attributes (i.e. Network,
 *	supported prefixes, numeric 005 data, etc)
 */

#include "autoconf.h"

#include <string>
#include <cstring>
#include <cstdlib>
#include "irc/server_info.h"
#include "irc/rfc1459.h"
#include "textline.h"
#include "debug.h"

using config::config_target;
using namespace util::strings;

namespace irc {

/* static */ const size_t server_info::MAX_FLAGS = sizeof(server_info::mode_flag_t) * 8;

const char server_info::def_chan_types[] = "#&";
const char server_info::def_prefix_symbol_list[] = "@+";
const char server_info::def_prefix_mode_list[] = "ov";
const char server_info::def_irc_network[] = "unknown";
const char server_info::def_chan_mode_list[] = "b,k,l,imnpst";

/**
  * Settings for supported Case Mappings (as given by 005 numeric)
  */
const server_info::casemapping server_info::ASCII_MAPPING = {
	ASCII,
	"ascii",
	&irc::is_legal_nick,
	&::strcasecmp,
	&::strncasecmp,
	&irc_channel_hash,
	&irc_nick_hash,
	&util::strings::to_lowercase	
};

const server_info::casemapping server_info::RFC1459_MAPPING = {
	RFC1459,
	"rfc1459",
	&irc::is_legal_nick,
	&irc_casecmp,
	&irc_ncasecmp,
	&irc_channel_hash,
	&irc_nick_hash,
	&irc_to_lowercase	
};

// FIXME: incomplete
const server_info::casemapping server_info::STRICT_RFC1459_MAPPING = {
	STRICT_RFC1459,
	"strict-rfc1459",
	&irc::is_legal_nick,
	&irc_casecmp,
	&irc_ncasecmp,
	&irc_channel_hash,
	&irc_nick_hash,
	&irc_to_lowercase
};


const config::target_list server_info::default_network_target_list(1, config_target("default"));
const config::target_list server_info::default_server_target_list(2, config_target("default"));

server_info::server_info(const char * s_name) :
		network_target_list( default_network_target_list ),
		server_target_list( default_server_target_list ),
		default_channel_target_list(3, config_target("default")),
		mapping(&RFC1459_MAPPING),
	        max_chans(DEFAULT_MAX_CHANNELS),		
		nick_len(DEFAULT_NICK_LEN)
{
	/* Unofficial server name (i.e. what we connected to the server as) */
	strings.set(UNOFFICIAL_SERVER_NAME, s_name);

        /* Load some of the default settings */
	strings.set(CHAN_TYPES, def_chan_types);
	strings.set(PREFIX_SYMBOL_LIST, def_prefix_symbol_list);
	strings.set(PREFIX_MODE_LIST, def_prefix_mode_list);
	strings.set(IRC_NETWORK, def_irc_network);
	strings.set(CHAN_MODE_LIST, def_chan_mode_list);
}

/**
  * Processing of channel and user modes.
  */
/**
  * NOTE: we exile the ugly numeric parsing code below 
  */
int server_info::parse_numeric(const textline& args)
{
	const char * numeric = args[1];

	if (!is_non_empty(name())) {
		strings.set(SERVER_NAME, no_leading(args[0]));
		server_target_list[1] = config_target( name() );
		default_channel_target_list[1] = config_target( name() );
        }

	if (strcmp(numeric, "005") == 0) {
	        return parse_numeric_005(args);
	}
        if (strcmp(numeric, "004") == 0) {
	        return parse_numeric_004(args);
	}
        if (strcmp(numeric, "003") == 0) {
	        return parse_numeric_003(args);
	}
        return -1;
}

/**
 * used to parse stuff after PREFIX=, etc.. all the way up to ' '
 * or NULL, whatever comes first 
 */
/* static */ int server_info::get_005_token(const char * text,
			const char * token, char * buf, int bufflen)
{
	const char * tok = strstr(text, token);
	int c = 0;
	if (!tok) {
		return 0;
	}
	tok += strlen(token) + 1;
	/* we should now have `TOKEN=' */
	while (*tok && *tok != ' ' && ++c < bufflen) {
		*buf++ = *tok++;
	}

	*buf = 0;
	return c;
}


/**
 * NOTE: some servers send more than 1 005 numeric. we handle up to 3
 * also- we assume we will see them only once upon connect, and we ignore
 * subsequent calls to this function. 
 *
 * Example:
 * :irc.blahblah.com 005 steve CMDS=KNOCK,MAP,DCCALLOW,USERIP NAMESX SAFELIST HCN 
 * 			MAXCHANNELS=10 CHANLIMIT=#:10 MAXLIST=b:60,e:60,I:60 NICKLEN=30 CHANNELLEN=32 
 * 			TOPICLEN=307 KICKLEN=307 AWAYLEN=307 MAXTARGETS=20 :are supported by this server
 */
int server_info::parse_numeric_005(const textline& args)
{
	assert(args >= 4);
	if (strings[NUMERIC_005_1].empty()) {
		strings.set(NUMERIC_005_1, args.get_rest(3));
	}
	else if (strings[NUMERIC_005_2].empty()) {
		strings.set(NUMERIC_005_2, args.get_rest(3));
	}
	else if (strings[NUMERIC_005_3].empty()) {
		strings.set(NUMERIC_005_3, args.get_rest(3));
	}
	else {
		return -1;
	}

        char buf[30];
	const char * text = args.all();

	/* CHANTYPES=&!# */
	if (get_005_token(text, "CHANTYPES", buf, sizeof(buf))) {
	        strings.set(CHAN_TYPES, buf);
	}
	/* NETWORK=xxxx */
        if (get_005_token(text, "NETWORK", buf, sizeof(buf))) {
	        strings.set(IRC_NETWORK, buf);
		network_target_list[0] = config_target( network() );
		server_target_list[0] = config_target( network() );
		default_channel_target_list[0] = config_target( network() );
	}
        /* CHANMODES=xxxx */
	if (get_005_token(text, "CHANMODES", buf, sizeof(buf))) {
	        strings.set(CHAN_MODE_LIST, buf);
	}
	/* PREFIX=(ovh)@%+ */
	if (get_005_token(text, "PREFIX", buf, sizeof(buf))) {
                char * ptr = strstr(buf, ")");

		if (ptr) {
			*ptr = 0;
			strings.set(PREFIX_MODE_LIST, buf+1);
			strings.set(PREFIX_SYMBOL_LIST, ptr+1);
		}
	}
        if (get_005_token(text, "NICKLEN", buf, sizeof(buf))) {
	        nick_len = atoi(buf);
		if (nick_len < 1) {
		        nick_len = 30;
		}
        }
	if (get_005_token(text, "MAXCHANNELS", buf, sizeof(buf))) {
	        max_chans = atoi(buf);
		if (max_chans < 1) {
		        max_chans = 10;
		}
	}
	if (get_005_token(text, "CASEMAPPING", buf, sizeof(buf))) {
		set_casemapping(buf);
	}
	return 0;
}

/**
 * Example:
 *
 * :irc.arcti.ca 003 habib :This server was created Mon Sep 22 2003 at 11:10:14 MDT
 */
int server_info::parse_numeric_003(const textline& args)
{
	assert(args >= 4);
	// we need: server created
	strings.set_once(SERVER_CREATED, non_null(args.get_rest(7))); 
	return 0;
}

/**
 * Numeric 004 -- Example:
 *
 * :irc.arcti.ca 004 habib irc.arcti.ca ircd-ratbox-1.2-2
 *				oiwszcerkfydnxbaugl biklmnopstveIa bkloveI
 */
int server_info::parse_numeric_004(const textline& args)
{
	assert(args >= 4);
	strings.set_once(SERVER_NAME, args[3]);
	strings.set_once(SERVER_VERSION, non_null(args[4]));
	strings.set_once(SERVER_MODES, non_null(args.get_rest(5)));

	// update this
	server_target_list[1] = config_target( name() );
	default_channel_target_list[1] = config_target( name() );
	return 0;
}

/**
  * Assign the proper settings required by the server's CASEMAPPING variable.
  */
void server_info::set_casemapping(const char * buf)
{
	if (::strcasecmp(buf, "ASCII") == 0) {		
		mapping = &ASCII_MAPPING;
	}
	else if (::strcasecmp(buf, "RFC1459") == 0) {
		mapping = &RFC1459_MAPPING;
	}
	else if (::strcasecmp(buf, "STRICT-RFC1459") == 0) {
		/**
		  * FIXME: I don't know if any servers actually use this.
		  * 	   The behavior is different only for two characters.
		  */
		mapping = &STRICT_RFC1459_MAPPING;
	}
	else {
		/* XXX: should not happen.  stay with current setting. */
		DEBUG("server_info::set_casemapping(): Unknown option '%s'\n", buf);
	}
}

/**
 * See if a channel mode matches anything in the "CHANMODE=A,B,C,D"
 * numeric 005 token.
 */
server_info::chan_mode server_info::chan_mode_type(char t) const
{
	using std::string;
	const chan_mode states[] = {CHAN_MODE_A, CHAN_MODE_B, CHAN_MODE_C, CHAN_MODE_D};
	unsigned int s = 0;

	if (strings[PREFIX_MODE_LIST].find(t) != string::npos) {
		return CHAN_MODE_PREFIX;
	}
	const char * p = strings[CHAN_MODE_LIST].c_str();
	const size_t max = sizeof(states) / sizeof(chan_mode);
	while (*p && s < max) {
		if (*p == t) {
			return states[s];
		}
		if (*p == ',') {
			++s;
		}
		++p;
	}
	return CHAN_MODE_UNKNOWN;
}

/**
  * Determine the flag value of the given mode character of type 't'.
  * CHAN_MODE_LIST is in the format: A,B,C,D
  *
  * Return:
  *		 0 	- character was not found in the mode definition
  *		>0	- numeric flag that can be used to represent this mode
  */
server_info::mode_flag_t server_info::mode_to_flag(server_info::chan_mode t, char c) const
{
	const char * modes = get_modes_ptr(t);
	if (modes == NULL) {
		return 0;
	}

	const char * end = strchr(modes, ',');
	int idx = index_of(modes, c);
	if (idx == -1 || unsigned(idx) >= MAX_FLAGS) {
		return 0;
	}
	
	// check legality
	if (end != NULL) {
		if ((modes + idx) >= end) {
			return 0;
		}
	}	
	return (1 << idx);
}

/**
  * Return pointer to the start of the characters for mode 't'
  */
const char * server_info::get_modes_ptr(chan_mode t) const
{
	const char * modes = strings[CHAN_MODE_LIST].c_str();

	switch (t) {
	case CHAN_MODE_PREFIX:
		/* Not channel mode; but nickname prefix like +@ */
		modes = strings[PREFIX_MODE_LIST].c_str();
		break;

	case CHAN_MODE_D:
		modes = strchr(modes, ',');
		if (modes != NULL) {
			++modes;
			// fall thru
	case CHAN_MODE_C:
			modes = strchr(modes, ',');
			if (modes != NULL) {
				++modes;
				// fall thru
	case CHAN_MODE_B:
				modes = strchr(modes, ',');
			}
		}
		if (modes == NULL) {
			// fall thru
	case CHAN_MODE_UNKNOWN:
	default:
			return NULL;
		}
		++modes;
		// fall thru
	case CHAN_MODE_A:
		break;
	}
	return modes;
}

/**
  * Translate flags of mode 't' into their string representations.
  *
  * NOTE: the buffer must be able to accomodate a string of MAX_FLAGS length.
  * Return: the number of characters copied (but not including the terminating NIL)
  */
size_t	server_info::str_flags(chan_mode t, mode_flag_t flags, char * buf) const
{
	const char * modes = get_modes_ptr(t);
	if (modes == NULL) {
		// shouldn't happen
		*buf = 0;
		return 0;
	}

	unsigned len;
	const char * end = strchr(modes, ',');
	if (end != NULL) {
		len = end - modes;
	}
	else {
		len = strlen(modes);
	}
	len = std::min(len, (unsigned) server_info::MAX_FLAGS); 
	
	// now assemble the string
	size_t copied = 0;
	mode_flag_t flag = 1;

	for (unsigned j = 0; j < len; ++j, flag<<=1) {
		if (flags & flag) {
			*buf++ = modes[j];
			++copied;
		}
	}
	*buf = 0;
	return copied;
}

/**
  * NOTE: the buffer must be able to accomodate a string of MAX_FLAGS length.
  * Return: the number of characters copied (but not including the terminating NUL)
  */
size_t server_info::str_prefix_symbols(mode_flag_t i, char *buf) const
{
       unsigned num = std::min(num_prefix_symbols(), MAX_FLAGS);
       mode_flag_t flag = 1;
       size_t copied = 0;

       for (unsigned j = 0; j < num; ++j, flag<<=1) {
               if (i & flag) {
                       *buf++ = strings[PREFIX_SYMBOL_LIST][j];
                       ++copied;
               }
       }
       *buf = 0;
       return copied;
}

/**
  * Returns pointer to string without the leading nickname prefix symbols.
  */
const char * server_info::strip_prefix_symbols(const char * buf,
						mode_flag_t * what) const
{
	assert(buf);
	mode_flag_t codes = 0;
	while (is_prefix_symbol(*buf)) {
		codes |= prefix_symbol_to_flag(*buf++);
	}
	if (what) {
		*what = codes;
	}
	return buf;
}

/**
 * Check if a channel name is legal.
 * TODO: perform additional checks. RFC says:
 * 	'any octet except NUL, BELL, CR, LF, " ", "," and ":"'
 * 	(but most servers permit the ':')
 */
bool server_info::is_channel(const char * str) const 
{
	return is_channel_prefix(str[0]); 
}

//--------------------------------------------------
// /* static */ const char * server_info::str_casemapping(casemapping_t m) 
// {
// 	switch (m) {
// 	case ASCII:
// 		return "ascii";
// 	case RFC1459:
// 		return "rfc1459";
// 	case STRICT_RFC1459:
// 		return "strict-rfc1459";
// 	}
// 	
// 	// should never happen.
// 	assert(false);
// 	return "Unknown";
// }
//-------------------------------------------------- 

} // namespace irc
