/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/other.cc
 * (C) 2001-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <list>
#include <algorithm>
#include <functional>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <unistd.h>
#include <sys/time.h>
#include <sys/utsname.h>
#include <sys/resource.h>
#include "util/generic.h"
#include "util/strings.h"
#include "util/iterators.h"
#include "util/tracked_object.h"
#include "util/counted_object.h"
#include "util/timer.h"
#include "config/node_searcher.h"
#include "io/error.h"
#include "irc/address.h"
#include "irc/cache.h"
#include "irc/server_info.h"
#include "fs/file_system.h"
#include "fs/directory.h"
#include "fs/key.h"
#include "logging/chatlog.h"
#include "net/types.h"
#include "commands.h"
#include "textline.h"
#include "proxy.h"
#include "ruleset.h"
#include "conn.h"
#include "messages.h"
#include "user.h"
#include "dcc.h"
#include "dcc_offer.h"
#include "ezbounce.h"
#include "debug.h"

using std::list;
using std::string;
using std::vector;
using irc::cache_entry;
using irc::channel;
using irc::server_info;

using namespace util::strings;

#ifdef __DEBUG__
CMDFUNC(zombify) 
{
	die(0, "ZOMBIFY command issued");
	return 1;
}

CMDFUNC(debug)
{
	cprintf("*** Debug information ***\r\n");
	cprintf("\002Object counts\002\r\n");
	cprintf("conn..........: %zu\r\n", conn::count());
	cprintf("dcc...........: %zu\r\n", dcc::count());
	cprintf("dcc_offer.....: %zu\r\n", dcc_offer::count());
	cprintf("userdef.......: %zu\r\n", userdef::count());
	cprintf("ruleset.......: %zu\r\n", ruleset::count());
	cprintf("timer.........: %zu\r\n", util::timer::count());
	cprintf("file_entry....: %zu\r\n", fs::file_entry::count());
	cprintf("flib_key......: %zu\r\n", fs::flib_key::count());
	cprintf("directory.....: %zu\r\n", fs::directory::count());
	cprintf("\r\n");
	cprintf("\002Buffer sizes\002\r\n");
	cprintf("client: incoming: %zu allocated: %zu\r\n", client->get_ibuff().size(), 
								client->get_ibuff().capacity());
	cprintf("client: outgoing: %zu allocated: %zu\r\n", client->get_obuff().size(), 
								client->get_obuff().capacity());
	if (is_bounced()) {
		cprintf("server: incoming: %zu allocated: %zu\r\n", server->get_ibuff().size(), 
								server->get_ibuff().capacity());
		cprintf("server: outgoing: %zu allocated: %zu\r\n", server->get_obuff().size(), 
								server->get_obuff().capacity());
	}
	return 1;
}

CMDFUNC(reconnect)
{
	cprintf("OK, faking disconnection\r\n");
	if (is_reconnecting()) {
		cprintf("NOTE: Reconnect was already in progress ...\r\n");
	}
	on_server_disconnect(io::READ_ERROR);
	return 1;
}
#endif


/**
 * ezb command handler.
 * bump up the pointer and call the lookup function
 * again. we do a few checks on the result afterwards.. 
 */
CMDFUNC(ezb)
{
	int r = 0;

	if (args == 0) {
		cprintf("EZB: usage `/quote ezb <command> [args]'\r\n");
		return 1;
	}

	const struct cmd * c = lookup_command(cmdhash, args[0], stat);

	if (!c)	{
		cprintf("EZB: bad or unknown command\r\n");
		return 1;
	}
	else {
		/* Special commands we should be aware of.. prevent double ezbounce command
		 * and don't engage the privmsg handler */
		switch (c->id) {
		case CMD_EZBOUNCE:
		case CMD_PRIVMSG:
			cprintf("EZB: Hey! Cannot use %s command with 'ezb' command!\r\n", c->msg);
			return 1;
		case CMD_QUIT:
			/* EZB QUIT: Force disconnection from server */
			/* When auto-detach enabled, use this to send quit
			   to IRC server */
			server->printf("QUIT :%s\r\n", args.get_rest(1));
			return 1;
		}
		/* just call the handler then */
		textline new_args( args.get_rest(1) );
		DEBUG("       ###### HANDLER: %s(%d, %s)\n", c->msg, c->id, new_args.all());
		r = (this->*(c->handler))(c->id, new_args);
		return r;
	}
	return 1;
}

/**
 * Help system
 */
CMDFUNC(help)
{
	if (args == 0) {
		cprintf_multiline(__HELP_ENTRY(command_list));
		return 1;
	}

	// Check for 'help option <option name>'
	if (strcasecmp(args[0], "option") == 0) {
		using config::hash_entry;
		using config::node_searcher;
		if (args < 2) {
			cprintf("HELP: try 'help option <option name>'\r\n");
			cprintf("HELP: for a list of options try 'options'\r\n");
			return 1;
		}
		const hash_entry * h = node_searcher<user_config_root>::lookup_option(args[1]);
		if (h == NULL) {
			cprintf("HELP: no such option '%s'\r\n", args[1]);
			return 1;
		}
		cprintf("option name..: '%s'\r\n", h->item->name);
		cprintf("       level.: %s\r\n", node_searcher<user_config_root>::lookup_id(h->level));
		cprintf("       type..: %s\r\n", config::stroption(h->type));
		cprintf("       info..: %s\r\n", h->item->desc);

		return 1;
	}

	// Other entries
	help_hash_table_t::const_iterator i = help_table.find(args[0]);
	if (i != help_table.end()) {
		cprintf_multiline((*i).second);
		return 1;
	}

	cprintf("HELP: no help found for `%s'\r\n", args[0]);
	return 1;
}

/**
  * Display Message of the Day 
  */
CMDFUNC(motd)
{
	show_motd();
	return 1;
}

/**
 * Dump information about the proxy
 */
CMDFUNC(status)
{
	string uptime;
	string ts;

	duration(uptime, proxy->time() - proxy->start_time(), true);
	timestamp_full(ts);

	cprintf(MSG_STATUS_UPTIME, ts.c_str(), uptime.c_str());

#ifdef HAVE_GETRUSAGE
	struct rusage ru;
	char buff[100];
	getrusage(RUSAGE_SELF, &ru);
	time_t mins = (int) ((ru.ru_utime.tv_sec + ru.ru_stime.tv_sec) / 60);
	time_t secs = (int) ((ru.ru_utime.tv_sec + ru.ru_stime.tv_sec) - (mins * 60));
	snprintf(buff, sizeof buff, "%02d%c%02d%c", (int) mins, 'm', (int) secs, 's');
	cprintf(MSG_STATUS_CPUTIME, buff);
#endif

	if (is_admin()) {
		cprintf("Active Connections:    %d\r\n", conn::count());
		cprintf("  |--> Timers:         %d\r\n", util::timer::count());
		cprintf("  |--> Sockets:        %d\r\n", -1);
		cprintf("  |--> DCCs:           %d   Offers: %d\r\n", dcc::count(), dcc_offer::count());
		cprintf("  \\--> File pointers:  %d   Keys: %d\r\n", fs::file_entry::count(), 
									fs::flib_key::count());
		cprintf("Listing all connections ...\r\n");
	} 
	else {
		cprintf("Listing connections for user `%s'\r\n", user()->name());
	}

	client->printf(MSG_STATUS_LISTHEADER, irc->nick());

	const std::list<conn *>& conn_list = proxy->conn_list();
	for (std::list<conn *>::const_iterator i = conn_list.begin(),
						e = conn_list.end(); 
						i != e; 
						++i) {	   
		conn * c = *i;
		if (!is_admin() && (c->user() == NULL || 
					userdef::namecmp(c->user()->name(), user()->name()) )) {		 
			continue;
		}
		char str_stat[9] = "?";
		string u_name;
		
		c->mkstat(str_stat);
		duration(ts, proxy->time() - c->connect_time, false);
		if (c->user()) {
			u_name = c->user()->name();
			u_name.resize(10);
		}
		else {
			u_name = "(none)";
		}

		/* ":" "info!ezb" " NOTICE %s :ID    TIME  NICK       FROM         TO             STAT           VHOST\n"; */
		client->printf(":%s NOTICE %s :%-6d", EZBOUNCE_HEADER, irc->nick(), c->id());
		client->printf("%-6s",   ts.c_str());
		client->printf("%-10s ", u_name.c_str());
		client->printf("%-15s ", c->client ? c->client->peer_addr() : "(n/a)");
		client->printf("%-15s ", c->server ? c->server->peer_addr() : "(n/a)");
		client->printf("%-9s\r\n",   str_stat);
		client->flushO();
	}
	return 1;
}

/**
  * Checks cache for address of a nick.
  */
CMDFUNC(acache)
{
	if (args < 1) {
		cprintf("acache: please provide a nickname to look up\r\n");
		return 1;
	}
        cache_entry * e = acache->lookup_nick(args[0]);

	if (!e) {
	        cprintf("acache: nickname not found\r\n");
                return 1;
        }

	if (e) {
        	cprintf("Lookup returns: %s!%s@%s\r\n", e->nick(), e->user(), e->host());
        	cprintf("    on channels: %d\r\n", e->references().size());
		std::list<channel *>::const_iterator beg = e->references().begin(),
						end = e->references().end();
		for (; beg != end; ++beg) {
			char mode_buffer[server_info::MAX_FLAGS+1];
			channel * c = *beg;
			servinfo->str_prefix_symbols(c->nick_flags(e), mode_buffer);
	                cprintf("    on channel: %s [mode: %s]\r\n", c->name(), mode_buffer);
		}
	        return 1;
        }
	return 1;
}

/**
  * Display basic information about the server retrieved from numeric 005 parsing.
  */
CMDFUNC(servinfo) 
{
	if (servinfo == NULL) {
		// XXX: really necessary?
		cprintf("servinfo: No server information received yet!\r\n");
		return 1;
	}

	cprintf("server name.......: %s\r\n", servinfo->name());
	cprintf("       network....: %s\r\n", servinfo->network());
	cprintf("       version....: %s\r\n", servinfo->version());
	cprintf("       created....: %s\r\n", servinfo->created());
	cprintf("       modes......: %s\r\n", servinfo->modes());
	cprintf("       nick modes.: %s [%s]\r\n", servinfo->prefix_symbols(), servinfo->prefix_modes());
	cprintf("       casemapping: %s\r\n", servinfo->casemapping_name());

	// logging information	
	const bool want_private_logging = decide<server_node>(get_server_target(), irc_server_config::LOG_PRIVATE) == 1;
	if (want_private_logging) {
		if (priv_log != NULL) {
			const string& logname = priv_log->filename();
			cprintf("       message log: %s\r\n", logname.c_str());
		}
		else {
			cprintf("       message log: failed during setup\r\n");
		}
	}
	else {
		cprintf("       logging....: disabled\r\n");
	}
	return 1;
}

/**
 * Display information about channels seen, or about a specific channel.
 */
CMDFUNC(chaninfo)
{
	using logging::chatlog;
	if (args < 1) {
		if (acache->num_channels() == 0) {
			cprintf("chaninfo: you don't appear to be on any channels ...\r\n");
			return 1;
		}

		std::string channels;
		util::print_into(make_value_iterator(acache->channels_begin()), 
					make_value_iterator(acache->channels_end()), channels, ", ", NULL);
		cprintf("chaninfo: %zd channels seen: %s\r\n", acache->num_channels(), channels.c_str());
		return 1;
	}

	channel * c = acache->lookup_channel(args[0]);
	if (c == NULL) {
		cprintf("chaninfo: channel '%s' not found in cache\r\n", args[0]);
		return 1;
	}

	std::string mode;
	c->get_all_modes(servinfo, mode);
	cprintf("channel name.....: %s\r\n", c->name());
	cprintf("        users....: %d\r\n", c->population());
	cprintf("        mode.....: %s\r\n", mode.c_str());
	
	if (c->has_topic()) {
		cprintf("        topic....: %s\r\n", c->topic());
		cprintf("        set by...: %s at %s\r\n", c->topic_setter(), c->topic_time());
	}

	// logging information
	if (c->is_logging()) {
		chatlog * log = c->get_chatlog();
		if (log == NULL) {
			log = chan_log;
		}
	
		// still NULL?  this should only happen if log setup failed
		// TODO: should is_logging() be false in this case?
		if (log == NULL) {
			cprintf("        log......: %s\r\n", "failed during setup");
		}
		else {
			const std::string& logname = log->filename();
			cprintf("        log......: %s\r\n", logname.c_str());
		}
	}		
	else {
		const config::target_list& target = c->channel_target();
		const bool want_chan_detached_only = decide<channel_node>(target, irc_channel_config::LOG_DETACHED_ONLY) == 1;
		if (want_chan_detached_only) {
			cprintf("        logging..: only while detached\r\n");
		}
		else {
			cprintf("        logging..: disabled\r\n");
		}		
	}
	return 1;
}

CMDFUNC(traffic)
{
	string ts;
	timestamp_full(ts);
	cprintf("ezbounce traffic stats @ %s\r\n", ts.c_str());
	cprintf("clients ---> ezbounce          : %.2f K\r\n", (float)bytes_fromc / 1024);
	cprintf("             ezbounce ---> IRC : %.2f K\r\n", (float)bytes_tos / 1024);
	cprintf("             ezbounce <--- IRC : %.2f K\r\n", (float)bytes_froms / 1024);
	cprintf("clients <--- ezbounce          : %.2f K\r\n", (float)bytes_toc / 1024);

	return 1;
}


CMDFUNC(echo)
{
	if (args > 0) {
		client->printf(":%s\r\n", args.all());
	}
	return 1;
}

/*
 * This thing is spiffy.
 */
CMDFUNC(trace)
{
	char addrs[4][net::MAX_ADDRSTRLEN+7] = 
		{"client is detached",
		"",
		"",
		"  not connected"};
	
	conn * c = this;

	if (args > 0 && is_admin()) {
		c = conn::lookup(args[0]);
		if (!c)	{
			cprintf("TRACE: can't find user id %s\r\n", args[0]);
			return 1;
		} 
		else if (c->is_dead()) {
			cprintf("TRACE: can't trace id %s: zombie connection\r\n", args[0]);
			return 1;
		} 
		else if (!c->user()) {
			cprintf("TRACE: can't trace id %s: not yet logged in\r\n", args[0]);
		}
	}

	cprintf("Showing network info for connection id %d (%s)\r\n", c->id(), c->user()->name());
	
	if (c->client) {
		sprintf(addrs[0], "%s:%u", c->client->peer_addr(), c->client->peer_port());
		sprintf(addrs[1], "%s:%u", c->client->local_addr(), c->client->local_port());
	}
	if (c->server) {
		sprintf(addrs[2], "%s:%u", c->server->local_addr(), c->server->local_port());
		sprintf(addrs[3], "%s:%u", c->server->peer_addr(), c->server->peer_port());
	}
	
	cprintf(" ________________________\r\n");
	cprintf(" [%-22s]\r\n", (c->client) ? c->user()->name() : "this");
	cprintf(" [%-22s]\r\n", addrs[0]);
	cprintf(" \\______________________/\r\n");
	cprintf("         ^\r\n");
	cprintf("         |\r\n");
	cprintf("         |      /----------------------\\\r\n");
	cprintf("         \\----->[%22s]\r\n", addrs[1]);
	cprintf("                [\002%22s\002]\r\n", "ezbounce");
	cprintf("                [%22s]\r\n", EZBOUNCE_VERSION);
	if (c->server) {
		cprintf("                [%22s]\r\n", addrs[2]);
	}
	cprintf("                \\----------------------/\r\n");
	cprintf("                          ^\r\n");
	cprintf("                          |\r\n");
	cprintf("                          |\r\n");
	cprintf("                          \\----->[%22s]\r\n", addrs[3]);
	if (c->server) {
		cprintf("                                 [%22s]\r\n", c->irc->nick());
		cprintf("                                 [                      ]\r\n");
		cprintf("                                 [%22s]\r\n", c->servinfo->name());
		cprintf("                                 [%22s]\r\n", c->servinfo->version());
	}
	return 1;
}

CMDFUNC(about)
{
	struct utsname uts;
	memset(&uts, 0, sizeof(uts));
	uname(&uts);
	cprintf("This is \002%s\002 [built " __DATE__ " " __TIME__ "]\r\n", EZBOUNCE_VERSION);
	cprintf("Running on: %s %s\r\n", uts.sysname, uts.release);
	cprintf("   Visit the ezbounce web site at http://www.ezbounce.net/\r\n");
	return 1;
}

CMDFUNC(version)
{
	cprintf("%s\r\n", EZBOUNCE_VERSION);
	return 1;
}
