/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/log.cc
 * (c) 2007 Murat Deligonul
 */

#include "autoconf.h"

#include "conn.h"
#include "commands.h"
#include "textline.h"
#include "proxy.h"
#include "messages.h"
#include "debug.h"

using std::list;
using std::vector;


/**
 * The LOG command: no longer big and ugly, but still displays some useful information
 * and provides help if an obsolete option is used.
 */
CMDFUNC(log)
{
	if (!is_allowed(user_perms::ENABLE_CHAT_LOGGING)) {
		cprintf("LOG: Sorry, you are not allowed to use the chat logging system\r\n");
		return 1;
	}

	if (!proxy->has_vfs()) {
		cprintf("LOG: Cannot log; no VFS is available\r\n");
		return 1;
	}

	if (args.empty()) {
		cprintf(MSG_INSUFFICIENT_ARGS, "LOG");
		return 1;
	}

	const char * cmd = args[0];

	if (strcasecmp(cmd, "STATUS") == 0) {
		cprintf("FIXME: implement this command\r\n");
	}
	else if (strcasecmp(cmd, "SET") == 0) {
		cprintf("LOG: 'log set' is now obsolete\r\n");
		cprintf("LOG: Try 'help logging' to learn about using the chat logging system\r\n");
	}
	else if (strcasecmp(cmd, "HELP") == 0) {
		cprintf_multiline(__HELP_ENTRY(log));
	}
	else {
		cprintf("LOG: Unknown command '%s'\r\n", cmd);
		cprintf("LOG: Try 'help log'\r\n");
	}
	return 1;
}

