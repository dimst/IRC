/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/table.cc
 * (c) 2006 Murat Deligonul
 */

#include "autoconf.h"

#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include "util/strings.h"
#include "util/hash.h"
#include "config/node_searcher.h"
#include "commands.h"
#include "conn.h"
#include "messages.h"
#include "debug.h"

using std::list;
using std::string;
using std::vector;

/**
 * The NDMs are No Direct Match (when Connected).
 * 'ezb' command is directly matched when connected.
 * the other commands are not.
 *
 * PPE = hack to make sure Ping/pong/error don't match
 * on initial command scan
 */
const struct cmd command_table[] = {
    /* str          int-id        req_flag                                 bad_flag                       handler               help */
    /* -------------------------------------------------------------------------------------------------------------------------------------------*/
    { "USER",       CMD_USER,       0,                            NDM | USERED | CONNECTING,	&conn::do_registration_cmd,   __HELP_ENTRY(user)},
    { "NICK",       CMD_NICK,       0,                            NDM | CONNECTING | BOUNCED,	&conn::do_registration_cmd,   __HELP_ENTRY(nick)},
    { "PASS",       CMD_PASS,       0,                            NDM | LOGGED_IN | CONNECTING, &conn::do_login_cmd,          __HELP_ENTRY(pass)},
    { "LOGIN",      CMD_LOGIN,      0,                            NDM | LOGGED_IN | CONNECTING, &conn::do_login_cmd,          __HELP_ENTRY(login)},
    { "CONN",       CMD_CONN,       REGISTERED,                   BOUNCED | CONNECTING,		&conn::do_conn_cmd,           __HELP_ENTRY(conn)},
    { "CANCEL" ,    CMD_CANCEL,     REGISTERED, 	 	  NDM,				&conn::do_cancel_cmd,         __HELP_ENTRY(cancel)},
    { "IDENT",      CMD_IDENT,      REGISTERED,                   NDM | CONNECTING,		&conn::do_ident_cmd,          __HELP_ENTRY(ident)},
    { "MOTD",       CMD_MOTD,       REGISTERED,                   NDM | CONNECTING,		&conn::do_motd_cmd,           __HELP_ENTRY(motd)},
    { "HELP",       CMD_HELP,       REGISTERED,                   NDM | CONNECTING,		&conn::do_help_cmd,           __HELP_ENTRY(help)},

    { "INTERFACE",  CMD_INTERFACE,  REGISTERED,                   BOUNCED | CONNECTING,       &conn::do_vhost_cmd,          __HELP_ENTRY(vhost)},
    { "VHOST",      CMD_INTERFACE,  REGISTERED,                   BOUNCED | CONNECTING,       &conn::do_vhost_cmd,          __HELP_ENTRY(vhost)},
    { "VHOSTS",     CMD_VHOSTS,     REGISTERED,                   NDM | CONNECTING,           &conn::do_vhosts_cmd,         __HELP_ENTRY(vhosts)},

    { "DETACH",     CMD_DETACH,     REGISTERED,                   NDM | DETACHED | CONNECTING,&conn::do_detach_cmd,         __HELP_ENTRY(detach)},
    { "REATTACH",   CMD_REATTACH,   REGISTERED,                   NDM | CONNECTING,           &conn::do_reattach_cmd,       __HELP_ENTRY(reattach)},
    { "ATTACH",     CMD_REATTACH,   REGISTERED,                   NDM | CONNECTING,           &conn::do_reattach_cmd,       __HELP_ENTRY(reattach)},
    { "DISCONNECT", CMD_DISCONNECT, REGISTERED | BOUNCED,         NDM | CONNECTING,           &conn::do_disconnect_cmd,     __HELP_ENTRY(disconnect)},
    { "LOG",        CMD_LOG,        REGISTERED,                   NDM | CONNECTING,           &conn::do_log_cmd,            __HELP_ENTRY(log)},

    { "SESSIONS",   CMD_SESSIONS,   REGISTERED,                   CONNECTING,                 &conn::do_sessions_cmd,       __HELP_ENTRY(sessions)},
    { "TRAFFIC",    CMD_TRAFFIC,    REGISTERED,                   NDM | CONNECTING,           &conn::do_traffic_cmd,        __HELP_ENTRY(traffic)},
    { "TRACE",      CMD_TRACE,      REGISTERED,           	  NDM | CONNECTING,           &conn::do_trace_cmd,          __HELP_ENTRY(trace)},
    { "SET",	    CMD_SET,	    REGISTERED,			  NDM | CONNECTING,	      &conn::do_set_cmd,            __HELP_ENTRY(set)},
    { "GET",	    CMD_GET,	    REGISTERED,			  NDM | CONNECTING,	      &conn::do_get_cmd,            __HELP_ENTRY(get)},
    { "UNSET",	    CMD_UNSET,	    REGISTERED,			  NDM | CONNECTING,	      &conn::do_unset_cmd,          __HELP_ENTRY(unset)},
    { "ISSET",	    CMD_ISSET,	    REGISTERED,			  NDM | CONNECTING,	      &conn::do_isset_cmd,          __HELP_ENTRY(isset)},
    { "PREFS",	    CMD_PREFS,	    REGISTERED,			  NDM | CONNECTING,	      &conn::do_prefs_cmd,          __HELP_ENTRY(prefs)},
    { "PREFERENCES",CMD_PREFS,	    REGISTERED,			  NDM | CONNECTING,	      &conn::do_prefs_cmd,          __HELP_ENTRY(prefs)},
    { "OPTIONS",    CMD_OPTIONS,    REGISTERED,			  NDM | CONNECTING,	      &conn::do_options_cmd,          __HELP_ENTRY(options)},
    { "ECHO",	    CMD_ECHO,	    REGISTERED,			  NDM,                        &conn::do_echo_cmd,           __HELP_ENTRY(echo)},
    { "ALLOWED",    CMD_ALLOWED,    REGISTERED,                   NDM | CONNECTING,           &conn::do_allowed_cmd,        __HELP_ENTRY(allowed)},
    { "VERSION",    CMD_VERSION,    REGISTERED,                   NDM | CONNECTING,           &conn::do_version_cmd,        __HELP_ENTRY(version)},
    { "ABOUT",      CMD_ABOUT,      REGISTERED,                   NDM | CONNECTING,           &conn::do_about_cmd,          __HELP_ENTRY(about)},

    { "EZBOUNCE",   CMD_EZBOUNCE,   REGISTERED,                   CONNECTING,                 &conn::do_ezb_cmd,            __HELP_ENTRY(ezbounce)},
    { "EZB",        CMD_EZBOUNCE,   REGISTERED,                   CONNECTING,                 &conn::do_ezb_cmd,            __HELP_ENTRY(ezbounce)},
    { "QUIT",       CMD_QUIT,       REGISTERED | BOUNCED,         CONNECTING,                 &conn::do_quit_cmd,           __HELP_ENTRY(quit)},
    { "PRIVMSG",    CMD_PRIVMSG,    REGISTERED,                   CONNECTING,                 &conn::do_privmsg_cmd,        NULL},
    { "NOTICE",	    CMD_NOTICE,	    REGISTERED | BOUNCED,	  CONNECTING,		      &conn::do_notice_cmd,	    NULL},
    { "PROTOCTL",   CMD_PROTOCTL,   REGISTERED | BOUNCED,	  CONNECTING,		      &conn::do_protoctl_cmd,	    NULL},
    { "CAP",	    CMD_CAP,	    REGISTERED | BOUNCED,	  CONNECTING,		      &conn::do_cap_cmd,	    NULL},

    { "STATUS",     CMD_STATUS,     REGISTERED,                   NDM | CONNECTING,           &conn::do_status_cmd,         __HELP_ENTRY(status)},
    { "SAVE",       CMD_SAVE,       REGISTERED | ADMIN,           NDM | CONNECTING,           &conn::do_save_cmd,           __HELP_ENTRY(save)},
    { "REHASH",     CMD_REHASH,     REGISTERED | ADMIN,           NDM | CONNECTING,           &conn::do_rehash_cmd,         __HELP_ENTRY(rehash)},
    { "WRITE",      CMD_WRITE,      REGISTERED | ADMIN,           NDM | CONNECTING,           &conn::do_write_cmd,          __HELP_ENTRY(write)},
    { "HASH",       CMD_HASH,       REGISTERED | ADMIN,           NDM | CONNECTING,           &conn::do_hash_cmd,           __HELP_ENTRY(hash)},
    { "DIE" ,       CMD_DIE,        REGISTERED | ADMIN,           NDM | CONNECTING,           &conn::do_die_cmd,            __HELP_ENTRY(die)},
    { "DIENOW",     CMD_DIENOW,     REGISTERED | ADMIN,           NDM | CONNECTING,           &conn::do_die_cmd,            __HELP_ENTRY(dienow)},
    { "WHOIS",      CMD_WHOIS,      REGISTERED | ADMIN,           NDM | CONNECTING,           &conn::do_whois_cmd,          __HELP_ENTRY(whois)},
    { "RELOAD",     CMD_RELOAD,     REGISTERED | ADMIN,           NDM | CONNECTING,           &conn::do_reload_cmd,         __HELP_ENTRY(reload)},
    { "FILE",       CMD_FILE,       REGISTERED,                   NDM | CONNECTING,           &conn::do_file_cmd,           __HELP_ENTRY(file)},
    { "DCC",        CMD_DCC,        REGISTERED,                   NDM | CONNECTING,           &conn::do_dcc_cmd,            __HELP_ENTRY(dcc)},
    { "WHO",        CMD_WHO,        REGISTERED | BOUNCED,         CONNECTING,                 &conn::do_who_cmd,            NULL},
    { "MODE",       CMD_MODE,       REGISTERED | BOUNCED,         CONNECTING,                 &conn::do_mode_cmd,           NULL},
    { "KILL",       CMD_KILL,       REGISTERED,                   NDM | CONNECTING,           &conn::do_kill_cmd,           __HELP_ENTRY(kill)},
    { "ACACHE",     CMD_ACACHE,     REGISTERED | BOUNCED,         NDM,                        &conn::do_acache_cmd,         NULL},
    { "SERVINFO",   CMD_SERVINFO,   REGISTERED | BOUNCED,	  NDM,			      &conn::do_servinfo_cmd,	    __HELP_ENTRY(servinfo)},
    { "CHANINFO",   CMD_CHANINFO,   REGISTERED | BOUNCED,         NDM,			      &conn::do_chaninfo_cmd,       __HELP_ENTRY(chaninfo)},
#ifdef __DEBUG__
    { "ZOMBIFY",    CMD_ZOMBIFY,    REGISTERED,                   NDM,                        &conn::do_zombify_cmd,        NULL},
    { "RECONNECT",  CMD_RECONNECT,  REGISTERED | BOUNCED,         NDM,                        &conn::do_reconnect_cmd,      NULL},
    { "DEBUG",      CMD_DEBUG,      REGISTERED,                   NDM,                        &conn::do_debug_cmd,          __HELP_ENTRY(debug)}
#endif
};

/**
 * Command table for incoming traps.
 */
const struct cmd incoming_command_table[] = {
	{"PRIVMSG",     INCOMING_PRIVMSG,           0,                  0,              &conn::do_privmsg_incoming_cmd},
	{"NICK",        INCOMING_NICK,              0,                  0,              &conn::do_nick_incoming_cmd},
	{"MODE",        INCOMING_MODE,              0,                  0,              &conn::do_mode_incoming_cmd},
	{"JOIN",        INCOMING_JOIN,              0,                  0,              &conn::do_join_incoming_cmd},
	{"PART",        INCOMING_PART,              0,                  0,              &conn::do_part_incoming_cmd},
	{"KICK",        INCOMING_KICK,              0,                  0,              &conn::do_kick_incoming_cmd},
	{"TOPIC",       INCOMING_TOPIC,             0,		        0,              &conn::do_topic_incoming_cmd},
	{"NOTICE",      INCOMING_NOTICE,            0,           	0,              &conn::do_notice_incoming_cmd},
	{"QUIT",        INCOMING_QUIT,              0,                  0,              &conn::do_quit_incoming_cmd},
	{"003",         INCOMING_003,               0,                  0,              &conn::do_servinfo_incoming_cmd},
	{"004",         INCOMING_004,               0,                  0,              &conn::do_servinfo_incoming_cmd},
	{"005",         INCOMING_005,               0,                  0,              &conn::do_servinfo_incoming_cmd},
	{"PONG",        INCOMING_PONG,              0,                  0,              &conn::do_pong_incoming_cmd},
	{"PING",        INCOMING_PING,              PPE,                0,              &conn::do_ping_incoming_cmd},
	{"ERROR",       INCOMING_ERROR,             DETACHED | PPE,     0,              &conn::do_error_incoming_cmd},
	{"353",	 	INCOMING_353,		    0,		    	0,		&conn::do_names_incoming_cmd},
	{"366",	    	INCOMING_366,		    0,		    	0,		&conn::do_names_incoming_cmd},
	{"352",         INCOMING_352,		    0,	            	0,		&conn::do_who_incoming_cmd},
	{"315",	    	INCOMING_315,		    0,		    	0,		&conn::do_who_incoming_cmd},
	{"332",	    	INCOMING_332,		    0,		    	0,		&conn::do_topic_incoming_cmd},
	{"333",	    	INCOMING_333,		    0,		    	0,		&conn::do_topic_info_incoming_cmd},
	{"324",		INCOMING_324,		    0,			0,		&conn::do_mode_incoming_cmd},

	{"001",		INCOMING_001,		RECONNECTING,		0, 		&conn::do_001_incoming_cmd},	
	{"432",		INCOMING_432,		RECONNECTING,		0,		&conn::do_nick_failed_incoming_cmd},
	{"433",		INCOMING_433,		RECONNECTING,		0,		&conn::do_nick_failed_incoming_cmd},
	{"403",		INCOMING_403,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd},
	{"405",		INCOMING_405,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd},
	{"470",		INCOMING_470,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd},
	{"471",		INCOMING_471,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd},
	{"473",		INCOMING_473,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd},
	{"474",		INCOMING_474,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd},
	{"475",		INCOMING_475,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd},
	{"477",		INCOMING_477,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd},
	{"479",		INCOMING_479,		RECONNECTING,		0,		&conn::do_join_failed_incoming_cmd}
};

/**
  * Table for any additional help entries.
  */
/* static */ const char * conn::extra_help_entries[] = {
	"testing", 		"a dummy help entry",
	"config",		__HELP_ENTRY(config),
	"logging",		__HELP_ENTRY(logging),
	"vfs", 			__HELP_ENTRY(vfs),
	"reconnecting",		__HELP_ENTRY(reconnection),
	"reconnection",		__HELP_ENTRY(reconnection),
};

/* static */ void conn::init_command_hash()
{
	const size_t size = sizeof(command_table) / sizeof(struct cmd);
	for (unsigned i = 0; i < size; ++i) {
		cmdhash.insert(command_table[i].msg, &command_table[i]);
	}

	const size_t size2 = sizeof(incoming_command_table) / sizeof(struct cmd);
	for (unsigned i = 0; i < size2; ++i) {
		incoming_hash.insert(incoming_command_table[i].msg, &incoming_command_table[i]);
	}
}

/* static */ void conn::init_help_system() 
{
	const size_t size = sizeof(command_table) / sizeof(struct cmd);
	for (unsigned i = 0; i < size; ++i) {
		const char * help_msg = command_table[i].help;
		if (help_msg != NULL) {
			help_table.insert(command_table[i].msg, help_msg);
		}
	}

	// Add other entries
	const size_t size2 = sizeof(extra_help_entries) / sizeof(const char *);
	for (unsigned i = 0; i + 1 < size2; i+= 2) {
		assert(!help_table.contains(extra_help_entries[i]));
		help_table.insert(extra_help_entries[i], extra_help_entries[i+1]);
	}

	// Set up config variable lookup
	config::node_searcher<user_config_root>::populate_table();
}


/**
 * Note: str must be capitalized.
 * FIXME: dunno if that's even true anymore.
 */
const struct cmd * conn::lookup_command(hash_table_t& table,
					const char * str,
					int flags)
{
	hash_table_t::const_iterator i = table.find(str);
	if (i != table.end()) {
		const struct cmd * c = (*i).second;
		/* No required flags for this command or we meet all required flags */
		if (((flags & c->req_flags) == c->req_flags) || (!c->req_flags)) {
			/* Check that we don't have any of the bad flags */
			if (!c->bad_flags ||
					!((flags & c->bad_flags) & c->bad_flags)) {
				/* Found it */
				return c;
			}
		}
	}
	return 0;
}
