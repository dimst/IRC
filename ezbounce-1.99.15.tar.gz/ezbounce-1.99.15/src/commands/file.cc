/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/file.cc
 * (C) 2006-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <vector>
#include <list>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <unistd.h>
#include <sys/time.h>
#include "util/strings.h"
#include "fs/directory.h"
#include "fs/file_system.h"
#include "fs/utility.h"
#include "fs/entry.h"
#include "fs/error.h"
#include "fs/key.h"
#include "commands.h"
#include "textline.h"
#include "proxy.h"
#include "conn.h"
#include "dcc.h"
#include "messages.h"
#include "user.h"
#include "debug.h"

using std::list;
using std::vector;
using std::string;

using fs::directory;
using fs::entry_data;
using fs::file_entry;
using fs::file_system;
using fs::flib_key;

using namespace util::strings;

CMDFUNC(file)
{
	if (!is_allowed(user_perms::ENABLE_VFS_ACCESS)) {
		cprintf("Sorry, you don't have VFS access.\r\n");
		return 1;
	}
	if (!proxy->has_vfs()) {
		cprintf("No VFS is available.\r\n");
		return 1;
	}
	if (key == NULL) {
		cprintf("error: You don't have a VFS access key.\r\n");
		cprintf("error: You may not have sufficient permission to access the VFS, "
			        "or it may have failed to initialize correctly.\r\n");
		return 1;
	}

	if (args < 1) {
		cprintf("Usage: \002FILE\002 <command> <parameters>\r\n");
		cprintf("Available commands: \r\n");
		cprintf("       ls        info      pwd\r\n");
		cprintf("       cd        mkdir     rmdir\r\n");
		cprintf("       send      get       view\r\n");
		cprintf("       show      help      chattr\r\n");
		cprintf("       chmod     chown     chgrp\r\n");
		cprintf("       rm        desc\r\n");
		cprintf("\r\n");
		cprintf("For more information, try \002file help\002\r\n");
		return 1;
	}

	enum {
		LS = 1, INFO, PWD, CD, MKDIR, RMDIR,
		SEND, GET, VIEW, SHOW, RM,
		DESC, CHMOD, CHOWN, CHATTR, HELP
	};
	
	static const simple_table cmds[] = {
		{ "ls", LS },  		{ "info", INFO},
		{ "list", LS},
		{ "pwd", PWD}, 		{ "cd", CD},
		{ "mkdir", MKDIR}, 	{ "rmdir", RMDIR},
		{ "send", SEND}, 	{ "get", GET},
		{ "view", VIEW},	{ "show", SHOW },	
		{ "rm", RM},		{ "del", RM},		
		{ "desc", DESC},	{ "chmod", CHMOD},
		{ "chown", CHOWN},	{ "chattr", CHATTR},	
		{ "help", HELP}
	};

	int num = simple_table_lookup(args[0], (const simple_table *) &cmds, sizeof(cmds) / sizeof (struct simple_table));
	if (num == -1) {
		cprintf("FILE: Unknown command '%s'\r\n", args[0]);
		return 1;
	}

	file_system * lib = proxy->vfs();
	file_entry * fe = NULL;
	int err = 0;
	string ts;

	switch (num) {
	case LS:
	{
		const char * pattern = (args >= 2) ? args[1] : "*";		
		vector<entry_data> files;
		err = lib->ls(key, pattern, files);

		if (err < 0) {
			goto err_out;
		}

		std::sort(files.begin(), files.end(), fs::sort_normal());
		std::ostringstream out;

		fs::print_full_ls(files, out, "\r\n");
				
		const std::string& str = out.str();
		cprintf("Listing results:\r\n");
		cprintf_multiline(str.c_str());
		cprintf("[%d file(s) found]\r\n", files.size());	
		break;
	} 
	
	case PWD:
		cprintf("pwd: %s\r\n", key->dir()->rel_path());
		break;
		
	case INFO:
		if (args < 2) {
			goto args_out;
		}
		fe = lib->open(key, args[1], O_RDONLY, 0, &err);
		if (fe == NULL) {
			goto err_out;
		}		
	
		timestamp_full(ts, fe->creation());

	        cprintf("---------------------------------------------------------\r\n");
        	cprintf("\002Filename\002:       %s\r\n", fe->name());
		cprintf("\002Location\002:       %s\r\n", fe->dir()->rel_path());
        	cprintf("\002Owner\002:          %s\r\n", fe->owner());
        	cprintf("\002Group\002:          %s\r\n", fe->group());
		cprintf("\002Mode\002:           %.4o\r\n", fe->mode());
	        cprintf("\002Size\002:           %d bytes\r\n", fe->size());
	        cprintf("\002Timestamp\002:      %s\r\n", ts.c_str());
        	cprintf("\002Recv'ed from\002:   %s\r\n", fe->from() ? fe->from() : "(n/a)");
        	cprintf("\002Description\002:    %s\r\n", fe->desc());
	        cprintf("---------------------------------------------------------\r\n");

		lib->close(fe);
		break;
		
	case HELP:
		cprintf_multiline(__HELP_ENTRY(file));
		break;

	case CD:
		if (args < 2) {
			goto args_out;
		}

		err = lib->chdir(key, args[1]);
		if (err < 0) {
			goto err_out;
		}
		cprintf("Changed directory to: %s\r\n", key->dir()->rel_path());
		break;
		
	case RM:
		if (args < 2) {
			goto args_out;
		}

		err = lib->unlink(key, args[1]);
		if (err < 0) {
			goto err_out;
		}

		cprintf("Removed: %s\r\n", args[1]);		
		break;

	case GET:		
	case VIEW:
	case SEND:
	case SHOW:
	{
		/** 
		 * Send/show file.  Available forms:
		 * 	GET <filename>
		 * 	VIEW <filename>
		 * 	SEND [target] <filename>
		 * 	SHOW [target] <filename>
		 *
		 * For commands with optional target, target defaults to ezb user.
		 */
		if (args < 2) {
			goto args_out;
		}

		int file_idx = 1;
		const char * target = NULL;

		// check for target given with SHOW or SEND
		if ((num == SHOW || num == SEND) && args > 2) {
			target = args[1];
			file_idx = 2;
		}

		fe = lib->open(key, args[file_idx], O_RDONLY, 0, &err);
		if (fe == NULL) {
			goto err_out;
		}
		
		bool ischat = (num == VIEW) || (num == SHOW);
		dccsend * d = dcc_send_file(fe, target, (const char *) NULL, ischat);

		if (d == NULL) {
			cprintf("%s: DCC Send of '%s' failed (errno: %s)\r\n", args[1], fe->name(), ::strerror(errno));
			lib->close(fe);
			break;
		}	
		// new dcc automatically added to global list
		break;
	}

	case MKDIR:
		if (args < 2) {
			goto args_out;
		}
		
		directory * d;
	        d = lib->mkdir(key, args[1], 0775, &err);
		if (d == 0) {
			cprintf("ERROR: Unable to create directory '%s': %s\r\n", args[1], fs::strerror(err));
			break;
		}
		cprintf("Created directory '%s'\r\n", args[1]);
		break;
		
	case RMDIR:
		if (args < 2) {
			goto args_out;
		}
		
	        err = lib->rmdir(key, args[1]);
		if (err < 0) {
			cprintf("ERROR: Unable to remove directory '%s': %s\r\n", args[1], fs::strerror(err));
			break;
		}
		cprintf("Removed directory '%s'\r\n", args[1]);
		break;
	
	case CHMOD:
	{
		/**
		 * Standard chmod command.
		 * chmod <permissions> <file>...
		 */
		if (args < 3) {
			goto args_out;
		}

		fs::entry_data data;
		err = lib->stat(key, args[2], data);
		if (err < 0) {
			goto err_out;
		}

		int new_mode = fs::translate_chmod_str(key, &data, args[1]);
		if (new_mode < 0) {
			cprintf("ERROR: Unable to parse permission string '%s'\r\n", args[1]);
			break;
		}

		err = lib->chmod(key, args[2], new_mode);
		if (err < 0) {
			goto err_out;
		}
		cprintf("chmod: new permissions: %.4o\r\n", new_mode);
		break;
	}
			
	default:
		cprintf("ERROR: This command is currently unimplemented.\r\n");
		
		
	}  /* switch */
	return 1;

args_out:
	cprintf("ERROR: %s: insufficient arguments for this command\r\n", args[0]);
	return 1;

err_out:
	cprintf("ERROR: %s: %s\r\n", args[0], fs::strerror(err));
	return 1;
}

