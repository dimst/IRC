/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/preferences.cc
 * (c) 2006-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <list>
#include <algorithm>
#include <functional>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <unistd.h>
#include <sys/time.h>
#include "util/generic.h"
#include "util/strings.h"
#include "config/node_searcher.h"
#include "irc/address.h"
#include "logging/chatlog.h"
#include "commands.h"
#include "conn.h"
#include "textline.h"
#include "messages.h"
#include "proxy.h"
#include "user.h"
#include "debug.h"

using std::list;
using std::string;
using std::vector;

using config::node_searcher;
using namespace util::strings;

/**
 * Dumps list of options for a node class and data type.
 */
template<typename T, typename V> void conn::dump_options(const char * prefix)	
{
	using config::traits;

	if (traits<T,V>::DEFAULTS.SIZE > 0) {
		cprintf("%s\002[%s]\002\r\n", prefix, config::stroption(traits<T,V>::OPTION_TYPE));
		for (unsigned i = 0; i < traits<T,V>::DEFAULTS.SIZE; ++i) {
			cprintf("%s%s\r\n", prefix, traits<T,V>::DEFAULTS.settings[i].info.name);
		}
	}
}

/**
 * Post-processing after using 'set' command.
 * For logging-related options, set logging up once again.
 */
void conn::options_updated(const config::hash_entry * entry)
{
	// TODO: can this really happen?
	if (is_dead()) {
		return;
	}

	bool do_logs = false;

	if (entry->level == channel_node::ID) {
		switch (entry->option) {
		case irc_channel_config::LOG_ALWAYS:
		case irc_channel_config::LOG_OWN_FILE:
		case irc_channel_config::LOG_DETACHED_ONLY:
		case irc_channel_config::LOG_ADDRESSES:
		case irc_channel_config::LOG_TIMESTAMPS:
			do_logs = true;
			break;
		default:
			break;
		}
	}
	else if (entry->level == server_node::ID) {
		switch (entry->option) {
		case irc_server_config::LOG_PRIVATE:
			do_logs = true;
			break;
		default:
			break;
		}
	}

	if (do_logs) {
		// Only need to worry about this if we are connected to a server.
		if (is_bounced()) {
			if (!is_allowed(user_perms::ENABLE_CHAT_LOGGING)) {
				cprintf("NOTE: You are not allowed to use the chat logging system\r\n");
			}
			else {
				cprintf("Updating IRC logging setup ...\r\n");
			}
			setup_irc_logs(IRC_CONNECT);
		}
	}		
}

CMDFUNC(set)
{
	if (args < 2) {
		cprintf("SET: usage: set [target] <preference> <value>\r\n");
		cprintf("SET: for help try 'help set' or 'help config'\r\n");
		return 1;
	}

	// The last argument shall be the value. 
	const char * value = args.back();
	const size_t num = args.num_tokens();

	std::vector<config::parse_token> params;
 
	// Copy params from first till second to last token.
	args.get(params, 0, num-1);

	config::target_list targets;
	const config::hash_entry * entry;

	config::parse_result r = node_searcher<user_config_root>::parse_user_command(
			params, targets, &entry);

	if (r.first != config::SUCCESS) {
		cprintf("Error: Parse error at token: '%s'\r\n", params[r.second]);
		cprintf("Error: %s\r\n", config::strerror(r.first));
		return 1;
	}

	bool b_value = false;
	int i_value = 0;

	bool is_string = (args.get_properties(num-1) & textline::STRING_LITERAL);
	bool is_bool = is_string ? false : check_bool(value, &b_value);
	bool is_int  = is_string ? false : check_int(value, &i_value);
	
	// check for alternate boolean forms
	is_bool = is_bool ? true : check_on_off(value, &b_value);
	
	bool error = false;

	try {
		switch (entry->type) {
		case config::STRING:
			/**
			  * is_string == true isn't necessary, as it's only true for explicit string
			  * literals.  Pretty much everything can be a string actually ..
			  */
			user()->options()->set<string>(targets, entry->option, value);
			break;

		case config::BOOLEAN:
			if (!is_bool) {
				cprintf("Error: the '%s' preference requires a boolean value (true or false)\r\n", entry->item->name);
				error = true;
				break;
			}

			user()->options()->set<bool>(targets, entry->option, b_value);
			break;

		case config::INTEGER:
			if (!is_int) {
				cprintf("Error: the '%s' preference requires an integer value\r\n", entry->item->name);
				error = true;
				break;
			}

			user()->options()->set<int>(targets, entry->option, i_value);
			break;
		
		default:			
			/* Should not happen */
			abort();
		}

		if (!error) {
			cprintf("OK, assigned value '\002%s\002' to preference '%s'\r\n", value, entry->item->name);
			if (!targets.empty()) {
				// generate user friendly target list.
				std::vector<string> friendly;
				string out;
				node_searcher<user_config_root>::generate_user_command(targets, friendly);
				util::print_container(friendly, out, " ", NULL);
				cprintf("Target was: '%s'\r\n", out.c_str());
			}
			user()->options_updated(entry);
		}
	}
	catch (std::exception &e) {
		cprintf("Error occurred while setting preference '%s': %s\r\n", entry->item->name, e.what());	
	}
	return 1;
}

/**
  * 'get' command
  *
  * example: get network EFNet channel #linux auto-rejoin
  */
CMDFUNC(get) 
{
	if (args.empty()) {
		cprintf("GET: usage: get [target] <preference>\r\n");
		cprintf("GET: for help try 'help get' or 'help config'\r\n");
		return 1;
	}

	/**
	  * Get arguments (all of them; no value this time)
	  */
	const size_t num = args.num_tokens();
	vector<config::parse_token> params;
	args.get(params, 0, num);

	config::target_list targets;
	const config::hash_entry * entry;

	config::parse_result r = node_searcher<user_config_root>::parse_user_command(
			params, targets, &entry);

	if (r.first != config::SUCCESS) {
		cprintf("Error: Parse error at token: '%s'\r\n", params[r.second]);
		cprintf("Error: %s\r\n", config::strerror(r.first));
		return 1;
	}
	
	const char * s_value;
	int i_value;
	bool b_value;

	cprintf("Checking value of '%s' ...\r\n", args.all());
	try {
		switch (entry->type) {
		case config::STRING:			
			s_value = user()->options()->get<string>(targets, entry->option).c_str();
			cprintf("Got string value: \"%s\"\r\n", s_value);
			break;

		case config::BOOLEAN:
			b_value = user()->options()->get<bool>(targets, entry->option);
			cprintf("Got boolean value: %s\r\n", true_false(b_value));
			break;

		case config::INTEGER:
			i_value = user()->options()->get<int>(targets, entry->option);
			cprintf("Got integer value: %d\r\n", i_value);
			break;
		
		default:			
			/* Should not happen */
			abort();
		}
	}
	catch (std::exception &e) {
		cprintf("Error reading value: exception '%s'\r\n", e.what());	
	}
	return 1;
}


CMDFUNC(unset) 
{
	if (args.empty()) {
		cprintf("UNSET: usage: unset [target] <preference>\r\n");
		return 1;		
	}

	/**
	  * Get arguments (all of them; no value this time)
	  */
	const size_t num = args.num_tokens();
	vector<config::parse_token> params;
	args.get(params, 0, num);

	config::target_list targets;
	const config::hash_entry * entry;

	config::parse_result r = node_searcher<user_config_root>::parse_user_command(
			params, targets, &entry);

	if (r.first != config::SUCCESS) {
		cprintf("Error: Parse error at token: '%s'\r\n", params[r.second]);
		cprintf("Error: %s\r\n", config::strerror(r.first));
		return 1;
	}

	// do not allow unsets of "default" targets.
	// we rely on there always being a "default" value for everything!
	if (targets.empty() || !strcasecmp(targets.back(), "all")
			|| !strcasecmp(targets.back(), "default")) {
		cprintf("error: cannot unset a preference in the 'all' or 'default' targets\r\n");
		return 1;
	}
	
	cprintf("Unsetting '%s' ...\r\n", args.all());
	try {
		switch (entry->type) {
		case config::STRING:			
			user()->options()->unset<string>(targets, entry->option);
			break;

		case config::BOOLEAN:
			user()->options()->unset<bool>(targets, entry->option);
			break;

		case config::INTEGER:
			user()->options()->unset<int>(targets, entry->option);
			break;
		
		default:			
			/* Should not happen */
			abort();
		}

		cprintf("Done.\r\n");
	}
	catch (std::exception &e) {
		cprintf("Error unsetting preference: exception '%s'\r\n", e.what());	
	}
	return 1;
}

CMDFUNC(isset) 
{
	if (args.empty()) {
		cprintf("ISSET: usage: isset [target] <preference>\r\n");
		return 1;	
	}

	/**
	  * Get arguments (all of them; no value this time)
	  */
	const size_t num = args.num_tokens();
	vector<config::parse_token> params;
	args.get(params, 0, num);

	config::target_list targets;
	const config::hash_entry * entry;

	config::parse_result r = node_searcher<user_config_root>::parse_user_command(
			params, targets, &entry);

	if (r.first != config::SUCCESS) {
		cprintf("Error: Parse error at token: '%s'\r\n", params[r.second]);
		cprintf("Error: %s\r\n", config::strerror(r.first));
		return 1;
	}
	
	bool b_value = false;

	cprintf("Checking whether '%s' has been explicitly set...\r\n", args.all());
	try {
		switch (entry->type) {
		case config::STRING:			
			b_value = user()->options()->is_set<string>(targets, entry->option);
			break;

		case config::BOOLEAN:
			b_value = user()->options()->is_set<bool>(targets, entry->option);
			break;

		case config::INTEGER:
			b_value = user()->options()->is_set<int>(targets, entry->option);
			break;
		
		default:			
			/* Should not happen */
			abort();
		}

		cprintf("Got result: %s\r\n", true_false(b_value));
	}
	catch (std::exception &e) {
		cprintf("Error checking preference: exception '%s'\r\n", e.what());	
	}
	return 1;
}

CMDFUNC(prefs) 
{
	cprintf("FIXME: unimplemented\r\n");
	//--------------------------------------------------
	// cprintf("Your Current Preferences:\r\n");
	// cprintf("  VHost:         %s\r\n", prefs->get(user_perms::VHOST));
	// cprintf("  Auto-Server:   %s\r\n", prefs->get(user_perms::AUTO_SERVER));
	// cprintf("  Fake Ident:    %s\r\n", prefs->get(user_perms::FAKE_IDENT));
	// cprintf("  Detach-nick:   %s\r\n", prefs->get(user_perms::DETACH_NICK));
	// cprintf("  Detach-away:   %s\r\n", prefs->get(user_perms::DETACH_AWAY));
	// cprintf("  CTCP:\r\n");
	// cprintf("  version-reply: %s\r\n", prefs->get(user_perms::CTCP_VERSION_REPLY));
	// cprintf("  Auto-Detach:   %s\r\n", yesno(prefs->get<bool>(user_perms::AUTO_DETACH)));
	// cprintf("  Proxy DCC-in:  %s\r\n", yesno(prefs->get<bool>(user_perms::DCC_IN)));
	// cprintf("  Proxy DCC-out: %s\r\n", yesno(prefs->get<bool>(user_perms::DCC_OUT)));
	// cprintf("  Filter DCCS:   %s\r\n", yesno(prefs->get<bool>(user_perms::ENABLE_DCC_FILTER)));
	//-------------------------------------------------- 
	return 1;
}

/**
  * Display available configuration variables, sorted by level.
  */
CMDFUNC(options)
{
	static const char prefix[] = "-     ";
	cprintf("Listing configurable preferences...\r\n");
	cprintf("-    \002User level\002:\r\n");
	dump_options<user_config, string>(prefix);
	cprintf("-\r\n");
	cprintf("-    \002IRC Network/Server level\002:\r\n");
	dump_options<irc_server_config, bool>(prefix);
	dump_options<irc_server_config, int>(prefix);
	dump_options<irc_server_config, string>(prefix);
	cprintf("-\r\n");
	cprintf("-    \002Channel level\002:\r\n");
	dump_options<irc_channel_config, bool>(prefix);
	dump_options<irc_channel_config, string>(prefix);
	cprintf("-\r\n");
	cprintf("For help with a specific option, try 'help option <option name>'\r\n");
	return 1;
}

CMDFUNC(allowed)
{
	userdef * u = user();
	user_permissions * p  = u->config();
	if (args > 0 && is_admin()) {
		userdef::hash_table_t::iterator i = proxy->users().find(args[0]);
		if (i == proxy->users().end()) {
			cprintf("ALLOWED: invalid user %s\r\n", args[0]);
			return 1;
		}
		u = (*i).second;
		p = u->config();
	}

	cprintf("\002Configuration\002 for user %s: \r\n", user()->name());
	cprintf("  VHOST command:                     %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_VHOST_COMMAND)));
	cprintf("  Fake Ident services:               %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_FAKE_IDENTS)));
	cprintf("  Detach capability:                 %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_DETACH_COMMAND)));
	cprintf("  \002VFS access\002:               %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_VFS_ACCESS)));
	cprintf("    ---> Quota:                      %d\r\n", p->get<int>(user_perms::VFS_QUOTA));
	cprintf("    ---> DCC Storage:                %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_DCC_STORAGE)));
	cprintf("  \002Chat Logging\002:                      %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_CHAT_LOGGING)));
	cprintf("    ---> Per-channel Logging:        %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_PER_CHANNEL_LOGGING)));
	cprintf("  \002DCC Proxying\002\r\n");
	cprintf("    ---> Incoming:                   %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_INCOMING_DCC_PROXYING)));
	cprintf("    ---> Outgoing:                   %s\r\n", yesno(p->get<bool>(user_perms::ENABLE_OUTGOING_DCC_PROXYING)));
	cprintf("    ---> Max DCCs & Offers:          %d\r\n", p->get<int>(user_perms::MAX_DCCS));
	return 1;
}

