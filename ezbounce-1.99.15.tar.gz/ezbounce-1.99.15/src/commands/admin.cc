/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/admin.cc
 * (c) 2007-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <vector>
#include <list>
#include <cstdlib>
#include "irc/address.h"
#include "irc/cache.h"
#include "irc/channel.h"
#include "conn.h"
#include "commands.h"
#include "textline.h"
#include "proxy.h"
#include "messages.h"
#include "debug.h"

using irc::channel;
using std::list;
using std::string;
using std::vector;

using namespace util::strings;

/*
 * Show some info on 'c' 
 */
void conn::show_whois(conn * c) const
{
	string timebuff;
	char flagbuff[10];

	c->mkstat(flagbuff);
	duration(timebuff, proxy->time() - c->connect_time, false);

	cprintf("---> Connection ID %d\r\n",c->id());
	cprintf("     Online:       %s\r\n",timebuff.c_str());
	if (c->client) {
		cprintf("     From:         %s\r\n", c->client->peer_addr());
	}
	cprintf("     IRC Nick:     %s\r\n", c->irc->nick());
	if (c->server) {
		cprintf("     Connected to: %s:%d (running %s)\r\n",
				c->server->peer_addr(),
				c->server->peer_port(),
				c->servinfo->version());
	}
	cprintf("     Active DCCs:  %d\r\n", c->dcc_count());
	cprintf("     Flags:        %s (0x%X)\r\n", flagbuff, c->stat);
	cprintf("<--- [end of info]\r\n");
}

CMDFUNC(rehash)
{
	proxy->printlog("%s is rehashing proxy configuration file..\n", addr());
	if (proxy->rehash() == 0) {
		proxy->printlog("Rehash successful\n");
		cprintf("REHASH successful\r\n");
	}
	else {
		proxy->printlog("Rehash failed -- errors loading file\n");
		proxy->printlog("--> errno was: %d [%s]\n", errno, strerror(errno));
		cprintf("REHASH failed: unable to load config file\r\n");
		cprintf("REHASH: check ezbounce log file for details (output will be here one day)\r\n");
	}
	return 1;
}

/**
  * Display hash table performance statistics.
  */
CMDFUNC(hash)
{
	struct util::hash_stats ht;
	memset(&ht, 0, sizeof(ht));

	if (args == 0) {
		cprintf("Usage: HASH <1-5 | channel>\r\n");
		return 1;
	}

	switch (atoi(args[0]))
	{
	case 1:
		cprintf("User Command Parser stats ...\r\n");
		cmdhash.stat(&ht);
		break;
	case 2:
		cprintf("Incoming Command Parser stats ...\r\n");
		incoming_hash.stat(&ht);
		break;
	case 3:
		if (acache) {
			cprintf("Nickname hash stats ...\r\n");
			acache->stats(&ht, 0);
			break;

	case 4:
			if (acache) {
				cprintf("Channel Name Hash stats ...\r\n");
				acache->stats(0, &ht);
				break;
			}
		}
		cprintf("HASH: Not connected to IRC\r\n");
		return 1;

	case 5:
		cprintf("Help system hash stats ...\r\n");
		help_table.stat(&ht);
		break;
	
	default:
		/**
	         * May be a channel.
		 */
		if (acache && servinfo->is_channel(args[0])) {
			channel * c = acache->lookup_channel(args[0]);
			if (!c) {
				cprintf("HASH: Channel not found\r\n");
				return 1;
			}
			c->nick_hash_stats(&ht);
			cprintf("Channel %s nickname hash stats ...\r\n", args[0]);
			break;
		}	

		cprintf("HASH: Unknown option. Use 1-5, or the name of a channel\r\n");
		return 1;
	}

	cprintf("   Entries:   %d\r\n", ht.size);
	cprintf("   Buckets:   %d (%.1f entries/bucket)\r\n", ht.buckets, (float) ht.size / ht.buckets);
	cprintf("   In Use:    %d (%.1f%%)\r\n", ht.buckets_in_use, (float) ht.buckets_in_use / ht.buckets * 100);
	cprintf("     [empty]: %d (%.1f%%)\r\n", ht.sizes[0], (float) ht.sizes[0] / ht.buckets * 100);
	cprintf("     [1]:     %d (%.1f%%)\r\n", ht.sizes[1], (float) ht.sizes[1] / ht.buckets * 100);
	cprintf("     [2]:     %d (%.1f%%)\r\n", ht.sizes[2], (float) ht.sizes[2] / ht.buckets * 100);
	cprintf("     [3]:     %d (%.1f%%)\r\n", ht.sizes[3], (float) ht.sizes[3] / ht.buckets * 100);
	cprintf("     [4+]:    %d (%.1f%%)\r\n", ht.sizes[4], (float) ht.sizes[4] / ht.buckets * 100);
	cprintf("   Lookups:   %d\r\n", ht.lookups);
	cprintf("   Hits:      %d (%.1f%%)\r\n", ht.hits, float(ht.hits) / ht.lookups * 100);
	return 1;
}

/*
 * Send a message to a single user or everybody
 * using the proxy. Unfortunately there is no
 * way for the proxy users to respond back ;)
 */
CMDFUNC(write)
{
	if (args < 2) {
		cprintf("Usage: WRITE <userid | all> <message>\r\n");
		return 1;
	}
	const char * message = args.get_rest(1);
	if (strcasecmp(args[0], "ALL") == 0) {
		char * buff;
		my_asprintf(&buff, "* * * * * BROADCAST MESSAGE FROM %s * * * * *\r\n%s\r\n", user()->name(), message);
		for_each(proxy->conn_list().begin(), proxy->conn_list().end(), 
				bind2nd(std::mem_fun(&conn::cprintf_multiline), buff));
		delete[] buff;
	}
	else {
		conn * c = lookup(args[0]);
		if (c == NULL) {
			cprintf("Can't find user by id: '%s'\r\n", args[0]);
			return 1;
		} 

		if (c->client) {
			c->cprintf("*** Message from %s: %s\r\n", user()->name(), message);
		} 
		else {
			cprintf("WRITE: Can't deliver message: user is detached or dead.\r\n");
		} 
	}
	return 1;
}


/* The other admin commands that no one really
 * cares about */
CMDFUNC(die)
{
	if (args > 0) {
		cprintf(type == CMD_DIENOW ? MSG_DIEING_NOW : MSG_DIEING);
		proxy->request_shutdown((type == CMD_DIENOW), args.all());
	}
	else {
		cprintf(MSG_INSUFFICIENT_ARGS, "die/dienow");
	}
	return 1;
}


CMDFUNC(whois)
{
	if (args == 0) {
		cprintf("WHOIS: must specify connection id or user name\r\n");
		return 1;
	}
	userdef * u = NULL;
       
	userdef::hash_table_t::iterator i = proxy->users().find(args[0]);
	
	if (i == proxy->users().end()) {
		conn * c = lookup(args[0]);
		if (c == NULL) {
			cprintf("WHOIS: id not found: %s\r\n", args[0]);
			return 1;
		}
		if (c->user() != NULL) {
			cprintf("Connection '%d' is user '%s'\r\n", c->id(), c->user()->name());
		}
		else {
			cprintf("Connection '%d' has not logged in.\r\n", c->id());
		}
		show_whois(c);
		return 1;
	} 
	else {
		u = (*i).second;
	}

	cprintf("User info for %s\r\n", args[0]);
	cprintf("---> Active connections: %d\r\n", u->conns().size());
	std::for_each( u->conns().begin(), 
			u->conns().end(), 
			std::bind1st( std::mem_fun(&conn::show_whois), this ));
	return 1;
}

CMDFUNC(reload)
{
	const string& name = proxy->config().get<string>(proxy_config::USER_FILE);
	if (name.empty()) {
		cprintf("Can't reload user preferences: user file wasn't set in the config\r\n");
		return 1;
	}
	proxy->printlog("Reloading user preferences from disk [requested by %s]...\n", addr());
	cprintf("Reloading user preferences file...\r\n");
	if (proxy->load_prefs() != 0) {
		cprintf("   .... failed\r\n");
	} 
	else {
		cprintf("   .... success\r\n");
	}
	return 1;
}

CMDFUNC(save)
{
	const string& name = proxy->config().get<string>(proxy_config::USER_FILE);
	if (name.empty()) {
		cprintf("Can't save options to disk: no user file was set in the config.\r\n");
		return 1;
	}
	proxy->printlog("Saving user preferences to disk [requested by %s]...\n", addr());
	cprintf("Saving preferences to disk ...\r\n");
	if (proxy->save_prefs() != 0) {
		cprintf("    .... Failed: %s\r\n", strerror(errno));
	} 
	else {
		cprintf("    .... Success\r\n");
	}
	return 1;
}
