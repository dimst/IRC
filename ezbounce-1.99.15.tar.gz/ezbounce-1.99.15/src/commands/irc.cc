/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/irc.cc
 * (c) 2007-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <string>
#include <cstdlib>
#include "irc/address.h"
#include "irc/cache.h"
#include "irc/event.h"
#include "irc/message.h"
#include "conn.h"
#include "commands.h"
#include "textline.h"
#include "messages.h"
#include "debug.h"

/**
 * This file contains traps for outgoing standard IRC commands:
 * PRIVMSG, NOTICE, QUIT and others.
 */

using std::string;
using irc::channel;

using namespace util::strings;

CMDFUNC(quit)
{
	if (decide<server_node>(servinfo->server_target(), 
			       	irc_server_config::AUTO_DETACH) == 1) {
		do_auto_detach();
		return 1;
	}
	return 0;
}

/**
 * Outgoing PRIVMSG handler -- Current does:
 *  Outgoing DCC proxying (and that's it) 
 */
CMDFUNC(privmsg)
{
	const char * target = args[0];
	const char * message = no_leading(args.get_rest(1));

	string ctcp;
	string ctcp_subtype, ctcp_args;

	// determine what happened
	irc::event orig_event;
	if (is_bounced()) {
		orig_event = servinfo->is_channel(target) ? irc::PUBLIC_PRIVMSG : irc::PRIVATE_PRIVMSG;
	}
	else {
		orig_event = irc::PRIVATE_PRIVMSG;
	}
	irc::event event = irc::extract_ctcp(orig_event, args, 1, ctcp, ctcp_subtype, ctcp_args);

	if (event == irc::DCC) {
		if (is_bounced()) {
			log_irc_event(event, irc, target, 
					ctcp_args.c_str(), ctcp_subtype.c_str());
		}

		const bool do_dcc_out = (decide<server_node>(get_server_target(), 
						irc_server_config::PROXY_DCC_OUT) > 0) ||
					(decide<server_node>(get_server_target(),
					     irc_server_config::FILTER_DCCS) > 0);
		if (do_dcc_out) {
			return handle_dcc(false, irc, target, 
					ctcp_subtype.c_str(), ctcp_args.c_str());
		}
	}
	else if (event == irc::PRIVATE_CTCP || event == irc::PUBLIC_CTCP) {
		// currently, do nothing special for these
	}
	else if (is_bounced()) {
		// Log if necessary
		log_irc_event(event, irc, target, message, NULL);
	}
	return 0;
}

/**
  * Handle outgoing NOTICEs and log; currently does nothing.
  */
CMDFUNC(notice)
{
	// FIXME: at least log them
	return 0;
}

/** 
 * During reattach, capture who commands and queue them with the
 * the throttle timer. Most IRC clients will send 'WHO #chan' upon
 * joining, which is an expensive operation.
 */
CMDFUNC(who)
{
	if (args < 1) {		
		return 0;
	}
	channel * c = acache->lookup_channel(args[0]);
	if (!c) {
		return 0;
	}

	if (c->chan_flags() & channel::WHO_REQ_SENT) {
		DEBUG("conn::do_who_command(): Suppressing outgoing WHO command for %s\n", c->name());
		c->set_chan_flag(channel::RELAY_WHO_RESP);
		return 1;
	}
	if (c->chan_flags() & channel::WHO_DATA_RECVED) {
		// create the restartable procedure if needed
		if (recently_reattached()) {
			rfunc * rf = acache->create_rfunc(acache->RFUNC_WHO,
					client, c->name(), irc->nick());
			if (!rf) {
				return 0;
			}
			rfuncs.push_back(rf);
			DEBUG("conn::do_who_command() : created WHO rfunc for %s on %s\n", irc->nick(), c->name());
			return 1;
		}
	}
	return 0;
}

/**
  * Outgoing MODE commands.
  * Clients will send these after joining, and we do too.
  * 
  */
CMDFUNC(mode) 
{
	if (args < 1) {		
		return 0;
	}
	channel * c = acache->lookup_channel(args[0]);
	if (!c) {
		return 0;
	}

	if (c->chan_flags() & channel::MODE_REQ_SENT) {
		DEBUG("conn::do_who_command(): Suppressing outgoing MODE command for %s\n", c->name());
		c->set_chan_flag(channel::RELAY_MODE_RESP);
		return 1;
	}
	if (c->chan_flags() & channel::MODE_DATA_RECVED) {
		// XXX: do anything here?
		if (client) {
		} 
	}
	return 0;
}

/**
 * TODO: implement.
 */
CMDFUNC(protoctl) 
{
	return 0;
}

/**
 * TODO: implement.
 */
CMDFUNC(cap)
{
	return 0;
}
