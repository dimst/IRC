/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/incoming.cc
 * (c) 2006-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <string>
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include "util/strings.h"
#include "irc/address.h"
#include "irc/cache.h"
#include "irc/channel.h"
#include "irc/flood.h"
#include "irc/ignore.h"
#include "irc/message.h"
#include "commands.h"
#include "conn.h"
#include "proxy.h"
#include "reconnect.h"
#include "textline.h"
#include "debug.h"

using std::string;

using irc::channel;
using irc::address_cache;
using irc::flood_protector;

using namespace util::strings;

/*********************************************************
 * INCOMING command handlers
 * Notes:
 *   Return values and their meanings are the same
 *   Return values are meaningless when detached
 *   'args.all()' contains ENTIRE line,
 *      so that the token before the command may be read
 *********************************************************/

/**
 * Gather information about the server during connect, so we can
 * dump it back during reattach ..
 * 11/03 -- now server_info object takes care of parsing and storage 
 *
 * Example:
 * :irc.blahblah.com 005 steve CMDS=KNOCK,MAP,DCCALLOW,USERIP NAMESX SAFELIST HCN 
 * 			MAXCHANNELS=10 CHANLIMIT=#:10 MAXLIST=b:60,e:60,I:60 NICKLEN=30 CHANNELLEN=32 
 * 			TOPICLEN=307 KICKLEN=307 AWAYLEN=307 MAXTARGETS=20 :are supported by this server
 */
CMDFUNC(servinfo_incoming)
{
	if (args < 4) {
		return 0;
	}

	const char * target = args[2];

	if (type == INCOMING_003 && servinfo->strcasecmp(target, irc->nick()) != 0) {
		/** 
		 * Here we find out when the server was created,
		 * as well as the server's true name,
		 * and, we might as well get a positive identification on our
		 * nickname...
		 */
		irc->set_nick(target);
		update_client_address();
	}

	/**
	  * For numeric 005, the address cache may have to be re-created if we learn
	  * of a new casemapping.  Also, ignore any numeric 005 requests if we're already
	  * on channels.
	  */
	if (type == INCOMING_005) {
		if (acache->num_channels() > 0) {
			return 0;
		}
		string old_network = servinfo->network();
		int i = servinfo->parse_numeric(args);
		if (i < 0) {
			return 0;
		}
		// Create address cache again just to be safe, to ensure that it's using 
		// the correct hash functions and everything for this casemapping.  Also
		// initialize logging again to put everything in the correct directory.
		if (strcasecmp(old_network.c_str(), servinfo->network()) != 0) {
			stop_irc_logs("Discovered IRC network name; switching directories");
			if (is_detached()) {
				// This may be the case during a reconnect
				setup_irc_logs(DETACH);
			}
			else {
				setup_irc_logs(IRC_CONNECT);
			}
		}
		delete acache;
		delete floodp;
		acache = new address_cache(servinfo, 37);
		floodp = new flood_protector(servinfo, ignores, 37);
	}
	else {
		servinfo->parse_numeric(args);
	}
	return 0;
}


/**
 *  What all we need to do:
 * -- Handle CTCP DCC (only when !detached and DCC_IN)
 * -- Handle CTCP PING (only when detached)
 * -- Handle all CTCP (only when detached)
 * -- Handle all Other (only when detached) 
 *
 * Example:
 * :nick!user@whatever PRIVMSG target :etc etc etc
 */
CMDFUNC(privmsg_incoming)
{
	if (args < 4) {
		return 0;
	}

	const char * source = no_leading(args[0]);
	const char * target = args[2];
	const char * message = no_leading(args.get_rest(3));

	if (!is_non_empty(source)) {
		return 0;
	}

	irc::address ia(source);

	string ctcp, ctcp_subtype, ctcp_args;

	/**
	 * Determine what happened.  Start with the original event
	 * and try to find a CTCP or DCC within.
	 */
	const irc::event orig_event = servinfo->is_channel(target) ? irc::PUBLIC_PRIVMSG : irc::PRIVATE_PRIVMSG;
	const irc::event event = irc::extract_ctcp(orig_event, args, 3, ctcp, ctcp_subtype, ctcp_args);

	if (ignores->is_ignored(&ia, event, proxy->time())) {
		// ignoring; discard message
		return 1;
	}

	if (is_detached()) {
		int r = floodp->in(&ia, event, proxy->time());
		if (r == irc::flood_protector::NOW_IGNORING) {
			// XXX: flood detected
			return 1;
		}
	}

	if (event == irc::PRIVATE_CTCP || event == irc::PUBLIC_CTCP) {
		/**
		 * Handle CTCPs (only while detached).
		 */
		log_irc_event(event, &ia, target, ctcp_args.c_str(), ctcp.c_str());
		if (is_detached()) {
			return handle_ctcp(&ia, ctcp.c_str(), ctcp_args.c_str());
		}
	}
	else if (event == irc::DCC) {
		/**
		 * Handler incoming DCC proxying & filtering.
		 */
		log_irc_event(event, &ia, target, ctcp_args.c_str(), ctcp_subtype.c_str());

		if (!is_detached()) {
			const bool do_dcc_in = (decide<server_node>(servinfo->server_target(), 
							irc_server_config::PROXY_DCC_IN) > 0) ||
						(decide<server_node>(servinfo->server_target(),
							irc_server_config::FILTER_DCCS) > 0);

			if (do_dcc_in) { 
				return handle_dcc(true, &ia, target, ctcp_subtype.c_str(), ctcp_args.c_str());
			}
		}
	}
	else {
		// Normal message: just log it
		log_irc_event(event, &ia, target, message, "");
	}
	return 0;
}

/**
 * Incoming NICK messages
 * Example:    
 *    :murat_!~murat@xxxx NICK :druglord 
 */
CMDFUNC(nick_incoming)
{
	if (args < 3) {
		return 0;
	}

	const char * source = no_leading(args[0]);
	const char * new_nick = no_leading(args[2]);

	if (!is_non_empty(source)) {
		return 0;
	}

	irc::address ia(source);

	log_irc_event(irc::NICK_CHANGE,
			&ia, (const char *) NULL, NULL, new_nick);

	acache->change_nick(ia.nick(), new_nick);

	if (servinfo->strcasecmp(ia.nick(), irc->nick()) == 0) {
		*irc = ia;
		irc->set_nick(new_nick);
		update_client_address();
	}
	return 0;
}


/**
 * This handles both the initial mode numeric (324) and MODE commands issued by users:
 *
 * :brown.freenode.net 324 druglord #test +sn  
 * :druglord!xxxxx@xxx.rr.com MODE #test +t 
 */
CMDFUNC(mode_incoming)
{
	if (args < 4) {
		return 0;
	}

	const char * source = no_leading(args[0]);
	const char * target = args[2];
	const char * mode_str = NULL;

	if (!is_non_empty(source)) {
		return 0;
	}

	channel * c = NULL;
	int ret = 0;

	if (type == INCOMING_MODE) {
		irc::address ia(source);
		mode_str = no_leading(args.get_rest(3));
		if (servinfo->is_channel(target)) {
			log_irc_event(irc::MODE, &ia, target, mode_str, NULL);
			c = acache->lookup_channel(target);
		}
	}
	else {
		// Numeric 324
		c = acache->lookup_channel(args[3]);
		mode_str = no_leading( args.get_rest(4) );

		// Check if we need to relay this to the client
		if (c != NULL && (c->chan_flags() & channel::MODE_REQ_SENT)) {
			c->clear_chan_flag(channel::MODE_REQ_SENT);
			c->set_chan_flag(channel::MODE_DATA_RECVED);
			ret = (c->chan_flags() & channel::RELAY_MODE_RESP) == 0;
		}
	}

	/* update acache */
	if (c != NULL) {
		textline line(mode_str);
		acache->parse_mode_line(c->name(), line);
	}
	return ret;
}

/**
 * example: 
 * :druglord_!~murat@xxxx JOIN :#test 
 */
CMDFUNC(join_incoming)
{
	if (args < 3) {
		return 0;
	}

	const char * source = no_leading(args[0]);
	const char * chan = no_leading(args[2]);
	
	if (!is_non_empty(source)) {
		return 0;
	}

	irc::address ia(source);

	DEBUG("current irc data: %s %s %s\n", irc->nick(), irc->user(), irc->host());
	if (servinfo->strcasecmp(ia.nick(), irc->nick()) == 0) {
		DEBUG("Adding %s to channel list!\n", chan);
		acache->add_channel(chan);

		/* request MODE data */
		channel * c = acache->lookup_channel(chan);
		c->set_chan_flag(channel::MODE_REQ_SENT);
		queue_command("MODE %s\r\n", chan);

		/* request WHO data */
		c->set_chan_flag(channel::WHO_REQ_SENT);
		queue_command("WHO %s\r\n", chan);

		/* setup logging */
		setup_channel_log(c, CHANNEL_JOIN);

		/* If we didn't know our hostname... we do now..
		 * update accordingly */
		if ( !irc->has_user_host() ) {
			delete irc;
			irc = new irc::address(ia);
			DEBUG("Found out address for %s (%s@%s)\n", irc->nick(), irc->user(), irc->host());
		}

		/* check reconnection progress if needed */
		if (is_reconnecting()) {
			if (rinfo->has_target(chan)) {
				rinfo->add_succeeded(chan);
			}

			const size_t total = rinfo->num_succeeded() + rinfo->num_failed();
			const size_t goal  = rinfo->channels().size();

			assert(total <= goal);
			if (total >= goal) {
				finish_reconnect();
			}
		}

	}

	/* add the nickname itself */
	acache->add_entry(&ia, chan);

	log_irc_event(irc::JOIN, &ia, chan, NULL, NULL);
	return 0;
}


/**
 * example: 
 *
 * :druglord_!~murat@xxxx PART :#test
 * :druglord_!~murat@xxxx PART #test :<reason>
 */
CMDFUNC(part_incoming)
{
	// NOTE: some networks still do not support PART reason messages (I believe)
	if (args < 3) {
		return 0;
	}

	const char * source = no_leading(args[0]);
	const char * chan = no_leading(args[2]);
	const char * reason = no_leading( non_null(args.get_rest(3)) );

	if (!is_non_empty(source)) {
		return 0;
	}

	irc::address ia(source);

	log_irc_event(irc::PART, &ia, chan, reason, NULL);

	if (servinfo->strcasecmp(ia.nick(), irc->nick()) == 0) {
		channel * c = acache->lookup_channel(chan);
		if (c == NULL) {
			// This should never happen, unless we are on some kind of fake
			// IRC server
			assert(false);
			return 0;
		}
		setup_channel_log(c, CHANNEL_PART);
		acache->delete_channel(chan);
	}
	else {
		acache->delete_nick(ia.nick(), chan);
	}
		
	return 0;
}

/**
 * example:
 *
 * :murat9!murat@host KICK #testing bob :reason for kick
 */
CMDFUNC(kick_incoming)
{
	if (args < 4) {
		return 0;
	}

	const char * source = no_leading(args[0]);
	const char * chan = args[2];
	const char * target = args[3];
	const char * reason = no_leading(non_null(args.get_rest(4)));

	if (!is_non_empty(source)) {
		return 0;
	}

	irc::address ia(source);

	log_irc_event(irc::KICK, &ia,  chan, reason, target);

	if (servinfo->strcasecmp(target, irc->nick()) == 0) {
		DEBUG("conn::do_kick_incoming_cmd(): removing channel: %s\n", chan);
		channel * c = acache->lookup_channel(chan);
		if (c == NULL) {
			// shouldn't happen
			assert(false);
			return 0;
		}
		setup_channel_log(c, CHANNEL_PART);

		acache->delete_channel(chan);

		if (is_detached()) {
			const bool want_rejoin = user()->options()->get<channel_node, bool>(c->channel_target(),
										irc_channel_config::AUTO_REJOIN);
			if (want_rejoin) {
				queue_command("JOIN :%s\r\n", chan);
			}
		}
	} 
	else {
		acache->delete_nick(target, chan);
	}
	return 0;
}

/**
 * Handle notices -- so far just used for logging
 *
 * :nick!user@host NOTICE <target> :<message>
 */
CMDFUNC(notice_incoming)
{
	if (args < 4) {
		return 0;
	}

	const char * source = no_leading(args[0]);
	const char * target = args[2];
	const char * message = no_leading(args.get_rest(3));

	if (!is_non_empty(source)) {
		return 0;
	}

	irc::address ia(source);
	log_irc_event(servinfo->is_channel(target) ? irc::PUBLIC_NOTICE : irc::PRIVATE_NOTICE,
			&ia, target, message, "");
	return 0;
}

/**
 * This handles both topic changes as well as the topic numeric (#332)
 * that is sent on join. Examples:
 *
 *  :druglord!xxx@xxx.rr.com TOPIC #channel :test
 *  :brown.freenode.net 332 druglord #ubuntu :XXXX
 */
CMDFUNC(topic_incoming)
{
	if (args < 4) {
		return 0;
	}

	const char * source = no_leading(args[0]);
	const char * target = args[2];
	const char * str = NULL;
	channel * c = NULL;

	if (!is_non_empty(source)) {
		return 0;
	}

	if (type == INCOMING_TOPIC) {
		// :druglord!xxx@xxx.rr.com TOPIC #channel :test
		irc::address ia(source);
		str = no_leading(args.get_rest(3));

		log_irc_event(irc::TOPIC, &ia, target, str, NULL);

		c = acache->lookup_channel(target);
	}
	else {
		// numeric 332
		// :brown.freenode.net 332 druglord #ubuntu :XXXX
		target = args[3];
		str = no_leading( non_null(args.get_rest(4)) );
		c = acache->lookup_channel(target);
	}

	if (c != NULL) {
		c->set_topic(str);
		DEBUG("conn::on_topic_incoming_cmd(): setting %s topic to: %s\n", c->name(), str);
	}
	return 0;
}

/**
  * :brown.freenode.net 333 druglord_ #ubuntu apokryphos 1174667005
  */
CMDFUNC(topic_info_incoming)
{
	if (args < 6) {
		return 0;
	}

	const char * chan = args[3];
	channel * c = acache->lookup_channel(chan);
	if (c != NULL) {
		const char * setter = args[4];
		const char * time = args[5];
		c->set_topic_data(setter, time);
	}
	return 0;
}

/**
 * QUIT messages.
 * :murat!name@host QUIT :Connection reset by peer
 */
CMDFUNC(quit_incoming)
{
	const char * source = no_leading(args[0]);
	const char * message = no_leading( non_null(args.get_rest(2)) );

	if (!is_non_empty(source)) {
		return 0;
	}

	irc::address ia(source);

	 // Remove reference entirely ...	
	acache->delete_nick(ia.nick());
	log_irc_event(irc::QUIT, &ia, (const char *) NULL, message, NULL);
	return 0;
}

/**
 * Handles incoming server pings -- example:
 * PING :irc.lagged.org 
 */
CMDFUNC(ping_incoming)
{
        const char * ping_args = args.get_rest(1);
        server->printf("PONG %s\r\n", ping_args);
        DEBUG("Replying to server ping: %s\n", ping_args);
        return 0;
}

/**
 * TODO: when we start pinging the IRC server, this will be
 * 	 the handler.
 */
CMDFUNC(pong_incoming)
{
	DEBUG("Got a server PONG: %s\n", args.all());
	return 0;
}

/** 
 * Handle ERROR strings when we are detached.
 */
CMDFUNC(error_incoming)
{
//	if (log)
//	{
//		log->dump(args.all());
// 		log->dump("\n");
//	}
	return 0;
}

/** 
 * Syntax
 *
 * :irc.avalonworks.ca 353 druglord @ #channel :+Xfig moofo fiend- Fizzter ryan[WIN] +shea_
 * :irc.foxlink.net 366 druglord #channel :End of /NAMES list.
 *
 * FIXME: does not handle old IRC format sans @/=/+ character between target nickname
 *        and channel name 
 */
CMDFUNC(names_incoming)
{
	if (type == INCOMING_353) {
		// Single NAMES message
		if (args < 6) {
			return 0;
		}
		const char * params = no_leading(args.get_rest(5));
		const char * chan = args[4];
		textline data(params);
		acache->parse_names_block(chan, data);
	} 
	else {
		// End of /NAMES list
		if (args < 4) {
			return 0;
		}
		const char * chan = args[3];
	        acache->end_names_block(chan);
	}
	return 0;
}

/**
 * WHO command syntax:
 *
 * :irc.avalonworks.ca 352 druglord #channel ~murat xxxx.address.com irc.avalonworks.ca druglord H :0 yes
 * :irc.avalonworks.ca 315 druglord #channel :End of /WHO list.
 */
CMDFUNC(who_incoming)
{
	if (args < 5) {
		return 0;
	}

	const char * chan = args[3];
	channel * c = acache->lookup_channel(chan);
	if (!c) {
		return 0;
	}

	if (type == INCOMING_352) {
		textline data(args.get_rest(4));
		acache->parse_who_block(chan, data);
	}
       	else {
		acache->end_who_block(chan);
	}

	/* We might have requested this data ourselves ..
	 * in that case, don't relay it to the client unless
	 * he has requested it as well */
	if (c->chan_flags() & channel::WHO_REQ_SENT) {
		if (type == INCOMING_315) {
			DEBUG("conn::who_incoming() completed who data retrieval for %s\n", c->name());
			c->clear_chan_flag(channel::WHO_REQ_SENT);
		}
		return (c->chan_flags() & channel::RELAY_WHO_RESP) == 0;
	}
	return 0;
}

/**
  * Numeric 001: Usually the first thing sent by the IRC server when
  * we have successfully connected and logged in.
  */
CMDFUNC(001_incoming)
{
	if (!is_reconnecting()) {
		return 0;
	}

	// We could be done reconnecting already.
	if (rinfo->channels().empty()) {
		finish_reconnect();
		return 0;
	}

	// Queue all join commands now
	cprintf("Queuing JOINs for %zd channels\r\n", rinfo->channels().size());
	for (reconnect_info::channel_map::const_iterator i = rinfo->channels().begin(),
							 e = rinfo->channels().end();
							 i != e; ++i) {
		const std::string& target = (*i).first;
		const std::string& key = (*i).second;
		queue_command("JOIN %s %s\r\n", target.c_str(), key.c_str());
	}
	rinfo->reset_succeeded();
	rinfo->reset_failed();
	return 0;
}

/**
  * Occurs when a nickname cannot be acquired.  
  * Trapped *only* during reconnection attempts.
  * Syntax:
  * :pratchett.freenode.net 432 druglord ChanServ :Erroneous Nickname
  * :pratchett.freenode.net 433 druglord xxx :Nickname is already in use
  *
  */
CMDFUNC(nick_failed_incoming)
{
	if (args < 4) {
		return 0;
	}
	std::string nick = args[3];
	const size_t max = servinfo->get_nick_len();

	if (nick.size() < max) {
		nick += '_';
	}
	else {
		for (unsigned i = max-1; i > 0; --i) {
			char &c = nick[i];
			if (c < '0' || c > '9') {
				c = '1';
				break;
			}
			if (c < '9') {
				++c;
				break;
			}
			c = '0';
		}
	}
	cprintf("reconnect: nickname was in use, trying '%s'\r\n", nick.c_str());
	server->printf("NICK %s\r\n", nick.c_str());

	// at the moment, we hide this from the user	
	return 1;
}

/**
  * Occurs when a channel cannot be joined.
  * Trapped *only* during reconnection attempts.
  * Numeric 470 (channel forwarding) is also handled and counts as a failed join
  *
  * :irc.server.com 471 druglord #channel :Channel is full
  * :pratchett.freenode.net 470 druglord #ubuntu #ubuntu-read-topic :Forwarding to another channel
  */
CMDFUNC(join_failed_incoming)
{
	if (args < 4) {
		return 0;
	}
	const char * chan = args[3];
	if (rinfo->has_target(chan)) {
		rinfo->add_failed(chan);
	}

	// We may be finished.	
	const size_t total = rinfo->num_succeeded() + rinfo->num_failed();
	const size_t goal  = rinfo->channels().size();

	assert(total <= goal);
	if (total >= goal) {
		finish_reconnect();
	}
	return 0;
}

