/**
 * commands/dcc.cc
 *
 * (C) 2006-2008 Murat Deligonul
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 */

#include "autoconf.h"

#include <list>
#include <algorithm>
#include <functional>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <cctype>
#include <unistd.h>
#include <sys/time.h>
#include "util/strings.h"
#include "fs/directory.h"
#include "fs/file_system.h"
#include "fs/entry.h"
#include "logging/chatlog.h"
#include "commands.h"
#include "textline.h"
#include "proxy.h"
#include "dcc.h"
#include "dcc_offer.h"
#include "conn.h"
#include "messages.h"
#include "user.h"
#include "debug.h"

using std::list;
using std::string;
using std::vector;
using namespace util::strings;

/** 
 * DCC Command.
 */
CMDFUNC(dcc)
{
	enum {
		DCC_CMD_LIST = 1,
		DCC_CMD_HELP,
		DCC_CMD_KILL,
		DCC_CMD_INFO,
		DCC_CMD_STORE,
		DCC_CMD_PROXY,
		DCC_CMD_ACCEPT,
	};
	static const struct simple_table cmds[] = {
		{ "list",   DCC_CMD_LIST },
		{ "proxy",  DCC_CMD_PROXY },
		{ "store",  DCC_CMD_STORE },
		{ "info",   DCC_CMD_INFO },
		{ "kill",   DCC_CMD_KILL },
		{ "close",  DCC_CMD_KILL },
		{ "reject", DCC_CMD_KILL },
		{ "get",    DCC_CMD_ACCEPT},
		{ "accept", DCC_CMD_ACCEPT},
		{ "relay",  DCC_CMD_ACCEPT},
		{ "send",   DCC_CMD_ACCEPT},
		{ "help",   DCC_CMD_HELP},
	};

	if (args.empty()) {
		cprintf("DCC: Try `help dcc'\r\n");
		return 1;
	}
	const time_t now = proxy->time();
	const std::list<dcc *>& dcc_list = proxy->dcc_list();
	const std::list<dcc_offer *>& dcc_offer_list = proxy->dcc_offer_list();

	std::list<dcc *>::const_iterator dcc_i = dcc_list.begin(),
					dcc_end = dcc_list.end();
	std::list<dcc_offer *>::const_iterator offer_i = dcc_offer_list.begin(),
						offer_end = dcc_offer_list.end();

	dcc * d = NULL;
	dcc_offer * offer = NULL;
	std::string err;

	int cmd = simple_table_lookup(args[0], (const simple_table *) &cmds,
			sizeof(cmds) / sizeof(struct simple_table));
	int found = 0;


	if (cmd == -1) {
		cprintf("DCC: Unknown command '%s'\r\n", args[0]);
		return 1;
	}

	/**
	 * Valid argument required for these options.
	 */
	if (cmd >= DCC_CMD_KILL) {
		if (args < 2) {
			cprintf("DCC: Usage: DCC %s <dcc id>\r\n", args[0]);
			return 1;
		}

		// verify legal id
		int temp = -1;
		const char * arg_str = args[1];
		if (!check_int(arg_str, &temp) || temp < 0) {
			cprintf("DCC: invalid ID: %s\r\n", arg_str);
			return 1;	
		}
		if (lookup_dcc_by_id(this, unsigned(temp), &d, &offer) != 0) {
			cprintf("DCC: ERROR: Invalid id `%s'\r\n", args[1]);
			return 1;
		}
	}

	/**
	 * Figure out some configuration settings first.
	 */
	const bool can_store = is_allowed(user_perms::ENABLE_DCC_STORAGE);
	const bool can_proxy_in = is_allowed(user_perms::ENABLE_INCOMING_DCC_PROXYING);
	const bool can_proxy_out = is_allowed(user_perms::ENABLE_OUTGOING_DCC_PROXYING);

	switch (cmd) {
	/** 
	 * List active dccs and offers.
	 */
	case DCC_CMD_LIST:
		cprintf("Active DCC \002Sessions\002 for %s\r\n", addr());
		cprintf("\002ID\002    \002Info\002                                     \002Age\002\r\n");
		cprintf("-------------------------------------------------------------------------\r\n");
		for (; dcc_i != dcc_end; ++dcc_i) {
			d = *dcc_i;
			if (d->owner() != this || d->status_check(0,0) < 0) {
				continue;
			}
			const string& info = d->info();
			cprintf("%-5d %-40s %d secs\r\n", d->id(), info.c_str(), d->age(now));
			++found;
		}
		if (!found) {
			cprintf("-- No active DCC sessions found for you --\r\n");
		}
		found = 0;
		/* print the offers now */
		cprintf("-\r\n");

		cprintf("Active DCC \002Offers\002 for %s\r\n", addr());
		cprintf("\002ID\002    \002Info\002                                     \002Age\002\r\n");
		cprintf("-------------------------------------------------------------------------\r\n");
		for (; offer_i != offer_end; ++offer_i) {
			offer = *offer_i;
			if (offer->owner() != this || offer->status_check(0,0) < 0) {
				continue;
			}

			const string& info = offer->info();
			cprintf("%-5d %-40s %d secs\r\n", offer->id(), info.c_str(), offer->age(now));
			++found;
		}

		if (!found) {
			cprintf("-- No active DCC offers found for you --\r\n");
		}
		break;

	/**
	 * Store a DCC offer locally, in the VFS.
	 */
	case DCC_CMD_STORE:
	{
		if (!offer) {
			cprintf("DCC: I can only store DCC \002offers\002\r\n");
			return 1;
		} 
		if (offer->status_check(0,0) < 0) {
			cprintf("DCC: Invalid offer\r\n");
			return 1;
		}
		if (!can_store) {
			cprintf("DCC: Sorry, you are not allowed to store files.\r\n");
			return 1;
		}

		if (strcasecmp(offer->type(), "SEND") != 0) {
			cprintf("DCC: I can only store DCC Sends\r\n");
			return 1;
		}

		/**
		 * Create a new file and start the DCC Get.
		 * Note that receive_dcc_offer() does the necessary checks to ensure
		 * VFS access permissions, etc.
		 */
		dccget * get = receive_dcc_offer(offer, err);
		if (!get) {
			cprintf("DCC: Error: couldn't receive file '%s' (error: %s)\r\n",
					offer->filename(), err.c_str());
			return 1;
		}
		offer->die(0, NULL);
		// new dcc object automatically added to a global list
		break;
	}

	/**
	 * Proxy a DCC offer.
	 */
	case DCC_CMD_PROXY:
	{
		if (!offer) {
			cprintf("DCC: I can only proxy DCC \002offers\002\r\n");
			return 1;
		}

		const bool is_incoming = offer->flags() & dcc_offer::INCOMING;
		const bool is_outgoing = offer->flags() & dcc_offer::OUTGOING;

		if ((is_incoming && !can_proxy_in)
			|| (is_outgoing && !can_proxy_out)) {
			cprintf("DCC: Sorry, you are not allowed to use DCC proxying\r\n");
			return 1;
		}
		if (is_outgoing && !is_bounced()) {
			cprintf("DCC: Not connected to IRC\r\n");
			return 1;
		}
		if (strcasecmp(offer->to(), "(ezbounce)") == 0) {
			cprintf("DCC: Cannot proxy a dcc to myself\r\n");
			return 1;
		}

		dccpipe * dp = proxy_dcc_offer(offer, err);
		if (!dp) {
			cprintf("DCC: ERROR: couldn't setup proxying (error: %s)\r\n", err.c_str());
			return 1;
		}
		offer->die(0, 0);
		// new dccproxy session automatically added to global list
		break;
	}

	/**
	 * Kill a DCC or a DCC Offer.
	 */
	case DCC_CMD_KILL:
		if (offer) {
			offer->die(dcc::DCC_USER_KILL, "");
		} 
		else {
			d->die(dcc::DCC_USER_KILL, "");
		}
		cprintf("DCC: Killed DCC/offer #%s\r\n", args[1]);
		break;

	/**
	 * Accept/relay a DCC offer.
	 */
	case DCC_CMD_ACCEPT:
		if (!offer) {
			cprintf("DCC: I can only accept DCC \002offers\002\r\n");
			return 1;
		}
		if (strcasecmp(offer->to(), "(ezbounce)") == 0) {
			cprintf("DCC: Use `dcc store %s' if you want to store a file\r\n", args[1]);
			return 1;
		}
		if ((offer->flags() & dcc_offer::OUTGOING) && !is_bounced()) {
			cprintf("DCC: Not connected to IRC\r\n");
			return 1;
		}

		if (relay_dcc_offer(offer, offer->to(), err) != 0) {
			cprintf("DCC: Unable to relay offer (error: %s)\r\n", err.c_str());
			return 1;
		}
		cprintf("DCC: Relayed %s offer %d from %s to %s\r\n",
			offer->type(), offer->id(), offer->from(), offer->to());
		offer->die(0, 0);
		break;

	/**
	 * Display information on a DCC or an offer.
	 */
	case DCC_CMD_INFO:
	{
		cprintf("\002Information\002 for DCC/Offer %s\r\n", args[1]);
		const string& info = offer ? offer->full_info() : d->full_info();
		cprintf_multiline(info.c_str());
		break;
	}

	/**
	 * Display help.
	 */
	case DCC_CMD_HELP:
		cprintf_multiline(__HELP_ENTRY(dcc));
		break;
	}
	return 1;
}

