/**
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * commands/basic.cc
 * (c) 2007-2008 Murat Deligonul
 */

#include "autoconf.h"

#include <vector>
#include <string>
#include <list>
#include <cstdlib>
#include "util/tokenizer.h"
#include "irc/address.h"
#include "irc/cache.h"
#include "irc/rfc1459.h"
#include "fs/error.h"
#include "net/error.h"
#include "conn.h"
#include "commands.h"
#include "textline.h"
#include "proxy.h"
#include "messages.h"
#include "debug.h"

using std::list;
using std::string;
using std::vector;

using namespace util::strings;

/** 
 * Command functions below.
 * Type: int conn::do_XXX_cmd(int type, textline& args)
 *       .. or CMDFUNC(XXX)
 *
 * Return:
 *    0 - Unhandled, relay to IRC server
 *    1 - Handled properly
 *   -1 - Handled, but destroy object immediately
 */

/* int */ CMDFUNC(registration) /* (int type, textline& args) */
{
	switch (type) {
	case CMD_USER:
		/* Check for non-blank non-whitespace valid arguments */
		if (args == 0) {
			return 1;
		}
		strings.set(USERCMD, args.all());
		setf(USERED);
		break;	

	case CMD_NICK:
		if (args == 0) {
			return 1;
		}

		// prevent multiple NICK commands before login
		if (checkf(NICKED) && !(checkf(USERED) && is_logged_in())) {
			return 1;
		}
	
		// check legality
		const char * nick = args[0];
		if (!irc::is_legal_nick(nick)) {
			// :ircd.lagged.org 432 druglord $$$ :Erroneous Nickname
			const char * orig = checkf(NICKED) ? irc->nick() : "*";
			client->printf(":%s 432 %s %s :Erroneous Nickname\r\n", EZBOUNCE_HEADER, orig, nick);
			return 1;
		}

		irc->set_nick( args[0] );

		// if user is already logged in, display his updated nick
		if (checkf(NICKED)) {
			assert(checkf(USERED) && is_logged_in());
			client->printf(":%s!%s@%s NICK :%s\r\n", irc->nick(), user()->name(), client->peer_addr(), nick);
			return 1;
		}

		// first NICK
		setf(NICKED);
	}

	if (checkf(USERED) && checkf(NICKED)) {
		/* Got password? */
    		if (!is_logged_in()) {
			greet_client();
		}
		/* Yes, we have password */
		else {
			greet_login();
		}
	}
	return 1;
}


CMDFUNC(login)
{
	using std::string;
	string params[2];	/* store login and password */
	int as_ptr = 2;
	
	if (args == 0) {
		return 1;
	}
	
	if (type == CMD_PASS) {
		// check if login & password have been provided in the 
		// combined, colon-separated format
		tokenize(args[0], ":", &params[0], 2);
		if (!params[1].empty()) {
			as_ptr = 1;
		} 
		else {
			/* FIXME: this is an error condition. */
			return 1;
		}
	} 
	else {
		if (args < 2) {
			return 1;
		}
		params[0] = args[0];
		params[1] = args[1];
	}


	int i = auth.login_connection(this, params[0].c_str(), params[1].c_str());
	if (i == auth.SUCCESS) {
		i = auth.register_connection();
	}
	const int max_failed = proxy->config().get<int>(proxy_config::MAX_FAILED_PASSWORDS);

	/** unable to login, check reasons **/
	switch (i) {
	case authorizer::ERR_BAD_PASSWORD:
	case authorizer::ERR_UNKNOWN_USER: 
        	cprintf("LOGIN: \002Incorrect\002 user/password combination.\r\n");
        	proxy->printlog("Authenticaton failure: user '%s' from %s\n", params[0].c_str(), addr());

        	if (++failed_passwords >= max_failed && max_failed > 0)	{
            		cprintf(MSG_TOO_MANY_FAILURES);
            		proxy->printlog("... disconnecting client for too many failed login attempts!\n");
            		return -1;
        	}
		return 1;
	
	case authorizer::ERR_NO_MATCH:
        	cprintf("No authorization.\r\n");
        	proxy->printlog("Connection Denied: Connection from %s: No authorization\n", addr());
		return -1;
	
	case authorizer::ERR_NOT_ALLOWED:
		cprintf(MSG_BANNED, auth.get(auth.FAILURE_REASON), auth.get(auth.FAILURE_REASON));	
		proxy->printlog("Connection Denied: from %s on port %d (%s)\n", addr(), client->local_port(), auth.get(authorizer::FAILURE_REASON));
		auth.logout_connection(this);
		return -1;
		
	case authorizer::SUCCESS:
		break;
	default:
		DEBUG("conn::do_login_cmd():  unknown handler for register_connection() return value\n");
		abort();		
	}

	/**
	 * Ready to go.
	 * NOTE: in the past admins' ruleset lists would be cleared
 	 * we don't do this anymore (instead we don't bother w/ checking 
	 * rulesets on outgoing connection attempts) 
	 */
	int err = 0;
	key = user()->create_fs_key(&err); 

	if (key == NULL) {
		cprintf("Unable to setup VFS access for you: %s\r\n", fs::strerror(err));
	}

	setf(LOGGED_IN);

	/* Auto server: */
	const char * auto_server = args[as_ptr];
	if (is_non_empty(auto_server)) {
		user()->options()->set<string>(user_config::AUTO_SERVER, auto_server);
	}

	if (checkf(USERED) && checkf(NICKED)) {
		greet_login();
	}
	return 1;
}

/**
 *  The /conn command 
 */
CMDFUNC(conn)
{
	const char * port = NULL;
	const char * pass = NULL;
	int i = 0, inssl = 0;
	unsigned short p = 6667;
	
	if (args == 0) {
		cprintf(MSG_INSUFFICIENT_ARGS, "CONN");
		return 1;
	}

	if (is_reconnecting()) {
		cprintf("error: a reconnect attempt is already in progress\r\n");
		cprintf("error: use '/ezb cancel' to cancel it\r\n");
		return 1;
	}
	if (strcasecmp("-ssl", args[i]) == 0) {
		if (args < 2) {
			cprintf(MSG_INSUFFICIENT_ARGS, "CONN");
			return 1;
		}
		inssl=1;
		i++;
	}
	if (args > (i+1)) {  /* we have a port */
		port = args[i+1];
		p = (unsigned short) atoi(port);
		if (!p) {
			p = 6667;
		}
	}
	
	pass = args[i + 2];

	// we can now try to connect.. 
	setup_connect(args[i], p, pass, inssl);

	const string& vhost = user()->options()->get<string>(user_config::VHOST);
	cprintf("[\02connecting to\02]: %s port %d\r\n", args[i], p);
	if (!vhost.empty()) {
		cprintf("[\02vhost\02]:         %s\r\n", vhost.c_str());
	}
#ifdef HAVE_SSL
	if (inssl) {
		cprintf("[\02ssl\02]:           yes\r\n");
	}
#endif
	cprintf("Use `/quote cancel' to abort\r\n");

	string msg = my_sprintf("IRC Connection Attempt: %s to %s port %d"
#ifdef HAVE_SSL
			" %s"
#endif
			"\n", addr(), args[i], p
#ifdef HAVE_SSL
			,(inssl ? "(using ssl)" : "")
#endif
		);
	proxy->printlog("%s", msg.c_str());
	user()->printlog("%s", msg.c_str());
	return 1;
}

/**
 * VHOST & INTERFACE commands.
 */
CMDFUNC(vhost)
{
	if (!is_allowed(user_perms::ENABLE_VHOST_COMMAND)) {
		cprintf("This command has been disabled here.\r\n");
		return 1;
	}
	if (args == 0) {
		/**
		 * No arguments given: set vhost to default
		 * interface
		 */
		user()->options()->set<string>(user_config::VHOST, "0.0.0.0");
		cprintf("VHOST: Set vhost to default interface\r\n");
		return 1;
	}
	/**
	 * Arguments given: check if the vhost exists in the table
	 * and then set it if so
	 * (ignore what's in the table for admin)
	 */
	std::vector<string>::const_iterator i = proxy->vhost_list().begin(),
	       				 e = proxy->vhost_list().end();
	if (!is_admin()) {
		for (; i != e; ++i) {
			const string& s = *i;
			const char * str = s.c_str();
			if (strcasecmp(str, "all") == 0 || strcasecmp(str, args[0]) == 0) {
				goto found;
			}
		}

		if (user()->vhosts().size() > 0) {
			i = user()->vhosts().begin();
			e = user()->vhosts().end();
			for (; i != e; ++i) {
				const string& s = *i;
				const char * str = s.c_str();
				if (strcasecmp(str, "all") == 0 || strcasecmp(str, args[0]) == 0) {
					goto found;
				}
			}
		}
		cprintf("Host is on not on my vhost list.\r\n");
		return 1;
	}


found:	
	user()->options()->set<string>(user_config::VHOST, args[0]);
	cprintf("Set your interface to: %s\r\n", args[0]);
	return 1;
}

CMDFUNC(vhosts)
{
	if (!is_allowed(user_perms::ENABLE_VHOST_COMMAND)) {	
		cprintf("This command has been disabled here.\r\n");
		return 1;
	}
	cprintf("Available interfaces:\r\n");

	int n = 0;
	std::vector<string>::const_iterator i = proxy->vhost_list().begin(),
					  e = proxy->vhost_list().end();

	for (; i != e; ++i) {
		cprintf("%d) %s\r\n", ++n, (*i).c_str());
	}
	if (user()->vhosts().size() > 0) {
		i = user()->vhosts().begin();
		e = user()->vhosts().end();
		for (; i != e; ++i) {
			cprintf("%d) %s\r\n", ++n, (*i).c_str());
		}
	}
	cprintf("End of list.\r\n");
	return 1;
}


/**
 * Disconnect from the IRC server, also canceling any
 * active reconnection attempts.
 */
CMDFUNC(disconnect)
{
	if (is_bounced()) {
		const bool want_part_all = decide<server_node>(servinfo->server_target(), 
				irc_server_config::PART_ON_DISCONNECT) == 1;
		if (want_part_all) {
			show_part_all();
		}
	}

	abort_reconnect();
	server_lost();
	cprintf("OK, broke your connection to the IRC server.\r\n");
	proxy->printlog("IRC Disconnect: %s from IRC server by his request.\n", addr());
	user()->printlog("IRC Disconnect: %s from IRC server (by own request)\n", addr());
	return 1;
}

/*
 * Set a fake ident.
 */
CMDFUNC(ident)
{
	if (!is_allowed(user_perms::ENABLE_FAKE_IDENTS)) {
		cprintf("Sorry, fake idents have been disabled here.\r\n");
		return 1;
	}

	if (args > 0) {
		user()->options()->set<string>(user_config::FAKE_IDENT, args[0]);
		cprintf("Ok, set your fake ident to %s\r\n", args[0]);
	} 
	else {
		cprintf(MSG_INSUFFICIENT_ARGS, "IDENT");
	}
	return 1;
}

/**
  * Cancel a connection attempt (or a reconnection)
  */
CMDFUNC(cancel)
{
	if (is_reconnecting()) {
		cprintf("OK, Canceling reconnection...\r\n");
		abort_reconnect();
	}
	if (is_connecting()) {
		server->on_connect_fail(net::ERR_CONN_ABORTED);
	}
	return 1;
}

CMDFUNC(kill)
{
	int arg = 0;    	// where the id is
	bool want_kill = true;   // force detach or kill?

	/* force a detach ? */
	if (args > 0 && !strcasecmp(args[0], "-d")) {
		want_kill = false;
		arg = 1;
	}

	if (args < 1 || (!want_kill && args < 2)) {
		return cprintf("Usage: /quote ezb kill [-d] <id> [reason/password]\r\n"), 1;
	}
	
	conn * victim = conn::lookup(args[arg]);
	if (victim == NULL) {
		cprintf("KILL: Error: couldn't find id `%s'\r\n", args[arg]);
		return 1;
	}

	const char * reason = args.get_rest(arg+1);
	unsigned int i = victim->id();

	/* sanity checks .. */
	if (!is_admin() && (!victim->user() ||
				userdef::namecmp(this->user()->name(), victim->user()->name()))) {
		cprintf("KILL: Error: couldn't find id `%d'\r\n", i);
		return 1;
	}
	if (victim->is_dead()) {
		cprintf("KILL: Error: user id `%d' is a zombie\r\n", i);
		return 1;
	}

	/** forced detaches **/
	if (!want_kill) { 
		if (victim->is_detached()) {
			cprintf("KILL: Error: user id `%d' is already detached!\r\n", i);
			return 1;
		}
		if (!victim->is_bounced()) {
			cprintf("KILL: Error: user id '%d' is not connected to IRC!\r\n", i);
			return 1;
		}
		if (!is_allowed(user_perms::ENABLE_DETACH_COMMAND)) {
			cprintf("KILL: Error: you are not allowed to detach!\r\n");
			return 1;
		}

		proxy->printlog("Client Detached: %s has forced detach on %s\r\n", addr(), victim->addr());
		cprintf("Forcing detach for user id `%d' (%s)\r\n", i, victim->addr());
		victim->cprintf("\002You have been forcefully detached by %s\002\r\n", user()->name());
		victim->detach();
		return 1;
	}

	cprintf("Killed user '%d' (%s)\r\n", i, victim->addr());
	proxy->printlog("Client Killed: %s killed by %s: %s\n", victim->addr(), addr(), reason);

	victim->cprintf("\002You were killed by %s\002\r\n", user()->name());
	if (victim == this) {
		return -1;		
	}
	victim->die(KILLED, reason);

	return 1;
}


/**
 * Sessions [username] -- list all detached connections for
 * a particular user 
 */
CMDFUNC(sessions)
{
	userdef * u;
	int idx = 0;
	bool hShown = 0;

	/* Argument specified ... show sessions for a user.. only
	 * if we are admin though */
	if (args > 0) {
		if (is_admin()) {
			userdef::hash_table_t::iterator i = proxy->users().find(args[0]);
			if (i == proxy->users().end()) {
				cprintf("SESSIONS: unknown user `%s'\r\n", args[0]);
				return 1;
			}
			u = (*i).second;
		}
		else {
			cprintf("SESSIONS: you must be admin to view sessions for other proxy->users()\r\n");
			return 1;
		}
	} 
	else {
		u = this->user();
	}

	for (std::list<conn *>::const_iterator i = u->conns().begin(), 
					       e = u->conns().end();
					       	i != e; 
						++i) {
		conn * c = *i;
		if (c->is_detached()) {
			std::string timebuff;
			if (!hShown) {
				cprintf("Current detached sessions for user %s:\r\n", u->name());
				cprintf("#   IRC NICK             TO                   TIME      REAL ID\r\n");
				hShown = 1;
			}
			duration(timebuff, proxy->time() - c->detach_time, false);
			cprintf("%-3d %-20s %-20s %-9s %d\r\n", ++idx, c->irc->nick(), 
					c->strings[SERVER].c_str(), timebuff.c_str(), c->id());
		}
	}
	if (!hShown) {
		cprintf("No detached sessions found for %s\r\n", u->name());
	}
	return 1;
}


CMDFUNC(detach)
{
	/* We'll check for this here, to be more user-friendly */
	if (!is_allowed(user_perms::ENABLE_DETACH_COMMAND)) {
		cprintf("detach: Sorry, this command has been disabled here\r\n");
		return 1;
	}
	if (!is_bounced() && !is_reconnecting()) {
		cprintf("detach: you must be connected to an IRC server first ...\r\n");
		return 1;
	}

	if (detach() < 0) {
		cprintf("Detach failed!\r\n");
	}
	return 1;
}


CMDFUNC(reattach)
{
	if (!is_allowed(user_perms::ENABLE_DETACH_COMMAND)) {
		cprintf("Sorry, the detach/reattach commands have been disabled here\r\n");
		return 1;
	}
	
	int id_arg = 0;
	unsigned int target;
	bool force = false;

	// real id vs. session number
	bool want_real = false;
	const char * id_type = "session number";
	
	while (args[id_arg] != NULL) {
		const char * opt = args[id_arg];
		if (strcasecmp(opt, "--force") == 0) {
			force = true;
		}
		else if (strcasecmp(opt, "--real-id") == 0 || 
				strcasecmp(opt, "-r") == 0) {
			want_real = true;
			id_type = "connection ID";
		}
		else {
			break;
		}
		++id_arg;		
	}

	// Extract id (session # or real) -- check bounds, legality of argument
	if (args > id_arg) {
		int temp = -1;
		const char * arg_str = args[id_arg];
		if (!check_int(arg_str, &temp) || temp < 0) {
			cprintf("REATTACH: invalid ID: %s\r\n", arg_str);
			return 1;		
		}

		target = temp;
	}
	else {
		// no argument provided -- not legal for real id 
		if (want_real) {
			cprintf("REATTACH: must specify ID when using -r (or --real-id) option\r\n");
			return 1;
		}
		target = 1;
	}
	
	/* Find it in the list */
	unsigned int ctr = 0;
	userdef * u = user();
	std::list<conn *>::const_iterator i = u->conns().begin(),
						e = u->conns().end();
	for (; i != e; ++i) {
		conn * c = *i;
		if (!want_real && !c->is_detached()) {
			continue;
		}

		const bool matches = want_real ? (c->id() == target) :
						(++ctr == target);
						
		if (matches) {
			if (validate_reattach(c, force) < 0) {
				return 1;
			}
			if (reattach(c) < 0) {
				cprintf("REATTACH: Reattach attempt to %s '%d' failed!\r\n", id_type, target); 
			}
			return 1;
		}
	}
	cprintf("REATTACH: Could not find %s %d: try `sessions' to list current detached sessions\r\n", id_type, target);
	return 1;
}

