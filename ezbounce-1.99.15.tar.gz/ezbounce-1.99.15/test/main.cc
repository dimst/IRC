/**
 * Testing code.
 */
#include "autoconf.h"

#undef NDEBUG

#include <cstdio>
#include <cstdlib>
#include "util/hash.h"

extern int do_irc_test(int, char **);
extern int do_fs_test(int, char **);

typedef int (*test_cmd_handler_t)(int, char **);

typedef util::hash_table<const char *, test_cmd_handler_t> cmd_hash_t;

static void setup_cmds(cmd_hash_t& table)
{
	table.insert("irc", &do_irc_test);
	table.insert("fs", &do_fs_test);
}

static void usage(const char * exe)
{
	fprintf(stderr, "usage: %s: <test name> [params]\n"
		 	"\n"
			"Available tests:\n"
			"irc\n"
			"fs\n", exe);
}


int test_main(int argc, char ** argv)
{
	cmd_hash_t	hash(7);

	setup_cmds(hash);
	srand(time(NULL));

	if (argc == 1) {
		usage(argv[0]);
		return 1;
	}

	cmd_hash_t::iterator i = hash.find(argv[1]);
	if (i == hash.end()) {
		fprintf(stderr, "unknown test: %s\n", argv[1]);
		return 1;
	}
	return (i->second)(argc - 2, &argv[2]);
}

int do_fs_test(int, char **)
{
	return 0;
}
