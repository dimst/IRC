/**
 * Tests for the IRC-related code.
 */
#include "autoconf.h"

#undef NDEBUG

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <cstdio>
#include <cstdlib>
#include <boost/test/minimal.hpp>
#include <boost/timer.hpp>
#include <boost/progress.hpp>
#include "irc/cache.h"
#include "irc/server_info.h"
#include "irc/address.h"
#include "irc/message.h"
#include "irc/flood.h"
#include "irc/ignore.h"
#include "textline.h"

using namespace std;

using irc::address_cache;
using irc::server_info;
using irc::address;

using util::hash_stats;

/**
 * Print hash stats.
 */
static void print_hash_stats(const char * name, const hash_stats * h)
{
	printf("%s stats:\n"
		"\tbuckets..........: %d\n"
		"\tbuckets_in_use...: %d (%.2f%%)\n"
		"\tentries..........: %d (%.2f / bucket)\n"
		"\tsize[0]..........: %d (%.2f%%)\n"
		"\tsize[1]..........: %d (%.2f%%)\n"
		"\tsize[2]..........: %d (%.2f%%)\n"
		"\tsize[3]..........: %d (%.2f%%)\n"
		"\tsize[4+].........: %d (%.2f%%)\n",
			name,
			h->buckets,
			h->buckets_in_use,
			(float) h->buckets_in_use / h->buckets * 100,
			h->size, 
			(float) h->size / h->buckets_in_use,
			h->sizes[0], (float) h->sizes[0] / h->buckets * 100,
			h->sizes[1], (float) h->sizes[1] / h->buckets * 100,
			h->sizes[2], (float) h->sizes[2] / h->buckets * 100, 
			h->sizes[3], (float) h->sizes[3] / h->buckets * 100,
			h->sizes[4], (float) h->sizes[4] / h->buckets * 100);
}

/** 
 * Print hash table statistics and such.
 */
static void print_stats(const address_cache * c)
{
	util::hash_stats h1, h2;
	c->stats(&h1, &h2);
	print_hash_stats("nick_hash", &h1);
	print_hash_stats("channel_hash", &h2);
}

/**
 * How many digits in this number?
 * (There must be a more elegant way of doing this)
 */
int numdigits(int num)
{
	char buff[50];
	snprintf(buff, sizeof buff, "%d", num);
	return strlen(buff);
}

void randchars(char * buff, size_t s, char min = '$', char max = '~')
{
	assert(s > 0);
	assert(min <= max);
	const int range = max - min;

	for (unsigned i = 0; i < s-1; ++i)
	{
		buff[i] = min + (rand() % range);
	}

	buff[s-1]=0;
}

/**
 * Load an arbitrary number of random channels.
 */
static void load_channels(address_cache * c, unsigned num, vector<string>& out)
{
	out.reserve(num);
	for (unsigned i = 0; i < num; ++i) {
		char buff[10];
		ostringstream os;
		randchars(buff, sizeof buff);
		os << "#" << buff << "-" << i;
	
		const string& chan = os.str();
		out.push_back(chan);
		c->add_channel(chan.c_str());
	}
}

/**
 * Generate arbitrary number of random nicks.
 */
static void generate_nicks(unsigned num, unsigned nicklen, vector<address>& out)
{
	out.reserve(num);
	unsigned digitslen = numdigits(num);
	unsigned randlen = nicklen - digitslen;

	assert(randlen + digitslen == nicklen);

	char tmp[40];
	char nick[40];
	char user[100];
	char host[100];

	for (unsigned i = 0; i < num; ++i) {
		// generate nickname
		randchars(tmp, randlen, 'a', '}');
		snprintf(nick, sizeof nick, "%s%u", tmp, i);

		randchars(user, 10, 'a', 'z');
		randchars(host, 50, 'a', 'z');
		
		out.push_back(address(nick, user, host));
	}
}

/**
 * Load nicks randomly into channels.
 */
static void load_nicks(address_cache * c, const vector<string>& chans, const vector<address>& nicks)
{
	const size_t num_chans = chans.size();
	const size_t num_nicks = nicks.size();

	for (unsigned i = 0; i < num_nicks; ++i) {
		const string& rand_chan = chans[rand() % num_chans];

		int ret = c->add_entry(&nicks[i], rand_chan.c_str());

		BOOST_REQUIRE(ret == 0);
	}
}

/**
 * Test performance with insane amounts of nicks and channels.
 */
static void do_stress_test1()
{
	server_info s_info("testing_server");
	address_cache cache(&s_info, 7);


	// Test #1
	const unsigned NUM_CHANS = 25000;
	vector<string> channels;
	printf("* About to create %d channels\n", NUM_CHANS);
	load_channels(&cache, NUM_CHANS, channels);

	BOOST_REQUIRE(cache.num_channels() == NUM_CHANS);

	// populate these channels with random users
	const unsigned NUM_NICKS = 500000;
	vector<address> nicks;
	generate_nicks(NUM_NICKS, s_info.get_nick_len(), nicks);

	{
		printf("* About to load %d nicks\n", NUM_NICKS);
		boost::progress_timer t;
		load_nicks(&cache, channels, nicks);
	}

	BOOST_REQUIRE(cache.num_nicks() == NUM_NICKS);

	// cleanup
	print_stats(&cache);
}

/**
 * Test basic error checking features of the cache.
 */
static void do_legality_test1()
{
	server_info s_info("testing_server");
	address_cache cache(&s_info, 7);

	printf("* Starting test: legality1 *\n");

	// check duplicate channel joining	
	BOOST_CHECK(cache.add_channel("#test") == 0);
	BOOST_CHECK(cache.add_channel("#test") != 0);
	BOOST_CHECK(cache.add_channel("#murat") == 0);
	BOOST_CHECK(cache.add_channel("#murat") != 0);

	BOOST_CHECK(cache.num_channels() == 2);

	// test channel parting
	BOOST_CHECK(cache.delete_channel("#test") == 0);
	BOOST_CHECK(cache.delete_channel("#dummy") != 0);
	BOOST_CHECK(cache.delete_channel("#test") != 0);
	BOOST_CHECK(cache.delete_channel("") != 0);

	BOOST_CHECK(cache.num_channels() == 1);

	// join #test again
	BOOST_CHECK(cache.add_channel("#test") == 0);

	// try adding illegal channels
	BOOST_CHECK(cache.add_channel("bad_channel") != 0); 
	BOOST_CHECK(cache.add_channel("") != 0); 
	BOOST_CHECK(cache.add_channel("_") != 0); 

	// try adding bogus nicks
	BOOST_CHECK(cache.add_nick("12345", "#test") != 0);	
	BOOST_CHECK(cache.add_nick("asdfasdfasdfasdfsdafasdfasfdfa", "") != 0);	
	BOOST_CHECK(cache.add_nick("$", "") != 0);

	// add legal nick to legal channels
	address murat("murat!~testing@some.leet.domain.com");

	BOOST_CHECK(cache.add_entry(&murat, "#test") == 0);
	BOOST_CHECK(cache.add_entry(&murat, "#murat") == 0);
	BOOST_CHECK(cache.delete_nick(murat.nick(), "#murat") == 0);
	BOOST_CHECK(cache.lookup_nick("murat") != NULL);

	// legal nick to bogus channels
	BOOST_CHECK(cache.delete_nick(murat.nick(), "#murat") != 0);
	BOOST_CHECK(cache.delete_nick(murat.nick(), "unknown") != 0);
	BOOST_CHECK(cache.delete_nick(murat.nick(), "#bad_channel") != 0);
	BOOST_CHECK(cache.add_entry(&murat, "bad_channel") != 0);
	BOOST_CHECK(cache.add_entry(&murat, "#not_on_here") != 0);
	BOOST_CHECK(cache.lookup_nick("murat") != NULL);

	// alternate add method
	BOOST_CHECK(cache.add_nick("bob", "#murat", 0) == 0);
	BOOST_CHECK(cache.num_channels() == 2);

	// bind nick for bob
	BOOST_CHECK(cache.set_nick_user_host("bob", "bob", "192.168.1.1") == 0);
	BOOST_CHECK(cache.set_nick_user_host("bob", "bobXXX", "192.168.1.5") == 0);
	BOOST_CHECK(cache.set_nick_user_host("bad_user", "bob", "192.168.1.1") != 0);
	BOOST_CHECK(cache.lookup_nick("bob")->has_user_host());
	BOOST_CHECK(strcmp(cache.lookup_nick("bob")->user(), "bobXXX") == 0);
	BOOST_CHECK(strcmp(cache.lookup_nick("bob")->host(), "192.168.1.5") == 0);

	// attempt to change names
	BOOST_CHECK(cache.lookup_nick("murat") != NULL);
	BOOST_CHECK(cache.change_nick("murat", "murat99") == 0);
	BOOST_CHECK(cache.change_nick("murat", "murat99") != 0);
	BOOST_CHECK(cache.change_nick("murat99", "murat1") == 0);
	BOOST_CHECK(cache.change_nick("murat1", "MURAT1") == 0);
	BOOST_CHECK(cache.change_nick("MURAT1", "murat99") == 0);

	// same nick, diff case is OK
	BOOST_CHECK(cache.change_nick("murat99", "MuRaT99") == 0);
	BOOST_CHECK(cache.change_nick("MuRaT99", "MURAT99") == 0);
	BOOST_CHECK(cache.change_nick("MuRaT99", "murat99") == 0);

	// bogus nick changes
	BOOST_CHECK(cache.change_nick("murat99", "this_nick_is_too_long_for_standard_irc") != 0);
	BOOST_CHECK(cache.change_nick("murat99", "$$$") != 0);
	BOOST_CHECK(cache.change_nick("murat99", "5asdf") != 0);
	BOOST_CHECK(cache.change_nick("murat99", "!^^^") != 0);
	BOOST_CHECK(cache.change_nick("murat99", "bob") != 0);
	BOOST_CHECK(cache.change_nick("murat99", "BOB") != 0);
	BOOST_CHECK(cache.change_nick("murat99", "") != 0);
	BOOST_CHECK(cache.change_nick("murat99", "murat99\003") != 0);

	// part all channels, ensure no one is left
	BOOST_CHECK(cache.delete_channel("#murat") == 0);
	BOOST_CHECK(cache.delete_channel("#test") == 0);
	BOOST_CHECK(cache.delete_channel("#test") != 0);
	BOOST_CHECK(cache.num_channels() == 0);
	BOOST_CHECK(cache.num_nicks() == 0);

	// 100 random users
	const unsigned NUM_NICKS = 100;
	vector<address> nicks;
	generate_nicks(NUM_NICKS, s_info.get_nick_len(), nicks);

	vector<string> channels;
	channels.push_back("#testing");
	// join the channel
	cache.add_channel("#testing");	
	load_nicks(&cache, channels, nicks);

	BOOST_CHECK(cache.num_channels() == 1);
	BOOST_CHECK(cache.num_nicks() == NUM_NICKS);
	BOOST_CHECK(cache.lookup_channel("#testing")->population() == NUM_NICKS);
	BOOST_CHECK(cache.delete_channel("#testing") == 0);
	BOOST_CHECK(cache.num_channels() == 0);
	BOOST_CHECK(cache.num_nicks() == 0);

	printf("* Test finished: legality1 *\n");
}

/**
 * Legality test #2:
 * Verify behavior of NAMES, MODE, and WHO line parsing.
 */
static void do_legality_test2()
{
	printf("* Starting test: legality2 *\n");
	// TODO: implement
}

/**
 * Legality test #3:
 * Verify correct behavior of different CASEMAPPING modes.
 */

static void do_legality_test3()
{
	printf("* Starting test: legality3 *\n");
	// TODO: implement
}

/**
 * Channel test #1:
 * Verify all member functions of channel class work.
 */
static void do_channel_test1()
{
	printf("* Starting test: channel1 *\n");
	// TODO: implement
}

/**
 * server_info test #1
 * Verify all member functions of server_info class work.
 */
static void do_server_info_test1()
{
	printf("* Starting test: server_info1 *\n");
	// TODO: implement
}

/**
 * irc::address test #1
 * Verify that address class functions.
 */
static void do_address_test1()
{
	printf("* Starting test: address1 *\n");

	// basic cases
	address test1("bob!bob@some.domain.com");
	address test2("BOB9");
	address test3("segfault!~bob@some.network.net");

	BOOST_CHECK(strcmp(test1.nick(), "bob") == 0);
	BOOST_CHECK(strcmp(test1.user(), "bob") == 0);
	BOOST_CHECK(strcmp(test1.host(), "some.domain.com") == 0);
	BOOST_CHECK(test1.has_user_host());

	BOOST_CHECK(strcmp(test2.nick(), "BOB9") == 0);
	BOOST_CHECK(!test2.has_user_host());
	BOOST_CHECK(test2.user() != NULL);
	BOOST_CHECK(test2.host() != NULL);

	BOOST_CHECK(strcmp(test3.nick(), "segfault") == 0);
	BOOST_CHECK(strcmp(test3.user(), "~bob") == 0);
	BOOST_CHECK(strcmp(test3.host(), "some.network.net") == 0);

	// corrupt cases
	address bad1("murat!");
	address bad2("murat!@");
	address bad3("murat!asdfasdf");
	address bad4("!asdfasdf");
	address bad5("badnick!baduser@");
	
	BOOST_CHECK(strcmp(bad1.nick(), "murat") == 0);
	BOOST_CHECK(!bad1.has_user_host());
	BOOST_CHECK(!bad2.has_user_host());
	BOOST_CHECK(!bad3.has_user_host());
	BOOST_CHECK(!bad4.has_user_host());

	printf("* Test finished: address1 *\n");	
}

/**
 * Helper for message tests.
 */
static irc::event mtest(irc::event type, const char * message)
{
	string m = ":some!user@irc.com PRIVMSG murat :";
	m += message;

	textline t(m.c_str());
	string dummy, dummy2, dummy3;

	return irc::extract_ctcp(type, t, 3, dummy, dummy2, dummy3);
}

/**
 * IRC message function test #1
 * Test CTCP extraction function.
 */
static void do_message_test1()
{
	//--------------------------------------------------
	// static const char PRIV_CTCP_1[] = ":some!user@irc.com PRIVMSG murat :\001TIME\001";
	// static const char PRIV_CTCP_2[] = ":some!user@irc.com PRIVMSG murat :\001PING 1340534394\001";
	// static const char PRIV_CTCP_3[] = ":some!user@irc.com PRIVMSG murat :\001ACTION is on fire\001";
	// 
	// static const char DCC_1[] = ":some!user@irc.com PRIVMSG murat :\001DCC SEND file.txt 12345 4444 600000\001";
	// static const char DCC_2[] = ":some!user@irc.com PRIVMSG murat :\001DCC CHAT CHAT 12345 4444\001";
	//-------------------------------------------------- 

	printf("* Starting test: message1 *\n");

	using irc::event;
	using irc::extract_ctcp;

	// valid CTCPs
	BOOST_CHECK(mtest(irc::PUBLIC_PRIVMSG, "\001TIME\001") == irc::PUBLIC_CTCP);
	BOOST_CHECK(mtest(irc::PUBLIC_PRIVMSG, "\001PING xxxx xxxx\001") == irc::PUBLIC_CTCP);
	BOOST_CHECK(mtest(irc::PRIVATE_PRIVMSG, "\001PING xxxx xxxx\001") == irc::PRIVATE_CTCP);

	// DCCs
	BOOST_CHECK(mtest(irc::PRIVATE_PRIVMSG, "\001DCC CHAT CHAT 12345678 1234\001") == irc::DCC);
	BOOST_CHECK(mtest(irc::PRIVATE_PRIVMSG, "\001DCC CHAT CHAT 12345678 1234\001") == irc::DCC);
	
	// CTCP replies
	BOOST_CHECK(mtest(irc::PRIVATE_NOTICE, "\001PING xxxx xxxx\001") == irc::CTCP_REPLY);

	// invalid examples
	BOOST_CHECK(mtest(irc::PUBLIC_PRIVMSG, "\001 \001") == irc::PUBLIC_PRIVMSG);
	BOOST_CHECK(mtest(irc::PUBLIC_PRIVMSG, "\001\001") == irc::PUBLIC_PRIVMSG);
	BOOST_CHECK(mtest(irc::PUBLIC_PRIVMSG, "\001\001\001") == irc::PUBLIC_PRIVMSG);
	BOOST_CHECK(mtest(irc::PUBLIC_PRIVMSG, "\001DCC SEND file.txt 604504 4544 6666\001") == irc::PUBLIC_PRIVMSG);
	BOOST_CHECK(mtest(irc::PUBLIC_NOTICE, "\001PING xxxx xxxx\001") == irc::PUBLIC_NOTICE);
	BOOST_CHECK(mtest(irc::PUBLIC_NOTICE, "\001DCC SEND file.txt 12345678 12345 12345\001") == irc::PUBLIC_NOTICE);


	// completely bogus
	try {
		mtest(irc::JOIN, "\001PING\001");
		BOOST_CHECK(false);
	}
	catch (std::exception& e) {
		BOOST_CHECK(true);
	}

	printf("* Test finished: message1 *\n");
}

/**
 * Test ignore_list functionality.
 *
 * FIXME: expand this test
 */
static void do_ignore_test1()
{
	printf("* Starting test: ignore1 *\n");

	using irc::ignore_list;
	using irc::event_flagset_t;

	ignore_list i;

	i.add("*!*@*", event_flagset_t(1 << irc::PUBLIC_PRIVMSG), ignore_list::IGNORE_FOREVER);

	BOOST_CHECK(i.contains("*!*@*", irc::PUBLIC_PRIVMSG));
	BOOST_CHECK(!i.contains("*!*@*", irc::PRIVATE_CTCP));
	BOOST_CHECK(!i.contains("*!*@invalid.ignore", irc::PUBLIC_PRIVMSG));
	BOOST_CHECK(i.size() == 1);
	BOOST_CHECK(!i.empty());
	
	printf("* Test finished: ignore1 *\n");
}

/**
 * Helper for flood protection tests.
 */
static int flood(irc::flood_protector& f, const char * host, irc::event ev, int m, time_t when)
{
	irc::address addr(host);

	int result = 0;
	for (int i = 0; i < m; ++i) {
		result = f.in(&addr, ev, when);
		if (result != 0) {
			return result;
		}
	}
	return 0;
}

/**
 * Flood protector test.
 */
static void do_flood_test1()
{
	printf("* Starting test: flood1 *\n");

	using irc::ignore_list;
	using irc::flood_protector;
	ignore_list i;
	server_info s_info("testing_server");

	flood_protector f(&s_info, &i, 49); 

	f.set_priv_msg_rate(5, 1);
	f.set_global_priv_msg_rate(10, 3);

	f.set_auto_resp_rate(3, 1);
	f.set_global_auto_resp_rate(5, 3);

	BOOST_CHECK(flood(f, "joe!some@host.com", irc::PRIVATE_PRIVMSG, 3, 10) == 0);
	BOOST_CHECK(flood(f, "joe!some@host.com", irc::PRIVATE_PRIVMSG, 3, 11) == 0);
	BOOST_CHECK(flood(f, "joe!some@host.com", irc::PRIVATE_PRIVMSG, 4, 11) != 0);

	BOOST_CHECK(i.is_ignored("joe!some@host.com", irc::PRIVATE_PRIVMSG, 15) == true);
	BOOST_CHECK(i.is_ignored("joe!some@host.com", irc::PRIVATE_PRIVMSG, 1000) == false);

	BOOST_CHECK(flood(f, "joe!some@host2.net", irc::PRIVATE_CTCP, 2, 15) == 0);
	BOOST_CHECK(flood(f, "joe!some@host2.net", irc::PRIVATE_CTCP, 2, 16) == 0);
	BOOST_CHECK(flood(f, "joe!some@host2.net", irc::PRIVATE_CTCP, 2, 17) != 0);

	f.clear_expired(19);

	printf("* Test finished: flood1 *\n");
}

int do_irc_test(int, char **)
{
	// IRC message function tests
	do_message_test1();

	// ignore list tests
	do_ignore_test1();

	// flood control tests
	do_flood_test1();

	// IRC object tests
	do_address_test1();
	do_channel_test1();
	do_server_info_test1();

	// IRC caching test
	do_legality_test1();
	do_legality_test2();
	do_legality_test3();

	// performance tests
	do_stress_test1();	
	return 0;
}
