/**
 * mdidentd -- an IDENT daemon wrapper that supports user-customizable replies.
 *
 * (C) 2007-2008 Murat Deligonul
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  
 */

#include "autoconf.h"

#include <string>
#include <map>
#include <vector>
#include <utility>
#include <sstream>
#include <cstddef>
#include <cstdlib>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <csignal>
#include <ctime>
#include <cctype>
#include <cassert>
#include <cerrno>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <arpa/inet.h>
#ifdef HAVE_SYS_SELECT_H
#include <sys/select.h>
#endif
#include <sys/wait.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <syslog.h>
#ifdef HAVE_PWD_H
#include <pwd.h>
#endif

#include "util/lib_mdidentd.h"
#include "debug.h"

const char MDIDENTD_VERSION[] = "0.90";

/**
 * These are some constants for mdidentd that you can tweak to your
 * needs. The defaults should be fine for most people.
 */

/**
 * How long do we wait on port 113 (or the domain socket) before the client
 * sends some text? (seconds)
 */

const int CONNECTION_TIMEOUT = 30;

/**
 * How long will fake ident requests live in memory? Should not be more
 * than a minute.
 */

const int FAKE_IDENT_LIFETIME = 60;

/**
 * A fake ident request.
 */
struct request {
	std::string		ident;
	time_t			created;
	unsigned short		peer_port;

	// default constructor
	request() : ident("unknown"), 
			created(0), 
			peer_port(0) { }
};

/** 
 * Type of the open sockets.
 */
enum socket_type {
	NONE = 0,
	UNIX_LISTEN,
	TCP_LISTEN,
	UNIX_CLIENT,
	TCP_CLIENT
};


typedef std::pair<socket_type, time_t>		connection_t;

typedef std::map<unsigned short, request>	ident_map_t;
typedef std::map<int, connection_t>		connection_map_t;

/**
 * Options
 */
struct options {
	unsigned int		hard_limit;
	uid_t			uid;

	int 			listen_fd;
	int			unix_fd;

	int 			num_cmdargs;

	char * 			identd_path;
	char **			identd_args;

	bool			foreground;
	bool			no_real;
};

// options stored here
static struct options options;

static time_t current_time;


/**
 * Prototypes
 */
static int  daemon(bool);

static int  listen(unsigned short);
static int  listen_unix(const char * );

static int  accept(int);
static int  accept_unix(int);

static int  service(int, ident_map_t&);
static int  service_unix(int, ident_map_t&);

static int  reply(int, const char *, ident_map_t&);
static int  start_server();
static int  parse_cmdline(int, char **, struct options *);

static void remove_idle(ident_map_t &);
static void remove_idle(connection_map_t &);
static bool is_real_user(const char *);
   
static void sighandler(int);

int fdprintf(int fd, const char *, ...);


/**
 * Functors to aid with select()
 */
class prepare_fd_set {
	int h;
	fd_set * fds;
public:
	prepare_fd_set(fd_set * f) : 
		h(-1), fds(f) { }

	void operator()(const connection_map_t::value_type& val) {
		int f = val.first;
		FD_SET(f, fds);
		h = std::max(h, f);
	}

	int highest() const {
		return h;
	}
};

/**
 * Handle socket events.
 */
class handle_socket {
	std::vector<int>		expired;
	connection_map_t		_new;
	ident_map_t& 			idents;
	fd_set  *			fds;

public:
	// constructor
	handle_socket(fd_set * f, ident_map_t& imap) : 
		idents(imap), fds(f) { }

	// accessors
	const std::vector<int>& to_remove() const {
		return expired;
	}

	const connection_map_t& to_add() const {
		return _new;
	}
		
	//
	// Handle events for all socket types
	void operator()(const connection_map_t::value_type& val) {
		int fd = val.first;
		socket_type type = val.second.first;

		if (!FD_ISSET(fd, fds)) {
			return;
		}

		int new_fd = -1;
		switch (type) {
		case UNIX_LISTEN:
			new_fd = accept_unix(fd);
			if (new_fd >= 0) {
				_new[new_fd] = connection_t(UNIX_CLIENT, current_time);
			}
			break;
		
		case TCP_LISTEN:
			new_fd = accept(fd);
			if (new_fd >= 0) {
				_new[new_fd] = connection_t(TCP_CLIENT, current_time);
			}
			break;

		case TCP_CLIENT:
			service(fd, idents);
			expired.push_back(fd);
			break;

		case UNIX_CLIENT:
			if (idents.size() < options.hard_limit) {
				service_unix(fd, idents);
			}
			expired.push_back(fd);
			break;

		default:
			// shouldn't get here
			abort();
		}
	}
};

/**
 * Functor to add sockets to map.
 */
class add_to_map {
	connection_map_t& 	target;
public:
	// constructor
	add_to_map(connection_map_t& map) : target(map) { }

	void operator()(const connection_map_t::value_type& val) {
		assert(target.find(val.first) == target.end());
		target[val.first] = val.second;
	}
};

/** 
 * Functor to close file descriptor and remove it from 
 * map.
 */
class remove_from_map {
	connection_map_t& 	target;
public:
	// constructor
	remove_from_map(connection_map_t& map) : target(map) { }

	void operator()(int fd) {
		assert(target.find(fd) != target.end());
		::close(fd);
		target.erase(fd);
	}
};

static void usage() 
{
	printf("mdidentd v%s - Murat Deligonul (murat@linuxftw.com) - (C) 1998-2008\n"
			"\nUsage:\n"
			"mdidentd [-f|-h|-u] <identd> [options]\nWhere:\n"
			"-u <userid>: Setuid to this user after binding sockets\n"
			"-h <number>: Hard limit on number of fake idents (maximum number to store at once)\n"
			"-f:          Stay in foreground\n"
			"-r:          Prevent users from using setting idents that are real users on this machine\n"
			"\n"
			"identd:      The path to your existing ident daemon.\n"
			"               It will be launched by mdidentd if needed\n"                           
			"               This is a required argument.  Try /usr/sbin/in.identd if unsure.\n"
			"options      Optional arguments to pass on to the ident daemon mentioned above\n",
			MDIDENTD_VERSION);
}
     
/**
 * Parse arguments including:
 *   the identd to spawn, and what arguments to give to it
 *   userid to become after getting port
 *   path of domain socket to create
 *   how long to keep custom idents alive.
 *
 * We don't make copies of the stuff in argv but that should be ok
 * for now.
 */
static int parse_cmdline(int argc, char ** argv, struct options * out)
{
	int cmdarg_start = 0;

	// fill in some defaults first
	out->num_cmdargs 	= 0;
	out->foreground  	= false; 
	out->uid 		= 0;
	out->hard_limit 	= INT_MAX;
	out->identd_args 	= NULL;

	out->listen_fd		= -1;
	out->unix_fd		= -1;

	if (argc < 2) {
		usage();
		return -1;
	}

	for (int y = 1; y < argc; ++y) {
		switch (argv[y][0]) {
		case '-':
			switch (argv[y][1]) {
			case 'r':
				out->no_real = true;
				break;

			case 'f':
				out->foreground = true;
				break;

			case 'u':
				char * id;
				id = argv[y+1];
				if (!id) {
					fprintf(stderr, "Option '-u' requires numeric user id to follow it\n");
					exit(1);
				}
				out->uid = (uid_t) atoi(id);
				++y;
				break;

			case 'h':
				id = argv[y+1];
				if ((!id) || !(out->hard_limit = (unsigned) atoi(id))) {
					fprintf(stderr, "Option '-h' requires a number greater than 0\n");
					exit(1);
				}
				++y;
				break;

			default:
				fprintf(stderr, "Unknown option '%c'\n", argv[y][1]);
				exit(1);
			}
			break;

		default:
			/**
			 * Assume this is the start of the path & cmdline 
			 * for the other identd. argv[y] is the executable
			 * and the rest is the arguments.
			 * We set the other program's argv[0] ourselves.
			 */
			out->identd_path = argv[y];
			cmdarg_start = y + 1;
			out->num_cmdargs = argc - (cmdarg_start) + 1;
			out->identd_args = new char*[out->num_cmdargs + 1	 /* need one argument for argv[0] 
								        	  * to be given to spawned identd */ 
							              + 1];      /* and one for NULL */
			out->identd_args[0] = out->identd_path;           /* set argv[0] here */
			for (int q = 1; q - 1 < out->num_cmdargs; q++) {
				out->identd_args[q] = argv[cmdarg_start + q - 1];
			}
			out->identd_args[out->num_cmdargs] = NULL;

			// DONE
			return 0;
		}
	}                   
	return 0;
}

/**
 * Set up signal handlers.
 */
static void setup_signals() 
{
	struct sigaction sa;
	memset(&sa, 0, sizeof(sa));
	sa.sa_flags = 0;
	sa.sa_handler = SIG_IGN;
	sigaction(SIGPIPE, &sa, NULL);
	sa.sa_handler = &sighandler;
	sigaction(SIGCHLD, &sa, NULL);
	sigaction(SIGINT, &sa, NULL);
	sigaction(SIGTERM, &sa, NULL);
	sigaction(SIGHUP, &sa, NULL);
}

/**
 * Listen on a TCP port.
 */
static int listen(unsigned short port)
{
	struct sockaddr_in sin;
	int parm = 1;

	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_port = htons(port);

	int fd = socket(AF_INET, SOCK_STREAM, 0);
	setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const char * ) &parm, sizeof(int));    
	if (fd < 0) {
		return -1;
	}

	if (bind(fd, (struct sockaddr *) &sin, sizeof(sin)) < 0
			|| ::listen(fd, 5) < 0) {
		close(fd);
		return -1;
	}
	return fd;  
}

/**
 * Setup UNIX domain socket at requested path.
 *
 * Return:  fd on success
 *         -1 failure - check errno
 */
static int listen_unix(char const * path)
{
	struct sockaddr_un thing;
	size_t len;
	
	memset(&thing, 0, sizeof(thing));
	
	int fd = socket(PF_UNIX, SOCK_STREAM, 0);
	if (fd < 0) {
		return -1;
	}

	unlink(path);
	thing.sun_family = AF_UNIX;
	memcpy(thing.sun_path, path, sizeof(thing.sun_path) - 1);

	len = sizeof(thing.sun_family) + strlen(thing.sun_path);

	if (bind(fd, (struct sockaddr *) &thing, len) < 0
			|| ::listen(fd, 5) < 0) {
		close(fd);
		return -1;
	}
	fchmod(fd, 0777);
	return fd;
}


/**
 * Accept domain socket connection.
 * Does limits and such. 
 */
static int accept_unix(int fd)
{
	struct sockaddr_un thing;
	memset(&thing, 0, sizeof(thing));
	socklen_t x = sizeof(thing);
	int fd2 =  ::accept(fd, (struct sockaddr *) &thing, &x);
	if (fd2 < 0) {
		return -1;
	}
	return fd2;
}

/**
 * Accept TCP connection on IDENT port.
 */
static int accept(int fd)
{
	struct sockaddr_in sin;
	memset(&sin, 0, sizeof(sin));
	socklen_t len = sizeof(sin);
	int fd2 = ::accept(fd, (struct sockaddr *) &sin, &len);
	if (fd2 < 0) {
		syslog(LOG_ERR, "accept: %s", strerror(errno));
		return -1;
	}
	return fd2;
}

/**
 * Answer a fake ident request.
 * We need to read with MSG_PEEK, because the data must also be readable
 * to the other ident daemon if it needs to be spawned.
 */
static int service(int fd, ident_map_t& idents)
{
	char input_buff[256] = "";
	int r = recv(fd, input_buff, sizeof(input_buff) - 1, MSG_PEEK);
	if (r < 0) {
		syslog(LOG_INFO, "Connection closed: %s", strerror(errno));
		return -1;
	}
	input_buff[r] = 0;
	return reply(fd, input_buff, idents);
}

/**
 * Read the ident request from its input buffer and 
 * see if matches any of our fake ones, if not..
 * it's time to load the user's other identd.
 */
static int reply(int fd, const char * buff, ident_map_t& idents)
{
	/** 
	 * Parse the request.
	 * NOTE: We must have terminating \r\n or we drop it.
	 */
	if (strstr(buff, "\r\n")) {
		unsigned short p1 = 0, p2 = 0;
		char dummy;
		std::istringstream in(buff);

		in >> p1 >> dummy >> p2;

		if (!in.fail() && dummy == ',') {
			struct sockaddr_in sin;
			memset(&sin, 0, sizeof(sin));
			socklen_t len = sizeof(sin);
			getpeername(fd, (struct sockaddr *) &sin, &len);

			ident_map_t::iterator i = idents.find(p1);
			if (i != idents.end()) {
				const request& req = (*i).second;

				syslog(LOG_INFO, "Request from %s for: %d , %d ", inet_ntoa(sin.sin_addr), p1, p2);
				syslog(LOG_INFO, "(fake) reply: %d , %d : USERID : UNIX :%s", p1, p2, req.ident.c_str());
				fdprintf(fd, "%d , %d : USERID : UNIX :%s\r\n",
							p1, p2, req.ident.c_str());
				idents.erase(i);
				return 0;
			}
		}
	}

	// delegate to secondary daemon
	pid_t p = fork();
	switch (p) {
	case 0:
		/**
		 * This is the child: close out unneeded fds, 
		 * redirect stdin/err/out to socket.
		 */
		close(options.unix_fd);
		close(options.listen_fd);
		dup2(fd, 0);
		dup2(0, 1);
		dup2(0, 2);
		signal(SIGPIPE, SIG_DFL);
		signal(SIGTERM, SIG_DFL);
		signal(SIGINT, SIG_DFL);
		signal(SIGALRM, SIG_DFL);
		if (execv(options.identd_path, options.identd_args) < 0) {
			syslog(LOG_ERR, "Unable to spawn %s: %s", options.identd_path, strerror(errno));
		}
		// Unreached
		exit(1);
		return 1;

	case -1:
		syslog(LOG_ERR, "Can't spawn %s: fork: %s", options.identd_path, strerror(errno));
	default:
		break;
	}
	return 0;
}

/*
 * Start the server and enter the main loop.
 * Create fd_sets, select, poll ilist.
 * Blah blah.
 */
static int start_server()
{
	fd_set fds;
	struct timeval tv;

	ident_map_t			idents;
	connection_map_t		sockets;


	options.listen_fd = listen(113);
	if (options.listen_fd < 0) {
		perror("Unable to bind to port 113");
		return 1;
	}

	options.unix_fd = listen_unix(MDIDENTD_SOCK_PATH);
	if (options.unix_fd < 0) {
		perror(MDIDENTD_SOCK_PATH);
		return 1;
	}
	
	sockets[options.listen_fd] = connection_t(TCP_LISTEN, 0);
	sockets[options.unix_fd] =   connection_t(UNIX_LISTEN, 0);
	

	// already did this, but doesn't appear to work on some systems (?)
	chmod(MDIDENTD_SOCK_PATH, 0777);

	if (!options.foreground) {
		int i = daemon(true);
		switch (i) {
		case -1:
			perror("Unable to go into the background");
			return 1;
		case 0:
			break;
		default:
			return 1;
		}
	}
	if (setuid(options.uid) != 0) {
		syslog(LOG_ERR, "setuid(%d) failed: %s (but continuing anyway)", options.uid, strerror(errno));
	}

	/**
	 * Syslog setup 
	 */
	openlog("mdidentd", LOG_PID, LOG_DAEMON);
	syslog(LOG_INFO, "Version %s starting. Using %s as secondary ident daemon.", MDIDENTD_VERSION, options.identd_path);

	while (true) { 
		FD_ZERO(&fds);
		const prepare_fd_set& p = for_each(sockets.begin(), 
							sockets.end(), 
							prepare_fd_set(&fds));

		int highest = p.highest();
			
		// 
		// set the select() timeout -- only 
		int seconds = INT_MAX;
		if (sockets.size() > 2) {
			seconds = CONNECTION_TIMEOUT;
		}
		if (!idents.empty()) {
			seconds = std::min(seconds, FAKE_IDENT_LIFETIME);
		}
		
		tv.tv_sec  = seconds;
		tv.tv_usec = 0;

		int r = select(highest + 1, &fds, NULL, NULL, 
					seconds < INT_MAX ? &tv : (struct timeval *) NULL);

		current_time = time(NULL);

		switch (r) {
		case 0:
			remove_idle(sockets);
			remove_idle(idents);
			continue;
		case -1:
			if (errno != EINTR) {
				syslog(LOG_ERR, "error in select(): %s (exiting)", strerror(errno));
				return -1;
			}
			continue;
		}

		const handle_socket& result = for_each(sockets.begin(), 
								sockets.end(), 
								handle_socket(&fds, idents));

		for_each(result.to_add().begin(),
				result.to_add().end(),
				add_to_map(sockets));

		for_each(result.to_remove().begin(),
				result.to_remove().end(),
				remove_from_map(sockets));

		remove_idle(sockets);
		remove_idle(idents);
	}   
	return 1;
}

void sighandler(int sig)
{
	switch (sig) {
	case SIGCHLD:
		/* Collect exit status from exiting child */
		wait(&sig);
		break;

	case SIGTERM:
	case SIGINT:
		syslog(LOG_INFO, "Exiting on signal %d", sig);
		closelog();
		delete[] options.identd_args;
		options.identd_args = NULL;
		exit(0);   

	case SIGHUP:
		break;
	}
}

/**
 * fork() and go into the background.
 * Return pid of child to parent.
 * 0 to child.
 * -1 on error.
 */
static int daemon(bool cr)
{
	pid_t xx = fork();
	switch (xx) {
	case 0:
		/* Child */
		setsid();
		close(STDIN_FILENO);
		close(STDOUT_FILENO);
		close(STDERR_FILENO);
		if (cr) {
			chroot("/");
		}
		return 0;

	case -1:
		return -1;
	}
	return xx;
}

/**
 * Check /etc/passwd if this is a valid user. Perhaps there 
 * is an easier way to do this, but I don't know it.
 */    
static bool is_real_user(const char * user)
{
#ifdef HAVE_PWD_H
	if (getpwnam(user) != NULL) {
		return true;
	}
#endif
	if (!strcasecmp(user, "root")) {
		return true;
	}
	return false;
}


/**
 * Read data from a UNIX domain socket connection.
 *
 * Return: 	0  - success 
 * 		-1 - error
 *
 * NOTE: We do not close the file descriptor.
 */
int service_unix(int fd, ident_map_t& idents)
{
	char buff[128];
	int r = read(fd, buff, sizeof(buff) - 1);
	if (r < 0) {
		return -1;
	}
	buff[r] = 0;

	unsigned short port1, port2;
	char dummy;
	std::string ident;
	std::istringstream in(buff);

	in >> port1 >> dummy >> port2 >> ident;

	if (in.fail() || !port1 || !port2) {
		write(fd, "INVAL\r\n", 7);
	 	syslog(LOG_ERR, "Invalid request: %s", buff);
		return -1;
	}

	// check validity of ident
	if (!strcasecmp(ident.c_str(), "root") || 
			(options.no_real && is_real_user(ident.c_str()))) {
		write(fd, "AUTH\r\n", 6);
		syslog(LOG_ERR, "Unauthorized fake ident request (rejected): %d , %d : %s", port1, port2, ident.c_str());
		return -1;
	}

	// check for duplicate
	if (idents.find(port1) != idents.end()) {
		write(fd, "EXISTS\r\n", 8);
	 	syslog(LOG_ERR, "Attempted to add duplicate fake ident: %d , %d : %s", port1, port2, ident.c_str());
		return -1;
	}
	
	// "protocol" still defines a "ERROR" return

	struct request request;
	request.ident   = ident;
	request.created = current_time;
	request.peer_port = port2;

	idents[port1] = request;

	// success
	write(fd, "OK\r\n", 4);
	syslog(LOG_INFO, "Fake ident registered: %d , %d : %s", port1, port2, ident.c_str());
	return 0;
}

/**
 * Remove fake ident requests that have exceeded
 * the maximum lifetime.
 */
static void remove_idle(ident_map_t& idents)
{
	ident_map_t::iterator i = idents.begin(), 
				e = idents.end();

	while (i != e) {
		const ident_map_t::value_type& val = *i;
		time_t created = val.second.created;
		time_t age = current_time - created;
		if (age >= FAKE_IDENT_LIFETIME) {
			syslog(LOG_INFO, "Deleting expired (%d secs) fake ident request %d , %d : %s",
					FAKE_IDENT_LIFETIME, val.first, val.second.peer_port, val.second.ident.c_str());
			idents.erase(i++);
			continue;
		}
		++i;
	}
}

/**
 * Remove idling connections on both TCP port and
 * domain socket.
 */
static void remove_idle(connection_map_t& connections)
{
	connection_map_t::iterator i = connections.begin(),
					e = connections.end();

	while (i != e) {
		const connection_map_t::value_type& val = *i;
		const connection_t& connection = val.second;

		if (connection.first == TCP_LISTEN || 
				connection.first == UNIX_LISTEN) {
			++i;
			continue;
		}

		time_t age = current_time - connection.second;
		if (age >= CONNECTION_TIMEOUT) {
			::close(val.first);			       
			connections.erase(i++);
			continue;
		}
		++i;
	}
}

int fdprintf(int fd, const char *format, ...)
{
	static char __mbuffer[1024];
	__mbuffer[0] = 0;
	va_list ap;
	va_start(ap, format);
	int len = vsnprintf(__mbuffer, sizeof(__mbuffer), format, ap);
	va_end(ap);
	return (write(fd, __mbuffer, len));
}

/**
 * Entry point.
 */
int main(int argc, char **argv)
{
	if (parse_cmdline(argc, argv, &options) == 0) {
    		setup_signals();
		return start_server();
	}
	return 1;
}

