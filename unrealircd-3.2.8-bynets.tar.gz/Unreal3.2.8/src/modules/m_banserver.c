#include "config.h"
#include "struct.h"
#include "common.h"
#include "sys.h"
#include "numeric.h"
#include "msg.h"
#include "proto.h"
#include "channel.h"
#include <time.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <io.h>
#endif
#include <fcntl.h>
#include "h.h"
#ifdef STRIPBADWORDS
#include "badwords.h"
#endif
#ifdef _WIN32
#include "version.h"
#endif

char *extban_modes_conv_param (char *para);
int extban_modes_is_banned(aClient *sptr, aChannel *chptr, char *banin, int type);

ModuleHeader MOD_HEADER(m_banserver)
  = {
	"banserver",	/* Name of module */
	"1.0.0",  /* Version */
	"Extban ~s", /* Short description of module */
	"3.2-b8-1",
	NULL,
    };

/* This is called on module init, before Server Ready */
DLLFUNC int MOD_INIT(m_banserver)(ModuleInfo *modinfo)
{
	ExtbanInfo req;

	memset(&req, 0, sizeof(ExtbanInfo));
	req.flag = 's';
	req.conv_param = extban_modes_conv_param;
	req.is_banned = extban_modes_is_banned;
	ExtbanAdd(modinfo->handle, req);
//	ircd_log(LOG_ERROR, "debug: mod_init called");
	
	ModuleSetOptions(modinfo->handle, MOD_OPT_PERM);
	return MOD_SUCCESS;
}

/* Is first run when server is 100% ready */
DLLFUNC int MOD_LOAD(m_banserver)(int module_load)
{
	return MOD_SUCCESS;
}

/* Called when module is unloaded */
DLLFUNC int MOD_UNLOAD(m_banserver)(int module_unload)
{
	return MOD_FAILED;
}

char *extban_modes_conv_param (char *para)
{
	char *mask, *ret = NULL;
	static char retbuf[HOSTLEN + 32];
	char tmpbuf[HOSTLEN + 32];

	strncpyzt(tmpbuf, para, sizeof(retbuf));
	mask = tmpbuf + 3;
	
	if (!strchr(mask, '.'))
		return NULL;
	
	ircsprintf(retbuf, "~s:%s", mask);
	return retbuf;

}

int extban_modes_is_banned(aClient *sptr, aChannel *chptr, char *banin, int type)
{
	char *ban = banin+3;
	if (!match(ban, sptr->srvptr->name))
		return 1;
	return 0;

}
