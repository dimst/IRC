/*
 * Unreal Internet Relay Chat Daemon, src/charsys.c
 * (C) Copyright 2005 Bram Matthys and The UnrealIRCd Team.
 *
 * Character system: This subsystem deals with finding out wheter a
 * character should be allowed or not in nicks (nicks only for now).
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 1, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include "config.h"
#include "struct.h"
#include "common.h"
#include "sys.h"
#include "macros.h"
#include "numeric.h"
#include "msg.h"
#include "channel.h"
#include <time.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <io.h>
#endif
#include <fcntl.h>
#include "h.h"
#include "proto.h"
#ifdef STRIPBADWORDS
#include "badwords.h"
#endif

#ifdef _WIN32
#include "version.h"
#endif

/* NOTE: it is guaranteed that char is unsigned by compiling options
 *       (-funsigned-char @ gcc, /J @ MSVC)
 * NOTE2: Original credit for supplying the correct chinese
 *        coderanges goes to: RexHsu, Mr.WebBar and Xuefer
 */

/** Our multibyte structure */
typedef struct _mblist MBList;
struct _mblist
{
	MBList *next;
	char s1, e1, s2, e2;
};
MBList *mblist = NULL, *mblist_tail = NULL;

/* Use this to prevent mixing of certain combinations
 * (such as GBK & high-ascii, etc)
 */
static int langav;
char langsinuse[4096];

/* bitmasks: */
#define LANGAV_ASCII		0x0001 /* 8 bit ascii */
#define LANGAV_LATIN1		0x0002 /* latin1 (western europe) */
#define LANGAV_LATIN2		0x0004 /* latin2 (eastern europe, eg: polish) */
#define LANGAV_ISO8859_7	0x0008 /* greek */
#define LANGAV_ISO8859_8I	0x0010 /* hebrew */
#define LANGAV_ISO8859_9	0x0020 /* turkish */
#define LANGAV_W1250		0x0040 /* windows-1250 (eg: polish-w1250) */
#define LANGAV_W1251		0x0080 /* windows-1251 (eg: russian) */
#define LANGAV_LATIN2W1250	0x0100 /* Compatible with both latin2 AND windows-1250 (eg: hungarian) */
#define LANGAV_GBK			0x1000 /* (Chinese) GBK encoding */

typedef struct _langlist LangList;
struct _langlist
{
	char *directive;
	char *code;
	int setflags;
};

/* MUST be alphabetized (first column) */
static LangList langlist[] = {
	{ "belarussian-w1251", "blr", LANGAV_ASCII|LANGAV_W1251 },
	{ "catalan",      "cat", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "chinese",      "chi-j,chi-s,chi-t", LANGAV_GBK },
	{ "chinese-ja",   "chi-j", LANGAV_GBK },
	{ "chinese-simp", "chi-s", LANGAV_GBK },
	{ "chinese-trad", "chi-t", LANGAV_GBK },
	{ "czech",        "cze-m", LANGAV_ASCII|LANGAV_W1250 },
	{ "danish",       "dan", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "dutch",        "dut", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "french",       "fre", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "gbk",          "chi-s,chi-t,chi-j", LANGAV_GBK },
	{ "german",       "ger", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "greek",        "gre", LANGAV_ASCII|LANGAV_ISO8859_7 },
	{ "hebrew",       "heb", LANGAV_ASCII|LANGAV_ISO8859_8I },
	{ "hungarian",    "hun", LANGAV_ASCII|LANGAV_LATIN2W1250 },
	{ "icelandic",    "ice", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "italian",      "ita", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "latin1",       "cat,dut,fre,ger,ita,spa,swe", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "latin2",       "hun,pol,rum", LANGAV_ASCII|LANGAV_LATIN2 },
	{ "polish",       "pol", LANGAV_ASCII|LANGAV_LATIN2 },
	{ "polish-w1250", "pol-m", LANGAV_ASCII|LANGAV_W1250 },
	{ "romanian",     "rum", LANGAV_ASCII|LANGAV_LATIN2W1250 },
	{ "russian-w1251","rus", LANGAV_ASCII|LANGAV_W1251 },
	{ "slovak",       "slo-m", LANGAV_ASCII|LANGAV_W1250 },
	{ "spanish",      "spa", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "swedish",      "swe", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "swiss-german", "swg", LANGAV_ASCII|LANGAV_LATIN1 },
	{ "turkish",      "tur", LANGAV_ASCII|LANGAV_ISO8859_9 },
	{ "ukrainian-w1251", "ukr", LANGAV_ASCII|LANGAV_W1251 },
	{ "windows-1250", "cze-m,pol-m,rum,slo-m,hun",  LANGAV_ASCII|LANGAV_W1250 },
	{ "windows-1251", "rus,ukr,blr", LANGAV_ASCII|LANGAV_W1251 },
	{ NULL, NULL, 0 }
};

/* For temporary use during config_run */
typedef struct _ilanglist ILangList;
struct _ilanglist
{
	ILangList *prev, *next;
	char *name;
};
ILangList *ilanglist = NULL;

static int do_nick_name_multibyte(char *nick);
static int do_nick_name_standard(char *nick);

/* These characters are ALWAYS disallowed... from remote, in
 * multibyte, etc.. even though this might mean a certain
 * (legit) character cannot be used (eg: in chinese GBK).
 * - no breaking space
 * - ! (nick!user seperator)
 * - prefix chars: +, %, @, &, ~
 * - channel chars: #
 * - scary chars: $, :, ', ", ?, *, ',', '.'
 * NOTE: the caller should also check for ascii <= 32.
 * [CHANGING THIS WILL CAUSE SECURITY/SYNCH PROBLEMS AND WILL
 *  VIOLATE YOUR ""RIGHT"" ON SUPPORT IMMEDIATELY]
 */
const char *illegalnickchars = "\xA0!+%@&~#$:'\"?*,.";

/** Set specified attribute for all characters in the specified string. */
void charsys_addattribute(char *s, unsigned short a)
{
	for (; *s; s++)
	{
		char_atribs[(unsigned int)*s] |= a;
	}
}

extern void charsys_addallowed(char *s)
{
	charsys_addattribute(s, ALLOWN);
} 

/** Called on boot and just before config run */
void charsys_reset(void)
{
int i;
MBList *m, *m_next;

	/* First, reset everything */
	for (i=0; i < 256; i++)
		char_atribs[i] &= ~(ALLOWN|HICHAR);
	for (m=mblist; m; m=m_next)
	{
		m_next = m->next;
		MyFree(m);
	}
	mblist=mblist_tail=NULL;
	/* Then add the default which will always be allowed */
	charsys_addattribute("0123456789-ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}",ALLOWN);
	charsys_addattribute("\x01\x02\x03\x04\x05\x06\x07\x08\x09\x0a\x0b\x0c\x0d\x0e\x0f"\
			     "\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f"\
			     "\x20\x21\x22\x23\x24\x25\x26\x27\x28\x29\x2a\x2b\x2c\x2d\x2e\x2f"\
			     "\x30\x31\x32\x33\x34\x35\x36\x37\x38\x39\x3a\x3b\x3c\x3d\x3e\x3f"\
			     "@ABCDEFGHIJKLMNOPQRSTUVWYZ",HICHAR);
	langav = 0;
	langsinuse[0] = '\0';
#ifdef DEBUGMODE
	if (ilanglist)
		abort();
#endif
}

void charsys_reset_pretest(void)
{
	langav = 0;
}

static inline void ilang_swap(ILangList *one, ILangList *two)
{
char *tmp = one->name;
	one->name = two->name;
	two->name = tmp;
}

static void ilang_sort(void)
{
ILangList *outer, *inner;
char *tmp;

	/* Selection sort -- perhaps optimize to qsort/whatever if
     * possible? ;)
     */
	for (outer=ilanglist; outer; outer=outer->next)
	{
		for (inner=outer->next; inner; inner=inner->next)
		{
			if (strcmp(outer->name, inner->name) > 0)
				ilang_swap(outer, inner);
		}
	}
}

void charsys_finish(void)
{
ILangList *e, *e_next;

	/* Sort alphabetically */
	ilang_sort();

	/* [note: this can be optimized] */
	langsinuse[0] = '\0';
	for (e=ilanglist; e; e=e->next)
	{
		strlcat(langsinuse, e->name, sizeof(langsinuse));
		if (e->next)
			strlcat(langsinuse, ",", sizeof(langsinuse));
	}
	
	/* Free everything */
	for (e=ilanglist; e; e=e_next)
	{
		e_next=e->next;
		MyFree(e->name);
		MyFree(e);
	}
	ilanglist = NULL;
#ifdef DEBUGMODE
	ircd_log(LOG_ERROR, "[Debug] langsinuse: '%s'", langsinuse);
	if (strlen(langsinuse) > 490)
		abort();
#endif
}

/** Add a character range to the multibyte list.
 * @param s1 Start of highest byte
 * @param e1 End of highest byte
 * @param s2 Start of lowest byte
 * @param e2 End of lowest byte
 * @example charsys_addmultibyterange(0xaa, 0xbb, 0x00, 0xff) for 0xaa00-0xbbff
 */
void charsys_addmultibyterange(char s1, char e1, char s2, char e2)
{
MBList *m = MyMallocEx(sizeof(MBList));

	m->s1 = s1;
	m->e1 = e1;
	m->s2 = s2;
	m->e2 = e2;

	if (mblist_tail)
		mblist_tail->next = m;
	else
		mblist = m;
	mblist_tail = m;
}

/** Loads allowed characters and case conversion tables from specified file */

int charsys_htoi(char *t)
{
int ret=0;
while(*t)
 {
 int x=-1;
 if((*t>='0')&&(*t<='9'))
  {
  x=(*t-'0');
  }else if((*t>='a')&&(*t<='f'))
  {
  x=10+(*t-'a');
  }else if((*t>='A')&&(*t<='F'))
  {
  x=10+(*t-'A');
  }
 if (x!=-1)
  {
  ret*=16;
  ret+=x;
  }else break;
 t++;
 }
return ret;
}

int charsys_loadchartable(FILE *fd, char *chartable, unsigned int maxindex)
{
#define LINE_BUFFER_LENGTH	(0x10000)

	char *buf=(char *)malloc(LINE_BUFFER_LENGTH);
	unsigned int i=0;
	int fail=0;
	memset(buf, 0, LINE_BUFFER_LENGTH);
	fgets(buf, LINE_BUFFER_LENGTH-0x10, fd);
	if (buf[0]&&(buf[strlen(buf)-1]=='\n'))buf[strlen(buf)-1] = 0;

	if (buf[0]=='.') /* simple plain-text string after dot */
	{
		i=strlen(buf+1);
		if (i>(maxindex+1)) i=maxindex+1;
		memcpy(chartable,buf+1,i);
	}else
	{
	char *p=buf;
	for (;;)
	{
		char *n;
		if (*p!='\'') /* decimal or hexadecimal char code */
		{
			if (*p=='0') p++;
			if (*p=='x') /* hex form */
			{
				p++;
				if(!*p){fail = 1; break;}
				chartable[i] = (char)(unsigned char)charsys_htoi(p);
			}else /* decimal form */
			{
				chartable[i] = (char)(unsigned char)atoi(p);
			}
			n=p+1;
		}else /* plain-text char between '' */
		{
			if (*(p+1)=='\\')
			{
				chartable[i] = *(p+2);
				n=p+4;
			}else
			{
				chartable[i] = *(p+1);
				n=p+3;
			}			
		}
		while (*n&&(*n!=',')&&(*n!=' ')) n++;
		if(*n==' ')
		{
			while (*n&&(*n==' ')) n++;
		}
		if (*n==',') n++;
		i++;
		if ((!*n)||(i>maxindex))break;
		
		while (*n&&(*n==' ')) n++;
		if (!*n) break;
		p = n;

	}
	}
	                                          
	free(buf);
	return fail;
}

int charsys_loadchartables(char *fname)
{
	int fail = 2,i;
	FILE *fd = fopen(fname, "r");
	if (fd)
	{
		char tmp_tbl[256] = {0};
		/* additional allowed charachters table */
		fail = 	charsys_loadchartable(fd, tmp_tbl, sizeof(tmp_tbl)-1);
		if (!fail)
		{
			charsys_addattribute(tmp_tbl,ALLOWN);

			/* multibyte allowed charachters ranges */
			memset(tmp_tbl, 0, sizeof(tmp_tbl));
			fail = 	charsys_loadchartable(fd, tmp_tbl, sizeof(tmp_tbl)-1);
		}
			
		if (!fail)
		{
			for(i=0;tmp_tbl[i];i+=4)
			{
				charsys_addmultibyterange(tmp_tbl[i], tmp_tbl[i+1], tmp_tbl[i+2], tmp_tbl[i+3]);
			}

			/* additional high-case charachters table */
			memset(tmp_tbl, 0, sizeof(tmp_tbl));
			fail = 	charsys_loadchartable(fd, tmp_tbl, sizeof(tmp_tbl)-1); /* multibyte ranges */
			if (!fail) charsys_addattribute(tmp_tbl,HICHAR);
		}

#ifndef USE_LOCALE
		/* case conversion tables */
		if (!fail)
			fail=charsys_loadchartable(fd, tolowertab, 255);
		if (!fail)
			fail=charsys_loadchartable(fd, touppertab, 255);
#endif
		fclose(fd);

		if (fail) 
			config_error("INTERNAL ERROR: charsys_loadchartables() called for illegal file: %s", fname);
	}else
		config_error("INTERNAL ERROR: charsys_loadchartables() called for missing file: %s", fname);

#ifdef DEBUGMODE
	if (fail) abort();
#endif	
	return fail;
}

int do_nick_name(char *nick)
{
	if (mblist)
		return do_nick_name_multibyte(nick);
	else
		return do_nick_name_standard(nick);
}

static int do_nick_name_standard(char *nick)
{
int len;
char *ch;

	if ((*nick == '-') || isdigit(*nick))
		return 0;

	for (ch=nick,len=0; *ch && len <= NICKLEN; ch++, len++)
		if (!isvalid(*ch))
			return 0; /* reject the full nick */
	*ch = '\0';
	return len;
}

static int isvalidmbyte(unsigned char c1, unsigned char c2)
{
MBList *m;

	for (m=mblist; m; m=m->next)
	{
		if ((c1 >= m->s1) && (c1 <= m->e1) &&
		    (c2 >= m->s2) && (c2 <= m->e2))
		    return 1;
	}
	return 0;
}

/* hmmm.. there must be some problems with multibyte &
 * other high ascii characters I think (such as german etc).
 * Not sure if this can be solved? I don't think so... -- Syzop.
 */
static int do_nick_name_multibyte(char *nick)
{
int len;
char *ch;
MBList *m;
int firstmbchar = 0;

	if ((*nick == '-') || isdigit(*nick))
		return 0;

	for (ch=nick,len=0; *ch && len <= NICKLEN; ch++, len++)
	{
		/* Some characters are ALWAYS illegal, so they have to be disallowed here */
		if ((*ch <= 32) || strchr(illegalnickchars, *ch))
			return 0;
		if (firstmbchar)
		{
			if (!isvalidmbyte(ch[-1], *ch))
				return 0;
			firstmbchar = 0;
		} else if ((*ch) & 0x80)
			firstmbchar = 1;
		else if (!isvalid(*ch))
			return 0;
	}
	if (firstmbchar)
		ch--;
	*ch = '\0';
	return len;
}

/** Does some very basic checking on remote nickname.
 * It's only purpose is not to cause the whole network
 * to fall down in pieces, that's all. Display problems
 * are not really handled here. They are assumed to have been
 * checked by PROTOCTL NICKCHARS= -- Syzop.
 */
int do_remote_nick_name(char *nick)
{
char *c;

	for (c=nick; *c; c++)
		if ((*c <= 32) || strchr(illegalnickchars, *c))
			return 0;

	return (c - nick);
}

/** Check if the specified charsets during the TESTING phase can be
 * premitted without getting into problems.
 * RETURNS: -1 in case of failure, 1 if ok
 */
int charsys_postconftest(void)
{
int x=0;
	if ((langav & LANGAV_ASCII) && (langav & LANGAV_GBK))
	{
		config_error("ERROR: set::allowed-nickchars specifies incorrect combination "
		             "of languages: high-ascii languages (such as german, french, etc) "
		             "cannot be mixed with chinese/..");
		return -1;
	}
	if (langav & LANGAV_LATIN1)
		x++;
	if (langav & LANGAV_LATIN2)
		x++;
	if (langav & LANGAV_ISO8859_7)
		x++;
	if (langav & LANGAV_ISO8859_9)
		x++;
	if (langav & LANGAV_W1250)
		x++;
	if (langav & LANGAV_W1251)
		x++;
	if ((langav & LANGAV_LATIN2W1250) && !(langav & LANGAV_LATIN2) && !(langav & LANGAV_W1250))
	    x++;
	if (x > 1)
	{
		config_status("WARNING: set::allowed-nickchars: "
		            "Mixing of charsets (eg: latin1+latin2) can cause display problems");
	}
	return 1;
}

static LangList *charsys_find_language(char *name)
{
int start = 0;
int stop = ARRAY_SIZEOF(langlist)-1;
int mid;

	while (start <= stop)
	{
		mid = (start+stop)/2;
		if (!langlist[mid].directive || smycmp(name, langlist[mid].directive) < 0)
			stop = mid-1;
		else if (strcmp(name, langlist[mid].directive) == 0)
			return &langlist[mid];
		else
			start = mid+1;
	}
	return NULL;
}

/** Check if language is available. */
int charsys_test_language(char *name)
{
LangList *l = charsys_find_language(name);

	if (l)
	{
		langav |= l->setflags;
		return 1;
	}
	if (!strcmp(name, "euro-west"))
	{
		config_error("set::allowed-nickchars: ERROR: 'euro-west' got renamed to 'latin1'");
		return 0;
	}
	return 0;
}

static void charsys_doadd_language(char *name)
{
LangList *l;
ILangList *li;
int found;
char tmp[512], *lang, *p;

	l = charsys_find_language(name);
	if (!l)
	{
#ifdef DEBUGMODE
		abort();
#endif
		return;
	}

	strlcpy(tmp, l->code, sizeof(tmp));
	for (lang = strtoken(&p, tmp, ","); lang; lang = strtoken(&p, NULL, ","))
	{
		/* Check if present... */
		found=0;
		for (li=ilanglist; li; li=li->next)
			if (!strcmp(li->name, lang))
			{
				found = 1;
				break;
			}
		if (!found)
		{
			/* Add... */
			li = MyMallocEx(sizeof(ILangList));
			li->name = strdup(lang);
			AddListItem(li, ilanglist);
		}
	}
}

void charsys_add_language(char *name)
{
	char chartable_file[256]; 
	/* Add our language to our list */
	charsys_doadd_language(name);

	/* INDIVIDUAL CHARSETS */
	sprintf(chartable_file,"locales/%s",name);
	charsys_loadchartables(chartable_file);
} 

int g_sim(char gl_c) {
char *gl_s = "0123456789[]-_{}|`^\0";
	for(;*gl_s;gl_s++)
		if (gl_c == *gl_s) return 1;
	return 0; 

}
