Here you can find locales configuration files.

Each file consists of five lines:
1: List of additional allowed charachters

2: List of additional allowed multibyte charachters ranges. In form: Sa_1 Ea_1 Sa_2 Ea_2 Sb_1 Eb_1 Sb_2 Eb_2... Total numbers count should be dividend of 4
   Sx_1 Start of highest byte
   Ex_1 End of highest byte
   Sx_2 Start of lowest byte
   Ex_2 End of lowest byte

3: List of additional charachters that should be treated as upper-case

4: 255 charachters table - to-lower case conversion table. Can be usefull for example for comparing nicknames that contains similar-looking charachters with different codes.

5: 255 charachters table - to-upper case conversion table. Can be usefull for example for comparing nicknames that contains similar-looking charachters with different codes.

Each line can be list of charachters or decimal/hexadecimal codes divided by spaces or commas in form like:
x01 x02 x03...
or
'a', 'b', 'c'
or combined:
x01, \x02 'a', 'b', \10, 'c',

It is also possible to write plain-text line of charachters. In this case it should begin by . (dot) charachter. For example:
.abcdefABCDEF23432*&^*
In this case every charachter of line except first dot specifies one charachter-code for table
