#include <znc/version.h>
const char* ZNC_VERSION_EXTRA = VERSION_EXTRA "";
