/* POSIX emulation layer for Windows.
 *
 * (C) 2008-2017 Anope Team
 * Contact us at team@anope.org
 *
 * Please read COPYING and README for further details.
 */

extern int pipe(int fds[2]);
