// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__734081F9_EEA5_43E9_94FC_FF68120321D4__INCLUDED_)
#define AFX_STDAFX_H__734081F9_EEA5_43E9_94FC_FF68120321D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern "C" {
	#include "../md5-c/global.h"
	#include "../md5-c/md5.h"
}

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__734081F9_EEA5_43E9_94FC_FF68120321D4__INCLUDED_)
