/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Channel activity for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Total");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Today");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("This Week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("This Month");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Nickname");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Letters");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Words");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Lines");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Actions");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Smileys");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Kicks");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Modes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Topics");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_activity.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_clients.tpl */
gettext("Current Client Statistics for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_clients.tpl */
gettext("Client");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_clients.tpl */
gettext("Count");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_clients.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_countries.tpl */
gettext("Current Country Statistics for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_countries.tpl */
gettext("Country");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_countries.tpl */
gettext("Count");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_countries.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Global channel activity");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Total");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Today");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("This Week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("This Month");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Channel");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Letters");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Words");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Lines");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Actions");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Smileys");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Kicks");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Modes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Topics");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_globalactivity.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_history.tpl */
gettext("Channel history");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_list.tpl */
gettext("Channel list");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_list.tpl */
gettext("Channel");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_list.tpl */
gettext("Current users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_list.tpl */
gettext("Max users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_list.tpl */
gettext("Modes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_list.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_main.tpl */
gettext("Channels");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_main.tpl */
gettext("Channels");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_main.tpl */
gettext("Activity");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_main.tpl */
gettext("History");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_profile.tpl */
gettext("Channel");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_profile.tpl */
gettext("Status");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_profile.tpl */
gettext("Countries");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_profile.tpl */
gettext("Clients");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_profile.tpl */
gettext("Activity");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Channel info for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Topic set by");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Current users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("User peak");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Modes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Join this channel");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Standard connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("IRC standard connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Secure connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("IRC secure connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Webchat");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Webchat");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Users currently in channel");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Nickname");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Modes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//channel_status.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//error.tpl */
gettext("Error");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_clients.tpl */
gettext("Current Client Statistics");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_clients.tpl */
gettext("Client");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_clients.tpl */
gettext("Count");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_clients.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_countries.tpl */
gettext("Current Country Statistics");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_countries.tpl */
gettext("Country");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_countries.tpl */
gettext("Count");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_countries.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_history.tpl */
gettext("Network Usage History");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("Network");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("Welcome");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("Status");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("Countries");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("Clients");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("Operators");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("History");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("Netsplit Graphs");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_main.tpl */
gettext("Mibbit Graphs");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_mibbit.tpl */
gettext("Mibbit Graphs");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_mibbit.tpl */
gettext("Day");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_mibbit.tpl */
gettext("Week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_mibbit.tpl */
gettext("Month");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_mibbit.tpl */
gettext("Year");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_mibbit.tpl */
gettext("More on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_netsplit.tpl */
gettext("Netsplit.de Graphs");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_netsplit.tpl */
gettext("Last week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_netsplit.tpl */
gettext("Last year");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_netsplit.tpl */
gettext("Complete history");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_netsplit.tpl */
gettext("Complete measured history about users and channels");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_netsplit.tpl */
gettext("More on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_operators.tpl */
gettext("Operators currently online");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_operators.tpl */
gettext("Nickname");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_operators.tpl */
gettext("Server");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_operators.tpl */
gettext("Online since");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_operators.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Live Network Status");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Network Status");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Servers");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Channels");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Operators");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Current");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Current");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Current");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Current");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Peak");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Peak");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Peak");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Peak");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Current 10 Biggest Chans");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Top 10 Channels Today");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Top 10 Users Today");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Channel");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Channel");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Lines");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("User");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Lines");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//network_status.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_clients.tpl */
gettext("Current Client Statistics for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_clients.tpl */
gettext("Client");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_clients.tpl */
gettext("Count");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_clients.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_countries.tpl */
gettext("Current Country Statistics for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_countries.tpl */
gettext("Country");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_countries.tpl */
gettext("Count");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_countries.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_history.tpl */
gettext("Server history");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Server info for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Description");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Country");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Online");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Version");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Uptime");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Last split");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Last ping");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Highest ping");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Current users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Max users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Current opers");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Max opers");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_info.tpl */
gettext("Message of the day");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Server list");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Connect to our network round robin");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Standard connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Secure connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Status");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Server");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Description");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Operators");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_list.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_main.tpl */
gettext("Servers");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_main.tpl */
gettext("Servers");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_main.tpl */
gettext("History");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_profile.tpl */
gettext("Server");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_profile.tpl */
gettext("Info");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_profile.tpl */
gettext("Countries");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//server_profile.tpl */
gettext("Clients");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("User activity for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Total");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Today");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("This Week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("This Month");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Global");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Overview");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Type");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Letters");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Words");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Lines");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Actions");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Smileys");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Kicks");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Modes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Topics");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_activity.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Global user activity");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Total");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Today");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("This Week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("This Month");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Nickname");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Letters");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Words");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Lines");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Actions");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Smileys");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Kicks");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Modes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Topics");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_globalactivity.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_history.tpl */
gettext("User history");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("User info for %1");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Nickname");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Aliases");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Stats Username");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Real name");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Hostname");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Server");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Connecting from");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Client");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Status");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_info.tpl */
gettext("Information for this user currently unavailable");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_main.tpl */
gettext("Users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_main.tpl */
gettext("Activity");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_main.tpl */
gettext("History");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_profile.tpl */
gettext("User");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_profile.tpl */
gettext("Info");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//user_profile.tpl */
gettext("Activity");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Network");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Servers");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Channels");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Loading");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Language");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Standard connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("IRC standard connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Secure connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("IRC secure connection");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Webchat");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Webchat");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("yyyy-MM-dd HH:mm:ss");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("%Y-%m-%d %H:%M:%S");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Unknown");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Away as");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Online as");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Online");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Offline");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Bot");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Service");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Available for help");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("join");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("days");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("hours");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("minutes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("All");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("1d");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("1w");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("1m");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("3m");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("6m");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("1y");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Unable to load contents");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Message");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Connected since");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Last quit");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Users online");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Servers online");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Servers");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Channels");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Users");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Operators");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Total");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Today");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("This Week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("This Month");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Yes");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("No");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Never");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("on");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("MOTD not available for this server");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Failed");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Close");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Status");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Country Statistics");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Client Statistics");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("none");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Relation of users and channels during the last week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Relation of users and channels during the last year");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Channels during the last week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Channels during the last year");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Servers during the last week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Servers during the last year");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Day");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Week");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Month");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Year");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Processing...");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Please wait - loading...");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Show _MENU_ entries");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("No matching records found");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("No data available in table");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Showing _START_ to _END_ of _TOTAL_ entries");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Showing 0 to 0 of 0 entries");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("(filtered from _MAX_ total entries)");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Search");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("click/return to sort ascending");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("click/return to sort descending");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("First");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Previous");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Next");

/* C:\xampp\htdocs\magirc\locale/../theme/default/tpl//_main.tpl */
gettext("Last");

