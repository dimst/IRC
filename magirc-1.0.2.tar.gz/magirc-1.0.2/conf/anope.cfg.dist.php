<?php
// Configure and rename this file to anope.cfg.php

$db = array(
	'username' => 'anope',
	'password' => 'anope',
	'database' => 'anope',
	'prefix' => 'anope_',
	'hostname' => 'localhost',
	'port' => 3306,
	'ssl' => false,
	'ssl_key' => null,
	'ssl_cert' => null,
	'ssl_ca' => null
);
