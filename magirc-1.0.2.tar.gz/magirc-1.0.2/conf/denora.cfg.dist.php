<?php
// Configure and rename this file to denora.cfg.php

$db = array(
	'username' => 'denora',
	'password' => 'denora',
	'database' => 'denora',
	'hostname' => 'localhost',
	'port'  => 3306,
	'ssl'  => false,
	'ssl_key' => null,
	'ssl_cert' => null,
	'ssl_ca' => null,
	'current' => 'current',
	'maxvalues' => 'maxvalues',
	'user' => 'user',
	'server' => 'server',
	'stats' => 'stats',
	'channelstats' => 'channelstats',
	'serverstats' => 'serverstats',
	'ustats' => 'ustats',
	'cstats' => 'cstats',
	'chan' => 'chan',
	'ison' => 'ison',
	'aliases' => 'aliases'
);
