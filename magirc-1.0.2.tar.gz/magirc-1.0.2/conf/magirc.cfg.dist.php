<?php
// Configure and rename this file to magirc.cfg.php

$db = array(
	'username'	=> 'magirc',
	'password'	=> 'magirc',
	'database'	=> 'magirc',
	'hostname'	=> 'localhost',
	'port'		=> 3306,
	'ssl'		=> false,
	'ssl_key'	=> null,
	'ssl_cert'	=> null,
	'ssl_ca'	=> null
);
