<?php

class Server extends ServerBase {
	
	function __construct() {
		parent::__construct();
		
	}
}
