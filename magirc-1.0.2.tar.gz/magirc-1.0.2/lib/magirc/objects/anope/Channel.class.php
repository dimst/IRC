<?php

class Channel extends ChannelBase {
	
	function __construct() {
		parent::__construct();
		
	}

}
