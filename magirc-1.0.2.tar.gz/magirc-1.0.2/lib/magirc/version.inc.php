<?php

define('VERSION_MAJOR', '1');
define('VERSION_MINOR', '0');
define('VERSION_REVISION', '2');
define('VERSION_EXTRA', '');

define('VERSION_FULL', sprintf('%s.%s.%s%s', VERSION_MAJOR, VERSION_MINOR, VERSION_REVISION, VERSION_EXTRA));

define('DB_VERSION', 16);
