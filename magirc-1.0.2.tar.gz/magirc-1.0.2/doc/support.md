Support Resources
=================

News & Updates
--------------
Find the latest news on the project on our [Homepage](http://www.magirc.org/)

Also visit our project on [github](https://github.com/h9k/magirc)

Need help?
----------
Chances are you will find what you are looking for in our [Wiki](https://github.com/h9k/magirc/wiki)

Not really? Then try our [Support Forum](http://forum.anope.org/)

Or if you prefer, come by and have a chat on our [IRC channel](irc://irc.anope.org:6667/magirc) with your IRC client or via [Mibbit](http://widget.mibbit.com/?settings=f7ba8c023c9faf063a67c101c76dfd48&server=irc.anope.org&channel=%23denora&promptPass=true)

Problems? Comments? Suggestions?
--------------------------------
You think you discovered a bug? Do you have an idea to improve MagIRC?

Feel free to open up a ticket in our [Issue Tracker](https://github.com/h9k/magirc/issues)