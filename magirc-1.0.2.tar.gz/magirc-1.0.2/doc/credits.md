MagIRC Credits
==============
MagIRC originates from the phpDenora project, but is a complete rewrite.

Used software
-------------
MagIRC uses the following open source products developed by third parties:

* [Slim Framework](http://www.slimframework.com)
* [Smarty Template Engine](http://www.smarty.net)
* [PHP-gettext](https://launchpad.net/php-gettext/)
* [jQuery](http://www.jquery.com)
* [jQuery-UI](http://www.jqueryui.com)
* [DataTables](http://www.datatables.net)
* [Highcharts and Highstock](http://www.highcharts.com)
* [jQuery dateFormat](https://github.com/phstc/jquery-dateFormat)
* [CKEditor](http://www.ckeditor.com)
* [Smarty JSMin Plugin](http://www.nsmith.me.uk/jsmin-smarty-wrapper/)
* [Smarty Markdown Plugin](http://michelf.com/projects/php-markdown/)
